import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { PublicLayout } from "@/components/PublicLayout";
import { CookieBanner } from "@/components/CookieBanner";
import { MaintenanceGate } from "@/components/MaintenanceGate";
import Home from "./pages/Home";
import Sobre from "./pages/Sobre";
import Servicos from "./pages/Servicos";
import Galeria from "./pages/Galeria";
import Produtos from "./pages/Produtos";
import Orcamento from "./pages/Orcamento";
import Contacto from "./pages/Contacto";
import Privacidade from "./pages/Privacidade";
import Cookies from "./pages/Cookies";
import Termos from "./pages/Termos";
import Blog from "./pages/Blog";
import FAQ from "./pages/FAQ";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import BlogPost from "./pages/BlogPost";

import { ClientLayout } from "./components/cliente/ClientLayout";
import ClienteDashboard from "./pages/cliente/ClienteDashboard";
import ClienteEventos from "./pages/cliente/ClienteEventos";
import ClienteOrcamentos from "./pages/cliente/ClienteOrcamentos";
import ClienteEventosConfirmados from "./pages/cliente/ClienteEventosConfirmados";
import Questionario from "./pages/cliente/Questionario";
import AlterarPassword from "./pages/cliente/AlterarPassword";
import Avaliacao from "./pages/cliente/Avaliacao";

import { AdminLayout } from "./components/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminPedidos from "./pages/admin/AdminPedidos";
import AdminEventos from "./pages/admin/AdminEventos";
import AdminNotasEventos from "./pages/admin/AdminNotasEventos";
import AdminCalendario from "./pages/admin/AdminCalendario";
import AdminMateriais from "./pages/admin/AdminMateriais";
import AdminEntregas from "./pages/admin/AdminEntregas";
import AdminFinanceiro from "./pages/admin/AdminFinanceiro";
import AdminRelatorio from "./pages/admin/AdminRelatorio";
import AdminQuestionarios from "./pages/admin/AdminQuestionarios";
import AdminUtilizadores from "./pages/admin/AdminUtilizadores";
import AdminDefinicoes from "./pages/admin/AdminDefinicoes";
import { AdminMensagens } from "./pages/admin/AdminMensagens";
import { AdminGaleria } from "./pages/admin/AdminGaleria";
import { AdminBlog } from "./pages/admin/AdminBlog";
import AdminFAQ from "./pages/admin/AdminFAQ";
import AdminPhoneMapping from "./pages/admin/AdminPhoneMapping";
import { PageBuilderPage } from "./pages/admin/PageBuilderPage";
import AdminDocumentos from "./pages/admin/AdminDocumentos";
import AdminProblemas from "./pages/admin/AdminProblemas";
import AdminPOS from "./pages/admin/AdminPOS";
import AdminNotificacoes from "./pages/admin/AdminNotificacoes";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <MaintenanceGate>
          <Routes>
            {/* Público */}
            <Route element={<PublicLayout />}>
              <Route path="/" element={<Home />} />
              <Route path="/sobre-nos" element={<Sobre />} />
              <Route path="/servicos" element={<Servicos />} />
              <Route path="/galeria" element={<Galeria />} />
              <Route path="/produtos" element={<Produtos />} />
              <Route path="/orcamento" element={<Orcamento />} />
              <Route path="/contacto" element={<Contacto />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/privacidade" element={<Privacidade />} />
              <Route path="/cookies" element={<Cookies />} />
              <Route path="/termos" element={<Termos />} />
              <Route path="/login" element={<Login />} />
              <Route path="/blog/:slug" element={<BlogPost />} />
            </Route>

            {/* Cliente */}
            <Route path="/cliente/login" element={<Navigate to="/login" replace />} />
            <Route path="/cliente" element={<ClientLayout />}>
              <Route index element={<ClienteDashboard />} />
              <Route path="eventos" element={<ClienteEventos />} />
              <Route path="confirmados" element={<ClienteEventosConfirmados />} />
              <Route path="orcamentos" element={<ClienteOrcamentos />} />
              <Route path="orcamentos/:id" element={<Questionario />} />
              <Route path="questionario" element={<Questionario />} />
              <Route path="avaliacao" element={<Avaliacao />} />
              <Route path="password" element={<AlterarPassword />} />
            </Route>

            {/* Redirecionar /portal para /cliente */}
            <Route path="/portal" element={<Navigate to="/cliente" replace />} />
            <Route path="/portal/*" element={<Navigate to="/cliente" replace />} />
            <Route path="/cliente/dashboard" element={<Navigate to="/cliente" replace />} />

            {/* Admin / Colaborador */}
            <Route path="/colaborador/login" element={<Navigate to="/login" replace />} />
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboard />} />
              <Route path="pedidos" element={<AdminPedidos />} />
              <Route path="eventos" element={<AdminEventos />} />
              <Route path="notas-eventos" element={<AdminNotasEventos />} />
              <Route path="calendario" element={<AdminCalendario />} />
              <Route path="entregas" element={<AdminEntregas />} />
              <Route path="materiais" element={<AdminMateriais />} />
              <Route path="financeiro" element={<AdminFinanceiro />} />
              <Route path="relatorio" element={<AdminRelatorio />} />
              <Route path="questionarios" element={<AdminQuestionarios />} />
              <Route path="documentos" element={<AdminDocumentos />} />
              <Route path="mensagens" element={<AdminMensagens />} />
              <Route path="galeria" element={<AdminGaleria />} />
              <Route path="blog" element={<AdminBlog />} />
              <Route path="faq" element={<AdminFAQ />} />
              <Route path="telefones" element={<AdminPhoneMapping />} />
              <Route path="page-builder/:pageSlug" element={<PageBuilderPage />} />
              <Route path="utilizadores" element={<AdminUtilizadores />} />
              <Route path="definicoes" element={<AdminDefinicoes />} />
              <Route path="problemas" element={<AdminProblemas />} />
              <Route path="pos" element={<AdminPOS />} />
              <Route path="notificacoes" element={<AdminNotificacoes />} />
            </Route>
            <Route path="/dashboard" element={<Navigate to="/admin" replace />} />

            <Route path="*" element={<NotFound />} />
          </Routes>
          <CookieBanner />
        </MaintenanceGate>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
