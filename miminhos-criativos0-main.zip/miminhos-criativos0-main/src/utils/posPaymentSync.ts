/**
 * Sincronização de pagamentos entre POS e eventos/questionários
 * Mapeia estado de pagamento POS para o campo estado_pagamento em events e questionnaires
 */

import { supabase } from "@/integrations/supabase/client";

export const PAYMENT_STATUS_MAP = {
  pago: "pago",
  por_pagar: "por_pagar",
  em_pagamento: "em_pagamento",
  nao_realizado: "nao_atribuido",
  nao_atribuido: "nao_atribuido",
} as const;

/**
 * Sincroniza o estado de pagamento de uma operação POS para eventos e questionários associados
 */
export const syncPaymentStatus = async (posOperation: {
  id: string;
  event_id?: string | null;
  questionnaire_id?: string | null;
  payment_status: string;
  client_id: string;
}) => {
  const mappedStatus = PAYMENT_STATUS_MAP[posOperation.payment_status as keyof typeof PAYMENT_STATUS_MAP] || posOperation.payment_status;

  const updates: any[] = [];

  // Atualizar event se existir
  if (posOperation.event_id) {
    updates.push(
      supabase
        .from("events")
        .update({
          estado_pagamento: mappedStatus,
          updated_at: new Date().toISOString(),
        })
        .eq("id", posOperation.event_id)
    );
  }

  // Atualizar questionnaire se existir
  if (posOperation.questionnaire_id) {
    updates.push(
      supabase
        .from("questionnaires")
        .update({
          estado_pagamento: mappedStatus,
          updated_at: new Date().toISOString(),
        })
        .eq("id", posOperation.questionnaire_id)
    );
  }

  // Se nenhum evento/questionário foi associado, procurar por cliente e data próxima
  if (!posOperation.event_id && !posOperation.questionnaire_id) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Procurar eventos não pagos do cliente nos próximos dias
    const { data: recentEvents } = await supabase
      .from("events")
      .select("id")
      .eq("client_id", posOperation.client_id)
      .eq("status", "confirmado")
      .is("estado_pagamento", null)
      .gte("event_date", today.toISOString())
      .lt("event_date", new Date(tomorrow.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString())
      .limit(1);

    if (recentEvents && recentEvents.length > 0) {
      updates.push(
        supabase
          .from("events")
          .update({
            estado_pagamento: mappedStatus,
            updated_at: new Date().toISOString(),
          })
          .eq("id", recentEvents[0].id)
      );
    }
  }

  if (updates.length > 0) {
    const results = await Promise.allSettled(updates);
    return results;
  }
};

/**
 * Cria um listener em tempo real para atualizações de pagamento
 */
export const listenToPaymentUpdates = (
  clientId: string,
  onUpdate: (type: "event" | "questionnaire", item: any) => void
) => {
  const eventSub = supabase
    .channel(`payment-updates:events:${clientId}`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "events",
        filter: `client_id=eq.${clientId}`,
      },
      (payload) => {
        onUpdate("event", payload.new);
      }
    )
    .subscribe();

  const questSub = supabase
    .channel(`payment-updates:questionnaires:${clientId}`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "questionnaires",
        filter: `client_id=eq.${clientId}`,
      },
      (payload) => {
        onUpdate("questionnaire", payload.new);
      }
    )
    .subscribe();

  return () => {
    eventSub.unsubscribe();
    questSub.unsubscribe();
  };
};
