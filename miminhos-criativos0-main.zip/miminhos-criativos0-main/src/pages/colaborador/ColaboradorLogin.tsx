import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import bgAsset from "@/assets/colaborador-login-bg.jpg.asset.json";
const bgImage = bgAsset.url;

const ColaboradorLogin = () => {
  const navigate = useNavigate();
  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  const isPhone = (v: string) => /^\d{9,}$/.test(v.replace(/\s|-/g, ""));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      let email = emailOrPhone;
      if (isPhone(emailOrPhone)) {
        const normalized = emailOrPhone.replace(/\D/g, "");
        const { data: foundEmail } = await supabase
          .rpc("get_email_by_phone", { _phone: normalized });
        if (foundEmail) {
          email = foundEmail as string;
        } else {
          const { data: profileRow } = await supabase
            .from("profiles").select("email").eq("phone", normalized).maybeSingle();
          if (profileRow?.email) email = profileRow.email;
          else { setLoading(false); toast.error("Telefone não encontrado. Tenta com o email."); return; }
        }
      }
      const { error, data } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) { toast.error("Email ou password incorretos"); return; }
      toast.success("Bem-vinda! 💛");
      const { data: roleData } = await supabase
        .from("user_roles").select("role").eq("user_id", data.user.id).single();
      const role = roleData?.role;
      if (role === "admin" || role === "colaborador") navigate("/admin");
      else navigate("/cliente");
    } catch {
      setLoading(false);
      toast.error("Erro ao fazer login");
    }
  };

  return (
    <div className="min-h-screen grid md:grid-cols-2 bg-[#a8987a]">
      {/* Left: photo */}
      <div
        className="hidden md:block bg-cover bg-center"
        style={{ backgroundImage: `url(${bgImage})`, backgroundPosition: "left center" }}
        aria-hidden
      />

      {/* Right: beige panel with form */}
      <div className="flex items-center justify-center p-6 md:p-12 bg-[#a8987a]">
        <div className="w-full max-w-md">
          <div className="flex justify-center mb-10">
            <Logo className="h-36 md:h-44" variant="light" />
          </div>

          <form onSubmit={onSubmit} className="space-y-5">
            <div>
              <Label className="text-white text-base font-semibold">Email ou Telefone</Label>
              <Input
                type="text"
                inputMode={/^[\d\s+-]*$/.test(emailOrPhone) && emailOrPhone.length > 0 ? "tel" : "text"}
                placeholder="exemplo@email.com ou 926992352"
                required
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                className="mt-2 h-12 rounded-full bg-white border-0 px-5"
                autoComplete="username"
              />
            </div>

            <div>
              <Label className="text-white text-base font-semibold">Password</Label>
              <Input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-2 h-12 rounded-full bg-white border-0 px-5"
                autoComplete="current-password"
              />
            </div>

            <Button
              type="submit"
              disabled={loading || !emailOrPhone || !password}
              className="w-full h-14 rounded-full bg-white text-black hover:bg-white/90 text-lg font-bold mt-4"
            >
              {loading ? "A entrar..." : "Entrar"}
            </Button>
          </form>

          <div className="text-center mt-6">
            <Link to="/" className="text-white/90 hover:text-white text-sm underline-offset-4 hover:underline transition">
              ← Voltar ao site
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ColaboradorLogin;
