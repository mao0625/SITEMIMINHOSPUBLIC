import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { ChevronDown, Plus, Edit, Trash2, HelpCircle, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

interface FAQ {
  id: string;
  question: string;
  answer: string;
  order: number;
  created_at: string;
}

const FAQ = () => {
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingFaq, setEditingFaq] = useState<FAQ | null>(null);
  const [form, setForm] = useState({ question: "", answer: "" });
  const [search, setSearch] = useState("");

  // Check if user is admin
  useEffect(() => {
    const checkAdmin = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .eq("role", "admin")
          .single();
        setIsAdmin(!!data);
      }
    };
    checkAdmin();
  }, []);

  // Load FAQs
  const loadFaqs = async () => {
    const { data } = await supabase
      .from("faqs")
      .select("*")
      .order("order", { ascending: true });
    setFaqs(data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    loadFaqs();

    const subscription = supabase
      .channel("faqs")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "faqs" },
        () => loadFaqs()
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const saveFaq = async () => {
    if (!form.question.trim() || !form.answer.trim()) {
      toast.error("Preencha todos os campos");
      return;
    }

    const payload = {
      question: form.question,
      answer: form.answer,
      order: editingFaq ? editingFaq.order : faqs.length,
    };

    if (editingFaq) {
      const { error } = await supabase
        .from("faqs")
        .update(payload)
        .eq("id", editingFaq.id);
      if (error) return toast.error(error.message);
      toast.success("Pergunta atualizada");
    } else {
      const { error } = await supabase.from("faqs").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("Pergunta criada");
    }

    setOpenDialog(false);
    setEditingFaq(null);
    setForm({ question: "", answer: "" });
    loadFaqs();
  };

  const deleteFaq = async (id: string) => {
    if (!confirm("Eliminar esta pergunta?")) return;
    await supabase.from("faqs").delete().eq("id", id);
    toast.success("Pergunta eliminada");
    loadFaqs();
  };

  const startEdit = (faq: FAQ) => {
    setEditingFaq(faq);
    setForm({ question: faq.question, answer: faq.answer });
    setOpenDialog(true);
  };

  const startNew = () => {
    setEditingFaq(null);
    setForm({ question: "", answer: "" });
    setOpenDialog(true);
  };

  const filteredFaqs = faqs.filter((f) =>
    search.trim() === "" ||
    f.question.toLowerCase().includes(search.toLowerCase()) ||
    f.answer.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <Navbar />

      {/* Hero — quiet, type-led, generous spacing */}
      <section className="pt-40 pb-20 bg-gradient-champagne text-center">
        <div className="container">
          <p className="font-script text-2xl text-primary mb-3 animate-fade-up" style={{ animationDelay: "0.05s" }}>
            Está com dúvidas?
          </p>
          <h1 className="font-display text-6xl md:text-8xl tracking-tight animate-fade-up" style={{ animationDelay: "0.15s" }}>
            Perguntas Frequentes
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto mt-5 text-base md:text-lg animate-fade-up" style={{ animationDelay: "0.25s" }}>
            As respostas que precisa, antes mesmo de perguntar.
          </p>

          {/* Search */}
          <div className="max-w-md mx-auto mt-10 animate-fade-up" style={{ animationDelay: "0.35s" }}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Pesquisar uma pergunta..."
                className="pl-11 h-12 rounded-full border-border bg-card/80 backdrop-blur-sm text-base shadow-soft"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ List */}
      <section className="py-20 md:py-28">
        <div className="container max-w-2xl">
          {loading ? (
            <div className="flex items-center justify-center min-h-64">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mx-auto mb-4" />
                <p className="text-muted-foreground">A carregar perguntas...</p>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-border border-t border-b border-border">
              {filteredFaqs.map((faq) => {
                const isOpen = expandedId === faq.id;
                return (
                  <div key={faq.id} className="group">
                    <button
                      onClick={() => setExpandedId(isOpen ? null : faq.id)}
                      className="w-full flex items-center justify-between gap-6 py-6 text-left transition-colors"
                    >
                      <span
                        className={`font-display text-xl md:text-2xl leading-snug transition-colors ${
                          isOpen ? "text-primary" : "text-foreground group-hover:text-primary"
                        }`}
                      >
                        {faq.question}
                      </span>
                      <span
                        className={`flex-shrink-0 h-9 w-9 rounded-full border border-border flex items-center justify-center transition-all duration-300 ${
                          isOpen ? "bg-primary border-primary rotate-180" : "group-hover:border-primary/50"
                        }`}
                      >
                        <ChevronDown
                          className={`h-4 w-4 transition-colors ${isOpen ? "text-primary-foreground" : "text-primary"}`}
                        />
                      </span>
                    </button>

                    {/* Animated answer panel */}
                    <div
                      className="overflow-hidden transition-all duration-300 ease-out"
                      style={{
                        maxHeight: isOpen ? "1000px" : "0px",
                        opacity: isOpen ? 1 : 0,
                      }}
                    >
                      <div className="pb-7 pr-14">
                        <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap text-base">
                          {faq.answer}
                        </p>

                        {isAdmin && (
                          <div className="flex gap-2 mt-5">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => startEdit(faq)}
                              className="hover:bg-primary/10 rounded-full"
                            >
                              <Edit className="h-3 w-3 mr-1.5" />
                              Editar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteFaq(faq.id)}
                              className="hover:bg-destructive/10 text-destructive hover:text-destructive rounded-full"
                            >
                              <Trash2 className="h-3 w-3 mr-1.5" />
                              Eliminar
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {filteredFaqs.length === 0 && faqs.length > 0 && (
                <div className="text-center py-16">
                  <p className="text-muted-foreground">
                    Nenhuma pergunta encontrada para "{search}"
                  </p>
                </div>
              )}

              {faqs.length === 0 && (
                <div className="text-center py-16">
                  <HelpCircle className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    Nenhuma pergunta disponível no momento
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Info / CTA Section — quiet, single focal point */}
      <section className="py-20 md:py-28 bg-gradient-champagne border-t border-border">
        <div className="container max-w-2xl text-center">
          <div className="inline-flex items-center justify-center h-14 w-14 rounded-full bg-card border border-border shadow-soft mb-6">
            <HelpCircle className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-display text-3xl md:text-4xl mb-4">
            Como peço o orçamento?
          </h3>
          <p className="text-muted-foreground text-lg leading-relaxed max-w-xl mx-auto">
            Vá a{" "}
            <a
              href="/orcamento"
              className="text-primary font-semibold hover:underline"
            >
              Pedir orçamento
            </a>
            , preencha o formulário e em 48 horas úteis receberá um email com
            acesso ao portal do cliente.
          </p>
        </div>
      </section>

      {/* Admin Controls */}
      {isAdmin && (
        <div className="fixed bottom-8 right-8 z-30">
          <Button
            onClick={startNew}
            className="bg-gradient-gold hover:opacity-90 shadow-gold rounded-full w-14 h-14 flex items-center justify-center"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </div>
      )}

      {/* Dialog */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingFaq ? "Editar pergunta" : "Nova pergunta"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="question" className="font-semibold">
                Pergunta *
              </Label>
              <Input
                id="question"
                value={form.question}
                onChange={(e) =>
                  setForm({ ...form, question: e.target.value })
                }
                placeholder="Digite a pergunta"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="answer" className="font-semibold">
                Resposta *
              </Label>
              <Textarea
                id="answer"
                rows={8}
                value={form.answer}
                onChange={(e) =>
                  setForm({ ...form, answer: e.target.value })
                }
                placeholder="Digite a resposta detalhada"
                className="mt-1"
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                onClick={saveFaq}
                className="flex-1 bg-gradient-gold"
              >
                {editingFaq ? "Atualizar" : "Criar"}
              </Button>
              <Button
                onClick={() => setOpenDialog(false)}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default FAQ;
