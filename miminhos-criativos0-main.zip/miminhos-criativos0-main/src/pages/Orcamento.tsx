import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Phone, MapPin, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const schema = z.object({
  name: z.string().trim().min(2, "Nome obrigatório").max(100),
  email: z.string().trim().email("Email inválido").max(255),
  phone: z.string().trim().min(9, "Telefone inválido").max(20),
  event_type: z.string().min(1, "Selecione o tipo"),
});
type FormData = z.infer<typeof schema>;

const types = ["Aniversário", "Batismo", "1ª Comunhão", "Babyshower", "Casamento", "Crisma", "Bodas", "Formatura", "Outro"];

const Orcamento = () => {
  const [done, setDone] = useState(false);
  const { register, handleSubmit, setValue, watch, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    const { error } = await supabase.from("quote_requests").insert({
      name: data.name,
      email: data.email,
      phone: data.phone,
      event_type: data.event_type,
    });
    if (error) {
      toast.error("Erro ao enviar pedido. Tente novamente.");
      return;
    }
    setDone(true);
  };

  if (done) {
    return (
      <section className="pt-32 pb-20 min-h-screen bg-gradient-champagne flex items-center justify-center">
        <div className="container max-w-lg text-center bg-card p-12 md:p-16 rounded-2xl shadow-elegant animate-fade-up">
          <div className="h-20 w-20 bg-gradient-gold rounded-full mx-auto flex items-center justify-center mb-7 shadow-gold">
            <Check className="h-10 w-10 text-primary-foreground" />
          </div>
          <h2 className="font-display text-4xl md:text-5xl mb-4">Pedido enviado!</h2>
          <p className="text-muted-foreground text-lg">Entraremos em contacto em breve.</p>
          <p className="font-script text-2xl text-primary mt-7">Com carinho, Miminhos Criativos 💛</p>
        </div>
      </section>
    );
  }

  return (
    <section className="pt-40 pb-24 bg-gradient-champagne min-h-screen">
      <div className="container max-w-5xl">

        {/* Hero — quiet, type-led, generous spacing */}
        <div className="text-center mb-16">
          <p className="font-script text-2xl text-primary mb-3 animate-fade-up" style={{ animationDelay: "0.05s" }}>
            Vamos criar juntas
          </p>
          <h1 className="font-display text-6xl md:text-8xl tracking-tight animate-fade-up" style={{ animationDelay: "0.15s" }}>
            Pedir Orçamento
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto mt-5 text-base md:text-lg animate-fade-up" style={{ animationDelay: "0.25s" }}>
            Preencha os seus dados. A nossa equipa irá analisar o seu pedido
            e entrar em contacto consigo brevemente.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <form onSubmit={handleSubmit(onSubmit)} className="md:col-span-2 bg-card rounded-2xl shadow-elegant p-8 md:p-10 space-y-6">
            <div className="space-y-1.5">
              <Label>Nome completo *</Label>
              <Input {...register("name")} className="h-11 rounded-xl" />
              {errors.name && <p className="text-destructive text-xs mt-1">{errors.name.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Email *</Label>
              <Input type="email" {...register("email")} className="h-11 rounded-xl" />
              {errors.email && <p className="text-destructive text-xs mt-1">{errors.email.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Telefone *</Label>
              <Input {...register("phone")} placeholder="9XX XXX XXX" className="h-11 rounded-xl" />
              {errors.phone && <p className="text-destructive text-xs mt-1">{errors.phone.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Tipo de evento *</Label>
              <Select onValueChange={(v) => setValue("event_type", v, { shouldValidate: true })} value={watch("event_type")}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>
                  {types.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
              {errors.event_type && <p className="text-destructive text-xs mt-1">{errors.event_type.message}</p>}
            </div>
            <Button type="submit" disabled={isSubmitting} className="bg-gradient-gold w-full h-12 rounded-xl text-base shadow-gold">
              {isSubmitting ? "A enviar..." : "Enviar Pedido"}
            </Button>
            <p className="text-[11px] text-muted-foreground text-center">
              Ao enviar, aceita a nossa Política de Privacidade.
            </p>
          </form>

          <aside className="bg-dark text-white rounded-2xl p-8 md:pt-10">
            <p className="text-xs uppercase tracking-[0.25em] text-primary/70 font-semibold mb-2">
              Diga olá
            </p>
            <h3 className="font-display text-2xl md:text-3xl mb-7">Falar connosco</h3>
            <ul className="space-y-4 text-sm">
              <li className="flex items-center gap-4">
                <span className="flex-shrink-0 h-10 w-10 rounded-full bg-white/5 flex items-center justify-center">
                  <Phone className="h-4 w-4 text-primary" />
                </span>
                <div>
                  <p className="text-white/50 text-xs mb-0.5">Telefone</p>
                  <p className="text-base">926 992 352</p>
                </div>
              </li>
              <li className="flex items-center gap-4">
                <span className="flex-shrink-0 h-10 w-10 rounded-full bg-white/5 flex items-center justify-center">
                  <MapPin className="h-4 w-4 text-primary" />
                </span>
                <div>
                  <p className="text-white/50 text-xs mb-0.5">Localização</p>
                  <p className="text-base">Madeira, Portugal</p>
                </div>
              </li>
            </ul>
            <p className="font-script text-2xl text-primary-glow mt-9">Resposta em 48h úteis 💛</p>
          </aside>
        </div>
      </div>
    </section>
  );
};

export default Orcamento;
