import { LoginPage } from "@/components/auth/LoginPage";
const Login = () => <LoginPage title="Entrar" subtitle="Bem-vinda de volta" />;
export default Login;
