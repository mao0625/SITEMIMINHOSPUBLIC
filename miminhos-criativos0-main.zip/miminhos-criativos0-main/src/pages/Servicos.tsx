import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import cake from "@/assets/cake-benfica.jpg";
import baptism from "@/assets/baptism-flowers.jpg";
import wedding from "@/assets/wedding-bouquet.jpg";
import sunflowers from "@/assets/sunflowers-event.jpg";
import mickey from "@/assets/cake-mickey.jpg";
import pokemon from "@/assets/cake-pokemon.jpg";
import floral from "@/assets/floral-vase.jpg";
import grad from "@/assets/graduation.jpg";
import babyshower from "@/assets/Babyshower.jpg";
import casamento from "@/assets/casamento.jpg";
import crisma from "@/assets/crismas.jpg";

const services = [
  { icon: "🎂", name: "Aniversários",  desc: "Decoração temática personalizada para todas as idades. Desde os mais pequenos aos mais crescidos.", img: cake      },
  { icon: "✝️", name: "Batismos",      desc: "Cerimónias delicadas com flores, balões e pormenores cheios de ternura.",                           img: sunflowers},
  { icon: "🕊️", name: "1ª Comunhão",  desc: "Celebrações elegantes que marcam este momento especial de fé.",                                     img: floral    },
  { icon: "🍼", name: "Babyshower",    desc: "Receba o bebé com muita doçura e detalhes encantadores.",                                           img: babyshower},
  { icon: "💍", name: "Casamentos",    desc: "O dia mais especial merece a decoração mais cuidada.",                                               img: casamento },
  { icon: "✨", name: "Crismas",        desc: "Momentos sagrados decorados com elegância e respeito.",                                             img: crisma    },
  { icon: "💛", name: "Bodas",         desc: "Celebre os anos de amor com uma festa inesquecível.",                                                img: pokemon   },
  { icon: "🎓", name: "Formaturas",    desc: "Coroe a conquista com uma festa à altura.",                                                          img: grad      },
];

const Servicos = () => (
  <>
    {/* ── Hero ── */}
    <section className="pt-32 pb-14 bg-gradient-champagne text-center relative overflow-hidden">
      {/* subtle decorative circles */}
      <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
      <div className="container relative z-10">
        <p className="font-script text-2xl text-primary mb-2">O que oferecemos</p>
        <h1 className="font-display text-5xl md:text-6xl mb-4">Os Nossos Serviços</h1>
        <div className="w-20 h-0.5 bg-gradient-gold mx-auto mt-2 mb-6" />
        <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
          Cada celebração é única. Personalizamos todos os detalhes para tornar o seu evento inesquecível.
        </p>
      </div>
    </section>

    {/* ── Cards ── */}
    <section className="py-20 bg-background">
      <div className="container grid md:grid-cols-2 lg:grid-cols-4 gap-7">
        {services.map((s) => (
          <article
            key={s.name}
            className="group bg-card rounded-xl overflow-hidden shadow-soft border border-border
                       hover:border-primary hover:shadow-elegant transition-all duration-300
                       hover:-translate-y-2 cursor-default flex flex-col"
          >
            {/* Image */}
            <div className="relative aspect-square overflow-hidden">
              <img
                src={s.img}
                alt={s.name}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              {/* gradient overlay on hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent
                              opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* emoji badge */}
              <div className="absolute top-3 right-3 text-3xl bg-white/90 backdrop-blur-sm rounded-full
                              h-12 w-12 flex items-center justify-center shadow-sm
                              transition-transform duration-300 group-hover:scale-110">
                {s.icon}
              </div>

              {/* title peek on hover */}
              <div className="absolute bottom-0 left-0 right-0 px-4 pb-4
                              translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100
                              transition-all duration-300">
                <p className="font-display text-white text-lg leading-tight drop-shadow">{s.name}</p>
              </div>
            </div>

            {/* Body */}
            <div className="p-5 flex flex-col flex-1">
              <h3 className="font-display text-xl mb-2 group-hover:text-primary transition-colors duration-200">
                {s.name}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed flex-1">{s.desc}</p>

              {/* CTA arrow */}
              <div className="mt-4 flex items-center gap-1.5 text-primary text-xs font-semibold
                              opacity-0 group-hover:opacity-100 translate-y-1 group-hover:translate-y-0
                              transition-all duration-300">
                Saber mais
                <svg className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </article>
        ))}
      </div>

      <div className="text-center mt-16">
        <Button asChild size="lg" className="bg-gradient-gold shadow-gold text-primary-foreground px-8 py-6 text-base hover:opacity-90 transition-opacity">
          <Link to="/orcamento">Pedir Orçamento</Link>
        </Button>
      </div>
    </section>
  </>
);

export default Servicos;
