import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import {
  Calendar, Tag, Newspaper, ArrowRight, Clock,
  Search, Folder, Sparkles, ChevronRight, X,
} from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

interface BlogPost {
  id: string; slug: string; title: string; excerpt: string;
  content: string; cover_url: string; published: boolean;
  created_at: string; published_at: string;
  category_id?: string; tags?: string[];
  featured?: boolean; reading_time?: number;
}
interface BlogCategory {
  id: string; name: string; slug: string; color?: string;
}

const readingTime = (content: string) => {
  const words = content.trim().split(/\s+/).length;
  return Math.max(1, Math.ceil(words / 200));
};

const Blog = () => {
  const [posts,      setPosts]      = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [search,     setSearch]     = useState("");
  const [activeCat,  setActiveCat]  = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      const [{ data: p }, { data: c }] = await Promise.all([
        supabase.from("blog_posts").select("*").eq("published", true).order("published_at", { ascending: false }),
        supabase.from("blog_categories").select("*").order("name"),
      ]);
      setPosts((p ?? []) as BlogPost[]);
      setCategories((c ?? []) as BlogCategory[]);
      setLoading(false);
    })();
  }, []);

  const filtered = posts.filter(p => {
    const matchSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || (p.excerpt ?? "").toLowerCase().includes(search.toLowerCase());
    const matchCat    = !activeCat || p.category_id === activeCat;
    return matchSearch && matchCat;
  });

  const featured = filtered.find(p => p.featured) ?? filtered[0];
  const rest     = filtered.filter(p => p.id !== featured?.id);

  const getCat   = (id?: string) => categories.find(c => c.id === id);
  const fmtDate  = (p: BlogPost) => format(new Date(p.published_at || p.created_at), "d 'de' MMMM 'de' yyyy", { locale: pt });
  const fmtShort = (p: BlogPost) => format(new Date(p.published_at || p.created_at), "dd/MM/yyyy");
  const rt       = (p: BlogPost) => p.reading_time ?? readingTime(p.content);

  return (
    <>
      <Navbar />

      {/* ── Hero ── */}
      <section className="pt-32 pb-14 bg-gradient-to-b from-[#fdf8f3] to-white border-b border-[#e8d5c4] text-center">
        <div className="container max-w-3xl">
          <p className="font-script text-2xl text-primary mb-2">Inspiração e novidades</p>
          <h1 className="font-display text-5xl md:text-6xl mb-4 text-[#2c1a0e]">Blog</h1>
          <p className="text-[#7a5c4a] max-w-xl mx-auto mb-8 text-lg">
            Dicas, tendências e inspiração para as suas decorações e eventos memoráveis.
          </p>

          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#b08070]" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Pesquisar artigos…"
              className="w-full h-12 pl-11 pr-4 rounded-full border border-[#e8d5c4] bg-white text-[#2c1a0e] text-sm outline-none focus:border-[#c17f4a] shadow-sm transition-colors"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#b08070] hover:text-[#7a5c4a]">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </section>

      {/* ── Category pills ── */}
      {categories.length > 0 && (
        <div className="sticky top-0 z-20 bg-white border-b border-[#e8d5c4] shadow-sm">
          <div className="container overflow-x-auto">
            <div className="flex items-center gap-2 py-3 min-w-max">
              <button
                onClick={() => setActiveCat("")}
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold border transition-all whitespace-nowrap ${!activeCat ? "bg-[#2c1a0e] text-white border-[#2c1a0e]" : "border-[#e8d5c4] text-[#7a5c4a] hover:border-[#c17f4a]"}`}>
                <Folder className="h-3 w-3" />Todos
              </button>
              {categories.map(c => (
                <button key={c.id} onClick={() => setActiveCat(activeCat === c.id ? "" : c.id)}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold border transition-all whitespace-nowrap"
                  style={{
                    background:   activeCat === c.id ? (c.color ?? "#c17f4a") : "white",
                    color:        activeCat === c.id ? "white" : (c.color ?? "#7a5c4a"),
                    borderColor:  activeCat === c.id ? (c.color ?? "#c17f4a") : "#e8d5c4",
                  }}>
                  {c.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Content ── */}
      <section className="py-16 bg-[#fdf8f3]">
        <div className="container">
          {loading ? (
            <div className="flex items-center justify-center py-24">
              <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 rounded-full border-4 border-[#e8d5c4] border-t-[#c17f4a] animate-spin" />
                <p className="text-[#b08070] text-sm">A carregar artigos…</p>
              </div>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-24">
              <div className="h-20 w-20 rounded-2xl bg-[#f5e6d3] flex items-center justify-center mx-auto mb-6">
                <Newspaper className="h-10 w-10 text-[#c17f4a]" />
              </div>
              <h2 className="font-display text-2xl text-[#2c1a0e] mb-2">
                {search ? "Sem resultados" : "Brevemente novos artigos"}
              </h2>
              <p className="text-[#7a5c4a] max-w-sm mx-auto">
                {search ? "Tente pesquisar por outra palavra." : "Estamos a preparar conteúdo exclusivo. Volte em breve!"}
              </p>
            </div>
          ) : (
            <>
              {/* ── Featured ── */}
              {featured && !search && !activeCat && (
                <article
                  onClick={() => navigate(`/blog/${featured.slug}`)}
                  className="mb-16 group cursor-pointer"
                >
                  <div className="grid md:grid-cols-2 gap-10 items-center bg-white rounded-2xl overflow-hidden border border-[#e8d5c4] shadow-sm hover:shadow-md transition-shadow">
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img
                        src={featured.cover_url || "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800"}
                        alt={featured.title}
                        loading="eager"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                      {featured.featured && (
                        <div className="absolute top-4 left-4">
                          <span className="inline-flex items-center gap-1.5 bg-white/95 text-[#c17f4a] px-3 py-1.5 rounded-full text-xs font-bold shadow border border-[#e8d5c4]">
                            <Sparkles className="h-3 w-3" />Destaque
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="p-8 space-y-4">
                      {/* Category */}
                      {featured.category_id && getCat(featured.category_id) && (
                        <span style={{ color: getCat(featured.category_id)?.color ?? "#c17f4a" }}
                          className="text-xs font-bold uppercase tracking-widest">
                          {getCat(featured.category_id)?.name}
                        </span>
                      )}
                      {/* Meta */}
                      <div className="flex items-center gap-3 text-sm text-[#b08070]">
                        <span className="inline-flex items-center gap-1.5">
                          <Calendar className="h-3.5 w-3.5" />{fmtDate(featured)}
                        </span>
                        <span>·</span>
                        <span className="inline-flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5" />{rt(featured)} min
                        </span>
                      </div>
                      <h2 className="font-display text-3xl md:text-4xl leading-tight text-[#2c1a0e] group-hover:text-[#c17f4a] transition-colors">
                        {featured.title}
                      </h2>
                      {featured.excerpt && (
                        <p className="text-[#7a5c4a] text-base leading-relaxed line-clamp-3">{featured.excerpt}</p>
                      )}
                      {/* Tags */}
                      {featured.tags && featured.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {featured.tags.slice(0, 4).map(t => (
                            <span key={t} className="text-[10px] bg-[#f5e6d3] text-[#7a5c4a] px-2 py-0.5 rounded-full border border-[#e8d5c4]">#{t}</span>
                          ))}
                        </div>
                      )}
                      <div className="pt-2">
                        <span className="inline-flex items-center gap-2 text-[#c17f4a] font-semibold group-hover:gap-3 transition-all">
                          Ler artigo completo
                          <ArrowRight className="h-4 w-4" />
                        </span>
                      </div>
                    </div>
                  </div>
                </article>
              )}

              {/* ── Grid ── */}
              {(search || activeCat ? filtered : rest).length > 0 && (
                <>
                  {!search && !activeCat && rest.length > 0 && (
                    <div className="flex items-center gap-4 mb-8">
                      <h3 className="font-display text-2xl text-[#2c1a0e]">Artigos recentes</h3>
                      <div className="flex-1 h-px bg-[#e8d5c4]" />
                    </div>
                  )}
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {(search || activeCat ? filtered : rest).map(post => {
                      const cat = getCat(post.category_id);
                      return (
                        <article key={post.id} onClick={() => navigate(`/blog/${post.slug}`)}
                          className="bg-white rounded-2xl overflow-hidden border border-[#e8d5c4] shadow-sm hover:shadow-md hover:-translate-y-1 transition-all cursor-pointer group flex flex-col">
                          {/* Cover */}
                          <div className="aspect-[16/10] overflow-hidden bg-[#f5e6d3] relative">
                            <img
                              src={post.cover_url || "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600"}
                              alt={post.title}
                              loading="lazy"
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                            />
                            <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-1 rounded-full flex items-center gap-1">
                              <Clock className="h-2.5 w-2.5" />{rt(post)} min
                            </div>
                            {post.featured && (
                              <div className="absolute top-3 left-3">
                                <span className="inline-flex items-center gap-1 bg-white/95 text-[#c17f4a] text-[9px] font-bold px-2 py-0.5 rounded-full border border-[#e8d5c4]">
                                  <Sparkles className="h-2.5 w-2.5" />Destaque
                                </span>
                              </div>
                            )}
                          </div>
                          {/* Body */}
                          <div className="p-5 flex-1 flex flex-col gap-2.5">
                            <div className="flex items-center justify-between gap-2">
                              {cat
                                ? <span style={{ color: cat.color ?? "#c17f4a" }} className="text-[10px] font-bold uppercase tracking-widest">{cat.name}</span>
                                : <span className="text-[10px] font-bold uppercase tracking-widest text-[#c17f4a]">Artigo</span>
                              }
                              <span className="text-xs text-[#b08070]">{fmtShort(post)}</span>
                            </div>
                            <h3 className="font-display text-xl leading-snug group-hover:text-[#c17f4a] transition-colors text-[#2c1a0e] line-clamp-2">
                              {post.title}
                            </h3>
                            <p className="text-sm text-[#7a5c4a] flex-1 line-clamp-2 leading-relaxed">
                              {post.excerpt || post.content.replace(/[#*_>`\[\]!()-]/g, "").substring(0, 120)}
                            </p>
                            {post.tags && post.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {post.tags.slice(0, 3).map(t => (
                                  <span key={t} className="text-[9px] bg-[#f5e6d3] text-[#7a5c4a] px-1.5 py-0.5 rounded-full">#{t}</span>
                                ))}
                              </div>
                            )}
                            <span className="inline-flex items-center gap-1.5 text-[#c17f4a] text-sm font-semibold mt-1 self-start group-hover:gap-2.5 transition-all">
                              Ler mais <ArrowRight className="h-3.5 w-3.5" />
                            </span>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </section>

      {/* ── CTA ── */}
      {!loading && posts.length > 0 && (
        <section className="py-16 bg-white border-t border-[#e8d5c4]">
          <div className="container text-center">
            <h2 className="font-display text-3xl text-[#2c1a0e] mb-3">Quer ver mais inspiração?</h2>
            <p className="text-[#7a5c4a] mb-6 max-w-md mx-auto">
              Siga-nos nas redes sociais para acompanhar novidades, dicas e transformações dos nossos projetos.
            </p>
            <div className="flex justify-center gap-6">
              <a href="https://instagram.com" target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-2 text-[#c17f4a] font-semibold hover:underline">📸 Instagram</a>
              <span className="text-[#e8d5c4]">·</span>
              <a href="https://facebook.com" target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-2 text-[#c17f4a] font-semibold hover:underline">👍 Facebook</a>
            </div>
          </div>
        </section>
      )}
    </>
  );
};

export default Blog;
