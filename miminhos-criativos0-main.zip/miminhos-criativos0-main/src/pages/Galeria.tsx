import { useState, useEffect } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import cake from "@/assets/cake-benfica.jpg";
import pokemon from "@/assets/cake-pokemon.jpg";
import mickey from "@/assets/cake-mickey.jpg";
import wedding from "@/assets/wedding-bouquet.jpg";
import baptism from "@/assets/baptism-flowers.jpg";
import baptismTable from "@/assets/baptism-table.jpg";
import sunflowers from "@/assets/sunflowers-event.jpg";
import floral from "@/assets/floral-vase.jpg";
import grad from "@/assets/graduation.jpg";
import babyshower from "@/assets/Babyshower.jpg";
import casamento from "@/assets/casamento.jpg";
import crisma from "@/assets/crismas.jpg";

type Photo = { src: string; cat: string; alt: string };

const photos: Photo[] = [
  { src: cake,          cat: "Aniversários", alt: "Bolo aniversário Benfica"  },
  { src: pokemon,       cat: "Aniversários", alt: "Bolo Pokemon"              },
  { src: mickey,        cat: "Aniversários", alt: "Bolo Mickey"               },
  { src: baptism,       cat: "Batismos",     alt: "Decoração floral batismo"  },
  { src: baptismTable,  cat: "Batismos",     alt: "Mesa decorada batismo"     },
  { src: sunflowers,    cat: "1ª Comunhão",  alt: "Decoração girassóis"       },
  { src: floral,        cat: "1ª Comunhão",  alt: "Arranjo floral elegante"   },
  { src: wedding,       cat: "Casamentos",   alt: "Bouquet de noiva"          },
  { src: grad,          cat: "Outros",       alt: "Decoração formatura"       },
  { src: babyshower,    cat: "Babyshower",   alt: "Babyshower"                },
  { src: crisma,        cat: "Crismas",      alt: "Crisma"                    },
];

const cats = ["Todos", "Aniversários", "Batismos", "Casamentos", "Babyshower", "1ª Comunhão", "Crismas", "Outros"];

const Galeria = () => {
  const [filter,  setFilter]  = useState("Todos");
  const [open,    setOpen]    = useState<number | null>(null);
  const [visible, setVisible] = useState(false);

  const filtered = filter === "Todos" ? photos : photos.filter(p => p.cat === filter);

  // Fade in on mount
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 30);
    return () => clearTimeout(t);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    if (open === null) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") setOpen(i => i !== null ? (i + 1) % filtered.length : null);
      if (e.key === "ArrowLeft")  setOpen(i => i !== null ? (i - 1 + filtered.length) % filtered.length : null);
      if (e.key === "Escape")     setOpen(null);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, filtered.length]);

  const prev = () => setOpen(i => i !== null ? (i - 1 + filtered.length) % filtered.length : null);
  const next = () => setOpen(i => i !== null ? (i + 1) % filtered.length : null);

  return (
    <>
      {/* ── Hero ── */}
      <section className="pt-32 pb-12 bg-gradient-champagne text-center">
        <div className="container">
          <p className="font-script text-2xl text-primary mb-2">Os nossos trabalhos</p>
          <h1 className="font-display text-5xl md:text-6xl">Galeria</h1>
          <p className="text-muted-foreground mt-4 max-w-md mx-auto text-base">
            Cada detalhe contado através das nossas criações.
          </p>
        </div>
      </section>

      {/* ── Filter bar ── */}
      <section className="sticky top-0 z-20 bg-white/80 backdrop-blur-xl border-b border-border py-4 shadow-sm">
        <div className="container">
          <div className="flex flex-wrap justify-center gap-2">
            {cats.map(c => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  filter === c
                    ? "bg-gradient-gold text-primary-foreground shadow-gold scale-105"
                    : "bg-secondary text-foreground hover:bg-muted hover:scale-[1.02]"
                }`}
              >
                {c}
                {filter === c && (
                  <span className="ml-2 text-[10px] font-bold opacity-70">
                    {filtered.length}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Grid ── */}
      <section className="py-16 bg-gradient-champagne min-h-[60vh]">
        <div className="container">
          {/* Count */}
          <p className="text-center text-xs text-muted-foreground uppercase tracking-widest mb-8 font-medium">
            {filtered.length} {filtered.length === 1 ? "fotografia" : "fotografias"}
          </p>

          <div
            className="columns-2 md:columns-3 lg:columns-4 gap-3 space-y-3"
            style={{ opacity: visible ? 1 : 0, transition: "opacity 0.4s ease" }}
          >
            {filtered.map((p, i) => (
              <button
                key={`${p.src}-${i}`}
                onClick={() => setOpen(i)}
                className="group relative block w-full overflow-hidden rounded-xl break-inside-avoid shadow-soft hover:shadow-elegant transition-all duration-300 hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                aria-label={`Ver ${p.alt}`}
              >
                <img
                  src={p.src}
                  alt={p.alt}
                  loading="lazy"
                  className="w-full h-auto object-cover group-hover:scale-[1.04] transition-transform duration-500"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <span className="text-white text-xs font-semibold tracking-wide">{p.alt}</span>
                  <div className="mt-0.5">
                    <span className="inline-block bg-white/20 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded-full border border-white/30">
                      {p.cat}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-20 text-muted-foreground">
              <p className="text-lg font-display">Sem fotografias nesta categoria</p>
            </div>
          )}
        </div>
      </section>

      {/* ── Lightbox ── */}
      {open !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: "rgba(0,0,0,0.92)", backdropFilter: "blur(12px)" }}
          onClick={() => setOpen(null)}
        >
          {/* Close */}
          <button
            onClick={() => setOpen(null)}
            className="absolute top-5 right-5 h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors backdrop-blur-sm border border-white/10 z-10"
            aria-label="Fechar"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Counter */}
          <div className="absolute top-5 left-1/2 -translate-x-1/2 bg-white/10 backdrop-blur-sm text-white text-xs font-medium px-4 py-1.5 rounded-full border border-white/10">
            {open + 1} / {filtered.length}
          </div>

          {/* Prev */}
          {filtered.length > 1 && (
            <button
              onClick={e => { e.stopPropagation(); prev(); }}
              className="absolute left-4 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors backdrop-blur-sm border border-white/10"
              aria-label="Anterior"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
          )}

          {/* Image */}
          <div
            className="flex flex-col items-center gap-3 px-20"
            onClick={e => e.stopPropagation()}
          >
            <img
              src={filtered[open].src}
              alt={filtered[open].alt}
              className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl object-contain"
              style={{ transition: "opacity 0.2s ease" }}
            />
            <div className="text-center">
              <p className="text-white font-medium text-sm">{filtered[open].alt}</p>
              <p className="text-white/50 text-xs mt-0.5">{filtered[open].cat}</p>
            </div>
          </div>

          {/* Next */}
          {filtered.length > 1 && (
            <button
              onClick={e => { e.stopPropagation(); next(); }}
              className="absolute right-4 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors backdrop-blur-sm border border-white/10"
              aria-label="Próxima"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          )}

          {/* Thumbnails strip */}
          {filtered.length > 1 && (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/10 max-w-[90vw] overflow-x-auto">
              {filtered.map((p, i) => (
                <button
                  key={i}
                  onClick={e => { e.stopPropagation(); setOpen(i); }}
                  className={`shrink-0 h-8 w-8 rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                    i === open ? "border-white scale-110" : "border-transparent opacity-50 hover:opacity-80"
                  }`}
                  aria-label={p.alt}
                >
                  <img src={p.src} alt={p.alt} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default Galeria;
