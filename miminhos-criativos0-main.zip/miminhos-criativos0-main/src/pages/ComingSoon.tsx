import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Sparkles, LogIn, Mail, Phone } from "lucide-react";

export const ComingSoon = () => {
  const [s, setS] = useState<{ title: string; message: string; phone?: string; email?: string } | null>(null);

  useEffect(() => {
    supabase.from("site_settings").select("coming_soon_title, coming_soon_message, contact_phone, contact_email").eq("id", 1).maybeSingle()
      .then(({ data }) => setS({
        title: data?.coming_soon_title || "Site brevemente disponível",
        message: data?.coming_soon_message || "Estamos a preparar algo especial para si.",
        phone: data?.contact_phone || "926 992 352",
        email: data?.contact_email || undefined,
      }));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-champagne relative overflow-hidden flex items-center justify-center p-6">
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-primary/30 blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-accent/30 blur-3xl" />
      </div>

      <div className="relative z-10 text-center max-w-2xl animate-in fade-in slide-in-from-bottom-4 duration-700">
        <Logo className="h-32 mx-auto mb-8 drop-shadow-lg" variant="dark" />

        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-xs uppercase tracking-widest mb-6">
          <Sparkles className="h-3 w-3" />
          Em construção
        </div>

        <h1 className="font-display text-5xl md:text-7xl mb-4 leading-tight">
          {s?.title || "Site brevemente disponível"}
        </h1>
        <p className="font-script text-3xl text-primary mb-6">Algo especial está a chegar</p>
        <p className="text-muted-foreground text-lg mb-10 max-w-lg mx-auto">
          {s?.message}
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center mb-10">
          <Button asChild size="lg" className="bg-gradient-gold shadow-elegant">
            <Link to="/colaborador/login"><LogIn className="h-4 w-4 mr-2" />Entrar como Colaborador</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <a href={`https://wa.me/351${(s?.phone || "926992352").replace(/\D/g,"")}`} target="_blank" rel="noreferrer">
              <Phone className="h-4 w-4 mr-2" />WhatsApp {s?.phone}
            </a>
          </Button>
        </div>

        {s?.email && (
          <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
            <Mail className="h-4 w-4" />{s.email}
          </p>
        )}

        <div className="mt-12 pt-6 border-t border-primary/20 text-xs text-muted-foreground">
          Miminhos Criativos · Funchal, Madeira · © {new Date().getFullYear()}
        </div>
      </div>
    </div>
  );
};

export default ComingSoon;
