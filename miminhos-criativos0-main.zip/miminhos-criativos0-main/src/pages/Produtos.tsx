import { useState } from "react";
import cake from "@/assets/cake-benfica.jpg";
import cookies from "@/assets/cake-mickey.jpg";
import brigadeiros from "@/assets/487308681_1062626702556812_149208961506037299_n.jpg";
import invites from "@/assets/crisma.jpg";

const products = [
  { icon: "🎂", name: "Bolos Decorados", desc: "Bolos personalizados com qualquer tema, sabor e tamanho.", img: cake },
  { icon: "🍫", name: "Brigadeiros", desc: "Brigadeiros gourmet artesanais, perfeitos para qualquer ocasião.", img: brigadeiros },
  { icon: "🍪", name: "Cookies", desc: "Cookies decoradas à mão, criativas e deliciosas.", img: cookies },
  { icon: "💌", name: "Convites", desc: "Convites personalizados que encantam desde o primeiro olhar.", img: invites },
];

const Produtos = () => {
  const [active, setActive] = useState(0);

  return (
    <>
      {/* Hero — quiet, generous, type-led */}
      <section className="pt-40 pb-24 bg-gradient-champagne text-center">
        <div className="container">
          <p className="font-script text-2xl text-primary mb-3 animate-fade-up" style={{ animationDelay: "0.05s" }}>
            Doçura e detalhe
          </p>
          <h1 className="font-display text-6xl md:text-8xl tracking-tight animate-fade-up" style={{ animationDelay: "0.15s" }}>
            Produtos
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto mt-5 text-base md:text-lg animate-fade-up" style={{ animationDelay: "0.25s" }}>
            Cada peça é feita à mão, pensada para o momento que a merece.
          </p>
        </div>
      </section>

      {/* Featured showcase — large hero image with selector, Apple product-page rhythm */}
      <section className="py-6 md:py-10">
        <div className="container">
          <div className="grid lg:grid-cols-[1.3fr_1fr] gap-8 lg:gap-14 items-center">

            {/* Big image */}
            <div className="relative aspect-[4/3] lg:aspect-[5/4] rounded-2xl overflow-hidden shadow-elegant border border-border bg-card">
              {products.map((p, i) => (
                <img
                  key={p.name}
                  src={p.img}
                  alt={p.name}
                  loading={i === 0 ? "eager" : "lazy"}
                  className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-out"
                  style={{ opacity: active === i ? 1 : 0 }}
                />
              ))}
              <div className="absolute bottom-5 left-5">
                <span className="inline-flex items-center gap-2 bg-white/90 dark:bg-black/70 backdrop-blur-sm text-foreground px-4 py-2 rounded-full text-sm font-medium shadow-sm border border-border">
                  <span className="text-lg leading-none">{products[active].icon}</span>
                  {products[active].name}
                </span>
              </div>
            </div>

            {/* Copy + selector */}
            <div className="space-y-8">
              <div>
                <p className="text-xs uppercase tracking-[0.25em] text-primary font-semibold mb-3">
                  A nossa gama
                </p>
                <h2 className="font-display text-4xl md:text-5xl leading-tight mb-4">
                  {products[active].name}
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {products[active].desc}
                </p>
              </div>

              {/* Selector list — minimal, type-forward */}
              <div className="flex flex-col divide-y divide-border border-t border-b border-border">
                {products.map((p, i) => (
                  <button
                    key={p.name}
                    onClick={() => setActive(i)}
                    className={`flex items-center justify-between py-4 text-left transition-colors duration-300 group ${
                      active === i ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <span className="text-xl leading-none">{p.icon}</span>
                      <span className={`font-display text-xl md:text-2xl transition-colors ${active === i ? "text-primary" : ""}`}>
                        {p.name}
                      </span>
                    </span>
                    <span
                      className={`h-2 w-2 rounded-full transition-all duration-300 ${
                        active === i ? "bg-primary scale-100" : "bg-border scale-75 group-hover:scale-100"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Full grid below — quiet cards, generous spacing */}
      <section className="py-24 md:py-32">
        <div className="container">
          <div className="flex items-end justify-between mb-12 flex-wrap gap-4">
            <h3 className="font-display text-3xl md:text-4xl">Toda a coleção</h3>
            <div className="flex-1 h-px bg-border ml-6 hidden md:block" />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((p) => (
              <article
                key={p.name}
                className="group bg-card rounded-2xl overflow-hidden shadow-soft hover:shadow-elegant border border-border hover:border-primary/40 transition-smooth"
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={p.img}
                    alt={p.name}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                </div>
                <div className="p-6 text-center">
                  <div className="text-3xl mb-3">{p.icon}</div>
                  <h3 className="font-display text-xl mb-2 group-hover:text-primary transition-smooth">{p.name}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Produtos;
