import { Link } from "react-router-dom";
import { ArrowRight, ChevronDown, Heart, Sparkles, Star, Quote } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import hero from "@/assets/sunflowers-event.jpg";
import g1 from "@/assets/cake-benfica.jpg";
import g2 from "@/assets/cake-pokemon.jpg";
import g3 from "@/assets/cake-mickey.jpg";
import g4 from "@/assets/wedding-bouquet.jpg";
import g5 from "@/assets/baptism-table.jpg";
import g6 from "@/assets/floral-vase.jpg";
import about from "@/assets/baptism-flowers.jpg";

const services = [
  { icon: "🎂", name: "Aniversários", desc: "Festas únicas para todas as idades" },
  { icon: "✝️", name: "Batismos",     desc: "Decoração delicada e inesquecível" },
  { icon: "🕊️", name: "1ª Comunhão", desc: "Celebrações cheias de fé e amor" },
  { icon: "🍼", name: "Babyshower",   desc: "Doçura para receber o bebé" },
  { icon: "💍", name: "Casamentos",   desc: "O dia mais especial das suas vidas" },
  { icon: "✨", name: "Crismas",       desc: "Momentos sagrados e elegantes" },
  { icon: "💛", name: "Bodas",        desc: "Aniversários de matrimónio" },
  { icon: "🎓", name: "Formaturas",   desc: "Conquistas que merecem festejar" },
];

const gallery = [g1, g2, g3, g4, g5, g6];

const testimonials = [
  { name: "Claudia Alves",   text: "Adorei o serviço e recomendo vivamente. Profissionais sempre atentos aos detalhes e sempre prontos para tornar o nosso dia o mais especial possível." },
  { name: "Diana Fernandes", text: "Recomendo muito! Profissionais e atenciosas. Decoração simples mas muito bonita e que faz toda a diferença numa comemoração." },
  { name: "Carlos Barros",   text: "Recomendo Miminhos criativos, profissionais, eficientes, decoração bonita, tudo tempo e horas obrigado por tudo." },
];

const Home = () => (
  <>
    <style>{`
      @keyframes heroDrop { from { opacity:0; transform:translateY(22px) } to { opacity:1; transform:translateY(0) } }
      @keyframes taglineDrop { from { opacity:0; transform:translateY(14px) } to { opacity:1; transform:translateY(0) } }
      @keyframes btnDrop { from { opacity:0; transform:translateY(10px) } to { opacity:1; transform:translateY(0) } }
      @keyframes imgZoom { from { transform:scale(1) } to { transform:scale(1.06) } }
      @keyframes chevFloat { 0%,100% { transform:translateX(-50%) translateY(0) } 50% { transform:translateX(-50%) translateY(7px) } }

      .hero-logo   { animation: heroDrop   0.9s cubic-bezier(0.22,1,0.36,1) 0.1s both; }
      .hero-tagline{ animation: taglineDrop 0.9s cubic-bezier(0.22,1,0.36,1) 0.3s both; }
      .hero-btn    { animation: btnDrop     0.9s cubic-bezier(0.22,1,0.36,1) 0.5s both; }
      .hero-bg     { animation: imgZoom 24s ease-in-out infinite alternate; }
      .chev        { animation: chevFloat 2.6s ease-in-out infinite; }

      /* service card */
      .svc { transition: transform 0.28s cubic-bezier(0.4,0,0.2,1), box-shadow 0.28s cubic-bezier(0.4,0,0.2,1); }
      .svc:hover { transform: translateY(-6px); box-shadow: 0 20px 56px rgba(0,0,0,0.10) !important; }
      .svc:hover .svc-icon { transform: scale(1.2); }
      .svc:hover .svc-name { color: var(--color-primary, #c9a244); }
      .svc-icon { transition: transform 0.28s cubic-bezier(0.4,0,0.2,1); display:inline-block; }
      .svc-name { transition: color 0.2s; }

      /* gallery */
      .gal-wrap { overflow:hidden; border-radius:14px; }
      .gal-wrap img { transition: transform 0.6s cubic-bezier(0.4,0,0.2,1); display:block; }
      .gal-wrap:hover img { transform: scale(1.07); }
      .gal-overlay { position:absolute; inset:0; background:linear-gradient(to top,rgba(0,0,0,0.38) 0%,transparent 55%); opacity:0; transition:opacity 0.3s; }
      .gal-wrap:hover .gal-overlay { opacity:1; }

      /* testimonial */
      .tcard { transition: transform 0.26s cubic-bezier(0.4,0,0.2,1), box-shadow 0.26s cubic-bezier(0.4,0,0.2,1); }
      .tcard:hover { transform: translateY(-4px); box-shadow: 0 14px 44px rgba(0,0,0,0.09) !important; }

      /* value pill */
      .vpill { transition: transform 0.24s, background 0.24s; }
      .vpill:hover { transform: translateY(-3px); background: #fff !important; }

      /* cta button */
      .cta-pill { transition: transform 0.22s cubic-bezier(0.4,0,0.2,1), box-shadow 0.22s; }
      .cta-pill:hover { transform: scale(1.04); }

      @media (prefers-reduced-motion: reduce) {
        .hero-logo,.hero-tagline,.hero-btn,.hero-bg,.chev,
        .svc,.svc-icon,.gal-wrap img,.gal-overlay,.tcard,.vpill,.cta-pill
        { animation:none !important; transition:none !important; }
      }
    `}</style>

    {/* ════════════════════════ HERO ════════════════════════ */}
    <section style={{ position:"relative", height:"100vh", minHeight:680, display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden" }}>

      <img
        src={hero}
        alt=""
        aria-hidden
        className="hero-bg"
        style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover", transformOrigin:"center" }}
      />

      {/* two-layer overlay: soft top, heavier bottom — keeps image visible mid-frame */}
      <div style={{ position:"absolute", inset:0, background:"linear-gradient(180deg, rgba(0,0,0,0.22) 0%, rgba(0,0,0,0.12) 40%, rgba(0,0,0,0.62) 100%)" }} />

      <div style={{ position:"relative", zIndex:10, textAlign:"center", padding:"0 24px", display:"flex", flexDirection:"column", alignItems:"center" }}>
        {/* Logo only — no text title */}
        <Logo
          className="hero-logo h-40 md:h-52"
          style={{ filter:"drop-shadow(0 6px 32px rgba(201,162,68,0.45))" }}
        />

        <p
          className="hero-tagline font-script"
          style={{ fontSize:"clamp(1.5rem,3.5vw,2.6rem)", color:"#c9a244", marginTop:28, marginBottom:48, textShadow:"0 2px 16px rgba(0,0,0,0.35)" }}
        >
          A festa é sua! O prazer em criar é nosso!
        </p>

        <div className="hero-btn">
          <Button
            asChild size="lg"
            className="bg-gradient-gold shadow-gold text-primary-foreground font-semibold cta-pill"
            style={{ borderRadius:980, padding:"14px 40px", fontSize:16, letterSpacing:"0.01em" }}
          >
            <Link to="/orcamento">
              Pedir Orçamento <ArrowRight style={{ marginLeft:8, width:17, height:17 }} />
            </Link>
          </Button>
        </div>
      </div>

      <ChevronDown
        className="chev"
        style={{ position:"absolute", bottom:30, left:"50%", width:26, height:26, color:"rgba(255,255,255,0.55)", zIndex:10, cursor:"default" }}
      />
    </section>

    {/* ════════════════════════ SERVICES ════════════════════════ */}
    <section style={{ padding:"112px 0", background:"#fff" }}>
      <div style={{ maxWidth:1080, margin:"0 auto", padding:"0 24px" }}>

        <div style={{ textAlign:"center", marginBottom:64 }}>
          <p style={{ fontSize:12, fontWeight:600, letterSpacing:"0.18em", textTransform:"uppercase", color:"#c9a244", marginBottom:10 }}>O que fazemos</p>
          <h2 className="font-display" style={{ fontSize:"clamp(1.9rem,3.8vw,2.8rem)", fontWeight:700, color:"#1d1d1f", letterSpacing:"-0.025em", lineHeight:1.1 }}>Os Nossos Serviços</h2>
          <div style={{ width:36, height:2, background:"linear-gradient(90deg,#c9a244,rgba(201,162,68,0))", borderRadius:2, margin:"18px auto 0" }} />
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(210px,1fr))", gap:14 }}>
          {services.map((s) => (
            <div
              key={s.name}
              className="svc"
              style={{ background:"#f5f5f7", borderRadius:16, padding:"30px 22px 26px", textAlign:"center", cursor:"default", boxShadow:"0 1px 4px rgba(0,0,0,0.04)" }}
            >
              <span className="svc-icon" style={{ fontSize:42, marginBottom:14, display:"inline-block" }}>{s.icon}</span>
              <h3 className="svc-name font-display" style={{ fontSize:18, fontWeight:600, color:"#1d1d1f", marginBottom:7 }}>{s.name}</h3>
              <p style={{ fontSize:13.5, color:"#6e6e73", lineHeight:1.55, margin:0 }}>{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* ════════════════════════ GALLERY ════════════════════════ */}
    <section style={{ padding:"112px 0", background:"#f5f5f7" }}>
      <div style={{ maxWidth:1080, margin:"0 auto", padding:"0 24px" }}>

        <div style={{ textAlign:"center", marginBottom:64 }}>
          <p style={{ fontSize:12, fontWeight:600, letterSpacing:"0.18em", textTransform:"uppercase", color:"#c9a244", marginBottom:10 }}>Inspirações</p>
          <h2 className="font-display" style={{ fontSize:"clamp(1.9rem,3.8vw,2.8rem)", fontWeight:700, color:"#1d1d1f", letterSpacing:"-0.025em", lineHeight:1.1 }}>Galeria</h2>
          <div style={{ width:36, height:2, background:"linear-gradient(90deg,#c9a244,rgba(201,162,68,0))", borderRadius:2, margin:"18px auto 0" }} />
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gridTemplateRows:"repeat(2,260px)", gap:10 }}>
          {gallery.map((src, i) => (
            <div
              key={i}
              className="gal-wrap"
              style={{ position:"relative", gridRow:i===0?"1/3":undefined, cursor:"pointer" }}
            >
              <img src={src} alt={`Trabalho realizado ${i+1}`} loading="lazy" style={{ width:"100%", height:"100%", objectFit:"cover" }} />
              <div className="gal-overlay" />
            </div>
          ))}
        </div>

        <div style={{ textAlign:"center", marginTop:44 }}>
          <Button
            asChild variant="outline"
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground cta-pill"
            style={{ borderRadius:980, padding:"10px 32px", fontSize:14 }}
          >
            <Link to="/galeria">Ver Galeria Completa</Link>
          </Button>
        </div>
      </div>
    </section>

    {/* ════════════════════════ ABOUT ════════════════════════ */}
    <section style={{ padding:"112px 0", background:"#fff" }}>
      <div style={{ maxWidth:1080, margin:"0 auto", padding:"0 24px", display:"grid", gridTemplateColumns:"1fr 1fr", gap:72, alignItems:"center" }}
        className="grid-cols-1 md:grid-cols-2">

        <div style={{ position:"relative" }}>
          <img
            src={about}
            alt="Sobre Miminhos Criativos"
            loading="lazy"
            style={{ borderRadius:20, width:"100%", aspectRatio:"4/5", objectFit:"cover", display:"block", boxShadow:"0 24px 72px rgba(0,0,0,0.13)" }}
          />
          {/* floating years badge */}
          <div
            style={{ position:"absolute", bottom:-16, right:-16, background:"linear-gradient(135deg,#c9a244,#ddb96a)", color:"#fff", padding:"22px 26px", borderRadius:14, boxShadow:"0 10px 36px rgba(201,162,68,0.4)", lineHeight:1.15 }}
            className="hidden md:block"
          >
            <p className="font-script" style={{ fontSize:20 }}>Mais de</p>
            <p className="font-display" style={{ fontSize:36, fontWeight:700 }}>8 anos</p>
            <p style={{ fontSize:12, opacity:.88, marginTop:2 }}>a criar momentos únicos</p>
          </div>
        </div>

        <div>
          <p style={{ fontSize:12, fontWeight:600, letterSpacing:"0.18em", textTransform:"uppercase", color:"#c9a244", marginBottom:10 }}>Sobre Nós</p>
          <h2 className="font-display" style={{ fontSize:"clamp(1.9rem,3.8vw,2.8rem)", fontWeight:700, color:"#1d1d1f", letterSpacing:"-0.025em", lineHeight:1.1, marginBottom:22 }}>Quem somos</h2>
          <p style={{ fontSize:16, color:"#6e6e73", lineHeight:1.72, marginBottom:14 }}>
            Somos uma equipa apaixonada por criar momentos inesquecíveis na bela ilha da Madeira. Cada evento é único e tratamos cada cliente com a dedicação que merece.
          </p>
          <p style={{ fontSize:16, color:"#6e6e73", lineHeight:1.72, marginBottom:44 }}>
            Da decoração aos pequenos detalhes, fazemos da sua festa uma verdadeira obra de arte.
          </p>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10 }}>
            {[
              { icon: Sparkles, label: "Criatividade" },
              { icon: Heart,    label: "Dedicação"    },
              { icon: Star,     label: "Qualidade"    },
            ].map((v) => (
              <div key={v.label} className="vpill" style={{ textAlign:"center", padding:"22px 10px", background:"#f5f5f7", borderRadius:12, cursor:"default" }}>
                <v.icon style={{ width:26, height:26, margin:"0 auto 10px", color:"#c9a244" }} />
                <p className="font-display" style={{ fontSize:13, fontWeight:600, color:"#1d1d1f" }}>{v.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>

    {/* ════════════════════════ TESTIMONIALS ════════════════════════ */}
    <section style={{ padding:"112px 0", background:"#f5f5f7" }}>
      <div style={{ maxWidth:960, margin:"0 auto", padding:"0 24px" }}>

        <div style={{ textAlign:"center", marginBottom:64 }}>
          <p style={{ fontSize:12, fontWeight:600, letterSpacing:"0.18em", textTransform:"uppercase", color:"#c9a244", marginBottom:10 }}>O que dizem</p>
          <h2 className="font-display" style={{ fontSize:"clamp(1.9rem,3.8vw,2.8rem)", fontWeight:700, color:"#1d1d1f", letterSpacing:"-0.025em", lineHeight:1.1 }}>Testemunhos</h2>
          <div style={{ width:36, height:2, background:"linear-gradient(90deg,#c9a244,rgba(201,162,68,0))", borderRadius:2, margin:"18px auto 0" }} />
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:16 }}>
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="tcard"
              style={{ background:"#fff", borderRadius:16, padding:"34px 28px", boxShadow:"0 2px 12px rgba(0,0,0,0.05)", display:"flex", flexDirection:"column" }}
            >
              <Quote style={{ width:26, height:26, color:"#c9a244", marginBottom:14, opacity:.7, flexShrink:0 }} />
              <div style={{ display:"flex", gap:3, marginBottom:16 }}>
                {[...Array(5)].map((_,i) => <Star key={i} style={{ width:13, height:13, fill:"#c9a244", color:"#c9a244" }} />)}
              </div>
              <p style={{ fontSize:14.5, color:"#6e6e73", fontStyle:"italic", lineHeight:1.7, flex:1, marginBottom:20 }}>"{t.text}"</p>
              <p className="font-display" style={{ fontSize:14, fontWeight:600, color:"#1d1d1f" }}>— {t.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* ════════════════════════ CTA ════════════════════════ */}
    <section style={{ padding:"112px 0", background:"#1d1d1f", position:"relative", overflow:"hidden" }}>
      {/* single centered radial — restrained, not decorative noise */}
      <div style={{ position:"absolute", top:"50%", left:"50%", transform:"translate(-50%,-50%)", width:700, height:500, background:"radial-gradient(ellipse, rgba(201,162,68,0.15) 0%, transparent 68%)", pointerEvents:"none" }} />

      <div style={{ maxWidth:680, margin:"0 auto", padding:"0 24px", textAlign:"center", position:"relative", zIndex:1 }}>
        <p className="font-script" style={{ fontSize:26, color:"#c9a244", marginBottom:12 }}>Pronta para começar?</p>
        <h2 className="font-display" style={{ fontSize:"clamp(2rem,5vw,3.6rem)", fontWeight:700, color:"#f5f5f7", letterSpacing:"-0.03em", lineHeight:1.08, marginBottom:20 }}>
          Vamos criar juntas?
        </h2>
        <p style={{ fontSize:17, color:"rgba(245,245,247,0.55)", lineHeight:1.65, marginBottom:48 }}>
          Conte-nos a sua ideia e nós tratamos de todos os detalhes para que o seu evento seja perfeito.
        </p>
        <Button
          asChild size="lg"
          className="bg-gradient-gold shadow-gold text-primary-foreground font-semibold cta-pill"
          style={{ borderRadius:980, padding:"15px 44px", fontSize:16, letterSpacing:"0.01em" }}
        >
          <Link to="/orcamento">Pedir Orçamento <ArrowRight style={{ marginLeft:8, width:17, height:17 }} /></Link>
        </Button>
      </div>
    </section>
  </>
);

export default Home;
