import { Logo } from "@/components/Logo";
import about from "@/assets/baptism-flowers.jpg";
import team from "@/assets/floral-vase.jpg";
import { Heart, Sparkles, Star } from "lucide-react";

const Sobre = () => (
  <>
    <style>{`
      @keyframes sobrefade { from{opacity:0;transform:translateY(18px)} to{opacity:1;transform:translateY(0)} }
      .sobre-hero-content { animation: sobrefade 1s cubic-bezier(0.22,1,0.36,1) 0.1s both; }
      .val-card { transition: transform 0.26s cubic-bezier(0.4,0,0.2,1), box-shadow 0.26s; }
      .val-card:hover { transform: translateY(-6px); box-shadow: 0 20px 52px rgba(0,0,0,0.09) !important; }
      .val-card:hover .val-icon { transform: scale(1.18); }
      .val-icon { transition: transform 0.26s cubic-bezier(0.4,0,0.2,1); }
      @media(prefers-reduced-motion:reduce){ .sobre-hero-content,.val-card,.val-icon{animation:none!important;transition:none!important;} }
    `}</style>

    {/* ── Hero ─────────────────────────────────────────────────────────── */}
    <section style={{ position:"relative", height:"52vh", minHeight:420, display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden" }}>
      <img
        src={about}
        alt="Sobre Miminhos Criativos"
        style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover" }}
      />
      <div style={{ position:"absolute", inset:0, background:"linear-gradient(180deg, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.62) 100%)" }} />
      <div className="sobre-hero-content" style={{ position:"relative", zIndex:10, textAlign:"center", paddingTop:80 }}>
        <p className="font-script" style={{ fontSize:"clamp(1.4rem,3vw,2.2rem)", color:"#c9a244", marginBottom:10, textShadow:"0 2px 12px rgba(0,0,0,0.35)" }}>
          A nossa história
        </p>
        <h1 className="font-display" style={{ fontSize:"clamp(2.4rem,6vw,4rem)", fontWeight:700, color:"#fff", letterSpacing:"-0.025em", lineHeight:1.08 }}>
          Sobre Nós
        </h1>
      </div>
    </section>

    {/* ── Story ────────────────────────────────────────────────────────── */}
    <section style={{ padding:"112px 0", background:"#fff" }}>
      <div style={{ maxWidth:1040, margin:"0 auto", padding:"0 24px", display:"grid", gridTemplateColumns:"1fr 1fr", gap:72, alignItems:"center" }}
        className="grid-cols-1 md:grid-cols-2">
        <div>
          <p style={{ fontSize:12, fontWeight:600, letterSpacing:"0.18em", textTransform:"uppercase", color:"#c9a244", marginBottom:10 }}>
            A nossa essência
          </p>
          <h2 className="font-display" style={{ fontSize:"clamp(1.8rem,3.5vw,2.6rem)", fontWeight:700, color:"#1d1d1f", letterSpacing:"-0.025em", lineHeight:1.1, marginBottom:22 }}>
            Onde tudo começou
          </h2>
          <p style={{ fontSize:16, color:"#6e6e73", lineHeight:1.75, marginBottom:16 }}>
            A Miminhos Criativos nasceu na Madeira do desejo de transformar momentos especiais em memórias eternas. Cada flor, cada laço, cada detalhe é cuidadosamente pensado para refletir a essência de quem celebra.
          </p>
          <p style={{ fontSize:16, color:"#6e6e73", lineHeight:1.75 }}>
            Acreditamos que cada evento conta uma história única, e é com muito carinho que damos vida a essas histórias.
          </p>
        </div>

        <div style={{ position:"relative" }}>
          <img
            src={team}
            alt="Equipa Miminhos Criativos"
            style={{ borderRadius:20, width:"100%", aspectRatio:"1/1", objectFit:"cover", display:"block", boxShadow:"0 24px 72px rgba(0,0,0,0.12)" }}
          />
          {/* subtle decorative frame offset */}
          <div style={{ position:"absolute", inset:0, borderRadius:20, border:"1.5px solid rgba(201,162,68,0.22)", transform:"translate(10px,10px)", zIndex:-1, pointerEvents:"none" }} />
        </div>
      </div>
    </section>

    {/* ── Quote ────────────────────────────────────────────────────────── */}
    <section style={{ padding:"96px 24px", background:"#f5f5f7", textAlign:"center" }}>
      <div style={{ maxWidth:640, margin:"0 auto" }}>
        <Logo
          className="h-20 mx-auto mb-10"
          variant="dark"
          style={{ opacity:.85 }}
        />
        {/* quote mark */}
        <div style={{ fontSize:80, lineHeight:.7, color:"#c9a244", opacity:.25, marginBottom:8, fontFamily:"Georgia,serif" }}>"</div>
        <p className="font-script" style={{ fontSize:"clamp(1.8rem,4vw,3rem)", color:"#c9a244", lineHeight:1.4 }}>
          A festa é sua!<br />O prazer em criar é nosso!
        </p>
        <div style={{ width:36, height:2, background:"linear-gradient(90deg,#c9a244,rgba(201,162,68,0))", borderRadius:2, margin:"28px auto 0" }} />
      </div>
    </section>

    {/* ── Values ───────────────────────────────────────────────────────── */}
    <section style={{ padding:"112px 0", background:"#fff" }}>
      <div style={{ maxWidth:880, margin:"0 auto", padding:"0 24px" }}>
        <div style={{ textAlign:"center", marginBottom:64 }}>
          <p style={{ fontSize:12, fontWeight:600, letterSpacing:"0.18em", textTransform:"uppercase", color:"#c9a244", marginBottom:10 }}>
            O que nos guia
          </p>
          <h2 className="font-display" style={{ fontSize:"clamp(1.8rem,3.5vw,2.6rem)", fontWeight:700, color:"#1d1d1f", letterSpacing:"-0.025em", lineHeight:1.1 }}>
            Os Nossos Valores
          </h2>
          <div style={{ width:36, height:2, background:"linear-gradient(90deg,#c9a244,rgba(201,162,68,0))", borderRadius:2, margin:"18px auto 0" }} />
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))", gap:16 }}>
          {[
            { icon: Sparkles, title: "Criatividade", desc: "Cada projeto é uma obra única, pensada ao detalhe." },
            { icon: Heart,    title: "Dedicação",    desc: "Tratamos cada cliente como família." },
            { icon: Star,     title: "Qualidade",    desc: "Excelência em tudo o que fazemos." },
          ].map((v) => (
            <div
              key={v.title}
              className="val-card"
              style={{ textAlign:"center", padding:"44px 28px 36px", background:"#f5f5f7", borderRadius:18, boxShadow:"0 2px 8px rgba(0,0,0,0.04)", cursor:"default" }}
            >
              <div className="val-icon" style={{ marginBottom:20 }}>
                <v.icon style={{ width:40, height:40, color:"#c9a244", margin:"0 auto" }} />
              </div>
              <h3 className="font-display" style={{ fontSize:20, fontWeight:700, color:"#1d1d1f", marginBottom:10 }}>{v.title}</h3>
              <p style={{ fontSize:14.5, color:"#6e6e73", lineHeight:1.6, margin:0 }}>{v.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Sobre;
