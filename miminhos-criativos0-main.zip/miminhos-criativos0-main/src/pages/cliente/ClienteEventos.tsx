import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { Calendar, MapPin, Users, Receipt, FileText, CheckCircle2, Clock, AlertCircle } from "lucide-react";

const statusColor: Record<string, string> = {
  pendente:   "bg-amber-100 text-amber-700",
  confirmado: "bg-green-100 text-green-700",
  cancelado:  "bg-red-100 text-red-700",
  concluido:  "bg-blue-100 text-blue-700",
};

const ClienteEventos = () => {
  const { user } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("events")
      .select("*")
      .eq("client_id", user.id)
      .order("event_date")
      .then(({ data }) => setEvents(data ?? []));
  }, [user]);

  return (
    <div>
      <h1 className="font-display text-3xl mb-6">Os meus eventos</h1>
      {events.length === 0 ? (
        <div className="bg-card border rounded-lg p-10 text-center shadow-soft">
          <p className="font-script text-2xl text-primary mb-2">Sem eventos ainda</p>
          <p className="text-muted-foreground">
            Quando a equipa Miminhos criar o seu evento, aparecerá aqui com todos os detalhes.
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {events.map((e) => {
            let valorOrcamento: number | null = null;
            if (e.orcamento) {
              try {
                const orc = typeof e.orcamento === "string" ? JSON.parse(e.orcamento) : e.orcamento;
                if (orc?.total) valorOrcamento = orc.total;
              } catch { /* ignore */ }
            } else if (e.budget != null) {
              valorOrcamento = Number(e.budget);
            }

            return (
              <div key={e.id} className="bg-card border rounded-lg shadow-soft p-5">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <h2 className="font-display text-xl">{e.title}</h2>
                    <p className="text-sm text-muted-foreground mt-0.5">{e.event_type}</p>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium capitalize flex items-center gap-1.5 ${statusColor[e.status] ?? "bg-muted text-muted-foreground"}`}>
                    {e.status}
                  </span>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{e.event_date ? format(new Date(e.event_date), "dd 'de' MMMM yyyy", { locale: pt }) : "Data por definir"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{e.location || "Local por definir"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{e.guests_count != null ? `${e.guests_count} convidados` : "Convidados por definir"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Receipt className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{valorOrcamento != null ? `${valorOrcamento.toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €` : "Orçamento por definir"}</span>
                  </div>
                </div>
                {e.notes && (
                  <div className="mt-3 flex items-start gap-2 bg-muted/40 p-3 rounded-md">
                    <FileText className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                    <p className="text-sm">{e.notes}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ClienteEventos;
