import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { Send, MessageSquare } from "lucide-react";
import { toast } from "sonner";

const ClienteMensagens = () => {
  const { user } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const [staff, setStaff] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [body, setBody] = useState("");

  useEffect(() => {
    (async () => {
      const { data: roles } = await supabase.from("user_roles").select("user_id, role").in("role", ["admin", "colaborador"]);
      const ids = Array.from(new Set((roles ?? []).map((r) => r.user_id)));
      if (!ids.length) return;
      const { data: profs } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
      setStaff(profs ?? []);
    })();
  }, []);

  useEffect(() => {
    if (!user) return;
    supabase.from("messages").select("*")
      .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
      .order("created_at").then(({ data }) => setMessages(data ?? []));
    const ch = supabase.channel(`msg-cliente-${user.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (p: any) => {
        const m = p.new;
        if (m.sender_id === user.id || m.recipient_id === user.id)
          setMessages((prev) => [...prev, m]);
      }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const send = async () => {
    if (!body.trim() || !user) return;
    const recipient_id = staff[0]?.id;
    if (!recipient_id) return toast.error("Sem equipa disponível");
    const { error } = await supabase.from("messages").insert({ sender_id: user.id, recipient_id, body });
    if (error) return toast.error(error.message);
    setBody("");
  };

  return (
    <div>
      <h1 className="font-display text-3xl mb-1">Mensagens</h1>
      <p className="text-sm text-muted-foreground mb-6">Fale diretamente com a equipa Miminhos.</p>
      <div className="bg-card border rounded-lg shadow-soft flex flex-col min-h-[500px]">
        <div className="flex-1 p-4 space-y-2 overflow-y-auto max-h-[500px]">
          {messages.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <MessageSquare className="h-10 w-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm">Sem mensagens ainda. Diga olá! 💛</p>
            </div>
          )}
          {messages.map((m) => (
            <div key={m.id} className={`max-w-[75%] p-3 rounded-lg text-sm ${m.sender_id === user?.id ? "bg-primary text-primary-foreground ml-auto" : "bg-muted"}`}>
              <p className="whitespace-pre-wrap">{m.body}</p>
              <p className="text-[10px] opacity-70 mt-1">{format(new Date(m.created_at), "dd/MM HH:mm")}</p>
            </div>
          ))}
        </div>
        <div className="p-3 border-t flex gap-2">
          <Textarea rows={2} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Escreva uma mensagem…" />
          <Button onClick={send} className="bg-gradient-gold self-end"><Send className="h-4 w-4" /></Button>
        </div>
      </div>
    </div>
  );
};

export default ClienteMensagens;
