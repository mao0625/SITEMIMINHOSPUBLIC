import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Calendar, FileText, Bell, ArrowRight, Sparkles, Clock, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

const ClienteDashboard = () => {
  const { user } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const [events, setEvents] = useState<any[]>([]);
  const [pendingQ, setPendingQ] = useState<any>(null);
  const [totalQ, setTotalQ] = useState(0);

  useEffect(() => {
    if (!user) return;
    supabase.from("events").select("*").eq("client_id", user.id).order("event_date")
      .then(({ data }) => setEvents(data ?? []));
    supabase.from("questionnaires").select("*").eq("client_id", user.id).order("created_at", { ascending: false })
      .then(({ data }) => {
        const all = data ?? [];
        setTotalQ(all.length);
        setPendingQ(all.find((q) => q.status === "pendente") ?? null);
      });
  }, [user]);

  const name = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "Cliente";

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold uppercase tracking-widest mb-4">
          <Sparkles className="h-3.5 w-3.5" /> Área Exclusiva
        </div>
        <h1 className="text-4xl md:text-5xl font-light text-foreground tracking-tight mb-2">
          Bem-vindo(a), <span className="font-semibold text-primary">{name}</span>.
        </h1>
        <p className="text-lg text-muted-foreground font-medium">
          Acompanhe todos os detalhes e planeamento do seu evento.
        </p>
      </div>

      {pendingQ && (
        <Link to="/cliente/questionario" className="group relative overflow-hidden flex flex-col sm:flex-row sm:items-center gap-5 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-2xl p-6 mb-10 hover:border-primary/40 transition-all duration-500 shadow-sm hover:shadow-md">
          <div className="bg-background/80 backdrop-blur-sm p-3 rounded-xl shadow-sm border border-primary/10 shrink-0">
            <Bell className="h-6 w-6 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-foreground text-lg mb-1">Dossier de Orçamento Aguarda Resposta</h3>
            <p className="text-sm text-muted-foreground">A nossa equipa preparou um novo questionário para afinar os detalhes do seu evento.</p>
          </div>
          <div className="flex items-center gap-2 text-sm font-semibold text-primary">
            Preencher Agora <ArrowRight className="h-4 w-4" />
          </div>
        </Link>
      )}

      <div className="grid sm:grid-cols-3 gap-6 mb-12">
        <Link to="/cliente/eventos" className="group bg-card/40 p-6 rounded-2xl border border-border/50 hover:border-primary/40 hover:bg-card transition-all duration-300 hover:-translate-y-1">
          <div className="bg-primary/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
            <Calendar className="h-6 w-6 text-primary" />
          </div>
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-1">Os Meus Eventos</h4>
          <p className="text-3xl font-light text-foreground group-hover:text-primary transition-colors">{events.length}</p>
        </Link>

        <Link to="/cliente/questionario" className="group bg-card/40 p-6 rounded-2xl border border-border/50 hover:border-primary/40 hover:bg-card transition-all duration-300 hover:-translate-y-1">
          <div className="bg-primary/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
            <FileText className="h-6 w-6 text-primary" />
          </div>
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-1">Orçamentos</h4>
          <p className="text-3xl font-light text-foreground group-hover:text-primary transition-colors">{totalQ}</p>
        </Link>

        <Link to="/cliente/confirmados" className="group bg-card/40 p-6 rounded-2xl border border-border/50 hover:border-primary/40 hover:bg-card transition-all duration-300 hover:-translate-y-1">
          <div className="bg-primary/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
            <CheckCircle2 className="h-6 w-6 text-primary" />
          </div>
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-1">Confirmados</h4>
          <p className="text-3xl font-light text-foreground group-hover:text-primary transition-colors">{events.filter(e => e.status === "confirmado").length}</p>
        </Link>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" /> Próximos Eventos
        </h2>
        <div className="bg-card/30 rounded-2xl border border-border/50 overflow-hidden shadow-sm">
          {events.length === 0 ? (
            <div className="p-12 text-center">
              <Calendar className="h-10 w-10 mx-auto text-muted-foreground/40 mb-4" />
              <p className="text-muted-foreground font-medium mb-2">Ainda não tem eventos agendados.</p>
              <Link to="/orcamento" className="inline-flex items-center gap-2 text-sm text-primary font-semibold hover:text-primary/80">
                Solicitar um novo orçamento <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-border/30">
              {events.map((e) => (
                <div key={e.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-muted/20 transition-colors">
                  <div>
                    <h3 className="font-semibold text-foreground text-lg mb-1">{e.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      {e.event_date ? format(new Date(e.event_date), "d 'de' MMMM, yyyy", { locale: pt }) : "Data a definir"}
                    </p>
                  </div>
                  <span className="text-xs font-semibold px-3 py-1.5 rounded-full bg-primary/10 text-primary capitalize border border-primary/20">
                    {e.status === "pendente" ? "Aguardar Aprovação" : e.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ClienteDashboard;
