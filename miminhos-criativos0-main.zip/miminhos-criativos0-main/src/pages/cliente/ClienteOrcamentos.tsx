import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { FileText, Trash2, Eye, Send, Save, CheckCircle2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { QUESTIONNAIRE_SECTIONS } from "@/lib/questionnaire";

interface OrcamentoItem {
  descricao: string;
  quantidade: number;
  preco_unitario: number;
}

interface Orcamento {
  items?: OrcamentoItem[];
  notas?: string;
  validade_dias?: number;
  total?: number;
  criado_em?: string;
}

interface QuoteRequest {
  id: string;
  name: string;
  email: string;
  phone: string;
  event_type: string;
  event_date: string | null;
  guests_count: number | null;
  message: string | null;
  status: string;
  created_at: string;
}

interface Questionnaire {
  id: string;
  client_id: string;
  orcamento?: string | Orcamento;
  reference_number?: string;
  status: string;
  answers?: Record<string, any>;
  created_at: string;
  submitted_at?: string;
}

// ─── Editor de campo ──────────────────────────────────────────────────────────
const FieldEditor = ({
  field, value, onChange, readOnly,
}: {
  field: any; value: any; onChange: (v: any) => void; readOnly: boolean;
}) => {
  if (field.type === "static") return (
    <p className="text-xs text-muted-foreground italic">{field.label}</p>
  );
  if (readOnly) {
    const display = Array.isArray(value) ? value.join(", ") : (value ?? "—");
    return <p className="text-sm text-foreground">{display || "—"}</p>;
  }
  if (field.type === "textarea") return (
    <Textarea value={value ?? ""} onChange={(e) => onChange(e.target.value)}
      rows={3} className="text-sm" placeholder="A sua resposta..." />
  );
  if (field.type === "select" || field.type === "radio") return (
    <div className="flex flex-wrap gap-2">
      {field.options?.map((opt: string) => (
        <button key={opt} type="button" onClick={() => onChange(opt)}
          className={`px-3 py-1.5 rounded-full text-sm border transition-all ${
            value === opt ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"
          }`}>{opt}</button>
      ))}
    </div>
  );
  if (field.type === "checkbox") return (
    <div className="flex flex-wrap gap-2">
      {field.options?.map((opt: string) => {
        const arr: string[] = Array.isArray(value) ? value : [];
        const checked = arr.includes(opt);
        return (
          <button key={opt} type="button"
            onClick={() => onChange(checked ? arr.filter((v) => v !== opt) : [...arr, opt])}
            className={`px-3 py-1.5 rounded-full text-sm border transition-all ${
              checked ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"
            }`}>{opt}</button>
        );
      })}
    </div>
  );
  if (field.type === "toggle") return (
    <div className="flex gap-2">
      {field.options?.map((opt: string) => (
        <button key={opt} type="button" onClick={() => onChange(opt)}
          className={`px-4 py-1.5 rounded-full text-sm border transition-all ${
            value === opt ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"
          }`}>{opt}</button>
      ))}
    </div>
  );
  return (
    <Input
      type={field.type === "number" ? "number" : field.type === "date" ? "date" : field.type === "time" ? "time" : field.type === "email" ? "email" : field.type === "tel" ? "tel" : "text"}
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      className="text-sm" placeholder="A sua resposta..."
    />
  );
};

// ─── Formulário do questionário ───────────────────────────────────────────────
const QuestionarioForm = ({ q, onRefresh }: { q: Questionnaire; onRefresh: () => void }) => {
  const [answers, setAnswers] = useState<Record<string, any>>(q.answers ?? {});
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const submetido = q.status === "submetido" || q.status === "aprovado";

  const setField = (id: string, value: any) => setAnswers((prev) => ({ ...prev, [id]: value }));

  const guardarRascunho = async () => {
    setSaving(true);
    const { error } = await supabase.from("questionnaires")
      .update({ answers, updated_at: new Date().toISOString() }).eq("id", q.id);
    setSaving(false);
    if (error) { toast.error("Erro ao guardar"); return; }
    toast.success("Rascunho guardado!");
    onRefresh();
  };

  const submeter = async () => {
    setSubmitting(true);
    const { error } = await supabase.from("questionnaires")
      .update({ answers, status: "submetido", submitted_at: new Date().toISOString(), updated_at: new Date().toISOString() })
      .eq("id", q.id);
    setSubmitting(false);
    if (error) { toast.error("Erro ao submeter"); return; }
    toast.success("Questionário submetido com sucesso!");
    onRefresh();
  };

  return (
    <div className="bg-card border rounded-lg shadow-soft overflow-hidden">
      <div className="px-5 py-4 bg-muted/40 border-b flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-semibold text-base">
            Questionário{q.reference_number ? ` — ${q.reference_number}` : ""}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Criado em {format(new Date(q.created_at), "dd 'de' MMMM yyyy", { locale: pt })}
          </p>
        </div>
        {submetido ? (
          <span className="flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-green-100 text-green-700 font-medium">
            <CheckCircle2 className="h-3.5 w-3.5" />
            {q.status === "aprovado" ? "Aprovado" : "Submetido"}
            {q.submitted_at && ` · ${format(new Date(q.submitted_at), "dd/MM/yyyy")}`}
          </span>
        ) : (
          <span className="flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-amber-100 text-amber-700 font-medium">
            <Clock className="h-3.5 w-3.5" /> Por preencher
          </span>
        )}
      </div>

      {submetido && (
        <div className="mx-5 mt-4 bg-green-50 border border-green-200 rounded-lg px-4 py-3 flex items-center gap-3">
          <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />
          <p className="text-sm text-green-700">
            O seu questionário foi submetido e está a ser analisado pela equipa. Será contactado brevemente.
          </p>
        </div>
      )}

      <div className="p-5 space-y-6">
        {QUESTIONNAIRE_SECTIONS.map((section) => (
          <div key={section.id}>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4 pb-1 border-b border-border">
              {section.title}
            </div>
            <div className="grid md:grid-cols-2 gap-x-10 gap-y-4">
              {section.fields.filter((f) => f.type !== "static").map((field) => (
                <div key={field.id} className={field.type === "textarea" ? "md:col-span-2" : ""}>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block uppercase tracking-wide">
                    {field.label}
                  </label>
                  <FieldEditor field={field} value={answers[field.id]} onChange={(v) => setField(field.id, v)} readOnly={submetido} />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {!submetido && (
        <div className="px-5 py-4 border-t bg-muted/20 flex gap-3 flex-wrap">
          <Button onClick={submeter} disabled={submitting || saving} className="bg-gradient-gold h-9 px-6 font-semibold">
            <Send className="h-4 w-4 mr-2" />
            {submitting ? "A submeter..." : "Submeter Questionário"}
          </Button>
          <Button variant="outline" onClick={guardarRascunho} disabled={saving || submitting} className="h-9 px-6">
            <Save className="h-4 w-4 mr-2" />
            {saving ? "A guardar..." : "Guardar Rascunho"}
          </Button>
        </div>
      )}
    </div>
  );
};

// ─── Página principal ─────────────────────────────────────────────────────────
const ClienteOrcamentos = () => {
  const { user } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const [quoteRequests, setQuoteRequests] = useState<QuoteRequest[]>([]);
  const [questionnaires, setQuestionnaires] = useState<Questionnaire[]>([]);
  const [selectedOrcamento, setSelectedOrcamento] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: quotes } = await supabase.from("quote_requests").select("*")
        .eq("email", user?.email).order("created_at", { ascending: false });
      setQuoteRequests(quotes ?? []);

      const { data: qs } = await supabase.from("questionnaires").select("*")
        .eq("client_id", user?.id).order("created_at", { ascending: false });
      setQuestionnaires((qs ?? []) as any);
    } catch {
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  const removeQuoteRequest = async (id: string, name: string) => {
    if (!confirm(`Tem a certeza que quer remover o pedido de orçamento de ${name}?`)) return;
    const { error } = await supabase.from("quote_requests").delete().eq("id", id);
    if (error) { toast.error("Erro ao remover"); return; }
    toast.success("Pedido removido com sucesso");
    loadData();
  };

  const parseOrcamento = (orcamento: string | Orcamento | undefined): Orcamento | null => {
    if (!orcamento) return null;
    if (typeof orcamento === "string") {
      try { return JSON.parse(orcamento); } catch { return null; }
    }
    return orcamento;
  };

  const calculateTotal = (orc: Orcamento): number => {
    if (orc.total) return orc.total;
    if (!orc.items) return 0;
    return orc.items.reduce((s, i) => s + i.quantidade * i.preco_unitario, 0);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":   return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "aprovado":   return "bg-green-100 text-green-800 border-green-300";
      case "rejeitado":  return "bg-red-100 text-red-800 border-red-300";
      case "convertido": return "bg-blue-100 text-blue-800 border-blue-300";
      default:           return "bg-muted text-foreground border-border";
    }
  };

  const paraPreencher = questionnaires.filter((q) => !parseOrcamento(q.orcamento));
  const comOrcamento = questionnaires.filter((q) => parseOrcamento(q.orcamento));
  const semConteudo = quoteRequests.length === 0 && questionnaires.length === 0;

  if (loading) return (
    <div>
      <h1 className="font-display text-3xl mb-6">Questionários e Orçamentos</h1>
      <div className="text-center text-muted-foreground py-10">A carregar...</div>
    </div>
  );

  return (
    <div>
      <h1 className="font-display text-3xl mb-6">Questionários e Orçamentos</h1>

      {/* Modal */}
      {selectedOrcamento && (() => {
        const orc = parseOrcamento(selectedOrcamento.orcamento);
        if (!orc) return null;
        return (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-card rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-display text-2xl">Detalhes do Orçamento</h2>
                <button onClick={() => setSelectedOrcamento(null)} className="text-muted-foreground hover:text-foreground text-xl">✕</button>
              </div>
              {orc.items && orc.items.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-semibold mb-3">Itens do Orçamento</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/30">
                          <th className="text-left py-2 px-3">Descrição</th>
                          <th className="text-right py-2 px-3">Qtd</th>
                          <th className="text-right py-2 px-3">Preço Unit.</th>
                          <th className="text-right py-2 px-3">Subtotal</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orc.items.map((item, idx) => (
                          <tr key={idx} className="border-b hover:bg-muted/20">
                            <td className="py-2 px-3">{item.descricao}</td>
                            <td className="text-right py-2 px-3">{item.quantidade}</td>
                            <td className="text-right py-2 px-3">{item.preco_unitario.toFixed(2)} €</td>
                            <td className="text-right py-2 px-3 font-semibold">{(item.quantidade * item.preco_unitario).toFixed(2)} €</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              <div className="flex justify-end mt-2 pt-4 border-t">
                <div className="text-right">
                  <p className="text-muted-foreground text-sm mb-1">Total:</p>
                  <p className="text-2xl font-display text-primary">{calculateTotal(orc).toFixed(2)} €</p>
                  {orc.validade_dias && <p className="text-xs text-muted-foreground mt-1">Válido por {orc.validade_dias} dias</p>}
                  {orc.criado_em && <p className="text-xs text-muted-foreground">Emitido em {format(new Date(orc.criado_em), "dd/MM/yyyy")}</p>}
                </div>
              </div>
              {orc.notas && (
                <div className="mt-4">
                  <h3 className="font-semibold mb-2">Notas</h3>
                  <div className="bg-muted/40 p-4 rounded text-sm">{orc.notas}</div>
                </div>
              )}
              <div className="flex justify-end mt-6">
                <Button variant="outline" onClick={() => setSelectedOrcamento(null)}>Fechar</Button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Vazio */}
      {semConteudo ? (
        <div className="bg-card border rounded-lg p-10 text-center shadow-soft">
          <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="font-script text-2xl text-primary mb-2">Sem questionários ainda</p>
          <p className="text-muted-foreground">
            Quando a equipa Miminhos criar o seu questionário, aparecerá aqui para preencher.
          </p>
        </div>
      ) : (
        <div className="grid gap-6">

          {/* Questionários para preencher */}
          {paraPreencher.length > 0 && (
            <div>
              <h2 className="font-semibold text-lg mb-3">Questionários por Preencher</h2>
              <div className="space-y-4">
                {paraPreencher.map((q) => (
                  <QuestionarioForm key={q.id} q={q} onRefresh={loadData} />
                ))}
              </div>
            </div>
          )}

          {/* Pedidos de orçamento */}
          {quoteRequests.length > 0 && (
            <div>
              <h2 className="font-semibold text-lg mb-3">Pedidos de Orçamento Enviados</h2>
              <div className="space-y-3">
                {quoteRequests.map((quote) => (
                  <div key={quote.id} className="bg-card border rounded-lg shadow-soft p-5">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{quote.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{quote.event_type}</p>
                        {quote.event_date && (
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(quote.event_date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
                          </p>
                        )}
                      </div>
                      <span className={`text-xs px-3 py-1 rounded border font-medium ${getStatusColor(quote.status)}`}>
                        {quote.status === "pendente" && "À espera"}
                        {quote.status === "aprovado" && "Aprovado"}
                        {quote.status === "rejeitado" && "Rejeitado"}
                        {quote.status === "convertido" && "Convertido"}
                      </span>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-3 mt-4 text-sm">
                      {quote.guests_count && <p><strong>Convidados:</strong> {quote.guests_count}</p>}
                      <p><strong>Criado:</strong> {format(new Date(quote.created_at), "dd/MM/yyyy")}</p>
                    </div>
                    {quote.message && <p className="mt-3 text-sm bg-muted/40 p-3 rounded">{quote.message}</p>}
                    <div className="flex gap-2 mt-4 justify-end">
                      <Button variant="destructive" size="sm" onClick={() => removeQuoteRequest(quote.id, quote.name)} className="gap-1">
                        <Trash2 className="w-4 h-4" /> Remover
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Orçamentos lançados */}
          {comOrcamento.length > 0 && (
            <div>
              <h2 className="font-semibold text-lg mb-3">Orçamentos Lançados</h2>
              <div className="space-y-3">
                {comOrcamento.map((q) => {
                  const orc = parseOrcamento(q.orcamento)!;
                  const total = calculateTotal(orc);
                  return (
                    <div key={q.id} className="bg-card border rounded-lg shadow-soft p-5">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">Orçamento #{q.reference_number || q.id.slice(0, 8)}</h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {format(new Date(q.created_at), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-display text-primary">{total.toFixed(2)} €</p>
                          <p className="text-xs text-muted-foreground mt-1">Valor total</p>
                        </div>
                      </div>
                      {orc.items && orc.items.length > 0 && (
                        <div className="mt-4 pt-4 border-t">
                          <p className="text-sm text-muted-foreground mb-2">
                            {orc.items.length} item{orc.items.length !== 1 ? "s" : ""}
                          </p>
                          <ul className="text-sm space-y-1">
                            {orc.items.slice(0, 3).map((item, idx) => (
                              <li key={idx} className="flex justify-between">
                                <span>{item.descricao}</span>
                                <span className="font-medium">{(item.quantidade * item.preco_unitario).toFixed(2)} €</span>
                              </li>
                            ))}
                            {orc.items.length > 3 && (
                              <li className="text-muted-foreground italic">+ {orc.items.length - 3} item(ns)</li>
                            )}
                          </ul>
                        </div>
                      )}
                      {orc.validade_dias && (
                        <p className="text-xs text-muted-foreground mt-3">Válido por {orc.validade_dias} dias</p>
                      )}
                      <div className="flex gap-2 mt-4 justify-end">
                        <Button variant="outline" size="sm" onClick={() => setSelectedOrcamento(q)} className="gap-1">
                          <Eye className="w-4 h-4" /> Ver Detalhes
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ClienteOrcamentos;
