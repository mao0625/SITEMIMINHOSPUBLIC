import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Eye, EyeOff, Lock, CheckCircle2, ShieldCheck, ArrowLeft } from "lucide-react";

// ─── helpers ────────────────────────────────────────────────────────────────
const strength = (pw: string) => {
  let score = 0;
  if (pw.length >= 8)          score++;
  if (/[A-Z]/.test(pw))        score++;
  if (/[0-9]/.test(pw))        score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return score; // 0-4
};
const strengthLabel = ["Muito fraca", "Fraca", "Razoável", "Boa", "Forte"];
const strengthColor = ["#c0392b", "#e67e22", "#f1c40f", "#a3c940", "#4caf50"];

interface FieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggle: () => void;
  placeholder?: string;
  hint?: string;
  hintOk?: boolean;
  autoComplete?: string;
}

const PasswordField = ({
  label, value, onChange, show, onToggle,
  placeholder, hint, hintOk, autoComplete,
}: FieldProps) => (
  <div className="space-y-1">
    <label style={{
      display: "block", fontSize: "0.68rem", fontWeight: 700,
      letterSpacing: "0.13em", textTransform: "uppercase", color: "#c9a227",
    }}>
      {label}
    </label>
    <div className="relative">
      <span style={{
        position: "absolute", left: 0, top: "50%", transform: "translateY(-50%)",
        color: "rgba(212,175,55,0.45)", pointerEvents: "none",
      }}>
        <Lock size={14} />
      </span>
      <input
        type={show ? "text" : "password"}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required
        style={{
          width: "100%", background: "transparent", border: "none",
          borderBottom: "1px solid rgba(212,175,55,0.3)", color: "#f5e8c0",
          fontSize: "0.875rem", padding: "8px 32px 8px 22px", outline: "none",
          transition: "border-color 0.2s",
        }}
        onFocus={e  => (e.currentTarget.style.borderBottomColor = "rgba(212,175,55,0.7)")}
        onBlur={e   => (e.currentTarget.style.borderBottomColor = "rgba(212,175,55,0.3)")}
      />
      <button type="button" onClick={onToggle} style={{
        position: "absolute", right: 0, top: "50%", transform: "translateY(-50%)",
        background: "none", border: "none", cursor: "pointer",
        color: "rgba(212,175,55,0.5)", padding: 0, lineHeight: 1, transition: "color 0.2s",
      }}
        onMouseEnter={e => ((e.currentTarget as HTMLElement).style.color = "#d4af37")}
        onMouseLeave={e => ((e.currentTarget as HTMLElement).style.color = "rgba(212,175,55,0.5)")}
      >
        {show ? <EyeOff size={15} /> : <Eye size={15} />}
      </button>
    </div>
    {hint && (
      <p style={{ fontSize: "0.7rem", marginTop: 4, color: hintOk ? "#8fbf72" : "#c87941", transition: "color 0.3s" }}>
        {hint}
      </p>
    )}
  </div>
);

// ─── Component ───────────────────────────────────────────────────────────────
const AlterarPassword = () => {
  const navigate = useNavigate();
  const [current,     setCurrent]     = useState("");
  const [next,        setNext]        = useState("");
  const [confirm,     setConfirm]     = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext,    setShowNext]    = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading,     setLoading]     = useState(false);
  const [done,        setDone]        = useState(false);

  const pw_strength = strength(next);

  const nextHint =
    next.length > 0 && next.length < 8 ? "Mínimo 8 caracteres" :
    next.length >= 8 ? `Força: ${strengthLabel[pw_strength]}` : "";
  const nextHintOk    = next.length >= 8 && pw_strength >= 2;
  const confirmHint   = confirm.length > 0
    ? confirm === next ? "✓ Passwords coincidem" : "As passwords não coincidem"
    : "";
  const confirmHintOk = confirm === next && confirm.length > 0;
  const canSubmit     = current.length > 0 && next.length >= 8 && confirm === next && !loading;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setLoading(true);

    try {
      // 1. Verificar utilizador atual
      const { data: { user } } = await supabase.auth.getUser();
      if (!user?.email) {
        toast.error("Sessão inválida. Faz login novamente.");
        setLoading(false);
        return;
      }

      // 2. Re-autenticar com password atual para validar
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: current,
      });
      if (signInError) {
        toast.error("Password atual incorreta.");
        setLoading(false);
        return;
      }

      // 3. Atualizar password
      const { error: updateError } = await supabase.auth.updateUser({ password: next });
      if (updateError) {
        toast.error("Erro ao atualizar password. Tenta novamente.");
        setLoading(false);
        return;
      }

      // 4. Desbloquear flag must_change_password no perfil
      await supabase.from("profiles")
        .update({ must_change_password: false })
        .eq("id", user.id);

      // 5. Sucesso — redirecionar imediatamente para o dashboard do cliente
      toast.success("Password alterada com sucesso! 💛");
      setCurrent(""); setNext(""); setConfirm("");
      navigate("/cliente", { replace: true });

    } catch {
      setLoading(false);
      toast.error("Ocorreu um erro inesperado.");
    }
  };

  return (
    <div style={{
      minHeight: "100%", display: "flex", alignItems: "flex-start",
      justifyContent: "center", padding: "2.5rem 1rem",
    }}>
      <div style={{ width: "100%", maxWidth: 420 }}>

        {/* ── Page header ── */}
        <div style={{ marginBottom: "2rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
            <ShieldCheck size={18} style={{ color: "#d4af37" }} />
            <h1 style={{
              fontFamily: "var(--font-display, Georgia, serif)",
              fontSize: "1.35rem", color: "#f5e8c0", letterSpacing: "0.04em", margin: 0,
            }}>
              Alterar Password
            </h1>
          </div>
          <p style={{ fontSize: "0.8rem", color: "#7a6540", margin: 0 }}>
            Mantém a tua conta segura com uma password forte.
          </p>
        </div>

        {/* ── Success state ── */}
        {done && (
          <div style={{
            display: "flex", flexDirection: "column", alignItems: "center", gap: 12,
            padding: "2.5rem 2rem", borderRadius: 16,
            background: "linear-gradient(160deg, rgba(20,14,6,0.92) 0%, rgba(30,22,8,0.96) 100%)",
            border: "1px solid rgba(212,175,55,0.2)", boxShadow: "0 8px 40px rgba(0,0,0,0.4)",
            textAlign: "center",
          }}>
            <CheckCircle2 size={44} style={{ color: "#8fbf72" }} />
            <p style={{ fontFamily: "var(--font-display, Georgia, serif)", fontSize: "1.1rem", color: "#f5e8c0", margin: 0 }}>
              Password atualizada!
            </p>
            <p style={{ fontSize: "0.8rem", color: "#7a6540", margin: 0 }}>
              A tua nova password está ativa. A redirecionar…
            </p>
            <button
              onClick={() => navigate("/cliente", { replace: true })}
              style={{
                marginTop: 4, fontSize: "0.75rem", color: "#c9a227",
                background: "none", border: "none", cursor: "pointer",
                textDecoration: "underline", textUnderlineOffset: 3,
                display: "flex", alignItems: "center", gap: 5,
              }}
            >
              <ArrowLeft size={12} /> Ir para o dashboard agora
            </button>
          </div>
        )}

        {/* ── Form ── */}
        {!done && (
          <div style={{
            borderRadius: 16, overflow: "hidden",
            background: "linear-gradient(160deg, rgba(20,14,6,0.92) 0%, rgba(30,22,8,0.96) 100%)",
            border: "1px solid rgba(212,175,55,0.18)", boxShadow: "0 8px 40px rgba(0,0,0,0.4)",
          }}>
            {/* gold top line */}
            <div style={{ height: 2, background: "linear-gradient(90deg, transparent, #d4af37 30%, #f0d060 50%, #d4af37 70%, transparent)" }} />

            <form onSubmit={handleSubmit} style={{ padding: "2rem 2rem 2.5rem" }}>
              <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>

                <PasswordField
                  label="Password atual" value={current} onChange={setCurrent}
                  show={showCurrent} onToggle={() => setShowCurrent(v => !v)}
                  placeholder="Introduz a password atual" autoComplete="current-password"
                />

                <div style={{ height: 1, background: "linear-gradient(90deg, transparent, rgba(212,175,55,0.2) 50%, transparent)" }} />

                <PasswordField
                  label="Nova password" value={next} onChange={setNext}
                  show={showNext} onToggle={() => setShowNext(v => !v)}
                  placeholder="Mínimo 8 caracteres" autoComplete="new-password"
                  hint={nextHint} hintOk={nextHintOk}
                />

                {next.length > 0 && (
                  <div style={{ marginTop: -8 }}>
                    <div style={{ height: 3, borderRadius: 99, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
                      <div style={{
                        height: "100%", width: `${(pw_strength / 4) * 100}%`,
                        background: strengthColor[pw_strength], borderRadius: 99,
                        transition: "width 0.4s ease, background 0.4s ease",
                      }} />
                    </div>
                  </div>
                )}

                <PasswordField
                  label="Confirmar nova password" value={confirm} onChange={setConfirm}
                  show={showConfirm} onToggle={() => setShowConfirm(v => !v)}
                  placeholder="Repete a nova password" autoComplete="new-password"
                  hint={confirmHint} hintOk={confirmHintOk}
                />

                {/* Tips */}
                <ul style={{
                  margin: 0, padding: "0.75rem 1rem", borderRadius: 8,
                  background: "rgba(212,175,55,0.05)", border: "1px solid rgba(212,175,55,0.1)",
                  listStyle: "none", display: "flex", flexDirection: "column", gap: 5,
                }}>
                  {[
                    { ok: next.length >= 8,          text: "Mínimo 8 caracteres" },
                    { ok: /[A-Z]/.test(next),         text: "Pelo menos uma maiúscula" },
                    { ok: /[0-9]/.test(next),         text: "Pelo menos um número" },
                    { ok: /[^A-Za-z0-9]/.test(next),  text: "Pelo menos um símbolo (!@#…)" },
                  ].map(({ ok, text }) => (
                    <li key={text} style={{
                      fontSize: "0.72rem", display: "flex", alignItems: "center", gap: 6,
                      color: ok ? "#8fbf72" : "rgba(255,255,255,0.3)", transition: "color 0.3s",
                    }}>
                      <span style={{ fontSize: "0.6rem" }}>{ok ? "✓" : "○"}</span>
                      {text}
                    </li>
                  ))}
                </ul>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={!canSubmit}
                  style={{
                    width: "100%", padding: "0.75rem", borderRadius: 8, border: "none",
                    cursor: canSubmit ? "pointer" : "not-allowed",
                    fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase",
                    background: canSubmit
                      ? "linear-gradient(135deg, #b8922a 0%, #e8c84a 40%, #d4af37 60%, #9a7420 100%)"
                      : "rgba(212,175,55,0.15)",
                    color: canSubmit ? "#1a1000" : "rgba(212,175,55,0.3)",
                    transition: "all 0.3s",
                    boxShadow: canSubmit ? "0 4px 20px rgba(212,175,55,0.3)" : "none",
                  }}
                  onMouseEnter={e => { if (canSubmit) (e.currentTarget as HTMLElement).style.boxShadow = "0 6px 28px rgba(212,175,55,0.5)"; }}
                  onMouseLeave={e => { if (canSubmit) (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(212,175,55,0.3)"; }}
                >
                  {loading ? (
                    <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                      <span style={{
                        display: "inline-block", width: 12, height: 12,
                        border: "2px solid rgba(26,16,0,0.3)", borderTopColor: "#1a1000",
                        borderRadius: "50%", animation: "spin 0.7s linear infinite",
                      }} />
                      A guardar...
                    </span>
                  ) : "Guardar nova password"}
                </button>
              </div>
            </form>

            <div style={{ height: 1, background: "linear-gradient(90deg, transparent, rgba(212,175,55,0.3) 50%, transparent)" }} />
          </div>
        )}
      </div>

      <style>{`
        @keyframes spin  { to { transform: rotate(360deg); } }
        @keyframes drain { from { width: 100%; } to { width: 0%; } }
      `}</style>
    </div>
  );
};

export default AlterarPassword;
