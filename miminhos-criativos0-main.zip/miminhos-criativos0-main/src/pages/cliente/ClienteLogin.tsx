import { LoginPage } from "@/components/auth/LoginPage";
const ClienteLogin = () => <LoginPage redirectTo="/cliente" title="Área de Cliente" subtitle="Bem-vinda à sua área" />;
export default ClienteLogin;
