import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Star } from "lucide-react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";

const Avaliacao = () => {
  const { user } = useAuth(["cliente","admin","colaborador"], "/cliente/login");
  const [events, setEvents] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [eventId, setEventId] = useState<string>("");
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState("");
  const [isPublic, setIsPublic] = useState(true);

  const load = async () => {
    if (!user) return;
    const { data: evs } = await supabase.from("events").select("id,title,event_date").eq("client_id", user.id).order("event_date",{ascending:false});
    setEvents(evs ?? []);
    const { data: revs } = await supabase.from("event_reviews").select("*").eq("client_id", user.id);
    setReviews(revs ?? []);
  };
  useEffect(() => { load(); }, [user]);

  const submit = async () => {
    if (!user) return;
    const payload = { client_id: user.id, event_id: eventId || null, rating, comment, is_public: isPublic };
    const { error } = await supabase.from("event_reviews").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Obrigada pela sua avaliação! 💛");
    setComment(""); setRating(5); setEventId("");
    load();
  };

  return (
    <div>
      <h1 className="font-display text-3xl mb-1">Avaliar o nosso serviço</h1>
      <p className="text-sm text-muted-foreground mb-6">A sua opinião é muito importante para nós.</p>

      <div className="bg-card border rounded-lg shadow-soft p-6 max-w-2xl space-y-4">
        <div>
          <Label>Evento (opcional)</Label>
          <Select value={eventId} onValueChange={setEventId}>
            <SelectTrigger><SelectValue placeholder="Selecionar evento..."/></SelectTrigger>
            <SelectContent>{events.map((e)=><SelectItem key={e.id} value={e.id}>{e.title}</SelectItem>)}</SelectContent>
          </Select>
        </div>

        <div>
          <Label>Classificação</Label>
          <div className="flex gap-1 mt-1">
            {[1,2,3,4,5].map((n)=>(
              <button key={n} type="button" onMouseEnter={()=>setHover(n)} onMouseLeave={()=>setHover(0)} onClick={()=>setRating(n)}>
                <Star className={`h-9 w-9 transition-smooth ${(hover||rating)>=n ? "fill-primary text-primary" : "text-muted-foreground/30"}`}/>
              </button>
            ))}
          </div>
        </div>

        <div>
          <Label>Comentário</Label>
          <Textarea rows={5} value={comment} onChange={(e)=>setComment(e.target.value)} placeholder="Conte-nos a sua experiência..."/>
        </div>

        <label className="flex items-center gap-2 text-sm">
          <Checkbox checked={isPublic} onCheckedChange={(v)=>setIsPublic(!!v)}/>
          Autorizo a publicação do meu testemunho no site
        </label>

        <Button onClick={submit} className="bg-gradient-gold w-full">Enviar avaliação</Button>
      </div>

      {reviews.length > 0 && (
        <div className="mt-8 max-w-2xl">
          <h2 className="font-display text-xl mb-3">As suas avaliações anteriores</h2>
          <ul className="space-y-3">
            {reviews.map((r)=>(
              <li key={r.id} className="bg-card border rounded p-4">
                <div className="flex gap-0.5 mb-1">{Array.from({length:r.rating}).map((_,i)=><Star key={i} className="h-4 w-4 fill-primary text-primary"/>)}</div>
                <p className="text-sm">{r.comment || <em className="text-muted-foreground">Sem comentário</em>}</p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
export default Avaliacao;
