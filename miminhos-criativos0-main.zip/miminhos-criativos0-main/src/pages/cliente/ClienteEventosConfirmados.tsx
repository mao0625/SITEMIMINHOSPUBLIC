import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import {
  CheckCircle2, Clock, Euro, XCircle, Calendar,
  MapPin, Users, Tag, AlertCircle, Sparkles,
} from "lucide-react";

const PAYMENT_STATUS: Record<string, { label: string; icon: any; cls: string; dot: string }> = {
  pago:          { label: "Pago",          icon: CheckCircle2, cls: "bg-emerald-50 text-emerald-700 border-emerald-200", dot: "bg-emerald-500" },
  por_pagar:     { label: "Por Pagar",     icon: Clock,        cls: "bg-amber-50 text-amber-700 border-amber-200",       dot: "bg-amber-500"   },
  em_pagamento:  { label: "Em Pagamento",  icon: Euro,         cls: "bg-blue-50 text-blue-700 border-blue-200",          dot: "bg-blue-500"    },
  nao_realizado: { label: "Não Realizado", icon: XCircle,      cls: "bg-red-50 text-red-700 border-red-200",             dot: "bg-red-400"     },
};

const PayBadge = ({ status }: { status?: string }) => {
  const cfg = PAYMENT_STATUS[status ?? "por_pagar"] ?? PAYMENT_STATUS.por_pagar;
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full border ${cfg.cls}`}>
      <Icon className="h-3.5 w-3.5" />{cfg.label}
    </span>
  );
};

const ClienteEventosConfirmados = () => {
  const { user } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("events")
      .select("*")
      .eq("client_id", user.id)
      .in("status", ["confirmado", "em_curso", "concluido"])
      .order("event_date", { ascending: true })
      .then(({ data }) => {
        setEvents(data ?? []);
        setLoading(false);
      });
  }, [user]);

  if (loading) return (
    <div className="flex items-center justify-center py-20 text-muted-foreground">
      <Clock className="h-5 w-5 animate-spin mr-2" />A carregar…
    </div>
  );

  const pendentes = events.filter(
    e => !e.estado_pagamento || e.estado_pagamento === "por_pagar" || e.estado_pagamento === "em_pagamento"
  );

  return (
    <div className="max-w-3xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold uppercase tracking-widest mb-3">
          <Sparkles className="h-3.5 w-3.5" />Eventos Confirmados
        </div>
        <h1 className="text-3xl font-bold">Os seus eventos</h1>
        <p className="text-muted-foreground mt-1">Consulte os detalhes e estado de pagamento dos seus eventos.</p>
      </div>

      {/* Alerta pagamentos pendentes */}
      {pendentes.length > 0 && (
        <div className="flex items-start gap-3 p-4 rounded-xl border border-amber-200 bg-amber-50 mb-6">
          <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-amber-800">
              {pendentes.length === 1
                ? "Tem 1 evento com pagamento pendente"
                : `Tem ${pendentes.length} eventos com pagamento pendente`}
            </p>
            <p className="text-xs text-amber-700 mt-0.5">
              Entre em contacto connosco para regularizar o pagamento.
            </p>
          </div>
        </div>
      )}

      {events.length === 0 ? (
        <div className="text-center py-16 bg-card rounded-2xl border border-border/50">
          <div className="w-16 h-16 bg-muted/40 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="h-6 w-6 text-muted-foreground/50" />
          </div>
          <p className="font-semibold text-foreground">Sem eventos confirmados</p>
          <p className="text-sm text-muted-foreground mt-1">Os seus eventos confirmados aparecerão aqui.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {events.map(e => {
            const payStatus = PAYMENT_STATUS[e.estado_pagamento ?? "por_pagar"] ?? PAYMENT_STATUS.por_pagar;
            return (
              <div key={e.id} className="bg-card border border-border/60 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                {/* Status stripe */}
                <div className={`h-1 ${payStatus.dot}`} />

                <div className="p-5">
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div>
                      <h3 className="font-bold text-lg text-foreground">{e.title}</h3>
                      {e.event_type && (
                        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground mt-1">
                          <Tag className="h-3 w-3" />{e.event_type}
                        </span>
                      )}
                    </div>
                    <PayBadge status={e.estado_pagamento} />
                  </div>

                  <div className="grid sm:grid-cols-3 gap-3">
                    {e.event_date && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="h-8 w-8 rounded-lg bg-muted/40 flex items-center justify-center shrink-0">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground/70">Data</p>
                          <p className="font-semibold text-foreground text-sm">
                            {format(new Date(e.event_date), "d 'de' MMMM, yyyy", { locale: pt })}
                          </p>
                        </div>
                      </div>
                    )}
                    {e.location && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="h-8 w-8 rounded-lg bg-muted/40 flex items-center justify-center shrink-0">
                          <MapPin className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground/70">Local</p>
                          <p className="font-semibold text-foreground text-sm truncate">{e.location}</p>
                        </div>
                      </div>
                    )}
                    {e.guests_count && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="h-8 w-8 rounded-lg bg-muted/40 flex items-center justify-center shrink-0">
                          <Users className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground/70">Convidados</p>
                          <p className="font-semibold text-foreground text-sm">{e.guests_count} pax</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Valor + estado pagamento */}
                  {(e.payment_value || e.estado_pagamento) && (
                    <div className="mt-4 pt-4 border-t border-border/40 flex items-center justify-between flex-wrap gap-3">
                      {e.payment_value && (
                        <div>
                          <p className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground/70 mb-0.5">Valor</p>
                          <p className="text-xl font-black text-foreground tabular-nums">
                            {e.payment_value.toLocaleString("pt-PT", { minimumFractionDigits: 2 })}€
                          </p>
                        </div>
                      )}
                      <div>
                        <p className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground/70 mb-1">Estado de Pagamento</p>
                        <PayBadge status={e.estado_pagamento} />
                      </div>
                    </div>
                  )}

                  {/* Mensagem estado */}
                  {e.estado_pagamento === "nao_realizado" && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                      <XCircle className="h-3.5 w-3.5 shrink-0" />
                      Este evento foi cancelado ou não realizado. Entre em contacto para mais informações.
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ClienteEventosConfirmados;
