import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { FileText, Trash2, Eye, Send, Save, CheckCircle2, Clock, Download, ArrowLeft, Pencil, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { QUESTIONNAIRE_SECTIONS, type QField } from "@/lib/questionnaire";
import { exportQuestionnairePDF } from "@/lib/pdf";

// ─── Interfaces ───────────────────────────────────────────────────────────────
interface OrcamentoItem {
  descricao: string;
  quantidade: number;
  preco_unitario: number;
}

interface Orcamento {
  items?: OrcamentoItem[];
  notas?: string;
  validade_dias?: number;
  total?: number;
  criado_em?: string;
  nome?: string;
}

interface QuoteRequest {
  id: string;
  name: string;
  email: string;
  phone: string;
  event_type: string;
  event_date: string | null;
  guests_count: number | null;
  message: string | null;
  status: string;
  created_at: string;
}

interface Questionnaire {
  id: string;
  client_id: string;
  orcamento?: string | Orcamento;
  reference_number?: string;
  status: string;
  answers?: Record<string, any>;
  created_at: string;
  submitted_at?: string;
}

// ─── Field ────────────────────────────────────────────────────────────────────
const Field = ({ f, v, onChange }: { f: QField; v: any; onChange: (v: any) => void }) => {
  if (f.type === "static") return <p className="text-sm text-muted-foreground italic">{f.label}</p>;
  if (f.type === "textarea") return <Textarea value={v ?? ""} onChange={(e) => onChange(e.target.value)} />;
  if (f.type === "toggle") return (
    <div className="flex gap-3">
      {f.options?.map((o) => (
        <label key={o} className="flex items-center gap-2 cursor-pointer">
          <input type="radio" name={f.id} value={o} checked={v === o} onChange={(e) => onChange(e.target.value)} className="w-4 h-4" />
          <span className="text-sm">{o}</span>
        </label>
      ))}
    </div>
  );
  if (f.type === "radio") return (
    <div className="flex flex-col gap-2">
      {f.options?.map((o) => (
        <label key={o} className="flex items-center gap-2 cursor-pointer">
          <input type="radio" name={f.id} value={o} checked={v === o} onChange={(e) => onChange(e.target.value)} className="w-4 h-4" />
          <span className="text-sm">{o}</span>
        </label>
      ))}
    </div>
  );
  if (f.type === "checkbox") return (
    <div className="flex flex-col gap-2">
      {f.options?.map((o) => (
        <label key={o} className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" value={o} checked={(v || []).includes(o)}
            onChange={(e) => {
              const arr = v || [];
              onChange(e.target.checked ? [...arr, o] : arr.filter((x: string) => x !== o));
            }} className="w-4 h-4" />
          <span className="text-sm">{o}</span>
        </label>
      ))}
    </div>
  );
  if (f.type === "select") return (
    <select className="w-full border rounded h-10 px-2 bg-background" value={v ?? ""} onChange={(e) => onChange(e.target.value)}>
      <option value="">—</option>
      {f.options?.map((o) => <option key={o} value={o}>{o}</option>)}
    </select>
  );
  return <Input type={f.type} value={v ?? ""} onChange={(e) => onChange(e.target.value)} required={f.required} />;
};

// ─── QuestionarioForm ─────────────────────────────────────────────────────────
const QuestionarioForm = ({ q, user, onRefresh }: { q: Questionnaire; user: any; onRefresh: () => void }) => {
  const [answers, setAnswers] = useState<Record<string, any>>(q.answers ?? {});
  const [saving, setSaving] = useState(false);
  const submetido = q.status === "submetido" || q.status === "aprovado";

  const upsert = async (status: string) => {
    setSaving(true);
    const payload: any = { answers, status };
    if (status === "submetido") payload.submitted_at = new Date().toISOString();
    payload.updated_at = new Date().toISOString();
    const { error } = await supabase.from("questionnaires").update(payload).eq("id", q.id);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    if (status === "submetido") toast.success("Questionário submetido com sucesso!");
    else toast.success("Rascunho guardado!");
    onRefresh();
  };

  return (
    <div className="bg-card border rounded-lg shadow-soft overflow-hidden">
      <div className="px-5 py-4 bg-muted/40 border-b flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="font-semibold text-base">
            Questionário{q.reference_number ? ` — ${q.reference_number}` : ""}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Criado em {format(new Date(q.created_at), "dd 'de' MMMM yyyy", { locale: pt })}
          </p>
        </div>
        {submetido ? (
          <span className="flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-green-100 text-green-700 font-medium">
            <CheckCircle2 className="h-3.5 w-3.5" />
            {q.status === "aprovado" ? "Aprovado" : "Submetido"}
            {q.submitted_at && ` · ${format(new Date(q.submitted_at), "dd/MM/yyyy")}`}
          </span>
        ) : (
          <span className="flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-amber-100 text-amber-700 font-medium">
            <Clock className="h-3.5 w-3.5" /> Por preencher
          </span>
        )}
      </div>

      {submetido && (
        <div className="mx-5 mt-4 bg-green-50 border border-green-200 rounded-lg px-4 py-3 flex items-center gap-3">
          <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />
          <p className="text-sm text-green-700">
            O seu questionário foi submetido e está a ser analisado pela equipa. Será contactado brevemente.
          </p>
        </div>
      )}

      <div className="p-5 space-y-6">
        {QUESTIONNAIRE_SECTIONS.map((s) => (
          <div key={s.id} className="bg-muted/20 rounded-lg p-4">
            <h2 className="font-display text-lg text-primary mb-4">{s.title}</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {s.fields.map((f) => (
                <div key={f.id} className={f.type === "textarea" || f.type === "static" ? "sm:col-span-2" : ""}>
                  {f.type !== "static" && <Label className="text-sm mb-1 block">{f.label}</Label>}
                  {submetido ? (
                    f.type !== "static" && (
                      <p className="text-sm text-foreground">
                        {Array.isArray(answers[f.id]) ? answers[f.id].join(", ") : answers[f.id] || "—"}
                      </p>
                    )
                  ) : (
                    <Field f={f} v={answers[f.id]} onChange={(v) => setAnswers({ ...answers, [f.id]: v })} />
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {!submetido && (
        <div className="flex flex-wrap gap-2 px-5 py-4 border-t bg-muted/20 sticky bottom-4">
          <Button variant="outline" disabled={saving} onClick={() => upsert(q.status || "rascunho")}>
            <Save className="h-4 w-4 mr-1" /> Guardar rascunho
          </Button>
          <Button className="bg-gradient-gold" disabled={saving} onClick={() => upsert("submetido")}>
            <Send className="h-4 w-4 mr-1" /> Enviar Pedido de Orçamento
          </Button>
          <Button variant="outline" onClick={() => exportQuestionnairePDF({
            clientName: user?.user_metadata?.full_name || user?.email || "Cliente",
            clientEmail: user?.email,
            answers,
          })}>
            <Download className="h-4 w-4 mr-1" /> PDF
          </Button>
          {q.status && <span className="ml-auto text-xs self-center text-muted-foreground capitalize">Estado: {q.status}</span>}
        </div>
      )}
    </div>
  );
};

// ─── Sub-página de detalhe do orçamento ──────────────────────────────────────
const OrcamentoDetalhe = ({
  q,
  onBack,
  onRefresh,
}: {
  q: Questionnaire;
  onBack: () => void;
  onRefresh: () => void;
}) => {
  const parseOrc = (raw: string | Orcamento | undefined): Orcamento | null => {
    if (!raw) return null;
    if (typeof raw === "string") { try { return JSON.parse(raw); } catch { return null; } }
    return raw;
  };

  const orc = parseOrc(q.orcamento);
  const [nome, setNome] = useState(orc?.nome ?? "");
  const [editingNome, setEditingNome] = useState(false);
  const [nomeTemp, setNomeTemp] = useState(nome);
  const [savingNome, setSavingNome] = useState(false);

  if (!orc) return null;

  const total = orc.total ?? (orc.items?.reduce((s, i) => s + i.quantidade * i.preco_unitario, 0) ?? 0);

  const guardarNome = async () => {
    setSavingNome(true);
    const orcAtualizado = { ...orc, nome: nomeTemp };
    const { error } = await (supabase as any)
      .from("questionnaires")
      .update({ orcamento: orcAtualizado, updated_at: new Date().toISOString() })
      .eq("id", q.id);
    setSavingNome(false);
    if (error) { toast.error("Erro ao guardar nome"); return; }
    setNome(nomeTemp);
    setEditingNome(false);
    toast.success("Nome guardado!");
    onRefresh();
  };

  return (
    <div className="space-y-0">
      {/* Cabeçalho */}
      <div className="bg-muted/60 border border-border rounded-t-lg px-4 py-2 flex items-center gap-3 flex-wrap">
        <Button variant="ghost" size="sm" onClick={onBack} className="h-7 px-2">
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
        <div className="h-4 w-px bg-border" />
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
          {editingNome ? (
            <div className="flex items-center gap-2">
              <Input
                value={nomeTemp}
                onChange={(e) => setNomeTemp(e.target.value)}
                className="h-7 text-sm w-56"
                placeholder="Nome do orçamento..."
                autoFocus
              />
              <Button size="sm" variant="ghost" className="h-7 w-7 p-0" disabled={savingNome} onClick={guardarNome}>
                <Check className="h-4 w-4 text-green-600" />
              </Button>
              <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => { setNomeTemp(nome); setEditingNome(false); }}>
                <X className="h-4 w-4 text-muted-foreground" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm truncate">
                {nome || q.reference_number || "Orçamento sem nome"}
              </span>
              <Button size="sm" variant="ghost" className="h-6 w-6 p-0 opacity-60 hover:opacity-100" onClick={() => { setNomeTemp(nome); setEditingNome(true); }}>
                <Pencil className="h-3 w-3" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Corpo */}
      <div className="border border-t-0 border-border rounded-b-lg bg-background p-6 space-y-6">

        {/* Resumo */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Referência</p>
            <p className="font-mono font-semibold text-primary">{q.reference_number || "—"}</p>
          </div>
          {orc.criado_em && (
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Emitido em</p>
              <p className="text-sm font-medium">{format(new Date(orc.criado_em), "dd/MM/yyyy 'às' HH:mm")}</p>
            </div>
          )}
          {orc.validade_dias && (
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Validade</p>
              <p className="text-sm font-medium">{orc.validade_dias} dias</p>
            </div>
          )}
          <div className="text-right">
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total</p>
            <p className="text-3xl font-display text-primary">{total.toFixed(2)} €</p>
          </div>
        </div>

        {/* Itens */}
        {orc.items && orc.items.length > 0 && (
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-2.5 bg-muted/40 border-b">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Itens do Orçamento</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/40 bg-muted/20">
                    <th className="text-left px-4 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Descrição</th>
                    <th className="text-right px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground w-16">Qtd</th>
                    <th className="text-right px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground w-28">Preço Unit.</th>
                    <th className="text-right px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground w-28">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/30">
                  {orc.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-muted/10">
                      <td className="px-4 py-2.5">{item.descricao}</td>
                      <td className="px-3 py-2.5 text-right">{item.quantidade}</td>
                      <td className="px-3 py-2.5 text-right">{item.preco_unitario.toFixed(2)} €</td>
                      <td className="px-3 py-2.5 text-right font-semibold">{(item.quantidade * item.preco_unitario).toFixed(2)} €</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Notas */}
        {orc.notas && (
          <div className="border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-2.5 bg-muted/40 border-b">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Notas e Condições</span>
            </div>
            <p className="p-4 text-sm text-foreground">{orc.notas}</p>
          </div>
        )}

        <div className="flex justify-end">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar à lista
          </Button>
        </div>
      </div>
    </div>
  );
};

// ─── Tabs ─────────────────────────────────────────────────────────────────────
type Tab = "questionarios" | "orcamentos" | "pedidos";

const TABS: { id: Tab; label: string }[] = [
  { id: "questionarios", label: "Questionários" },
  { id: "orcamentos",    label: "Orçamentos" },
  { id: "pedidos",       label: "Pedidos Enviados" },
];

// ─── Página principal ─────────────────────────────────────────────────────────
const Questionario = () => {
  const { user } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const [quoteRequests, setQuoteRequests] = useState<QuoteRequest[]>([]);
  const [questionnaires, setQuestionnaires] = useState<Questionnaire[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>("questionarios");
  const [orcamentoAberto, setOrcamentoAberto] = useState<Questionnaire | null>(null);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: quotes } = await supabase.from("quote_requests").select("*")
        .eq("email", user?.email).order("created_at", { ascending: false });
      setQuoteRequests(quotes ?? []);

      const { data: qs } = await supabase.from("questionnaires").select("*")
        .eq("client_id", user?.id).order("created_at", { ascending: false });
      setQuestionnaires((qs ?? []) as any);
    } catch {
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  const removeQuoteRequest = async (id: string, name: string) => {
    if (!confirm(`Tem a certeza que quer remover o pedido de orçamento de ${name}?`)) return;
    const { error } = await supabase.from("quote_requests").delete().eq("id", id);
    if (error) { toast.error("Erro ao remover"); return; }
    toast.success("Pedido removido com sucesso");
    loadData();
  };

  const parseOrcamento = (raw: string | Orcamento | undefined): Orcamento | null => {
    if (!raw) return null;
    if (typeof raw === "string") { try { return JSON.parse(raw); } catch { return null; } }
    return raw;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":   return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "aprovado":   return "bg-green-100 text-green-800 border-green-300";
      case "rejeitado":  return "bg-red-100 text-red-800 border-red-300";
      case "convertido": return "bg-blue-100 text-blue-800 border-blue-300";
      default:           return "bg-muted text-foreground border-border";
    }
  };

  const paraPreencher = questionnaires.filter((q) => !parseOrcamento(q.orcamento));
  const comOrcamento  = questionnaires.filter((q) =>  parseOrcamento(q.orcamento));

  // Contadores para as tabs
  const counts: Record<Tab, number> = {
    questionarios: paraPreencher.length,
    orcamentos:    comOrcamento.length,
    pedidos:       quoteRequests.length,
  };

  if (loading) return (
    <div>
      <h1 className="font-display text-3xl mb-6">Questionários e Orçamentos</h1>
      <div className="text-center text-muted-foreground py-10">A carregar...</div>
    </div>
  );

  // Sub-página orçamento
  if (orcamentoAberto) return (
    <div>
      <h1 className="font-display text-3xl mb-6">Orçamentos</h1>
      <OrcamentoDetalhe
        q={orcamentoAberto}
        onBack={() => setOrcamentoAberto(null)}
        onRefresh={loadData}
      />
    </div>
  );

  return (
    <div>
      <h1 className="font-display text-3xl mb-2">Questionários e Orçamentos</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Por favor, ao longo do questionário seja breve nas respostas. As respostas que não souber, deixe em branco.
      </p>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 border-b border-border">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 text-sm font-medium transition-colors relative flex items-center gap-2 ${
              activeTab === tab.id
                ? "text-primary border-b-2 border-primary -mb-px"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
            {counts[tab.id] > 0 && (
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                activeTab === tab.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
              }`}>
                {counts[tab.id]}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Tab: Questionários */}
      {activeTab === "questionarios" && (
        paraPreencher.length === 0 ? (
          <div className="bg-card border rounded-lg p-10 text-center shadow-soft">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="font-script text-2xl text-primary mb-2">Sem questionários por preencher</p>
            <p className="text-muted-foreground">
              Quando a equipa Miminhos criar o seu questionário, aparecerá aqui para preencher.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {paraPreencher.map((q) => (
              <QuestionarioForm key={q.id} q={q} user={user} onRefresh={loadData} />
            ))}
          </div>
        )
      )}

      {/* Tab: Orçamentos */}
      {activeTab === "orcamentos" && (
        comOrcamento.length === 0 ? (
          <div className="bg-card border rounded-lg p-10 text-center shadow-soft">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="font-script text-2xl text-primary mb-2">Sem orçamentos ainda</p>
            <p className="text-muted-foreground">Os orçamentos lançados pela equipa aparecerão aqui.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {comOrcamento.map((q) => {
              const orc = parseOrcamento(q.orcamento)!;
              const total = orc.total ?? (orc.items?.reduce((s, i) => s + i.quantidade * i.preco_unitario, 0) ?? 0);
              const nome = orc.nome || q.reference_number || `Orçamento ${q.id.slice(0, 6)}`;
              return (
                <div key={q.id} className="bg-card border rounded-lg shadow-soft p-5 flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-base truncate">{nome}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {orc.criado_em
                          ? format(new Date(orc.criado_em), "dd 'de' MMMM 'de' yyyy", { locale: pt })
                          : format(new Date(q.created_at), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
                        {orc.items && ` · ${orc.items.length} item${orc.items.length !== 1 ? "s" : ""}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-xl font-display text-primary">{total.toFixed(2)} €</p>
                      {orc.validade_dias && (
                        <p className="text-[10px] text-muted-foreground">válido {orc.validade_dias} dias</p>
                      )}
                    </div>
                    <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setOrcamentoAberto(q)}>
                      <Eye className="h-3.5 w-3.5 mr-1" /> Abrir
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )
      )}

      {/* Tab: Pedidos Enviados */}
      {activeTab === "pedidos" && (
        quoteRequests.length === 0 ? (
          <div className="bg-card border rounded-lg p-10 text-center shadow-soft">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="font-script text-2xl text-primary mb-2">Sem pedidos enviados</p>
            <p className="text-muted-foreground">Os seus pedidos de orçamento enviados aparecerão aqui.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {quoteRequests.map((quote) => (
              <div key={quote.id} className="bg-card border rounded-lg shadow-soft p-5">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{quote.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{quote.event_type}</p>
                    {quote.event_date && (
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(quote.event_date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
                      </p>
                    )}
                  </div>
                  <span className={`text-xs px-3 py-1 rounded border font-medium ${getStatusColor(quote.status)}`}>
                    {quote.status === "pendente"   && "À espera"}
                    {quote.status === "aprovado"   && "Aprovado"}
                    {quote.status === "rejeitado"  && "Rejeitado"}
                    {quote.status === "convertido" && "Convertido"}
                  </span>
                </div>
                <div className="grid sm:grid-cols-2 gap-3 mt-4 text-sm">
                  {quote.guests_count && <p><strong>Convidados:</strong> {quote.guests_count}</p>}
                  <p><strong>Criado:</strong> {format(new Date(quote.created_at), "dd/MM/yyyy")}</p>
                </div>
                {quote.message && <p className="mt-3 text-sm bg-muted/40 p-3 rounded">{quote.message}</p>}
                <div className="flex gap-2 mt-4 justify-end">
                  <Button variant="destructive" size="sm" onClick={() => removeQuoteRequest(quote.id, quote.name)} className="gap-1">
                    <Trash2 className="w-4 h-4" /> Remover
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
};

export default Questionario;
