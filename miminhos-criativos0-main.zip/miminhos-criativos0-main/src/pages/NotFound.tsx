import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";

const NotFound = () => (
  <div className="min-h-screen bg-gradient-champagne flex items-center justify-center p-4">
    <div className="text-center">
      <Logo className="h-20 mx-auto mb-6" variant="dark" />
      <h1 className="font-display text-7xl text-primary mb-3">404</h1>
      <p className="font-script text-3xl text-foreground mb-2">Oops!</p>
      <p className="text-muted-foreground mb-8">Neste Momento nao foi possivel encontrar a pagina .</p>
      <Button asChild className="bg-gradient-gold shadow-gold">
        <Link to="/">Voltar ao Início</Link>
      </Button>
    </div>
  </div>
);

export default NotFound;
