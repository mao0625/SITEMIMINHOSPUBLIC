import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Calendar, ArrowLeft, Clock, ArrowRight, Sparkles } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { Button } from "@/components/ui/button";

interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  cover_url: string;
  published: boolean;
  created_at: string;
  published_at: string;
  category_id?: string;
  tags?: string[];
  featured?: boolean;
  reading_time?: number;
}
interface BlogCategory {
  id: string; name: string; slug: string; color?: string;
}

// ─── Markdown renderer ────────────────────────────────────────────────────────
const renderMarkdown = (text: string): string =>
  text
    .replace(/^### (.+)$/gm, '<h3 style="font-size:1.2rem;font-weight:700;margin:2rem 0 0.75rem;color:#2c1a0e;font-family:inherit">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="font-size:1.5rem;font-weight:700;margin:2.5rem 0 1rem;color:#2c1a0e;font-family:inherit">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 style="font-size:2rem;font-weight:700;margin:2.5rem 0 1rem;color:#2c1a0e;font-family:inherit">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong style="font-weight:600;color:#2c1a0e">$1</strong>')
    .replace(/_(.+?)_/g, '<em style="font-style:italic">$1</em>')
    .replace(/^> (.+)$/gm, '<blockquote style="border-left:4px solid #c17f4a;padding:0.75rem 1rem 0.75rem 1.25rem;margin:1.5rem 0;background:#fdf5ec;border-radius:0 8px 8px 0;color:#7a5c4a;font-style:italic">$1</blockquote>')
    .replace(/^- (.+)$/gm, '<li style="margin-left:1.5rem;list-style:disc;margin-bottom:0.4rem;color:#5a3e28;line-height:1.7">$1</li>')
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" style="color:#c17f4a;text-decoration:underline;text-underline-offset:2px" target="_blank" rel="noopener noreferrer">$1</a>')
    .replace(/!\[(.+?)\]\((.+?)\)/g, '<img src="$2" alt="$1" style="max-width:100%;border-radius:12px;margin:1.5rem 0;border:1px solid #e8d5c4;box-shadow:0 2px 12px rgba(0,0,0,.06)" />')
    .replace(/\n\n/g, '</p><p style="margin-bottom:1.25rem;line-height:1.85;color:#5a3e28">')
    .replace(/\n/g, '<br/>');

// ─── OG meta ──────────────────────────────────────────────────────────────────
const updateOGMeta = (post: BlogPost) => {
  const siteUrl = window.location.origin;
  const postUrl = `${siteUrl}/blog/${post.slug}`;
  const description = post.excerpt || post.content.replace(/[#*_>`\[\]!()-]/g, "").substring(0, 200);
  const setMeta = (property: string, content: string, attr = "property") => {
    let el = document.querySelector(`meta[${attr}="${property}"]`) as HTMLMetaElement | null;
    if (!el) { el = document.createElement("meta"); el.setAttribute(attr, property); document.head.appendChild(el); }
    el.setAttribute("content", content);
  };
  document.title = `${post.title} | Blog`;
  setMeta("description", description, "name");
  setMeta("og:type", "article"); setMeta("og:title", post.title);
  setMeta("og:description", description); setMeta("og:url", postUrl);
  if (post.cover_url) { setMeta("og:image", post.cover_url); setMeta("og:image:width", "1200"); setMeta("og:image:height", "630"); setMeta("og:image:alt", post.title); }
  setMeta("twitter:card", post.cover_url ? "summary_large_image" : "summary", "name");
  setMeta("twitter:title", post.title, "name"); setMeta("twitter:description", description, "name");
  if (post.cover_url) setMeta("twitter:image", post.cover_url, "name");
};
const restoreOGMeta = () => {
  document.title = "Blog";
  ["og:type","og:title","og:description","og:url","og:image","og:image:alt"].forEach(p => document.querySelector(`meta[property="${p}"]`)?.remove());
  ["twitter:card","twitter:title","twitter:description","twitter:image","description"].forEach(p => document.querySelector(`meta[name="${p}"]`)?.remove());
};

const readingTime = (content: string) => Math.max(1, Math.ceil(content.trim().split(/\s+/).length / 200));

// ─── Main ─────────────────────────────────────────────────────────────────────
const BlogPost = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [post,       setPost]       = useState<BlogPost | null>(null);
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [related,    setRelated]    = useState<BlogPost[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [notFound,   setNotFound]   = useState(false);

  useEffect(() => {
    const load = async () => {
      if (!slug) return;
      const [{ data }, { data: cats }] = await Promise.all([
        supabase.from("blog_posts").select("*").eq("slug", slug).eq("published", true).single(),
        supabase.from("blog_categories").select("*"),
      ]);
      if (!data) { setNotFound(true); setLoading(false); return; }
      setPost(data);
      setCategories((cats ?? []) as BlogCategory[]);
      updateOGMeta(data);

      // Related posts (same category or just recent)
      const { data: rel } = await supabase
        .from("blog_posts").select("*").eq("published", true)
        .neq("id", data.id).limit(3).order("published_at", { ascending: false });
      setRelated((rel ?? []) as BlogPost[]);
      setLoading(false);
    };
    load();
    return () => restoreOGMeta();
  }, [slug]);

  const getCat = (id?: string) => categories.find(c => c.id === id);
  const fmtDate = (p: BlogPost) => format(new Date(p.published_at || p.created_at), "d 'de' MMMM 'de' yyyy", { locale: pt });
  const fmtShort = (p: BlogPost) => format(new Date(p.published_at || p.created_at), "dd/MM/yyyy");
  const rt = (p: BlogPost) => p.reading_time ?? readingTime(p.content);

  // ── Loading ──────────────────────────────────────────────────────────────────
  if (loading) return (
    <>
      <Navbar />
      <div className="flex items-center justify-center min-h-screen bg-[#fdf8f3]">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-[#e8d5c4] border-t-[#c17f4a] animate-spin mx-auto mb-4" />
          <p className="text-[#b08070] text-sm">A carregar artigo…</p>
        </div>
      </div>
    </>
  );

  // ── Not found ─────────────────────────────────────────────────────────────────
  if (notFound || !post) return (
    <>
      <Navbar />
      <div className="flex items-center justify-center min-h-screen bg-[#fdf8f3]">
        <div className="text-center">
          <p className="text-6xl mb-4">📰</p>
          <h1 className="font-display text-3xl text-[#2c1a0e] mb-3">Artigo não encontrado</h1>
          <p className="text-[#7a5c4a] mb-8">Este artigo não existe ou ainda não foi publicado.</p>
          <Button onClick={() => navigate("/blog")} variant="outline" className="border-[#e8d5c4] text-[#7a5c4a] hover:border-[#c17f4a] hover:text-[#c17f4a]">
            <ArrowLeft className="h-4 w-4 mr-2" />Voltar ao blog
          </Button>
        </div>
      </div>
    </>
  );

  const dateStr = post.published_at || post.created_at;
  const cat = getCat(post.category_id);

  return (
    <>
      <Navbar />

      {/* ── Hero ──────────────────────────────────────────────────────────────── */}
      {post.cover_url ? (
        <div className="relative h-[60vh] min-h-[400px] overflow-hidden">
          <img src={post.cover_url} alt={post.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />

          {/* Badges */}
          <div className="absolute top-6 left-6 flex items-center gap-2">
            <button
              onClick={() => navigate("/blog")}
              className="inline-flex items-center gap-1.5 bg-white/90 backdrop-blur-sm text-[#2c1a0e] text-xs font-semibold px-3 py-1.5 rounded-full border border-white/50 hover:bg-white transition-colors"
            >
              <ArrowLeft className="h-3 w-3" /> Blog
            </button>
            {post.featured && (
              <span className="inline-flex items-center gap-1 bg-[#c17f4a]/90 backdrop-blur-sm text-white text-xs font-bold px-3 py-1.5 rounded-full">
                <Sparkles className="h-3 w-3" /> Destaque
              </span>
            )}
          </div>

          {/* Title on image */}
          <div className="absolute bottom-0 left-0 right-0 px-6 pb-10 max-w-4xl mx-auto">
            {cat && (
              <span className="inline-block text-[11px] font-bold uppercase tracking-widest mb-3 px-3 py-1 rounded-full text-white/90"
                style={{ background: `${cat.color ?? "#c17f4a"}99`, border: `1px solid ${cat.color ?? "#c17f4a"}60` }}>
                {cat.name}
              </span>
            )}
            <div className="flex flex-wrap items-center gap-3 text-sm text-white/70 mb-3">
              <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" />{fmtDate(post)}</span>
              <span className="text-white/30">·</span>
              <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" />{rt(post)} min de leitura</span>
            </div>
            <h1 className="font-display text-3xl md:text-5xl text-white leading-tight drop-shadow-lg">
              {post.title}
            </h1>
          </div>
        </div>
      ) : (
        /* No cover — simple header */
        <section className="pt-32 pb-10 bg-gradient-to-b from-[#fdf8f3] to-white border-b border-[#e8d5c4]">
          <div className="container max-w-3xl">
            <button onClick={() => navigate("/blog")}
              className="inline-flex items-center gap-1.5 text-sm text-[#b08070] hover:text-[#c17f4a] transition-colors mb-6">
              <ArrowLeft className="h-4 w-4" /> Voltar ao blog
            </button>
            {cat && (
              <span className="inline-block text-[11px] font-bold uppercase tracking-widest mb-3 px-3 py-1 rounded-full"
                style={{ color: cat.color ?? "#c17f4a", background: `${cat.color ?? "#c17f4a"}18`, border: `1px solid ${cat.color ?? "#c17f4a"}30` }}>
                {cat.name}
              </span>
            )}
            <div className="flex flex-wrap items-center gap-3 text-sm text-[#b08070] mb-4">
              <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" />{fmtDate(post)}</span>
              <span className="text-[#e8d5c4]">·</span>
              <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" />{rt(post)} min de leitura</span>
            </div>
            <h1 className="font-display text-4xl md:text-5xl text-[#2c1a0e] leading-tight">
              {post.title}
            </h1>
          </div>
        </section>
      )}

      {/* ── Article card ──────────────────────────────────────────────────────── */}
      <div className={`container max-w-3xl mx-auto px-4 pb-6 ${post.cover_url ? "-mt-8 relative z-10" : "pt-8"}`}>
        <div className="bg-white rounded-2xl shadow-sm border border-[#e8d5c4] p-8 md:p-12">

          {/* Voltar (when cover exists, the hero button handles it; show again inline here) */}
          {post.cover_url && (
            <button onClick={() => navigate("/blog")}
              className="inline-flex items-center gap-1.5 text-sm text-[#b08070] hover:text-[#c17f4a] transition-colors mb-8">
              <ArrowLeft className="h-4 w-4" /> Voltar ao blog
            </button>
          )}

          {/* Excerpt */}
          {post.excerpt && (
            <p className="text-xl text-[#7a5c4a] mb-10 leading-relaxed border-l-4 pl-5 italic"
              style={{ borderColor: cat?.color ?? "#c17f4a" }}>
              {post.excerpt}
            </p>
          )}

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-8">
              {post.tags.map(t => (
                <span key={t} className="text-[10px] bg-[#f5e6d3] text-[#7a5c4a] px-2.5 py-1 rounded-full border border-[#e8d5c4] font-medium">
                  #{t}
                </span>
              ))}
            </div>
          )}

          <hr className="border-[#e8d5c4] mb-10" />

          {/* Article content */}
          <div
            style={{ fontFamily:"inherit", color:"#5a3e28", lineHeight:1.85, fontSize:"1.0625rem" }}
            dangerouslySetInnerHTML={{
              __html: `<p style="margin-bottom:1.25rem;line-height:1.85;color:#5a3e28">${renderMarkdown(post.content)}</p>`
            }}
          />

          <hr className="border-[#e8d5c4] mt-14 mb-8" />

          {/* Footer */}
          <div className="flex items-center justify-between flex-wrap gap-3">
            <button onClick={() => navigate("/blog")}
              className="inline-flex items-center gap-2 text-[#c17f4a] font-semibold hover:gap-3 transition-all text-sm">
              <ArrowLeft className="h-4 w-4" /> Todos os artigos
            </button>
            <span className="text-xs text-[#b08070]">Publicado em {fmtDate(post)}</span>
          </div>
        </div>
      </div>

      {/* ── Related posts ──────────────────────────────────────────────────────── */}
      {related.length > 0 && (
        <section className="py-16 bg-[#fdf8f3] border-t border-[#e8d5c4]">
          <div className="container max-w-5xl">
            <div className="flex items-center gap-4 mb-8">
              <h2 className="font-display text-2xl text-[#2c1a0e]">Artigos relacionados</h2>
              <div className="flex-1 h-px bg-[#e8d5c4]" />
              <button onClick={() => navigate("/blog")}
                className="text-sm text-[#c17f4a] font-semibold hover:underline flex items-center gap-1">
                Ver todos <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {related.map(p => {
                const pCat = getCat(p.category_id);
                return (
                  <article key={p.id} onClick={() => navigate(`/blog/${p.slug}`)}
                    className="bg-white rounded-2xl overflow-hidden border border-[#e8d5c4] shadow-sm hover:shadow-md hover:-translate-y-1 transition-all cursor-pointer group flex flex-col">
                    <div className="aspect-[16/10] overflow-hidden bg-[#f5e6d3] relative">
                      <img
                        src={p.cover_url || "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600"}
                        alt={p.title} loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute bottom-2 right-2 bg-black/55 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Clock className="h-2.5 w-2.5" />{rt(p)} min
                      </div>
                    </div>
                    <div className="p-5 flex-1 flex flex-col gap-2">
                      <div className="flex items-center justify-between gap-2">
                        {pCat
                          ? <span style={{ color: pCat.color ?? "#c17f4a" }} className="text-[10px] font-bold uppercase tracking-widest">{pCat.name}</span>
                          : <span className="text-[10px] font-bold uppercase tracking-widest text-[#c17f4a]">Artigo</span>
                        }
                        <span className="text-xs text-[#b08070]">{fmtShort(p)}</span>
                      </div>
                      <h3 className="font-display text-lg leading-snug group-hover:text-[#c17f4a] transition-colors text-[#2c1a0e] line-clamp-2">
                        {p.title}
                      </h3>
                      <p className="text-sm text-[#7a5c4a] line-clamp-2 leading-relaxed flex-1">
                        {p.excerpt || p.content.replace(/[#*_>`\[\]!()-]/g, "").substring(0, 100)}
                      </p>
                      <span className="inline-flex items-center gap-1.5 text-[#c17f4a] text-sm font-semibold mt-1 self-start group-hover:gap-2.5 transition-all">
                        Ler mais <ArrowRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* ── CTA ───────────────────────────────────────────────────────────────── */}
      <section className="py-16 bg-white border-t border-[#e8d5c4]">
        <div className="container text-center">
          <h2 className="font-display text-3xl text-[#2c1a0e] mb-3">Quer ver mais inspiração?</h2>
          <p className="text-[#7a5c4a] mb-6 max-w-md mx-auto">
            Siga-nos nas redes sociais para acompanhar novidades, dicas e transformações dos nossos projetos.
          </p>
          <div className="flex justify-center gap-6">
            <a href="https://instagram.com" target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 text-[#c17f4a] font-semibold hover:underline">📸 Instagram</a>
            <span className="text-[#e8d5c4]">·</span>
            <a href="https://facebook.com" target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 text-[#c17f4a] font-semibold hover:underline">👍 Facebook</a>
          </div>
        </div>
      </section>

      <div className="h-8" />
    </>
  );
};

export default BlogPost;
