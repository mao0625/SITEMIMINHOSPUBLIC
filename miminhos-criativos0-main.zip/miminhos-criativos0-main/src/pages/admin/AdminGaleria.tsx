import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Upload, Trash2, ImageIcon, Search, X, ZoomIn,
  ChevronLeft, ChevronRight, Grid3X3, LayoutList, Filter,
} from "lucide-react";

const CATEGORIES = ["Todas", "Casamentos", "Batismos", "Aniversários", "Eventos Corporativos", "Comunhões", "Outros"];

// ─── Lightbox ─────────────────────────────────────────────────────────────────
const Lightbox = ({ items, index, onClose }: { items: any[]; index: number; onClose: () => void }) => {
  const [current, setCurrent] = useState(index);

  const prev = () => setCurrent((c) => (c - 1 + items.length) % items.length);
  const next = () => setCurrent((c) => (c + 1) % items.length);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const item = items[current];
  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
      onClick={onClose}
    >
      {/* Fechar */}
      <button
        className="absolute top-4 right-4 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full p-2 transition-colors z-10"
        onClick={onClose}
      >
        <X className="h-5 w-5" />
      </button>

      {/* Contador */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 text-white/50 text-sm">
        {current + 1} / {items.length}
      </div>

      {/* Nav esquerda */}
      {items.length > 1 && (
        <button
          className="absolute left-4 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full p-3 transition-colors"
          onClick={(e) => { e.stopPropagation(); prev(); }}
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
      )}

      {/* Imagem */}
      <div className="max-w-4xl max-h-[80vh] mx-16" onClick={(e) => e.stopPropagation()}>
        <img
          src={item.image_url}
          alt={item.title || ""}
          className="max-w-full max-h-[75vh] object-contain rounded-lg shadow-2xl"
        />
        <div className="mt-3 text-center">
          <p className="text-white font-medium">{item.title || "—"}</p>
          <p className="text-white/40 text-sm">{item.category}</p>
        </div>
      </div>

      {/* Nav direita */}
      {items.length > 1 && (
        <button
          className="absolute right-4 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full p-3 transition-colors"
          onClick={(e) => { e.stopPropagation(); next(); }}
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      )}
    </div>
  );
};

// ─── Upload Zone ──────────────────────────────────────────────────────────────
const UploadZone = ({
  category, setCategory, title, setTitle, onUpload, uploading, fileRef,
}: any) => {
  const [dragging, setDragging] = useState(false);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    onUpload(e.dataTransfer.files);
  }, [onUpload]);

  return (
    <div className="border border-border rounded-lg overflow-hidden bg-card mb-6">
      {/* Cabeçalho SAP */}
      <div className="px-4 py-2.5 border-b border-border bg-muted/40">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Carregar Imagens</span>
      </div>

      <div className="p-5 grid md:grid-cols-3 gap-4 items-end">
        {/* Categoria */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide block mb-1.5">Categoria</label>
          <select
            className="w-full border border-border rounded h-9 px-3 bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {CATEGORIES.filter((c) => c !== "Todas").map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>

        {/* Título */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide block mb-1.5">Título (opcional)</label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Nome descritivo da imagem"
            className="h-9 text-sm"
          />
        </div>

        {/* Botão upload */}
        <div>
          <input ref={fileRef} type="file" accept="image/*" multiple onChange={(e) => onUpload(e.target.files)} className="hidden" id="gal-up" />
          <Button asChild className="bg-gradient-gold w-full h-9" disabled={uploading}>
            <label htmlFor="gal-up" className="cursor-pointer text-sm">
              <Upload className="h-3.5 w-3.5 mr-2" />
              {uploading ? "A carregar…" : "Selecionar ficheiros"}
            </label>
          </Button>
        </div>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`mx-5 mb-5 border-2 border-dashed rounded-lg flex flex-col items-center justify-center py-6 transition-all cursor-pointer ${
          dragging
            ? "border-primary bg-primary/5 scale-[1.01]"
            : "border-border/60 hover:border-primary/50 hover:bg-muted/30"
        }`}
        onClick={() => fileRef.current?.click()}
      >
        <Upload className={`h-6 w-6 mb-2 transition-colors ${dragging ? "text-primary" : "text-muted-foreground/40"}`} />
        <p className={`text-sm transition-colors ${dragging ? "text-primary font-medium" : "text-muted-foreground"}`}>
          {dragging ? "Largar para carregar" : "Arraste imagens aqui"}
        </p>
        <p className="text-xs text-muted-foreground/50 mt-0.5">PNG, JPG, WEBP · máx 5MB por ficheiro</p>
      </div>
    </div>
  );
};

// ─── Página principal ─────────────────────────────────────────────────────────
export const AdminGaleria = () => {
  const [items, setItems] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [category, setCategory] = useState("Casamentos");
  const [title, setTitle] = useState("");
  const [filterCat, setFilterCat] = useState("Todas");
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [lightbox, setLightbox] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = () =>
    supabase.from("gallery_items").select("*").order("created_at", { ascending: false })
      .then(({ data }) => setItems(data ?? []));

  useEffect(() => { load(); }, []);

  const upload = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        if (file.size > 5 * 1024 * 1024) { toast.error(`${file.name}: máx 5MB`); continue; }
        const path = `${Date.now()}_${file.name.replace(/[^\w.-]/g, "_")}`;
        const { error: upErr } = await supabase.storage.from("gallery").upload(path, file);
        if (upErr) { toast.error(upErr.message); continue; }
        const { data: { publicUrl } } = supabase.storage.from("gallery").getPublicUrl(path);
        await supabase.from("gallery_items").insert({ image_url: publicUrl, category, title: title || file.name });
      }
      toast.success("Imagens carregadas com sucesso");
      setTitle("");
      load();
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const remove = async (item: any, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Eliminar esta imagem?")) return;
    const path = item.image_url.split("/gallery/")[1];
    if (path) await supabase.storage.from("gallery").remove([path]);
    await supabase.from("gallery_items").delete().eq("id", item.id);
    toast.success("Imagem eliminada");
    load();
  };

  const filtered = items.filter((it) => {
    const matchCat = filterCat === "Todas" || it.category === filterCat;
    const matchSearch = search === "" ||
      it.title?.toLowerCase().includes(search.toLowerCase()) ||
      it.category?.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  // Contagem por categoria
  const counts = CATEGORIES.reduce((acc, cat) => {
    acc[cat] = cat === "Todas" ? items.length : items.filter((i) => i.category === cat).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <>
      <PageHeader title="Galeria" description="Imagens públicas dos eventos realizados" />

      <UploadZone
        category={category} setCategory={setCategory}
        title={title} setTitle={setTitle}
        onUpload={upload} uploading={uploading} fileRef={fileRef}
      />

      {/* Filtros + pesquisa + controlos */}
      <div className="border border-border rounded-lg overflow-hidden bg-card mb-4">
        <div className="px-4 py-2.5 border-b border-border bg-muted/40 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-1 flex-wrap">
            <Filter className="h-3.5 w-3.5 text-muted-foreground mr-1" />
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCat(cat)}
                className={`text-xs px-3 py-1 rounded-full border transition-all ${
                  filterCat === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border hover:border-primary text-muted-foreground hover:text-foreground"
                }`}
              >
                {cat}
                {counts[cat] > 0 && (
                  <span className={`ml-1.5 text-[10px] ${filterCat === cat ? "opacity-80" : "opacity-50"}`}>
                    {counts[cat]}
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-muted/60 rounded px-2 py-1">
              <Search className="h-3.5 w-3.5 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Pesquisar..."
                className="bg-transparent text-xs outline-none w-32 placeholder:text-muted-foreground/50"
              />
              {search && (
                <button onClick={() => setSearch("")} className="text-muted-foreground hover:text-foreground">
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
            {/* Vista */}
            <div className="flex border border-border rounded overflow-hidden">
              <button
                onClick={() => setView("grid")}
                className={`p-1.5 transition-colors ${view === "grid" ? "bg-primary text-primary-foreground" : "hover:bg-muted text-muted-foreground"}`}
              >
                <Grid3X3 className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => setView("list")}
                className={`p-1.5 transition-colors ${view === "list" ? "bg-primary text-primary-foreground" : "hover:bg-muted text-muted-foreground"}`}
              >
                <LayoutList className="h-3.5 w-3.5" />
              </button>
            </div>
            <span className="text-xs text-muted-foreground">{filtered.length} imagem{filtered.length !== 1 ? "ns" : ""}</span>
          </div>
        </div>

        {/* Conteúdo */}
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-3">
            <ImageIcon className="h-10 w-10 opacity-20" />
            <p className="text-sm">{items.length === 0 ? "Sem imagens. Carregue as primeiras!" : "Nenhuma imagem corresponde ao filtro."}</p>
            {search && (
              <button onClick={() => setSearch("")} className="text-xs text-primary hover:underline">Limpar pesquisa</button>
            )}
          </div>
        ) : view === "grid" ? (
          <div className="p-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {filtered.map((it, idx) => (
              <div
                key={it.id}
                className="group relative bg-muted rounded-lg overflow-hidden cursor-pointer border border-border hover:border-primary/50 hover:shadow-md transition-all duration-200"
                onClick={() => setLightbox(idx)}
              >
                <div className="aspect-square">
                  <img src={it.image_url} alt={it.title || ""} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                </div>
                {/* Overlay hover */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-200 flex items-center justify-center">
                  <ZoomIn className="h-6 w-6 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                </div>
                {/* Info */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-2 py-2 translate-y-full group-hover:translate-y-0 transition-transform duration-200">
                  <p className="text-white text-xs font-medium truncate">{it.title || it.category}</p>
                </div>
                {/* Badge categoria */}
                <div className="absolute top-1.5 left-1.5">
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/50 text-white/80 backdrop-blur-sm">
                    {it.category}
                  </span>
                </div>
                {/* Botão eliminar */}
                <button
                  onClick={(e) => remove(it, e)}
                  className="absolute top-1.5 right-1.5 bg-destructive text-destructive-foreground p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:bg-destructive/80"
                  title="Eliminar"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          /* Vista lista */
          <div className="divide-y divide-border">
            {filtered.map((it, idx) => (
              <div
                key={it.id}
                className="flex items-center gap-4 px-4 py-3 hover:bg-muted/40 cursor-pointer group transition-colors"
                onClick={() => setLightbox(idx)}
              >
                <div className="h-14 w-14 rounded border border-border overflow-hidden shrink-0 bg-muted">
                  <img src={it.image_url} alt={it.title || ""} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" loading="lazy" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{it.title || "—"}</p>
                  <p className="text-xs text-muted-foreground">{it.category}</p>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <ZoomIn className="h-4 w-4 text-muted-foreground" />
                  <button
                    onClick={(e) => remove(it, e)}
                    className="p-1.5 rounded hover:bg-destructive/10 transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <Lightbox items={filtered} index={lightbox} onClose={() => setLightbox(null)} />
      )}
    </>
  );
};
