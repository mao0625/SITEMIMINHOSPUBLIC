import React from 'react';
import { useParams } from 'react-router-dom';
import { PageBuilderEditor } from '@/components/PageBuilder/PageBuilderEditor';
import { useAuth } from '@/hooks/useAuth';
import { Navigate } from 'react-router-dom';

export const PageBuilderPage: React.FC = () => {
  const { pageSlug } = useParams<{ pageSlug: string }>();
  const { user } = useAuth();

  // Check if user is admin
  if (!user || user.role !== 'admin') {
    return <Navigate to="/login" replace />;
  }

  if (!pageSlug) {
    return <div className="p-6 text-center text-gray-500">Page slug not provided</div>;
  }

  return <PageBuilderEditor pageSlug={pageSlug} />;
};
