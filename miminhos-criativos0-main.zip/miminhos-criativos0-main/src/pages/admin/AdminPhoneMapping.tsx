import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Trash2, Edit, Copy, Check } from "lucide-react";

interface PhoneMapping {
  id: string;
  user_id: string;
  phone: string;
  email: string;
  created_at: string;
}

interface User {
  id: string;
  email: string;
}

const AdminPhoneMapping = () => {
  const [mappings, setMappings] = useState<PhoneMapping[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<PhoneMapping | null>(null);
  const [form, setForm] = useState({ user_id: "", phone: "", email: "" });
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  // Load mappings
  const loadMappings = async () => {
    const { data } = await supabase
      .from("user_phone_mappings")
      .select("*")
      .order("created_at", { ascending: false });
    setMappings(data ?? []);
  };

  // Load users from auth
  const loadUsers = async () => {
    const { data: { users: authUsers } } = await supabase.auth.admin.listUsers();
    setUsers((authUsers ?? []) as unknown as User[]);
  };

  useEffect(() => {
    loadMappings();
    loadUsers();
  }, []);

  const startNew = () => {
    setEdit(null);
    setForm({ user_id: "", phone: "", email: "" });
    setOpen(true);
  };

  const startEdit = (mapping: PhoneMapping) => {
    setEdit(mapping);
    setForm({ 
      user_id: mapping.user_id, 
      phone: mapping.phone, 
      email: mapping.email 
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.user_id || !form.phone || !form.email) {
      toast.error("Preencha todos os campos");
      return;
    }

    setLoading(true);

    // Validar formato do telefone
    const phoneRegex = /^\d{9,}$/;
    if (!phoneRegex.test(form.phone.replace(/\s|-/g, ""))) {
      toast.error("Telefone deve ter pelo menos 9 dígitos");
      setLoading(false);
      return;
    }

    const phoneFormatted = form.phone.replace(/\s|-/g, "");

    try {
      if (edit) {
        const { error } = await supabase
          .from("user_phone_mappings")
          .update({ 
            user_id: form.user_id, 
            phone: phoneFormatted, 
            email: form.email 
          })
          .eq("id", edit.id);

        if (error) {
          if (error.message.includes("duplicate")) {
            toast.error("Este telefone já está associado a outro utilizador");
          } else {
            toast.error(error.message);
          }
        } else {
          toast.success("Mapeamento atualizado");
          setOpen(false);
          loadMappings();
        }
      } else {
        const { error } = await supabase
          .from("user_phone_mappings")
          .insert({ 
            user_id: form.user_id, 
            phone: phoneFormatted, 
            email: form.email 
          });

        if (error) {
          if (error.message.includes("duplicate")) {
            toast.error("Este telefone já está registado no sistema");
          } else {
            toast.error(error.message);
          }
        } else {
          toast.success("Mapeamento criado");
          setOpen(false);
          loadMappings();
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm("Eliminar este mapeamento?")) return;

    const { error } = await supabase
      .from("user_phone_mappings")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success("Mapeamento eliminado");
      loadMappings();
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(text);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <>
      <PageHeader
        title="Telefones de Utilizadores"
        description="Gerir mapeamento de telefones para login"
        action={
          <Button onClick={startNew} className="bg-gradient-gold">
            <Plus className="h-4 w-4 mr-1" />
            Novo mapeamento
          </Button>
        }
      />

      <div className="bg-card border rounded shadow-soft overflow-hidden">
        {mappings.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-muted-foreground">Nenhum mapeamento criado</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold">Telefone</TableHead>
                <TableHead className="font-semibold">Email</TableHead>
                <TableHead className="font-semibold">User ID</TableHead>
                <TableHead className="font-semibold">Criado em</TableHead>
                <TableHead className="text-right font-semibold">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mappings.map((mapping) => (
                <TableRow key={mapping.id} className="hover:bg-muted/30">
                  <TableCell className="font-mono font-medium">
                    {mapping.phone}
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {mapping.email}
                  </TableCell>
                  <TableCell className="font-mono text-sm text-muted-foreground max-w-xs truncate">
                    <button
                      onClick={() => copyToClipboard(mapping.user_id)}
                      className="hover:text-primary transition-colors flex items-center gap-1"
                    >
                      {copied === mapping.user_id ? (
                        <Check className="h-3 w-3" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                      {mapping.user_id.substring(0, 8)}...
                    </button>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {new Date(mapping.created_at).toLocaleDateString("pt-PT")}
                  </TableCell>
                  <TableCell className="text-right space-x-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => startEdit(mapping)}
                      className="hover:bg-primary/10"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => remove(mapping.id)}
                      className="hover:bg-destructive/10"
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {edit ? "Editar mapeamento" : "Novo mapeamento"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="user_id" className="font-semibold">
                Utilizador *
              </Label>
              <select
                id="user_id"
                value={form.user_id}
                onChange={(e) =>
                  setForm({ ...form, user_id: e.target.value })
                }
                className="w-full mt-1 px-3 py-2 border border-input rounded-md bg-background text-foreground"
              >
                <option value="">Selecione um utilizador</option>
                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.email}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <Label htmlFor="phone" className="font-semibold">
                Telefone *
              </Label>
              <Input
                id="phone"
                type="tel"
                value={form.phone}
                onChange={(e) =>
                  setForm({ ...form, phone: e.target.value })
                }
                placeholder="926 992 352"
                className="mt-1"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Apenas números (9+ dígitos)
              </p>
            </div>

            <div>
              <Label htmlFor="email" className="font-semibold">
                Email *
              </Label>
              <Input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) =>
                  setForm({ ...form, email: e.target.value })
                }
                placeholder="email@exemplo.com"
                className="mt-1"
              />
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                onClick={save}
                disabled={loading}
                className="flex-1 bg-gradient-gold"
              >
                {loading ? "A guardar..." : edit ? "Atualizar" : "Criar"}
              </Button>
              <Button
                onClick={() => setOpen(false)}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AdminPhoneMapping;
