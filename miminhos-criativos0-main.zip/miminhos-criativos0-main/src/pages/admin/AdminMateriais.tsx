import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle, Plus, Trash2, PackageOpen, ArrowLeft, Save, X, Package, ChevronRight, BarChart3, TrendingDown, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

type Material = {
  id: string;
  name: string;
  category: string | null;
  quantity: number;
  min_quantity: number;
  unit: string | null;
  notes: string | null;
};

type FormState = {
  name: string;
  category: string;
  quantity: number;
  min_quantity: number;
  unit: string;
  notes: string;
};

const emptyForm: FormState = {
  name: "",
  category: "",
  quantity: 0,
  min_quantity: 0,
  unit: "un",
  notes: "",
};

// ─── Breadcrumb ───────────────────────────────────────────────────────────────
const Breadcrumb = ({ items }: { items: { label: string; onClick?: () => void }[] }) => (
  <nav className="flex items-center gap-1 text-xs text-muted-foreground mb-4 bg-muted/30 border border-border/50 rounded-md px-3 py-2">
    {items.map((item, i) => (
      <span key={i} className="flex items-center gap-1">
        {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground/40" />}
        {item.onClick ? (
          <button onClick={item.onClick} className="hover:text-primary transition-colors font-medium">
            {item.label}
          </button>
        ) : (
          <span className="text-foreground font-semibold">{item.label}</span>
        )}
      </span>
    ))}
  </nav>
);

// ─── Action Bar ───────────────────────────────────────────────────────────────
const ActionBar = ({
  onBack,
  backLabel = "Voltar",
  title,
  subtitle,
  actions,
}: {
  onBack: () => void;
  backLabel?: string;
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) => (
  <div className="flex items-center gap-3 bg-card border border-border shadow-sm rounded-lg px-4 py-2.5 mb-5 border-t-[3px] border-t-primary flex-wrap">
    <button
      onClick={onBack}
      className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors group font-medium"
    >
      <ArrowLeft className="h-3.5 w-3.5 transition-transform group-hover:-translate-x-0.5" />
      {backLabel}
    </button>
    <div className="h-4 w-px bg-border/70" />
    <div className="flex items-center gap-2 flex-1 min-w-0">
      <span className="text-sm font-semibold truncate">{title}</span>
      {subtitle && <span className="text-xs text-muted-foreground hidden sm:block">{subtitle}</span>}
    </div>
    {actions && <div className="flex items-center gap-2 ml-auto">{actions}</div>}
  </div>
);

// ─── Página Registar Material ─────────────────────────────────────────────────
const RegistarMaterial = ({
  onBack,
  onSaved,
}: {
  onBack: () => void;
  onSaved: () => void;
}) => {
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);

  const set = (key: keyof FormState, value: any) =>
    setForm((f) => ({ ...f, [key]: value }));

  const save = async () => {
    if (!form.name.trim()) return toast.error("O nome do material é obrigatório.");
    setSaving(true);
    const { error } = await supabase.from("materials").insert(form);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Material adicionado ao inventário.");
    onSaved();
  };

  const stockStatus = () => {
    if (form.quantity === 0) return null;
    if (form.quantity <= form.min_quantity) return "low";
    return "ok";
  };

  const status = stockStatus();

  const unitOptions = ["un", "kg", "cx", "l", "m", "m²", "par", "rolo"];
  const categoryOptions = ["Mobiliário", "Decoração", "Iluminação", "Audiovisual", "Louça", "Têxtil", "Estruturas", "Outro"];

  return (
    <div className="animate-in fade-in duration-300">
      <Breadcrumb
        items={[
          { label: "Inventário de Materiais", onClick: onBack },
          { label: "Registar Material" },
        ]}
      />

      <ActionBar
        onBack={onBack}
        backLabel="Inventário"
        title="Registar Novo Material"
        subtitle="Adicionar ao inventário"
        actions={
          <>
            <Button variant="outline" size="sm" onClick={onBack} className="h-8 text-xs">
              <X className="h-3.5 w-3.5 mr-1.5" /> Cancelar
            </Button>
            <Button size="sm" className="h-8 text-xs bg-gradient-gold" onClick={save} disabled={saving}>
              <Save className="h-3.5 w-3.5 mr-1.5" />
              {saving ? "A guardar…" : "Guardar Material"}
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-5">
        {/* Left – main form */}
        <div className="space-y-4">
          {/* Identificação */}
          <div className="bg-card border border-border/60 rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border flex items-center gap-2">
              <Package className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Identificação
              </span>
            </div>
            <div className="divide-y divide-border/40">
              <div className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/10 transition-colors">
                <label className="text-sm text-muted-foreground w-36 shrink-0">
                  Nome <span className="text-destructive">*</span>
                </label>
                <Input
                  value={form.name}
                  onChange={(e) => set("name", e.target.value)}
                  placeholder="Ex: Cadeiras Tiffany"
                  className="flex-1 h-9 text-sm border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30"
                />
              </div>

              <div className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/10 transition-colors">
                <label className="text-sm text-muted-foreground w-36 shrink-0">Categoria</label>
                <div className="flex-1 flex gap-2 flex-wrap">
                  {categoryOptions.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => set("category", form.category === cat ? "" : cat)}
                      className={`text-xs px-3 py-1.5 rounded-md border transition-all font-medium ${
                        form.category === cat
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border/60 text-muted-foreground hover:border-border hover:text-foreground"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                  <Input
                    value={categoryOptions.includes(form.category) ? "" : form.category}
                    onChange={(e) => set("category", e.target.value)}
                    placeholder="Outra…"
                    className="h-8 w-28 text-xs border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30"
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/10 transition-colors">
                <label className="text-sm text-muted-foreground w-36 shrink-0">Unidade</label>
                <div className="flex gap-2 flex-wrap">
                  {unitOptions.map((u) => (
                    <button
                      key={u}
                      onClick={() => set("unit", u)}
                      className={`text-xs px-3 py-1.5 rounded-md border font-mono transition-all ${
                        form.unit === u
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border/60 text-muted-foreground hover:border-border"
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-start gap-4 px-5 py-3.5 hover:bg-muted/10 transition-colors">
                <label className="text-sm text-muted-foreground w-36 shrink-0 pt-2">Notas</label>
                <Input
                  value={form.notes}
                  onChange={(e) => set("notes", e.target.value)}
                  placeholder="Fornecedor, referências, localização…"
                  className="flex-1 h-9 text-sm border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30"
                />
              </div>
            </div>
          </div>

          {/* Stock */}
          <div className="bg-card border border-border/60 rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border flex items-center gap-2">
              <BarChart3 className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Controlo de Stock
              </span>
            </div>
            <div className="p-5 grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Quantidade Inicial
                </Label>
                <div className="flex items-center gap-2 bg-muted/30 border border-border/60 rounded-lg px-3 py-2">
                  <Input
                    type="number"
                    min={0}
                    value={form.quantity}
                    onChange={(e) => set("quantity", Number(e.target.value))}
                    className="border-none bg-transparent shadow-none focus-visible:ring-0 h-8 text-xl font-bold w-20 p-0"
                  />
                  <span className="text-sm text-muted-foreground font-mono">{form.unit || "un"}</span>
                </div>
                <p className="text-xs text-muted-foreground">Quantidade em armazém agora</p>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-semibold text-amber-600 uppercase tracking-wider">
                  Alerta Mínimo
                </Label>
                <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg px-3 py-2">
                  <Input
                    type="number"
                    min={0}
                    value={form.min_quantity}
                    onChange={(e) => set("min_quantity", Number(e.target.value))}
                    className="border-none bg-transparent shadow-none focus-visible:ring-0 h-8 text-xl font-bold w-20 p-0 text-amber-700"
                  />
                  <span className="text-sm text-amber-600 font-mono">{form.unit || "un"}</span>
                </div>
                <p className="text-xs text-muted-foreground">Alerta quando stock atingir este valor</p>
              </div>
            </div>

            {/* Stock bar preview */}
            {form.min_quantity > 0 && (
              <div className="px-5 pb-5">
                <div className="bg-muted/30 border border-border/40 rounded-lg p-3 space-y-2">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Nível de stock</span>
                    <span className="font-mono">{form.quantity} / {form.min_quantity} mín.</span>
                  </div>
                  <div className="h-2 bg-muted/60 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        status === "low" ? "bg-amber-500" : "bg-emerald-500"
                      }`}
                      style={{
                        width: `${Math.min(100, (form.quantity / Math.max(form.min_quantity * 2, 1)) * 100)}%`,
                      }}
                    />
                  </div>
                  <p className={`text-xs font-medium ${status === "low" ? "text-amber-600" : "text-emerald-600"}`}>
                    {status === "low" ? "⚠ Stock abaixo do mínimo" : "✓ Stock dentro do normal"}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right – preview card */}
        <div className="space-y-4">
          <div className="bg-card border border-border/60 rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border">
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Pré-visualização
              </span>
            </div>
            <div className="p-4">
              {/* Mini card preview */}
              <div className={`rounded-lg border-2 p-4 transition-all ${
                status === "low"
                  ? "border-amber-200 bg-amber-50/50 dark:bg-amber-950/10"
                  : status === "ok"
                  ? "border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/10"
                  : "border-border/60 bg-muted/20"
              }`}>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <p className="font-semibold text-sm">{form.name || <span className="text-muted-foreground italic">Nome do material</span>}</p>
                    {form.category && (
                      <p className="text-xs text-muted-foreground mt-0.5">{form.category}</p>
                    )}
                  </div>
                  {status && (
                    <span className={`inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-full ${
                      status === "low"
                        ? "bg-amber-100 text-amber-700"
                        : "bg-emerald-100 text-emerald-700"
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${status === "low" ? "bg-amber-500 animate-pulse" : "bg-emerald-500"}`} />
                      {status === "low" ? "Baixo" : "OK"}
                    </span>
                  )}
                </div>
                <div className="flex items-end gap-1">
                  <span className="text-3xl font-bold">{form.quantity}</span>
                  <span className="text-sm text-muted-foreground mb-0.5 font-mono">{form.unit}</span>
                </div>
                {form.min_quantity > 0 && (
                  <p className="text-xs text-muted-foreground mt-1">Mín: {form.min_quantity} {form.unit}</p>
                )}
                {form.notes && (
                  <p className="text-xs text-muted-foreground mt-2 border-t border-border/40 pt-2 italic">{form.notes}</p>
                )}
              </div>
            </div>
          </div>

          {/* Resumo */}
          <div className="bg-card border border-border/60 rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border">
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Resumo</span>
            </div>
            <div className="divide-y divide-border/30">
              {[
                { label: "Nome", value: form.name || "—" },
                { label: "Categoria", value: form.category || "—" },
                { label: "Unidade", value: form.unit || "—" },
                { label: "Qtd. Inicial", value: `${form.quantity} ${form.unit}` },
                { label: "Alerta em", value: `${form.min_quantity} ${form.unit}` },
              ].map((f) => (
                <div key={f.label} className="flex justify-between items-center px-4 py-2.5 text-xs">
                  <span className="text-muted-foreground">{f.label}</span>
                  <span className="font-medium text-right max-w-[130px] truncate">{f.value}</span>
                </div>
              ))}
            </div>
            <div className="p-4">
              <Button onClick={save} disabled={saving} className="w-full bg-gradient-gold h-9 text-sm">
                <Save className="h-4 w-4 mr-2" />
                {saving ? "A guardar…" : "Guardar Material"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Página Principal ─────────────────────────────────────────────────────────
const AdminMateriais = () => {
  const [items, setItems] = useState<Material[]>([]);
  const [view, setView] = useState<"list" | "registar">("list");

  const load = async () => {
    const { data } = await supabase.from("materials").select("*").order("name");
    setItems((data ?? []) as Material[]);
  };

  useEffect(() => { load(); }, []);

  const updateQty = async (id: string, quantity: number) => {
    await supabase.from("materials").update({ quantity }).eq("id", id);
    toast.success("Quantidade atualizada.");
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Deseja eliminar este material do sistema?")) return;
    await supabase.from("materials").delete().eq("id", id);
    toast.success("Material eliminado.");
    load();
  };

  if (view === "registar") {
    return (
      <RegistarMaterial
        onBack={() => setView("list")}
        onSaved={() => { setView("list"); load(); }}
      />
    );
  }

  const lowStock = items.filter((i) => Number(i.quantity) <= Number(i.min_quantity));
  const okStock = items.filter((i) => Number(i.quantity) > Number(i.min_quantity));

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      <PageHeader
        title="Inventário de Materiais"
        description="Controlo de stock e monitorização de recursos."
        action={
          <Button
            onClick={() => setView("registar")}
            className="bg-gradient-gold shadow-sm hover:shadow-md transition-all"
          >
            <Plus className="h-4 w-4 mr-2" />
            Registar Material
          </Button>
        }
      />

      {/* Stats row */}
      {items.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card border border-border/60 rounded-lg px-4 py-3 shadow-sm flex items-center gap-3">
            <div className="bg-muted/50 rounded-md p-2">
              <Package className="h-4 w-4 text-foreground" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total</p>
              <p className="text-xl font-bold">{items.length}</p>
            </div>
          </div>
          <div className="bg-card border border-emerald-200/60 dark:border-emerald-800/40 rounded-lg px-4 py-3 shadow-sm flex items-center gap-3">
            <div className="bg-emerald-50 dark:bg-emerald-950/20 rounded-md p-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Stock OK</p>
              <p className="text-xl font-bold text-emerald-600">{okStock.length}</p>
            </div>
          </div>
          <div className="bg-card border border-amber-200/60 dark:border-amber-800/40 rounded-lg px-4 py-3 shadow-sm flex items-center gap-3">
            <div className="bg-amber-50 dark:bg-amber-950/20 rounded-md p-2">
              <TrendingDown className="h-4 w-4 text-amber-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Stock Baixo</p>
              <p className="text-xl font-bold text-amber-600">{lowStock.length}</p>
            </div>
          </div>
        </div>
      )}

      {/* Alert strip */}
      {lowStock.length > 0 && (
        <div className="border-l-4 border-amber-500 bg-amber-50 dark:bg-amber-950/20 p-4 rounded-r-lg shadow-sm flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 shrink-0" />
          <div>
            <h4 className="font-bold text-amber-800 dark:text-amber-400 text-sm uppercase tracking-wider mb-1">
              Stock Crítico — {lowStock.length} {lowStock.length === 1 ? "material" : "materiais"}
            </h4>
            <p className="text-sm text-amber-700 dark:text-amber-300">
              Necessitam de reposição:{" "}
              <span className="font-semibold">{lowStock.map((i) => i.name).join(", ")}</span>.
            </p>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border/60 rounded-lg shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/40 hover:bg-muted/40 border-b border-border/60">
              {["Material", "Categoria", "Quantidade Atual", "Alerta Mínimo", "Estado", ""].map((h) => (
                <TableHead
                  key={h}
                  className={`text-xs font-semibold uppercase tracking-widest text-muted-foreground py-3 ${h === "" ? "text-right" : ""}`}
                >
                  {h}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((m) => {
              const low = Number(m.quantity) <= Number(m.min_quantity);
              return (
                <TableRow
                  key={m.id}
                  className={`hover:bg-muted/20 transition-colors border-b border-border/40 last:border-0 ${low ? "bg-amber-50/30 dark:bg-amber-950/10" : ""}`}
                >
                  <TableCell>
                    <div>
                      <p className="font-semibold text-sm">{m.name}</p>
                      {m.notes && <p className="text-xs text-muted-foreground/70 mt-0.5 italic truncate max-w-[200px]">{m.notes}</p>}
                    </div>
                  </TableCell>
                  <TableCell>
                    {m.category ? (
                      <span className="text-xs px-2 py-0.5 rounded-md bg-muted border border-border/50 text-muted-foreground font-medium">
                        {m.category}
                      </span>
                    ) : (
                      <span className="text-muted-foreground/50 text-sm">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        defaultValue={m.quantity}
                        className={`h-8 w-20 font-bold text-sm text-center ${
                          low
                            ? "border-amber-400 bg-amber-50 dark:bg-amber-950/20 focus-visible:ring-amber-400"
                            : "border-border/60 focus-visible:border-primary focus-visible:ring-primary/30"
                        }`}
                        onBlur={(e) => updateQty(m.id, Number(e.target.value))}
                      />
                      <span className="text-xs text-muted-foreground font-mono">{m.unit}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground font-mono">
                    {m.min_quantity} <span className="text-xs">{m.unit}</span>
                  </TableCell>
                  <TableCell>
                    {low ? (
                      <span className="inline-flex items-center gap-1.5 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400 text-xs font-bold px-2.5 py-1 rounded-full border border-amber-200 dark:border-amber-800">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                        Baixo
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400 text-xs font-bold px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        OK
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      onClick={() => remove(m.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
            {items.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-16 text-muted-foreground">
                  <div className="flex flex-col items-center gap-3">
                    <div className="bg-muted/40 rounded-2xl p-5">
                      <PackageOpen className="h-9 w-9 text-muted-foreground/30" />
                    </div>
                    <p className="font-semibold text-base">O inventário está vazio</p>
                    <p className="text-sm opacity-60">Registe o primeiro material para começar.</p>
                    <Button
                      size="sm"
                      onClick={() => setView("registar")}
                      className="bg-gradient-gold mt-1"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Registar primeiro material
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default AdminMateriais;
