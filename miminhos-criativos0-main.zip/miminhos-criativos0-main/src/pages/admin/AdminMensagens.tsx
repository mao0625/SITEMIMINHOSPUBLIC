import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { format, isToday, isYesterday } from "date-fns";
import { pt } from "date-fns/locale";
import { Send, Search, MessageSquare, Circle } from "lucide-react";

const formatMsgDate = (dateStr: string) => {
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, "HH:mm");
  if (isYesterday(d)) return "Ontem";
  return format(d, "dd/MM/yyyy", { locale: pt });
};

const formatMsgTime = (dateStr: string) =>
  format(new Date(dateStr), "dd/MM/yyyy HH:mm", { locale: pt });

export const AdminMensagens = () => {
  const { user } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const [clients, setClients] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [body, setBody] = useState("");
  const [search, setSearch] = useState("");
  const [sending, setSending] = useState(false);
  const [lastMsgByClient, setLastMsgByClient] = useState<Record<string, any>>({});
  const bottomRef = useRef<HTMLDivElement>(null);

  // Carregar clientes
  useEffect(() => {
    (async () => {
      const { data: roles } = await supabase.from("user_roles").select("user_id").eq("role", "cliente");
      const ids = (roles ?? []).map((r) => r.user_id);
      if (!ids.length) return;
      const { data: profs } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
      setClients(profs ?? []);
    })();
  }, []);

  // Carregar última mensagem por cliente para preview na sidebar
  useEffect(() => {
    if (!user || !clients.length) return;
    const fetchLast = async () => {
      const map: Record<string, any> = {};
      await Promise.all(clients.map(async (c) => {
        const { data } = await supabase.from("messages").select("*")
          .or(`and(sender_id.eq.${user.id},recipient_id.eq.${c.id}),and(sender_id.eq.${c.id},recipient_id.eq.${user.id})`)
          .order("created_at", { ascending: false }).limit(1);
        if (data?.[0]) map[c.id] = data[0];
      }));
      setLastMsgByClient(map);
    };
    fetchLast();
  }, [clients, user]);

  // Carregar mensagens da conversa selecionada
  useEffect(() => {
    if (!selected || !user) return;
    supabase.from("messages").select("*")
      .or(`and(sender_id.eq.${user.id},recipient_id.eq.${selected.id}),and(sender_id.eq.${selected.id},recipient_id.eq.${user.id})`)
      .order("created_at")
      .then(({ data }) => setMessages(data ?? []));

    const ch = supabase.channel(`msg-${selected.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, (p: any) => {
        const m = p.new;
        if (
          (m.sender_id === user.id && m.recipient_id === selected.id) ||
          (m.sender_id === selected.id && m.recipient_id === user.id)
        ) {
          setMessages((prev) => [...prev, m]);
          setLastMsgByClient((prev) => ({ ...prev, [selected.id]: m }));
        }
      }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [selected, user]);

  // Auto-scroll para o fim
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    if (!body.trim() || !selected || !user) return;
    setSending(true);
    const { error } = await supabase.from("messages").insert({
      sender_id: user.id, recipient_id: selected.id, body: body.trim(),
    });
    setSending(false);
    if (!error) setBody("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  };

  const clientesFiltrados = clients.filter((c) =>
    search === "" ||
    c.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    c.email?.toLowerCase().includes(search.toLowerCase())
  );

  // Ordenar clientes por última mensagem
  const clientesOrdenados = [...clientesFiltrados].sort((a, b) => {
    const ta = lastMsgByClient[a.id]?.created_at ?? "";
    const tb = lastMsgByClient[b.id]?.created_at ?? "";
    return tb.localeCompare(ta);
  });

  return (
    <>
      <PageHeader title="Mensagens" description="Conversas com clientes em tempo real" />

      {/* Container SAP */}
      <div className="bg-muted/60 border border-border rounded-t-lg px-4 py-2 flex items-center gap-2">
        <MessageSquare className="h-4 w-4 text-primary" />
        <span className="font-semibold text-sm">Centro de Mensagens</span>
        <span className="text-xs text-muted-foreground">· {clients.length} clientes</span>
      </div>

      <div className="border border-t-0 border-border rounded-b-lg bg-background overflow-hidden" style={{ minHeight: 560 }}>
        <div className="grid md:grid-cols-[280px_1fr] h-full" style={{ minHeight: 560 }}>

          {/* ── Sidebar clientes ── */}
          <aside className="border-r border-border flex flex-col">
            {/* Pesquisa */}
            <div className="p-3 border-b border-border">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Pesquisar cliente..."
                  className="pl-8 h-8 text-xs"
                />
              </div>
            </div>

            {/* Lista */}
            <div className="flex-1 overflow-y-auto divide-y divide-border/50">
              {clientesOrdenados.map((c) => {
                const last = lastMsgByClient[c.id];
                const isSelected = selected?.id === c.id;
                const initials = (c.full_name || c.email || "?").substring(0, 2).toUpperCase();
                return (
                  <button
                    key={c.id}
                    onClick={() => setSelected(c)}
                    className={`w-full text-left px-3 py-3 hover:bg-muted/50 transition-colors flex items-start gap-3 ${isSelected ? "bg-primary/8 border-l-2 border-primary" : ""}`}
                  >
                    {/* Avatar */}
                    <div className={`h-9 w-9 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${isSelected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className={`text-sm font-medium truncate ${isSelected ? "text-primary" : ""}`}>
                          {c.full_name || c.email}
                        </span>
                        {last && (
                          <span className="text-[10px] text-muted-foreground shrink-0">
                            {formatMsgDate(last.created_at)}
                          </span>
                        )}
                      </div>
                      {last ? (
                        <p className="text-xs text-muted-foreground truncate mt-0.5">
                          {last.sender_id === user?.id ? "Eu: " : ""}{last.body}
                        </p>
                      ) : (
                        <p className="text-xs text-muted-foreground/50 mt-0.5">Sem mensagens</p>
                      )}
                    </div>
                  </button>
                );
              })}
              {clientesOrdenados.length === 0 && (
                <p className="p-6 text-xs text-muted-foreground text-center">Nenhum cliente encontrado.</p>
              )}
            </div>
          </aside>

          {/* ── Área de conversa ── */}
          <section className="flex flex-col">
            {!selected ? (
              <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-3 p-8">
                <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                  <MessageSquare className="h-8 w-8 opacity-30" />
                </div>
                <p className="text-sm">Selecione um cliente para ver a conversa</p>
                <p className="text-xs opacity-60">{clients.length} clientes disponíveis</p>
              </div>
            ) : (
              <>
                {/* Header da conversa */}
                <div className="px-4 py-3 border-b border-border bg-muted/20 flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold shrink-0">
                    {(selected.full_name || selected.email || "?").substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{selected.full_name || selected.email}</p>
                    <p className="text-xs text-muted-foreground">{selected.email}</p>
                  </div>
                  <div className="ml-auto flex items-center gap-1.5 text-xs text-green-600">
                    <Circle className="h-2 w-2 fill-green-500" />
                    online
                  </div>
                </div>

                {/* Mensagens */}
                <div className="flex-1 p-4 space-y-3 overflow-y-auto" style={{ maxHeight: 420 }}>
                  {messages.length === 0 && (
                    <div className="text-center py-12 text-muted-foreground">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-20" />
                      <p className="text-sm">Sem mensagens. Comece a conversa!</p>
                    </div>
                  )}

                  {/* Agrupar mensagens por dia */}
                  {messages.map((m, i) => {
                    const isMe = m.sender_id === user?.id;
                    const prevDate = i > 0 ? new Date(messages[i-1].created_at).toDateString() : null;
                    const currDate = new Date(m.created_at).toDateString();
                    const showDate = prevDate !== currDate;

                    return (
                      <div key={m.id}>
                        {showDate && (
                          <div className="flex items-center gap-2 my-3">
                            <div className="flex-1 h-px bg-border" />
                            <span className="text-xs text-muted-foreground px-2 bg-background">
                              {isToday(new Date(m.created_at)) ? "Hoje" : isYesterday(new Date(m.created_at)) ? "Ontem" : format(new Date(m.created_at), "dd 'de' MMMM", { locale: pt })}
                            </span>
                            <div className="flex-1 h-px bg-border" />
                          </div>
                        )}
                        <div className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                          <div className={`max-w-[72%] ${isMe ? "items-end" : "items-start"} flex flex-col`}>
                            <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                              isMe
                                ? "bg-primary text-primary-foreground rounded-br-sm"
                                : "bg-muted text-foreground rounded-bl-sm"
                            }`}>
                              {m.body}
                            </div>
                            <span className="text-[10px] text-muted-foreground mt-1 px-1" title={formatMsgTime(m.created_at)}>
                              {format(new Date(m.created_at), "HH:mm")}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={bottomRef} />
                </div>

                {/* Input */}
                <div className="p-3 border-t border-border bg-muted/10">
                  <div className="flex gap-2 items-end">
                    <div className="flex-1 relative">
                      <Input
                        value={body}
                        onChange={(e) => setBody(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Escreva uma mensagem… (Enter para enviar)"
                        className="pr-4 text-sm"
                        disabled={sending}
                      />
                    </div>
                    <Button
                      onClick={send}
                      disabled={sending || !body.trim()}
                      className="bg-gradient-gold shadow-gold h-10 w-10 p-0 shrink-0"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1.5 ml-1">
                    Enter para enviar · Shift+Enter para nova linha
                  </p>
                </div>
              </>
            )}
          </section>
        </div>
      </div>
    </>
  );
};
