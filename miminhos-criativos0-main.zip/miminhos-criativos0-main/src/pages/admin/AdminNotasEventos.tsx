import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Calendar, Users, MapPin, Save, StickyNote, MessageSquare, Clock } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";

const statusColor: Record<string, string> = {
  planeamento: "bg-blue-100/80 text-blue-800 border-blue-200",
  confirmado:  "bg-emerald-100/80 text-emerald-800 border-emerald-200",
  em_curso:    "bg-amber-100/80 text-amber-800 border-amber-200",
  concluido:   "bg-slate-100 text-slate-700 border-slate-200",
  cancelado:   "bg-red-100/80 text-red-800 border-red-200",
};

// ─── Detalhe de um evento com notas em tempo real ─────────────────────────────
const EventoNotas = ({ evento, onBack }: { evento: any; onBack: () => void }) => {
  const { user } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const [notas, setNotas] = useState<any[]>([]);
  const [texto, setTexto] = useState("");
  const [saving, setSaving] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadNotas = async () => {
    const { data } = await supabase
      .from("event_notes")
      .select("*, profiles(full_name, email)")
      .eq("event_id", evento.id)
      .order("created_at", { ascending: true });
    setNotas(data ?? []);
    setTimeout(scrollToBottom, 100);
  };

  useEffect(() => {
    loadNotas();

    // Subscrição em tempo real
    const channel = supabase
      .channel(`event_notes_${evento.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "event_notes", filter: `event_id=eq.${evento.id}` },
        () => loadNotas()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [evento.id]);

  const guardar = async () => {
    if (!texto.trim()) return;
    setSaving(true);
    const { error } = await supabase.from("event_notes").insert({
      event_id: evento.id,
      author_id: user?.id,
      content: texto.trim(),
    });
    setSaving(false);
    if (error) { toast.error("Erro ao guardar a nota: " + error.message); return; }
    setTexto("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) guardar();
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] max-h-[900px] animate-in fade-in slide-in-from-bottom-4 duration-300">
      {/* Cabeçalho - Estilo SAP Object Header */}
      <div className="bg-card border border-border/60 rounded-xl p-5 mb-4 shadow-sm">
        <div className="flex items-start gap-4">
          <Button variant="outline" size="icon" onClick={onBack} className="shrink-0 mt-1 hover:bg-muted">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-2 flex-wrap">
              <h2 className="text-2xl font-bold text-foreground truncate">{evento.title}</h2>
              <span className={`px-2.5 py-0.5 rounded-full capitalize text-xs font-semibold border shadow-sm ${statusColor[evento.status] || "bg-muted text-muted-foreground border-border"}`}>
                {evento.status?.replace("_", " ")}
              </span>
            </div>
            
            <div className="flex items-center gap-5 text-sm text-muted-foreground flex-wrap bg-muted/30 p-2.5 rounded-lg border border-border/40 inline-flex">
              {evento.event_date && (
                <span className="flex items-center gap-1.5 font-medium">
                  <Calendar className="h-4 w-4 text-primary" />
                  {format(new Date(evento.event_date), "dd 'de' MMMM, yyyy", { locale: pt })}
                </span>
              )}
              {evento.location && (
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-primary" />
                  {evento.location}
                </span>
              )}
              {evento.guests_count && (
                <span className="flex items-center gap-1.5">
                  <Users className="h-4 w-4 text-primary" />
                  {evento.guests_count} convidados
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Área de Conversação/Notas */}
      <div className="flex-1 bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden flex flex-col mb-4 relative">
        <div className="px-5 py-3 border-b border-border/60 bg-muted/20 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground">Registo de Ocorrências e Notas</span>
          </div>
          <span className="text-xs font-medium bg-background px-2.5 py-1 rounded-full border shadow-sm text-muted-foreground">
            {notas.length} {notas.length === 1 ? "nota registada" : "notas registadas"}
          </span>
        </div>

        <div className="flex-1 p-5 overflow-y-auto space-y-6 bg-gradient-to-b from-background to-muted/10">
          {notas.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground">
              <StickyNote className="h-12 w-12 mb-4 opacity-20" />
              <p className="text-lg font-medium">Sem notas de momento.</p>
              <p className="text-sm mt-1 max-w-sm opacity-80">
                Utilize este espaço para coordenar detalhes, partilhar requisitos de fornecedores ou registar alterações com a equipa.
              </p>
            </div>
          )}

          {notas.map((n) => {
            const isMe = n.author_id === user?.id;
            const autorNome = n.profiles?.full_name || n.profiles?.email || "Colaborador";
            const iniciais = autorNome.split(" ").map((w: string) => w[0]).slice(0, 2).join("").toUpperCase();

            return (
              <div key={n.id} className={`flex gap-3 w-full ${isMe ? "justify-end" : "justify-start"}`}>
                {/* Avatar para outros */}
                {!isMe && (
                  <div className="h-9 w-9 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center shrink-0 border border-primary/20 shadow-sm">
                    <span className="text-xs font-bold text-primary">{iniciais}</span>
                  </div>
                )}

                {/* Balão de Nota */}
                <div className={`max-w-[80%] md:max-w-[65%] flex flex-col gap-1.5 ${isMe ? "items-end" : "items-start"}`}>
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground font-medium px-1">
                    {!isMe && <span className="text-foreground">{autorNome}</span>}
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {n.created_at ? format(new Date(n.created_at), "dd/MM 'às' HH:mm") : ""}
                    </span>
                    {isMe && <span className="text-primary font-bold">Eu</span>}
                  </div>
                  
                  <div className={`px-4 py-3 text-sm whitespace-pre-wrap leading-relaxed shadow-sm ${
                    isMe
                      ? "bg-primary text-primary-foreground rounded-2xl rounded-tr-sm"
                      : "bg-card border border-border/50 text-foreground rounded-2xl rounded-tl-sm"
                  }`}>
                    {n.content}
                  </div>
                </div>

                {/* Avatar para mim */}
                {isMe && (
                  <div className="h-9 w-9 rounded-full bg-gradient-gold flex items-center justify-center shrink-0 shadow-sm">
                    <span className="text-xs font-bold text-primary-foreground">{iniciais}</span>
                  </div>
                )}
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Caixa de Input estilo WP Meta Box */}
      <div className="bg-card border border-border/60 rounded-xl p-4 shadow-sm shrink-0">
        <div className="relative focus-within:ring-1 focus-within:ring-primary rounded-lg transition-all">
          <Textarea
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Adicionar uma nota à equipa... (Ctrl + Enter para guardar)"
            className="resize-none min-h-[80px] border-border/50 bg-background shadow-inner mb-3 text-sm"
          />
        </div>
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5" />
            Visível para toda a equipa do evento.
          </p>
          <Button
            onClick={guardar}
            disabled={saving || !texto.trim()}
            className="bg-gradient-gold shadow-md hover:shadow-lg transition-all px-6"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? "A guardar..." : "Guardar Nota"}
          </Button>
        </div>
      </div>
    </div>
  );
};

// ─── Lista de eventos em cards ────────────────────────────────────────────────
const AdminNotasEventos = () => {
  const [eventos, setEventos] = useState<any[]>([]);
  const [eventoAberto, setEventoAberto] = useState<any>(null);
  const [filter, setFilter] = useState("all");
  const [notaCount, setNotaCount] = useState<Record<string, number>>({});

  const load = async () => {
    const { data } = await supabase
      .from("events")
      .select("*")
      .order("event_date", { ascending: true });
    setEventos(data ?? []);

    // Conta notas por evento
    const { data: counts } = await supabase
      .from("event_notes")
      .select("event_id");
    
    const map: Record<string, number> = {};
    (counts ?? []).forEach((n: any) => {
      map[n.event_id] = (map[n.event_id] || 0) + 1;
    });
    setNotaCount(map);
  };

  useEffect(() => { 
    load(); 
  }, []);

  const STATUS = ["planeamento", "confirmado", "em_curso", "concluido", "cancelado"];
  const filtered = filter === "all" ? eventos : eventos.filter((e) => e.status === filter);

  if (eventoAberto) {
    return <EventoNotas evento={eventoAberto} onBack={() => { setEventoAberto(null); load(); }} />;
  }

  return (
    <div className="space-y-6">
      <PageHeader 
        title="Coordenação & Notas" 
        description="Painel de comunicação interna e registos por evento." 
      />

      {/* Filtros estilo separadores WordPress */}
      <div className="flex gap-2 border-b border-border/50 pb-2 overflow-x-auto">
        <button
          onClick={() => setFilter("all")}
          className={`px-4 py-2 text-sm font-medium rounded-t-md transition-colors whitespace-nowrap ${filter === "all" ? "border-b-2 border-primary text-primary bg-primary/5" : "text-muted-foreground hover:bg-muted/50"}`}
        >
          Todos os Eventos <span className="ml-1 opacity-60 text-xs">({eventos.length})</span>
        </button>
        {STATUS.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-4 py-2 text-sm font-medium rounded-t-md capitalize transition-colors whitespace-nowrap ${filter === s ? "border-b-2 border-primary text-primary bg-primary/5" : "text-muted-foreground hover:bg-muted/50"}`}
          >
            {s.replace("_", " ")} <span className="ml-1 opacity-60 text-xs">({eventos.filter((e) => e.status === s).length})</span>
          </button>
        ))}
      </div>

      {/* Grelha de Cards SAP Fiori Style */}
      {filtered.length === 0 ? (
        <div className="bg-card border border-border/50 rounded-xl flex flex-col items-center justify-center py-20 text-muted-foreground shadow-sm">
          <MessageSquare className="h-12 w-12 mb-4 opacity-20" />
          <p className="text-lg font-medium">Nenhum evento encontrado nesta categoria.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filtered.map((e) => {
            const count = notaCount[e.id] ?? 0;
            const hasNotes = count > 0;

            return (
              <button
                key={e.id}
                onClick={() => setEventoAberto(e)}
                className="bg-card border border-border/60 rounded-xl p-5 text-left hover:border-primary hover:shadow-md transition-all group flex flex-col relative overflow-hidden h-full"
              >
                {/* Linha de cor lateral opcional para destacar status */}
                <div className={`absolute left-0 top-0 bottom-0 w-1 ${
                  e.status === 'confirmado' ? 'bg-emerald-500' : 
                  e.status === 'planeamento' ? 'bg-blue-500' : 
                  e.status === 'cancelado' ? 'bg-red-500' : 'bg-gradient-gold'
                }`}></div>

                {/* Topo do Card */}
                <div className="flex items-start justify-between gap-3 mb-4 pl-2">
                  <h3 className="font-bold text-lg text-foreground leading-tight group-hover:text-primary transition-colors line-clamp-2">
                    {e.title}
                  </h3>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full capitalize font-bold tracking-wider shrink-0 border ${statusColor[e.status] || "bg-muted text-muted-foreground"}`}>
                    {e.status?.replace("_", " ")}
                  </span>
                </div>

                {/* Informação Resumida */}
                <div className="space-y-2.5 text-sm text-muted-foreground mb-6 flex-1 pl-2">
                  {e.event_type && (
                    <span className="inline-block bg-muted text-foreground text-xs font-semibold px-2 py-1 rounded">
                      {e.event_type}
                    </span>
                  )}
                  {e.event_date && (
                    <p className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 shrink-0 text-foreground/50" />
                      {format(new Date(e.event_date), "dd/MM/yyyy")}
                    </p>
                  )}
                  {e.location && (
                    <p className="flex items-center gap-2 line-clamp-1" title={e.location}>
                      <MapPin className="h-4 w-4 shrink-0 text-foreground/50" />
                      {e.location}
                    </p>
                  )}
                </div>

                {/* Rodapé — Indicador de Notas */}
                <div className={`flex items-center gap-2 text-xs border-t border-border/50 pt-3 pl-2 mt-auto transition-colors ${hasNotes ? 'text-primary' : 'text-muted-foreground'}`}>
                  <div className={`p-1.5 rounded-md ${hasNotes ? 'bg-primary/10' : 'bg-muted'}`}>
                    <StickyNote className="h-4 w-4" />
                  </div>
                  <span className="font-medium">
                    {count} {count === 1 ? "nota registada" : "notas registadas"}
                  </span>
                  <span className="ml-auto text-primary font-bold text-[11px] uppercase tracking-wide opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
                    Abrir →
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default AdminNotasEventos;
