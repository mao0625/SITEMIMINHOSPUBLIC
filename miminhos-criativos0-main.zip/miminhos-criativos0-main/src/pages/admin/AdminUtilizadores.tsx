import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, KeyRound, User, ArrowLeft, Search, Pencil, Download, CalendarDays, FileText, Save, X, Users, ShieldCheck, UserCog, ChevronRight, RefreshCw, Lock } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

// ─── Email do super-admin com permissão de reset de admins ────────────────────
const SUPER_ADMIN_EMAIL = "mao0625@outlook.pt";

interface UserProfile {
  id: string;
  email?: string;
  full_name?: string;
  phone?: string;
  nif?: string;
  client_number?: number | string;
  roles: string[];
  must_change_password?: boolean;
}

interface EventData {
  id: string;
  title: string;
  event_type?: string;
  event_date?: string;
  location?: string;
  status: string;
}

interface QuestionnaireData {
  id: string;
  reference_number?: string;
  status: string;
  created_at?: string;
  submitted_at?: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const esc = (s: any): string => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");

const exportPDF = (user: UserProfile, events: EventData[], questionnaires: QuestionnaireData[]) => {
  const win = window.open("", "_blank");
  if (!win) return;
  const html = `<!DOCTYPE html><html lang="pt-PT"><head><meta charset="UTF-8"><title>Ficha de Cliente - ${esc(user.full_name || "Desconhecido")}</title>
  <style>body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;padding:40px;color:#333}h1{font-size:22px;border-bottom:2px solid #d4af37;padding-bottom:10px;color:#000}h2{font-size:16px;margin-top:30px;color:#444}p{font-size:14px;color:#555}table{width:100%;border-collapse:collapse;font-size:13px;margin-top:15px}th{background:#fdfbf7;padding:10px;text-align:left;border-bottom:2px solid #e5e7eb;color:#333}td{padding:10px;border-bottom:1px solid #f3f4f6}</style>
  </head><body>
  <h1>Ficha de Cliente — ${esc(user.full_name || "N/A")} (Nº ${esc(user.client_number ?? "—")})</h1>
  <p><strong>NIF:</strong> ${esc(user.nif || "—")} &nbsp;|&nbsp; <strong>Tel:</strong> ${esc(user.phone || "—")} &nbsp;|&nbsp; <strong>Email:</strong> ${esc(user.email || "—")}</p>
  <h2>Eventos</h2><table><tr><th>Título</th><th>Tipo</th><th>Data</th><th>Estado</th></tr>
  ${events.length ? events.map(e => `<tr><td>${esc(e.title)}</td><td>${esc(e.event_type || "—")}</td><td>${esc(e.event_date ? format(new Date(e.event_date), "dd/MM/yyyy") : "—")}</td><td>${esc(e.status)}</td></tr>`).join("") : "<tr><td colspan='4'>Sem eventos.</td></tr>"}
  </table><h2>Orçamentos</h2><table><tr><th>Referência</th><th>Estado</th><th>Data</th></tr>
  ${questionnaires.length ? questionnaires.map(q => `<tr><td>${esc(q.reference_number || "—")}</td><td>${esc(q.status)}</td><td>${esc(q.created_at ? format(new Date(q.created_at), "dd/MM/yyyy") : "—")}</td></tr>`).join("") : "<tr><td colspan='3'>Sem orçamentos.</td></tr>"}
  </table><script>window.onload=()=>{window.print()}window.onafterprint=()=>{window.close()}</script></body></html>`;
  win.document.write(html);
  win.document.close();
};

const statusColor: Record<string, string> = {
  pendente: "bg-amber-100 text-amber-700 border-amber-200",
  rascunho: "bg-blue-100 text-blue-700 border-blue-200",
  submetido: "bg-green-100 text-green-700 border-green-200",
  aprovado: "bg-emerald-100 text-emerald-700 border-emerald-200",
  rejeitado: "bg-red-100 text-red-700 border-red-200",
  planeamento: "bg-purple-100 text-purple-700 border-purple-200",
  confirmado: "bg-green-100 text-green-700 border-green-200",
  concluido: "bg-blue-100 text-blue-700 border-blue-200",
  cancelado: "bg-red-100 text-red-700 border-red-200",
};

const Breadcrumb = ({ items }: { items: { label: string; onClick?: () => void }[] }) => (
  <nav className="flex items-center gap-1 text-xs text-muted-foreground mb-4 bg-muted/30 border border-border/50 rounded-md px-3 py-2">
    {items.map((item, i) => (
      <span key={i} className="flex items-center gap-1">
        {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground/50" />}
        {item.onClick
          ? <button onClick={item.onClick} className="hover:text-primary transition-colors font-medium">{item.label}</button>
          : <span className="text-foreground font-semibold">{item.label}</span>}
      </span>
    ))}
  </nav>
);

const ActionBar = ({ onBack, backLabel = "Voltar", title, subtitle, actions }: {
  onBack: () => void; backLabel?: string; title: string; subtitle?: string; actions?: React.ReactNode;
}) => (
  <div className="flex items-center gap-3 bg-card border border-border shadow-sm rounded-lg px-4 py-2.5 mb-4 border-t-[3px] border-t-primary flex-wrap">
    <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors group font-medium">
      <ArrowLeft className="h-3.5 w-3.5 transition-transform group-hover:-translate-x-0.5" />
      {backLabel}
    </button>
    <div className="h-4 w-px bg-border/70" />
    <div className="flex items-center gap-2 flex-1 min-w-0">
      <span className="text-sm font-semibold truncate">{title}</span>
      {subtitle && <span className="text-xs text-muted-foreground hidden sm:block">{subtitle}</span>}
    </div>
    {actions && <div className="flex items-center gap-2 ml-auto">{actions}</div>}
  </div>
);

// ─── Nova Conta ───────────────────────────────────────────────────────────────
const NovaConta = ({ onBack, onCreated, currentRole }: {
  onBack: () => void; onCreated: () => void; currentRole: string;
}) => {
  const [form, setForm] = useState({ email: "", full_name: "", phone: "", role: "cliente", password: "" });
  const [creating, setCreating] = useState(false);

  const generatePwd = () => {
    const buf = new Uint8Array(12);
    window.crypto.getRandomValues(buf);
    return Array.from(buf, b => "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"[b % 56]).join("") + "!A1";
  };

  const create = async () => {
    if (!form.email.trim()) return toast.error("Email é obrigatório");
    if (!form.full_name.trim()) return toast.error("Nome é obrigatório");
    setCreating(true);
    const password = form.password || generatePwd();
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-create-user`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}`, apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY },
        body: JSON.stringify({ ...form, password }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Erro ao criar utilizador");
      toast.success(`Conta criada! Palavra-passe: ${password}`, { duration: 15000 });
      navigator.clipboard?.writeText(password);
      onCreated();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setCreating(false);
    }
  };

  const roleOptions = [
    { value: "cliente", label: "Cliente", desc: "Acesso ao Portal do Cliente", icon: User, color: "text-green-600 bg-green-50 border-green-200" },
    { value: "colaborador", label: "Colaborador", desc: "Acesso ao Portal da Equipa", icon: UserCog, color: "text-blue-600 bg-blue-50 border-blue-200", adminOnly: true },
    { value: "admin", label: "Administrador", desc: "Acesso Total ao Sistema", icon: ShieldCheck, color: "text-purple-600 bg-purple-50 border-purple-200", adminOnly: true },
  ].filter(r => !r.adminOnly || currentRole === "admin");

  return (
    <div className="animate-in fade-in duration-300">
      <Breadcrumb items={[{ label: "Utilizadores", onClick: onBack }, { label: "Nova Conta" }]} />
      <ActionBar onBack={onBack} backLabel="Utilizadores" title="Criar Nova Conta de Utilizador"
        actions={
          <>
            <Button variant="outline" size="sm" onClick={onBack} className="h-8 text-xs"><X className="h-3.5 w-3.5 mr-1.5" /> Cancelar</Button>
            <Button size="sm" className="h-8 text-xs bg-gradient-gold" onClick={create} disabled={creating}>
              <Save className="h-3.5 w-3.5 mr-1.5" />{creating ? "A criar conta…" : "Criar Conta"}
            </Button>
          </>
        }
      />
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-5">
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border flex items-center gap-2">
              <User className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Dados Pessoais</span>
            </div>
            <div className="p-5 space-y-0">
              {[
                { key: "full_name", label: "Nome Completo", placeholder: "Nome e apelido do utilizador", type: "text", required: true },
                { key: "email", label: "Endereço de Email", placeholder: "utilizador@exemplo.com", type: "email", required: true },
                { key: "phone", label: "Número de Telefone", placeholder: "9XX XXX XXX", type: "tel", required: false },
              ].map((field, i) => (
                <div key={field.key} className={`flex items-start gap-4 py-3.5 ${i < 2 ? "border-b border-border/50" : ""}`}>
                  <label className="text-sm text-muted-foreground w-44 shrink-0 pt-2">
                    {field.label}{field.required && <span className="text-destructive ml-0.5">*</span>}
                  </label>
                  <Input type={field.type} value={(form as any)[field.key]} onChange={(e) => setForm({ ...form, [field.key]: e.target.value })}
                    placeholder={field.placeholder} className="h-9 text-sm border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30" />
                </div>
              ))}
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border flex items-center gap-2">
              <KeyRound className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Autenticação</span>
            </div>
            <div className="p-5">
              <div className="flex items-start gap-4">
                <label className="text-sm text-muted-foreground w-44 shrink-0 pt-2">Palavra-passe<span className="block text-xs text-muted-foreground/60 font-normal mt-0.5">Opcional</span></label>
                <div className="flex-1 space-y-2">
                  <Input type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="Deixar em branco para gerar automaticamente"
                    className="h-9 text-sm font-mono border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30" />
                  <p className="text-xs text-muted-foreground bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
                    Se deixar em branco, será gerada uma palavra-passe temporária. O utilizador será obrigado a alterá-la no primeiro acesso.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border flex items-center gap-2">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Tipo de Conta</span>
            </div>
            <div className="p-4 space-y-2">
              {roleOptions.map((opt) => (
                <button key={opt.value} onClick={() => setForm({ ...form, role: opt.value })}
                  className={`w-full flex items-center gap-3 p-3.5 rounded-lg border-2 transition-all text-left ${form.role === opt.value ? "border-primary bg-primary/5" : "border-border/50 hover:border-border hover:bg-muted/30"}`}>
                  <div className={`p-2 rounded-md border ${opt.color} shrink-0`}><opt.icon className="h-4 w-4" /></div>
                  <div className="flex-1 min-w-0"><div className="text-sm font-semibold">{opt.label}</div><div className="text-xs text-muted-foreground">{opt.desc}</div></div>
                  <div className={`w-4 h-4 rounded-full border-2 shrink-0 ${form.role === opt.value ? "border-primary bg-primary" : "border-border/60"}`}>
                    {form.role === opt.value && <div className="w-full h-full flex items-center justify-center"><div className="w-1.5 h-1.5 rounded-full bg-white" /></div>}
                  </div>
                </button>
              ))}
            </div>
          </div>
          <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
            <div className="px-5 py-3 bg-muted/40 border-b border-border">
              <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Resumo</span>
            </div>
            <div className="p-4 space-y-2.5">
              {[
                { label: "Nome", value: form.full_name || "—" },
                { label: "Email", value: form.email || "—" },
                { label: "Telefone", value: form.phone || "—" },
                { label: "Tipo", value: roleOptions.find(r => r.value === form.role)?.label || "—" },
                { label: "Palavra-passe", value: form.password ? "Definida manualmente" : "Gerada automaticamente" },
              ].map((f) => (
                <div key={f.label} className="flex items-start justify-between gap-3 text-xs py-1.5 border-b border-border/30 last:border-0">
                  <span className="text-muted-foreground shrink-0">{f.label}</span>
                  <span className="font-medium text-right truncate max-w-[160px]">{f.value}</span>
                </div>
              ))}
            </div>
            <div className="px-4 pb-4">
              <Button onClick={create} disabled={creating} className="w-full bg-gradient-gold h-9 text-sm">
                <Save className="h-4 w-4 mr-2" />{creating ? "A criar conta…" : "Criar Conta de Utilizador"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Alterar Dados ────────────────────────────────────────────────────────────
const AlterarDadosCliente = ({ user, onBack, onSaved }: {
  user: UserProfile; onBack: () => void; onSaved: (u: UserProfile) => void;
}) => {
  const [form, setForm] = useState({ full_name: user.full_name || "", phone: user.phone || "", nif: user.nif || "" });
  const [saving, setSaving] = useState(false);

  const guardar = async () => {
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ full_name: form.full_name, phone: form.phone, nif: form.nif }).eq("id", user.id);
    if (error) { setSaving(false); toast.error("Erro ao guardar: " + error.message); return; }

    // Sincroniza mapeamento de telefone para login
    if (form.phone && user.email) {
      const phoneDigits = form.phone.replace(/\D/g, "").replace(/^351/, "");
      if (/^\d{9,}$/.test(phoneDigits)) {
        const { error: mapErr } = await supabase
          .from("user_phone_mappings")
          .upsert({ user_id: user.id, phone: phoneDigits, email: user.email }, { onConflict: "phone" });
        if (mapErr) console.error("Erro a sincronizar telefone:", mapErr);
      }
    }

    setSaving(false);
    toast.success("Dados atualizados com sucesso!");
    onSaved({ ...user, ...form });
  };

  return (
    <div className="animate-in fade-in duration-300">
      <Breadcrumb items={[{ label: "Utilizadores", onClick: () => onBack() }, { label: user.full_name || user.email || "Cliente", onClick: onBack }, { label: "Alterar Dados" }]} />
      <ActionBar onBack={onBack} backLabel="Ficha do Cliente" title={`Alterar Dados — ${user.full_name || user.email}`} subtitle={`Nº ${user.client_number ?? "—"}`}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={onBack} className="h-8 text-xs" disabled={saving}><X className="h-3.5 w-3.5 mr-1.5" /> Cancelar</Button>
            <Button size="sm" className="h-8 text-xs bg-gradient-gold" onClick={guardar} disabled={saving}>
              <Save className="h-3.5 w-3.5 mr-1.5" />{saving ? "A guardar…" : "Guardar Alterações"}
            </Button>
          </>
        }
      />
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-5">
        <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
          <div className="px-5 py-3 bg-muted/40 border-b border-border flex items-center gap-2">
            <User className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Dados Editáveis</span>
          </div>
          <div className="divide-y divide-border/50">
            {[
              { key: "full_name", label: "Nome Completo", placeholder: "Nome completo do cliente" },
              { key: "nif", label: "NIF", placeholder: "123456789" },
              { key: "phone", label: "Telefone", placeholder: "9XX XXX XXX" },
            ].map((f) => (
              <div key={f.key} className="flex items-center gap-4 px-5 py-3.5 hover:bg-muted/20 transition-colors">
                <label className="text-sm text-muted-foreground w-40 shrink-0">{f.label}</label>
                <Input value={(form as any)[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} placeholder={f.placeholder}
                  className="h-8 text-sm flex-1 border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30" />
              </div>
            ))}
            <div className="flex items-start gap-4 px-5 py-3.5 bg-muted/10">
              <label className="text-sm text-muted-foreground w-40 shrink-0 pt-1.5">Email</label>
              <div className="flex-1">
                <Input value={user.email} disabled className="h-8 text-sm opacity-50 cursor-not-allowed border-border/40" />
                <p className="text-xs text-muted-foreground/70 mt-1.5">O email é identificador único e não pode ser alterado.</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden h-fit">
          <div className="px-5 py-3 bg-muted/40 border-b border-border">
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Informação do Sistema</span>
          </div>
          <div className="divide-y divide-border/40">
            {[
              { label: "Nº de Cliente", value: String(user.client_number ?? "—") },
              { label: "Função", value: user.roles?.join(", ") || "—" },
              { label: "ID Interno", value: (user.id?.substring(0, 14) + "…") || "—" },
              { label: "Estado", value: user.must_change_password ? "Palavra-passe provisória" : "Ativo" },
            ].map((f) => (
              <div key={f.label} className="flex flex-col px-5 py-3">
                <span className="text-xs text-muted-foreground">{f.label}</span>
                <span className="text-sm font-medium mt-0.5">{f.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Ficha do Cliente ─────────────────────────────────────────────────────────
const FichaCliente = ({ user, onBack, currentRole }: {
  user: UserProfile; onBack: () => void; currentRole: string;
}) => {
  const [tab, setTab] = useState<"dados" | "eventos" | "orcamentos">("dados");
  const [events, setEvents] = useState<EventData[]>([]);
  const [questionnaires, setQuestionnaires] = useState<QuestionnaireData[]>([]);
  const [localUser, setLocalUser] = useState<UserProfile>({ ...user });
  const [showEdit, setShowEdit] = useState(false);
  const [loading, setLoading] = useState(false);

  const loadData = async () => {
    const [{ data: q }, { data: e }] = await Promise.all([
      supabase.from("questionnaires").select("*").eq("client_id", user.id).order("created_at", { ascending: false }),
      supabase.from("events").select("*").eq("client_id", user.id).order("event_date", { ascending: false }),
    ]);
    setQuestionnaires(q ?? []);
    setEvents(e ?? []);
  };

  useEffect(() => { loadData(); }, [user.id]);

  const abrirNovoOrcamento = async () => {
    setLoading(true);
    const { error } = await supabase.from("questionnaires").insert({ client_id: user.id, status: "pendente", answers: {} });
    setLoading(false);
    if (error) { toast.error("Erro: " + error.message); return; }
    toast.success("Novo orçamento aberto!");
    loadData();
    setTab("orcamentos");
  };

  if (showEdit) {
    return <AlterarDadosCliente user={localUser} onBack={() => setShowEdit(false)} onSaved={(u) => { setLocalUser(u); setShowEdit(false); }} />;
  }

  const tabs = [
    { key: "dados", label: "Dados Pessoais", icon: User },
    { key: "eventos", label: `Eventos (${events.length})`, icon: CalendarDays },
    { key: "orcamentos", label: `Orçamentos (${questionnaires.length})`, icon: FileText },
  ] as const;

  return (
    <div className="animate-in fade-in duration-300 space-y-0">
      <Breadcrumb items={[{ label: "Utilizadores", onClick: onBack }, { label: localUser.full_name || localUser.email || "Cliente" }]} />
      <ActionBar onBack={onBack} backLabel="Utilizadores" title={localUser.full_name || "—"} subtitle={`Nº ${localUser.client_number ?? "—"} · ${localUser.email || ""}`}
        actions={
          <>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setShowEdit(true)}>
              <Pencil className="h-3.5 w-3.5 mr-1.5" /> Alterar Dados
            </Button>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => exportPDF(localUser, events, questionnaires)}>
              <Download className="h-3.5 w-3.5 mr-1.5" /> PDF
            </Button>
            <Button size="sm" className="h-8 text-xs bg-gradient-gold" disabled={loading} onClick={abrirNovoOrcamento}>
              <Plus className="h-3.5 w-3.5 mr-1.5" /> Novo Orçamento
            </Button>
          </>
        }
      />

      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full border ${localUser.must_change_password ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-emerald-50 text-emerald-700 border-emerald-200"}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${localUser.must_change_password ? "bg-amber-500 animate-pulse" : "bg-emerald-500"}`} />
          {localUser.must_change_password ? "Palavra-passe provisória" : "Conta ativa"}
        </span>
        {localUser.roles.map(r => (
          <span key={r} className={`text-xs px-2 py-0.5 rounded-md font-medium border capitalize ${r === "admin" ? "bg-purple-50 text-purple-700 border-purple-200" : r === "colaborador" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-green-50 text-green-700 border-green-200"}`}>{r}</span>
        ))}
      </div>

      <div className="flex border-b border-border bg-card rounded-t-lg overflow-hidden">
        {tabs.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-5 py-3 text-sm border-r border-border/50 last:border-0 transition-all whitespace-nowrap ${tab === t.key ? "border-b-2 border-b-primary bg-background font-semibold text-primary -mb-px" : "text-muted-foreground hover:bg-muted/30 hover:text-foreground"}`}>
            <t.icon className="h-3.5 w-3.5" />{t.label}
          </button>
        ))}
      </div>

      <div className="border border-t-0 border-border rounded-b-lg bg-background p-6 shadow-sm min-h-[380px]">
        {tab === "dados" && (
          <div className="max-w-lg animate-in slide-in-from-left-2 duration-200">
            <div className="text-xs font-semibold text-primary uppercase tracking-widest mb-4 pb-2 border-b border-border">Informação do Cliente</div>
            {[
              { label: "Nº Cliente", value: String(localUser.client_number ?? "—") },
              { label: "Nome Completo", value: localUser.full_name || "—" },
              { label: "Email", value: localUser.email || "—" },
              { label: "Telefone", value: localUser.phone || "—" },
              { label: "NIF", value: localUser.nif || "—" },
            ].map((f) => (
              <div key={f.label} className="flex items-center border-b border-border/40 py-3 gap-4 hover:bg-primary/5 px-2 -mx-2 rounded-sm transition-colors">
                <span className="text-sm text-muted-foreground w-36 shrink-0">{f.label}</span>
                <span className="text-sm font-medium">{f.value}</span>
              </div>
            ))}
          </div>
        )}

        {tab === "eventos" && (
          <div className="animate-in slide-in-from-left-2 duration-200">
            <div className="text-xs font-semibold text-primary uppercase tracking-widest mb-4 pb-2 border-b border-border">Histórico de Eventos</div>
            <div className="border border-border/60 rounded-lg overflow-hidden shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="text-xs">Título</TableHead><TableHead className="text-xs">Tipo</TableHead>
                    <TableHead className="text-xs">Data</TableHead><TableHead className="text-xs">Local</TableHead><TableHead className="text-xs">Estado</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {events.map((ev) => (
                    <TableRow key={ev.id} className="hover:bg-muted/20">
                      <TableCell className="font-medium text-sm">{ev.title}</TableCell>
                      <TableCell className="capitalize text-sm text-muted-foreground">{ev.event_type || "—"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{ev.event_date ? format(new Date(ev.event_date), "dd/MM/yyyy", { locale: pt }) : "—"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{ev.location || "—"}</TableCell>
                      <TableCell><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize border ${statusColor[ev.status] ?? "bg-muted text-muted-foreground border-border"}`}>{ev.status}</span></TableCell>
                    </TableRow>
                  ))}
                  {events.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-12 text-muted-foreground text-sm">Sem eventos associados.</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </div>
        )}

        {tab === "orcamentos" && (
          <div className="animate-in slide-in-from-left-2 duration-200">
            <div className="text-xs font-semibold text-primary uppercase tracking-widest mb-4 pb-2 border-b border-border">Gestão de Orçamentos</div>
            <div className="border border-border/60 rounded-lg overflow-hidden shadow-sm">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/40 hover:bg-muted/40">
                    <TableHead className="text-xs">Referência</TableHead><TableHead className="text-xs">Criado em</TableHead>
                    <TableHead className="text-xs">Estado</TableHead><TableHead className="text-xs">Submetido em</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {questionnaires.map((q) => (
                    <TableRow key={q.id} className="hover:bg-muted/20">
                      <TableCell className="font-mono font-semibold text-sm text-primary">{q.reference_number || "—"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{q.created_at ? format(new Date(q.created_at), "dd/MM/yyyy HH:mm") : "—"}</TableCell>
                      <TableCell><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize border ${statusColor[q.status] ?? "bg-muted text-muted-foreground border-border"}`}>{q.status}</span></TableCell>
                      <TableCell className="text-sm text-muted-foreground">{q.submitted_at ? format(new Date(q.submitted_at), "dd/MM/yyyy HH:mm") : "—"}</TableCell>
                    </TableRow>
                  ))}
                  {questionnaires.length === 0 && <TableRow><TableCell colSpan={4} className="text-center py-12 text-muted-foreground text-sm">Sem orçamentos registados.</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Lista Principal ──────────────────────────────────────────────────────────
const AdminUtilizadores = () => {
  const { role, user: currentUser } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [view, setView] = useState<"list" | "nova-conta" | "ficha">("list");
  const [fichaUser, setFichaUser] = useState<UserProfile | null>(null);
  const [search, setSearch] = useState("");
  const [loadingReset, setLoadingReset] = useState<string | null>(null);

  const isSuperAdmin = currentUser?.email === SUPER_ADMIN_EMAIL;

  const load = async () => {
    try {
      const { data: roles } = await supabase.from("user_roles").select("user_id, role");
      const ids = Array.from(new Set((roles ?? []).map((r) => r.user_id)));
      if (!ids.length) return setUsers([]);
      const { data: profs } = await supabase.from("profiles").select("*").in("id", ids);
      const roleMap: Record<string, string[]> = {};
      (roles ?? []).forEach((r) => { if (!roleMap[r.user_id]) roleMap[r.user_id] = []; roleMap[r.user_id].push(r.role); });
      setUsers((profs ?? []).map((p) => ({ ...p, roles: roleMap[p.id] || [] })));
    } catch { toast.error("Erro ao carregar utilizadores."); }
  };

  useEffect(() => { load(); }, []);

  // ─── Regra de reset ───────────────────────────────────────────────────────
  // - Clientes: qualquer admin/colaborador pode fazer reset
  // - Admins/colaboradores: só o super-admin (mao0625@outlook.pt) pode fazer reset
  const podeResetear = (targetUser: UserProfile): boolean => {
    const isAdminOrColab = targetUser.roles.some(r => r === "admin" || r === "colaborador");
    if (isAdminOrColab) return isSuperAdmin;
    return true; // clientes: qualquer um pode
  };

  const resetPwd = async (targetUser: UserProfile, e: React.MouseEvent) => {
    e.stopPropagation();

    if (!podeResetear(targetUser)) {
      toast.error("Não tem permissão para fazer reset da palavra-passe deste utilizador.");
      return;
    }

    if (!confirm(`Definir nova palavra-passe temporária para ${targetUser.email}?`)) return;
    setLoadingReset(targetUser.id);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}`, apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY },
        body: JSON.stringify({ user_id: targetUser.id }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Erro");
      navigator.clipboard?.writeText(json.password);
      toast.success(`Nova palavra-passe copiada: ${json.password}`, { duration: 20000 });
      load();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoadingReset(null);
    }
  };

  if (view === "nova-conta") {
    return <NovaConta currentRole={role ?? ""} onBack={() => setView("list")} onCreated={() => { setView("list"); load(); }} />;
  }

  if (view === "ficha" && fichaUser) {
    return <FichaCliente user={fichaUser} currentRole={role ?? ""} onBack={() => { setView("list"); setFichaUser(null); load(); }} />;
  }

  const totalClients = users.filter(u => u.roles.includes("cliente")).length;
  const totalColabs = users.filter(u => u.roles.includes("colaborador") || u.roles.includes("admin")).length;
  const pendingPwd = users.filter(u => u.must_change_password).length;

  const filtered = users.filter(u =>
    search === "" ||
    u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    String(u.client_number ?? "").includes(search)
  );

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      <PageHeader
        title="Gestão de Utilizadores"
        description="Consulte e gira clientes, colaboradores e administradores do sistema."
        action={
          <Button onClick={() => setView("nova-conta")} className="bg-gradient-gold shadow-sm hover:shadow-md transition-all">
            <Plus className="h-4 w-4 mr-2" /> Nova Conta
          </Button>
        }
      />

      {users.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Total", value: users.length, icon: Users, color: "text-foreground" },
            { label: "Clientes", value: totalClients, icon: User, color: "text-green-600" },
            { label: "Equipa", value: totalColabs, icon: UserCog, color: "text-blue-600" },
            { label: "Pwd. Provisória", value: pendingPwd, icon: KeyRound, color: "text-amber-600" },
          ].map((s) => (
            <div key={s.label} className="bg-card border border-border/60 rounded-lg px-4 py-3 shadow-sm flex items-center gap-3">
              <div className="bg-muted/50 rounded-md p-2"><s.icon className={`h-4 w-4 ${s.color}`} /></div>
              <div><p className="text-xs text-muted-foreground">{s.label}</p><p className={`text-xl font-bold ${s.color}`}>{s.value}</p></div>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center gap-3 bg-card border border-border/60 shadow-sm rounded-lg px-3 py-2 border-t-[2px] border-t-primary">
        <Search className="h-4 w-4 text-primary shrink-0" />
        <Input placeholder="Pesquisar por nome, email ou n.º de cliente…" value={search} onChange={(e) => setSearch(e.target.value)}
          className="border-none bg-transparent shadow-none focus-visible:ring-0 flex-1" />
        {search && <button onClick={() => setSearch("")} className="text-xs text-muted-foreground hover:text-foreground">Limpar</button>}
        <div className="h-5 w-px bg-border hidden sm:block" />
        <span className="text-xs font-medium text-primary hidden sm:block whitespace-nowrap">{filtered.length} {filtered.length === 1 ? "resultado" : "resultados"}</span>
      </div>

      <div className="bg-card border border-border/60 rounded-lg shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/40 hover:bg-muted/40 border-b border-border/60">
              {["N.º", "Utilizador", "Perfil", "Estado", ""].map((h) => (
                <TableHead key={h} className={`text-xs font-semibold uppercase tracking-widest text-muted-foreground py-3 ${h === "" ? "text-right" : ""}`}>{h}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((u) => {
              const isAdminOrColab = u.roles.some(r => r === "admin" || r === "colaborador");
              const resetBloqueado = isAdminOrColab && !isSuperAdmin;
              return (
                <TableRow key={u.id} className="cursor-pointer hover:bg-primary/5 transition-colors group border-b border-border/40 last:border-0"
                  onClick={() => { setFichaUser(u); setView("ficha"); }}>
                  <TableCell className="font-mono text-xs text-primary font-semibold w-20">{u.client_number ?? "—"}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                        <User className="h-3.5 w-3.5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-sm group-hover:text-primary transition-colors">{u.full_name || <span className="text-muted-foreground italic">Sem nome</span>}</p>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1.5 flex-wrap">
                      {u.roles.map((r) => (
                        <span key={r} className={`text-xs px-2 py-0.5 rounded-md font-medium capitalize border ${r === "admin" ? "bg-purple-50 text-purple-700 border-purple-200" : r === "colaborador" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-green-50 text-green-700 border-green-200"}`}>{r}</span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    {u.must_change_password
                      ? <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 bg-amber-50 px-2 py-1 rounded-md border border-amber-200"><span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />Pwd. Provisória</span>
                      : <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />Ativo</span>}
                  </TableCell>
                  <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                    {resetBloqueado ? (
                      <span title="Apenas o super-administrador pode fazer reset desta conta"
                        className="inline-flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2.5 py-1.5 rounded-md border border-border/60 cursor-not-allowed">
                        <Lock className="h-3 w-3" /> Bloqueado
                      </span>
                    ) : (
                      <Button size="sm" variant="outline" className="h-7 text-xs border-border/60 hover:border-primary/40 hover:text-primary hover:bg-primary/5"
                        onClick={(e) => resetPwd(u, e)} disabled={loadingReset === u.id}>
                        {loadingReset === u.id ? <RefreshCw className="h-3 w-3 mr-1 animate-spin" /> : <KeyRound className="h-3 w-3 mr-1" />}
                        Reset
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-16 text-muted-foreground">
                  <div className="flex flex-col items-center gap-2">
                    <Search className="h-8 w-8 text-muted-foreground/20" />
                    <p className="text-sm">{search ? "Nenhum utilizador corresponde à pesquisa." : "Nenhum utilizador no sistema."}</p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default AdminUtilizadores;
