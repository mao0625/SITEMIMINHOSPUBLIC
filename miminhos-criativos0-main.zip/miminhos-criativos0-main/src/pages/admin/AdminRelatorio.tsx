import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, FileBarChart, Calendar, Users, DollarSign, TrendingUp, TrendingDown, ArrowUpRight, Loader2 } from "lucide-react";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { pt } from "date-fns/locale";
import jsPDF from "jspdf";
import logo from "@/assets/logo.png";

const AdminRelatorio = () => {
  const [month, setMonth] = useState(format(new Date(), "yyyy-MM"));
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    const start = startOfMonth(new Date(month + "-01"));
    const end = endOfMonth(start);
    const sIso = format(start, "yyyy-MM-dd");
    const eIso = format(end, "yyyy-MM-dd");

    const [{ data: events }, { data: expenses }, { data: clients }] = await Promise.all([
      supabase.from("events").select("id,title,event_date,budget,event_type").gte("event_date", sIso).lte("event_date", eIso),
      supabase.from("event_expenses").select("amount, expense_date, event_id").gte("expense_date", sIso).lte("expense_date", eIso),
      supabase.from("profiles").select("id,full_name,email,created_at").gte("created_at", start.toISOString()).lte("created_at", end.toISOString()),
    ]);

    const receita = (events ?? []).reduce((s, e) => s + Number(e.budget || 0), 0);
    const despesas = (expenses ?? []).reduce((s, e) => s + Number(e.amount || 0), 0);
    
    setStats({ 
      events: events ?? [], 
      expenses: expenses ?? [], 
      clients: clients ?? [], 
      receita, 
      despesas, 
      lucro: receita - despesas, 
      start, 
      end 
    });
    setLoading(false);
  };

  useEffect(() => { 
    load(); 
  }, [month]);

  const downloadPdf = async () => {
    if (!stats) return;
    const doc = new jsPDF();
    const img = new Image();
    img.src = logo;
    await new Promise((r) => { img.onload = r; img.onerror = r; });
    try { doc.addImage(img, "PNG", 14, 10, 30, 30); } catch (_) {}

    doc.setFontSize(18); doc.setTextColor(184, 134, 44);
    doc.text("Miminhos Criativos", 50, 20);
    doc.setFontSize(11); doc.setTextColor(80);
    doc.text("Relatório Mensal de Atividade", 50, 28);
    doc.text(format(stats.start, "MMMM 'de' yyyy", { locale: pt }), 50, 35);

    doc.setDrawColor(184, 134, 44); doc.line(14, 45, 196, 45);

    let y = 55;
    doc.setFontSize(13); doc.setTextColor(40);
    doc.text("Resumo Financeiro", 14, y); y += 8;
    doc.setFontSize(11);
    doc.text(`Receita total:  ${stats.receita.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}`, 14, y); y += 6;
    doc.text(`Despesas totais:  ${stats.despesas.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}`, 14, y); y += 6;
    doc.setTextColor(stats.lucro >= 0 ? 30 : 200, stats.lucro >= 0 ? 130 : 30, 30);
    doc.text(`Lucro Líquido:  ${stats.lucro.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}`, 14, y); y += 12;

    doc.setTextColor(40); doc.setFontSize(13);
    doc.text(`Eventos Realizados (${stats.events.length})`, 14, y); y += 7;
    doc.setFontSize(10);
    stats.events.forEach((e: any) => {
      if (y > 270) { doc.addPage(); y = 20; }
      doc.text(`• ${e.event_date ? format(new Date(e.event_date), "dd/MM") : "—"}   ${e.title}   (${e.event_type || "Geral"})   ${Number(e.budget||0).toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}`, 14, y);
      y += 5;
    });
    y += 6;

    if (y > 250) { doc.addPage(); y = 20; }
    doc.setFontSize(13); doc.setTextColor(40);
    doc.text(`Novos Clientes Registados (${stats.clients.length})`, 14, y); y += 7;
    doc.setFontSize(10);
    stats.clients.forEach((c: any) => {
      if (y > 280) { doc.addPage(); y = 20; }
      doc.text(`• ${c.full_name || c.email}`, 14, y);
      y += 5;
    });

    doc.setFontSize(8); doc.setTextColor(120);
    doc.text("A festa é sua! O prazer em criar é nosso! — Miminhos Criativos", 14, 290);

    doc.save(`relatorio-${month}.pdf`);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <PageHeader 
        title="Relatórios Mensais" 
        description="Análise consolidada de faturação, despesas operacionais e crescimento de carteira."
        action={
          <Button 
            onClick={downloadPdf} 
            disabled={!stats || loading} 
            className="bg-gradient-gold shadow-md hover:shadow-lg transition-all"
          >
            <Download className="h-4 w-4 mr-2" />
            Descarregar PDF
          </Button>
        }
      />

      {/* Filtro de Período Cronológico */}
      <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm max-w-xs">
        <div className="space-y-2">
          <Label className="text-sm font-semibold flex items-center gap-1.5 text-foreground">
            <Calendar className="h-4 w-4 text-primary" /> Competência Mensal
          </Label>
          <Input 
            type="month" 
            value={month} 
            onChange={(e) => setMonth(e.target.value)}
            className="bg-background border-border/60 shadow-inner"
          />
        </div>
      </div>

      {loading ? (
        <div className="bg-card border border-border/50 rounded-xl py-24 flex flex-col items-center justify-center text-muted-foreground shadow-sm">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
          <p className="text-sm font-medium">A compilar dados do servidor Supabase...</p>
        </div>
      ) : stats && (
        <>
          {/* Painel Analítico de KPIs - Estilo SAP Fiori Architecture */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Card Eventos */}
            <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm relative overflow-hidden group">
              <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
                <Calendar className="h-14 w-14 text-foreground" />
              </div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Volume de Eventos</p>
              <p className="text-3xl font-black text-foreground mt-2">{stats.events.length}</p>
              <div className="text-[11px] text-muted-foreground mt-2">Agendados ou executados no mês</div>
            </div>

            {/* Card Receitas */}
            <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm relative overflow-hidden group">
              <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
                <DollarSign className="h-14 w-14 text-primary" />
              </div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Faturação Ilíquida</p>
              <p className="text-3xl font-black text-foreground mt-2">
                {stats.receita.toLocaleString("pt-PT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 })}
              </p>
              <div className="text-[11px] text-emerald-600 mt-2 font-medium flex items-center gap-0.5">
                <ArrowUpRight className="h-3 w-3" /> Receita bruta totalizada
              </div>
            </div>

            {/* Card Despesas */}
            <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm relative overflow-hidden group">
              <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
                <TrendingDown className="h-14 w-14 text-destructive" />
              </div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Custos Operacionais</p>
              <p className="text-3xl font-black text-destructive mt-2">
                {stats.despesas.toLocaleString("pt-PT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 })}
              </p>
              <div className="text-[11px] text-muted-foreground mt-2">Subtotal de despesas registadas</div>
            </div>

            {/* Card Lucro Líquido */}
            <div className={`bg-card border rounded-xl p-5 shadow-sm relative overflow-hidden group border-l-4 ${stats.lucro >= 0 ? "border-l-emerald-500" : "border-l-red-500"}`}>
              <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
                <FileBarChart className="h-14 w-14 text-foreground" />
              </div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Resultado Líquido</p>
              <p className={`text-3xl font-black mt-2 ${stats.lucro >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                {stats.lucro.toLocaleString("pt-PT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 })}
              </p>
              <div className="text-[11px] text-muted-foreground mt-2 font-medium">
                Rentabilidade: <span className={stats.lucro >= 0 ? "text-emerald-600" : "text-red-600"}>
                  {stats.receita > 0 ? ((stats.lucro / stats.receita) * 100).toFixed(0) : 0}%
                </span>
              </div>
            </div>
          </div>

          {/* Secção de Novos Clientes Solitária Expandida */}
          <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm flex items-center justify-between group relative overflow-hidden">
            <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
              <Users className="h-14 w-14 text-foreground" />
            </div>
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Novos Clientes Angariados</p>
              <p className="text-3xl font-black text-foreground mt-1">{stats.clients.length}</p>
            </div>
            <div className="text-right text-xs text-muted-foreground hidden sm:block max-w-[200px]">
              Contas criadas na plataforma durante este ciclo mensal.
            </div>
          </div>

          {/* Antevisão da Estrutura - Estilo WordPress Admin Panels */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Eventos Combinados */}
            <div className="bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-border/60 bg-muted/20 flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Discriminação de Eventos</span>
                <span className="text-xs bg-background border px-2 py-0.5 rounded text-muted-foreground">{stats.events.length}</span>
              </div>
              <div className="divide-y divide-border/40 max-h-[300px] overflow-y-auto">
                {stats.events.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-12">Nenhum evento registado neste mês.</p>
                ) : (
                  stats.events.map((e: any) => (
                    <div key={e.id} className="p-3.5 flex items-center justify-between hover:bg-muted/30 transition-colors text-sm">
                      <div className="min-w-0 pr-4">
                        <p className="font-semibold text-foreground truncate">{e.title}</p>
                        <p className="text-xs text-muted-foreground capitalize mt-0.5">{e.event_type || "Geral"}</p>
                      </div>
                      <div className="text-right shrink-0 font-mono">
                        <p className="font-bold text-foreground">
                          {Number(e.budget || 0).toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}
                        </p>
                        <p className="text-[11px] text-muted-foreground">
                          {e.event_date ? format(new Date(e.event_date), "dd/MM/yyyy") : "—"}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Lista de Clientes Anexados */}
            <div className="bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-border/60 bg-muted/20 flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Novos Leads / Clientes</span>
                <span className="text-xs bg-background border px-2 py-0.5 rounded text-muted-foreground">{stats.clients.length}</span>
              </div>
              <div className="divide-y divide-border/40 max-h-[300px] overflow-y-auto">
                {stats.clients.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-12">Sem novos registos no período selecionado.</p>
                ) : (
                  stats.clients.map((c: any) => (
                    <div key={c.id} className="p-3.5 text-sm hover:bg-muted/30 transition-colors">
                      <p className="font-semibold text-foreground truncate">{c.full_name || "Utilizador Sem Nome"}</p>
                      <p className="text-xs text-muted-foreground truncate font-mono mt-0.5">{c.email}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AdminRelatorio;
