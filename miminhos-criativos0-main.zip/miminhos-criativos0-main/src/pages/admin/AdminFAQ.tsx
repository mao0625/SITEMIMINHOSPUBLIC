import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import {
  Plus, Trash2, HelpCircle, ArrowUp, ArrowDown,
  ArrowLeft, Save, X, Pencil, Search,
} from "lucide-react";

interface FAQ {
  id: string;
  question: string;
  answer: string;
  order: number;
  created_at: string;
}

// ─── Página de edição / criação (estilo SAP) ──────────────────────────────────
const FAQEditor = ({
  faq,
  totalItems,
  onBack,
  onSaved,
}: {
  faq: FAQ | null;
  totalItems: number;
  onBack: () => void;
  onSaved: () => void;
}) => {
  const isNew = !faq;
  const [form, setForm] = useState({
    question: faq?.question ?? "",
    answer: faq?.answer ?? "",
  });
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  const set = (k: keyof typeof form, v: string) => {
    setForm((p) => ({ ...p, [k]: v }));
    setDirty(true);
  };

  const save = async () => {
    if (!form.question.trim()) return toast.error("A pergunta é obrigatória");
    if (!form.answer.trim()) return toast.error("A resposta é obrigatória");
    setSaving(true);
    const payload = {
      question: form.question.trim(),
      answer: form.answer.trim(),
      order: faq ? faq.order : totalItems,
    };
    const res = faq
      ? await supabase.from("faqs").update(payload).eq("id", faq.id)
      : await supabase.from("faqs").insert(payload);
    setSaving(false);
    if (res.error) return toast.error(res.error.message);
    toast.success(faq ? "Pergunta atualizada" : "Pergunta criada");
    onSaved();
    onBack();
  };

  return (
    <div>
      {/* Barra SAP */}
      <div className="bg-muted/60 border border-border rounded-t-lg px-4 py-2 flex items-center gap-3 flex-wrap">
        <Button variant="ghost" size="sm" onClick={onBack} className="h-7 px-2">
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
        <div className="h-4 w-px bg-border" />
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <HelpCircle className="h-4 w-4 text-muted-foreground shrink-0" />
          <span className="font-semibold text-sm truncate">
            {isNew ? "Nova Pergunta FAQ" : (
              <>Editar Pergunta: <span className="text-primary truncate">{faq.question}</span></>
            )}
          </span>
          {dirty && (
            <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded ml-2">
              Alterações por guardar
            </span>
          )}
        </div>
        <div className="flex gap-2 ml-auto">
          <Button size="sm" className="h-7 text-xs bg-gradient-gold" disabled={saving} onClick={save}>
            <Save className="h-3 w-3 mr-1" />
            {saving ? "A guardar..." : "Guardar"}
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={onBack}>
            <X className="h-3 w-3 mr-1" /> Cancelar
          </Button>
        </div>
      </div>

      {/* Conteúdo */}
      <div className="border border-t-0 border-border rounded-b-lg bg-background">
        {/* Cabeçalho info */}
        <div className="px-6 py-3 bg-muted/30 border-b border-border flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Estado</span>
            <span className={`text-xs px-2 py-0.5 rounded font-medium ${isNew ? "bg-blue-100 text-blue-700" : "bg-green-100 text-green-700"}`}>
              {isNew ? "Novo registo" : "Edição"}
            </span>
          </div>
          {!isNew && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Posição</span>
              <span className="font-mono text-sm font-semibold bg-muted px-2 py-0.5 rounded border border-border">
                {faq.order + 1}
              </span>
            </div>
          )}
        </div>

        <div className="p-6 max-w-2xl space-y-0">
          {/* Pergunta */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 pb-1 border-b border-border">
              Conteúdo da FAQ
            </div>

            <div className="flex items-start border-b border-border py-3 gap-4">
              <label className="text-sm text-muted-foreground w-32 shrink-0 pt-2">Pergunta <span className="text-destructive">*</span></label>
              <div className="flex-1">
                <Input
                  value={form.question}
                  onChange={(e) => set("question", e.target.value)}
                  placeholder="Ex: Quanto tempo demora a receber o orçamento?"
                  className="text-sm border-0 border-b border-border rounded-none bg-transparent focus-visible:ring-0 focus-visible:border-primary px-1"
                />
                <p className="text-xs text-muted-foreground mt-1">{form.question.length} caracteres</p>
              </div>
            </div>

            <div className="flex items-start border-b border-border py-3 gap-4">
              <label className="text-sm text-muted-foreground w-32 shrink-0 pt-2">Resposta <span className="text-destructive">*</span></label>
              <div className="flex-1">
                <Textarea
                  rows={8}
                  value={form.answer}
                  onChange={(e) => set("answer", e.target.value)}
                  placeholder="Escreva a resposta detalhada aqui..."
                  className="text-sm border border-border rounded bg-transparent focus-visible:ring-0 focus-visible:border-primary resize-none"
                />
                <p className="text-xs text-muted-foreground mt-1">{form.answer.length} caracteres</p>
              </div>
            </div>
          </div>

          {/* Preview */}
          {(form.question || form.answer) && (
            <div className="pt-6">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 pb-1 border-b border-border">
                Pré-visualização
              </div>
              <div className="bg-muted/30 border border-border rounded-lg p-4">
                <p className="font-semibold text-sm mb-2">{form.question || "—"}</p>
                <p className="text-sm text-muted-foreground whitespace-pre-line">{form.answer || "—"}</p>
              </div>
            </div>
          )}
        </div>

        {/* Botões em baixo */}
        <div className="px-6 py-4 border-t border-border bg-muted/20 flex gap-3">
          <Button className="bg-gradient-gold h-9" disabled={saving} onClick={save}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? "A guardar..." : isNew ? "Criar Pergunta" : "Guardar Alterações"}
          </Button>
          <Button variant="outline" className="h-9" onClick={onBack}>
            <X className="h-4 w-4 mr-2" /> Cancelar
          </Button>
        </div>
      </div>
    </div>
  );
};

// ─── Página principal ─────────────────────────────────────────────────────────
export const AdminFAQ = () => {
  const [items, setItems] = useState<FAQ[]>([]);
  const [editFaq, setEditFaq] = useState<FAQ | null | "new">(null);
  const [search, setSearch] = useState("");

  const load = async () => {
    const { data } = await supabase
      .from("faqs")
      .select("*")
      .order("order", { ascending: true });
    setItems(data ?? []);
  };

  useEffect(() => { load(); }, []);

  const remove = async (id: string) => {
    if (!confirm("Eliminar esta pergunta?")) return;
    await supabase.from("faqs").delete().eq("id", id);
    toast.success("Pergunta eliminada");
    load();
  };

  const moveOrder = async (faq: FAQ, direction: "up" | "down") => {
    const idx = items.findIndex((i) => i.id === faq.id);
    const swapIdx = direction === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= items.length) return;
    const swap = items[swapIdx];
    await supabase.from("faqs").update({ order: swap.order }).eq("id", faq.id);
    await supabase.from("faqs").update({ order: faq.order }).eq("id", swap.id);
    load();
  };

  const filtered = items.filter((f) =>
    search === "" ||
    f.question.toLowerCase().includes(search.toLowerCase()) ||
    f.answer.toLowerCase().includes(search.toLowerCase())
  );

  // Vista de editor
  if (editFaq !== null) {
    return (
      <FAQEditor
        faq={editFaq === "new" ? null : editFaq}
        totalItems={items.length}
        onBack={() => setEditFaq(null)}
        onSaved={load}
      />
    );
  }

  return (
    <>
      <PageHeader
        title="FAQ"
        description="Perguntas e respostas frequentes do site público"
        action={
          <Button onClick={() => setEditFaq("new")} className="bg-gradient-gold">
            <Plus className="h-4 w-4 mr-1" /> Nova pergunta
          </Button>
        }
      />

      {/* KPI */}
      <div className="bg-muted/60 border border-border rounded-lg px-5 py-3 flex items-center gap-4 mb-6">
        <div className="h-9 w-9 rounded bg-primary/10 flex items-center justify-center">
          <HelpCircle className="h-4 w-4 text-primary" />
        </div>
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Total de perguntas</p>
          <p className="font-display text-2xl font-semibold">{items.length}</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Pesquisar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 text-sm w-56"
          />
          {search && (
            <span className="text-xs text-muted-foreground">{filtered.length} resultado{filtered.length !== 1 ? "s" : ""}</span>
          )}
        </div>
      </div>

      {/* Empty state */}
      {items.length === 0 ? (
        <div className="bg-card border border-border rounded-lg p-16 text-center">
          <HelpCircle className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-base font-semibold mb-1">Nenhuma pergunta criada</h3>
          <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto">
            Crie perguntas e respostas que aparecerão na página pública de FAQ.
          </p>
          <Button onClick={() => setEditFaq("new")} className="bg-gradient-gold">
            <Plus className="h-4 w-4 mr-2" /> Criar primeira pergunta
          </Button>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          {/* Cabeçalho SAP da tabela */}
          <div className="px-4 py-2.5 border-b border-border bg-muted/40 flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Lista de Perguntas
            </span>
            <span className="text-xs text-muted-foreground">{filtered.length} de {items.length}</span>
          </div>

          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="w-10 text-center">#</TableHead>
                <TableHead>Pergunta</TableHead>
                <TableHead className="hidden md:table-cell">Resposta</TableHead>
                <TableHead className="w-16 text-center">Ordem</TableHead>
                <TableHead className="text-right w-24">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((faq, i) => (
                <TableRow
                  key={faq.id}
                  className="hover:bg-primary/5 cursor-pointer transition-colors align-top group"
                  onClick={() => setEditFaq(faq)}
                >
                  <TableCell className="text-center text-sm text-muted-foreground font-mono pt-4">
                    {faq.order + 1}
                  </TableCell>
                  <TableCell className="pt-4">
                    <p className="font-medium text-sm line-clamp-2 group-hover:text-primary transition-colors">
                      {faq.question}
                    </p>
                  </TableCell>
                  <TableCell className="hidden md:table-cell pt-4">
                    <p className="text-sm text-muted-foreground line-clamp-2">{faq.answer}</p>
                  </TableCell>
                  <TableCell className="pt-3" onClick={(e) => e.stopPropagation()}>
                    <div className="flex flex-col items-center gap-0.5">
                      <button
                        onClick={() => moveOrder(faq, "up")}
                        disabled={i === 0}
                        className="p-1 rounded hover:bg-muted disabled:opacity-20 disabled:cursor-not-allowed transition-colors"
                        title="Mover para cima"
                      >
                        <ArrowUp className="h-3 w-3" />
                      </button>
                      <button
                        onClick={() => moveOrder(faq, "down")}
                        disabled={i === filtered.length - 1}
                        className="p-1 rounded hover:bg-muted disabled:opacity-20 disabled:cursor-not-allowed transition-colors"
                        title="Mover para baixo"
                      >
                        <ArrowDown className="h-3 w-3" />
                      </button>
                    </div>
                  </TableCell>
                  <TableCell className="text-right pt-3" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        size="sm" variant="ghost"
                        onClick={() => setEditFaq(faq)}
                        className="h-7 w-7 p-0 hover:bg-primary/10"
                        title="Editar"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="sm" variant="ghost"
                        onClick={() => remove(faq.id)}
                        className="h-7 w-7 p-0 hover:bg-destructive/10"
                        title="Eliminar"
                      >
                        <Trash2 className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </>
  );
};

export default AdminFAQ;
