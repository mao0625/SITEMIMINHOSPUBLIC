import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import {
  Download, Eye, Search, Save, RefreshCw, ArrowLeft,
  FileText, Lock, Globe, Pencil, X, Check,
  Receipt, Plus, Trash2, Calculator, Send, CheckCircle2,
  Euro, Clock, XCircle, Ban, Mail, ChevronRight,
  Filter, SlidersHorizontal,
} from "lucide-react";
import { exportQuestionnairePDF } from "@/lib/pdf";
import { QUESTIONNAIRE_SECTIONS } from "@/lib/questionnaire";
import { toast } from "sonner";

// ─── Status helpers ───────────────────────────────────────────────────────────
const statusColor: Record<string, string> = {
  pendente:  "bg-amber-100 text-amber-700",
  rascunho:  "bg-blue-100 text-blue-700",
  submetido: "bg-green-100 text-green-700",
  aprovado:  "bg-emerald-100 text-emerald-700",
  rejeitado: "bg-red-100 text-red-700",
};

const pagamentoColor: Record<string, string> = {
  por_pagar:     "bg-amber-100 text-amber-700 border-amber-200",
  em_pagamento:  "bg-blue-100 text-blue-700 border-blue-200",
  pago:          "bg-emerald-100 text-emerald-700 border-emerald-200",
  cancelado:     "bg-red-100 text-red-700 border-red-200",
  nao_atribuido: "bg-muted text-muted-foreground border-border",
};

const pagamentoLabel: Record<string, string> = {
  por_pagar:     "Por Pagar",
  em_pagamento:  "Em Pagamento",
  pago:          "Pago",
  cancelado:     "Orçamento Gratuito",
  nao_atribuido: "Não Atribuído",
};

const fmt = (n: number) =>
  n.toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ─── Template HTML do email ───────────────────────────────────────────────────
const buildEmailHTML = (clientName: string, mensagem: string, portalUrl: string) => `
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>Orçamento — Miminhos Criativos</title></head>
<body style="margin:0;padding:0;background:#f5f0e8;font-family:Georgia,serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f0e8;padding:24px 0;">
  <tr><td align="center">
    <table width="580" cellpadding="0" cellspacing="0" style="max-width:580px;width:100%;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);">
      <tr>
        <td style="background:#1a1a1a;padding:28px 32px;text-align:center;">
          <p style="margin:0 0 4px;font-size:10px;letter-spacing:4px;color:#c9a227;font-family:Arial,sans-serif;text-transform:uppercase;">A Festa é Sua! O Prazer em Criar é Nosso!</p>
          <h1 style="margin:0;font-size:28px;font-weight:900;color:#fff;font-family:Arial,sans-serif;letter-spacing:3px;text-transform:uppercase;line-height:1.2;">MIMINHOS<br/>CRIATIVOS</h1>
          <div style="width:40px;height:2px;background:#c9a227;margin:12px auto 0;"></div>
        </td>
      </tr>
      <tr>
        <td style="padding:36px 40px 28px;">
          <p style="margin:0 0 18px;font-size:16px;color:#2c2c2c;font-family:Georgia,serif;">
            Olá <strong style="color:#1a1a1a;">${clientName}</strong>,
          </p>
          <p style="margin:0 0 24px;font-size:15px;line-height:1.75;color:#3a3028;font-family:Georgia,serif;">${mensagem}</p>
          <table cellpadding="0" cellspacing="0" width="100%" style="margin:28px 0;">
            <tr><td align="center">
              <a href="${portalUrl}" style="display:inline-block;background:#c9a227;color:#fff;font-family:Arial,sans-serif;font-size:14px;font-weight:700;letter-spacing:2px;text-decoration:none;padding:14px 44px;border-radius:4px;text-transform:uppercase;">
                Aceder ao Portal do Cliente
              </a>
            </td></tr>
          </table>
          <p style="margin:0 0 6px;font-size:13px;color:#888;font-family:Georgia,serif;text-align:center;">
            Ou aceda diretamente em: <a href="${portalUrl}" style="color:#c9a227;text-decoration:none;">${portalUrl}</a>
          </p>
        </td>
      </tr>
      <tr><td style="padding:0 40px;"><div style="height:1px;background:#e8e2d9;"></div></td></tr>
      <tr>
        <td style="padding:24px 40px 28px;">
          <p style="margin:0 0 4px;font-size:14px;color:#3a3028;font-family:Georgia,serif;">Atenciosamente,</p>
          <p style="margin:0 0 2px;font-size:15px;font-weight:700;color:#1a1a1a;font-family:Georgia,serif;">Miminhos Criativos</p>
          <p style="margin:0;font-size:12px;color:#888;font-family:Arial,sans-serif;">
            site.miminhoscriativos@gmail.com &nbsp;·&nbsp; Madeira, Portugal
          </p>
        </td>
      </tr>
      <tr>
        <td style="background:#1a1a1a;padding:14px 40px;text-align:center;">
          <p style="margin:0;font-size:10px;color:#666;font-family:Arial,sans-serif;letter-spacing:1px;">
            © ${new Date().getFullYear()} Miminhos Criativos · Decoração de Eventos · Madeira, Portugal
          </p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;

const enviarEmailAutomatico = async (
  toEmail: string, clientName: string, mensagem: string,
  portalUrl: string, questionnaireId: string
): Promise<{ ok: boolean; error?: string }> => {
  try {
    const { error } = await supabase.functions.invoke("send-email", {
      body: {
        to: toEmail,
        subject: "O seu Orçamento está pronto — Miminhos Criativos",
        html: buildEmailHTML(clientName, mensagem, portalUrl),
      },
    });
    if (error) {
      const { error: err2 } = await (supabase as any).rpc("send_email_notification", {
        p_to: toEmail,
        p_subject: "O seu Orçamento está pronto — Miminhos Criativos",
        p_html: buildEmailHTML(clientName, mensagem, portalUrl),
      });
      if (err2) throw err2;
    }
    await supabase.from("questionnaires")
      .update({ email_enviado_em: new Date().toISOString() } as any)
      .eq("id", questionnaireId);
    return { ok: true };
  } catch (err: any) {
    return { ok: false, error: err?.message || String(err) };
  }
};

// ─── Modal de email — Apple style ────────────────────────────────────────────
const EmailModal = ({ q, onClose, onSent }: { q: any; onClose: () => void; onSent?: () => void }) => {
  const [sending,  setSending]  = useState(false);
  const [sent,     setSent]     = useState(false);
  const [preview,  setPreview]  = useState(false);
  const [mensagem, setMensagem] = useState(
    `O seu pedido de Orçamento já foi analisado e está disponível no Portal do Cliente. Para visualizar o seu Orçamento, entre com o seu email ou número de telefone.`
  );

  const clientName  = q.profile?.full_name || q.profile?.email || "Cliente";
  const clientEmail = q.profile?.email || "";
  const portalUrl   = `${window.location.origin}/cliente`;

  const sendEmail = async () => {
    if (!clientEmail) { toast.error("Este cliente não tem email registado."); return; }
    setSending(true);
    const result = await enviarEmailAutomatico(clientEmail, clientName, mensagem, portalUrl, q.id);
    setSending(false);
    if (result.ok) {
      setSent(true);
      toast.success(`Email enviado para ${clientEmail}!`, { duration: 6000 });
      onSent?.();
    } else {
      toast.error("Envio automático falhou. A abrir cliente de email…");
      const subject = encodeURIComponent("O seu Orçamento está pronto — Miminhos Criativos");
      const body = encodeURIComponent(`Olá ${clientName},\n\n${mensagem}\n\nAceda ao Portal do Cliente em:\n${portalUrl}\n\n— Miminhos Criativos`);
      window.open(`mailto:${clientEmail}?subject=${subject}&body=${body}`, "_blank");
      await supabase.from("questionnaires").update({ email_enviado_em: new Date().toISOString() } as any).eq("id", q.id);
      setSent(true); onSent?.();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-md p-4">
      <div className="bg-card/95 backdrop-blur-xl border border-border/60 rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">

        {/* Header */}
        <div className="flex items-center justify-between px-7 py-5 border-b border-border/40">
          <div className="flex items-center gap-4">
            <div className="h-11 w-11 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Mail className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-base">Enviar Email ao Cliente</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Para: <span className="font-medium text-foreground">{clientEmail || "Sem email"}</span>
                <span className="mx-1.5 opacity-30">·</span>
                <span>no-reply@md.lovable-app.email</span>
              </p>
            </div>
          </div>
          <button onClick={onClose} className="h-8 w-8 rounded-full bg-muted/60 hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 px-7 pt-4 pb-0">
          {[{ key: false, label: "Editar Mensagem" }, { key: true, label: "Pré-visualizar", icon: Eye }].map(tab => (
            <button key={String(tab.key)} onClick={() => setPreview(tab.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${preview === tab.key ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted/40"}`}>
              {tab.key && <Eye className="h-3 w-3" />}{tab.label}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-auto p-7 pt-4">
          {!preview ? (
            <div className="space-y-5">
              {/* Info cabeçalho */}
              <div className="bg-muted/30 rounded-2xl overflow-hidden">
                <div className="grid grid-cols-2 divide-x divide-border/40">
                  <div className="p-4">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-1.5">Para</p>
                    <p className={`text-sm font-semibold ${!clientEmail ? "text-destructive" : ""}`}>{clientEmail || "⚠ Sem email"}</p>
                  </div>
                  <div className="p-4">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-1.5">De (automático)</p>
                    <p className="text-sm font-medium text-muted-foreground">no-reply@md.lovable-app.email</p>
                  </div>
                  <div className="p-4 col-span-2 border-t border-border/40">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-1.5">Assunto</p>
                    <p className="text-sm font-medium">O seu Orçamento está pronto — Miminhos Criativos</p>
                  </div>
                </div>
              </div>

              {/* Mensagem */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground block">Corpo da Mensagem</label>
                <Textarea value={mensagem} onChange={e => setMensagem(e.target.value)} rows={4}
                  className="text-sm resize-none rounded-2xl border-border/60 bg-muted/20 focus:bg-background" placeholder="Mensagem para o cliente..." />
                <p className="text-[11px] text-muted-foreground">O cabeçalho com o logo, o botão "Portal do Cliente" e a assinatura são adicionados automaticamente.</p>
              </div>

              {/* Mini preview */}
              <div className="rounded-2xl overflow-hidden border border-border/40 bg-[#f5f0e8]">
                <div className="px-4 py-2.5 bg-muted/30 border-b border-border/40">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Aspeto do Email</span>
                </div>
                <div className="p-5 flex justify-center">
                  <div className="w-60 rounded-xl overflow-hidden shadow-lg border border-[#e8e2d9]">
                    <div className="bg-[#1a1a1a] px-4 py-5 text-center">
                      <p className="text-[7px] tracking-[3px] text-[#c9a227] mb-1 uppercase">A Festa é Sua!</p>
                      <p className="text-white font-black text-sm tracking-[2px] uppercase leading-tight">MIMINHOS<br/>CRIATIVOS</p>
                      <div className="w-6 h-[1.5px] bg-[#c9a227] mx-auto mt-2"></div>
                    </div>
                    <div className="bg-white px-4 py-4">
                      <p className="text-[11px] text-gray-700 mb-2">Olá <strong>{clientName}</strong>,</p>
                      <p className="text-[10px] text-gray-500 leading-relaxed mb-3">{mensagem.slice(0, 80)}…</p>
                      <div className="bg-[#c9a227] text-white text-[8px] font-bold py-2 px-3 rounded text-center tracking-wider uppercase">Portal do Cliente</div>
                    </div>
                    <div className="bg-white px-4 py-3 border-t border-[#e8e2d9]">
                      <p className="text-[9px] text-gray-500">Atenciosamente,</p>
                      <p className="text-[10px] font-bold text-gray-700">Miminhos Criativos</p>
                    </div>
                    <div className="bg-[#1a1a1a] px-4 py-2 text-center">
                      <p className="text-[7px] text-gray-500">© {new Date().getFullYear()} Miminhos Criativos · Madeira</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl overflow-hidden border border-border/40">
              <iframe srcDoc={buildEmailHTML(clientName, mensagem, portalUrl)} className="w-full h-[500px] border-0" title="Pré-visualização" />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-7 py-5 border-t border-border/40 flex items-center justify-between gap-3">
          {sent ? (
            <div className="flex items-center gap-2.5 text-emerald-600">
              <div className="h-7 w-7 rounded-full bg-emerald-100 flex items-center justify-center">
                <CheckCircle2 className="h-4 w-4" />
              </div>
              <span className="text-sm font-medium">Email enviado para {clientEmail}!</span>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              {clientEmail ? `Enviado via no-reply@md.lovable-app.email` : "⚠ Nenhum email registado"}
            </p>
          )}
          <div className="flex gap-2.5">
            <Button variant="outline" size="sm" onClick={onClose} className="h-9 px-4 rounded-xl text-xs">
              {sent ? "Fechar" : "Cancelar"}
            </Button>
            {!sent && (
              <Button size="sm" className="h-9 px-5 rounded-xl text-xs bg-gradient-gold gap-2"
                disabled={sending || !clientEmail} onClick={sendEmail}>
                {sending ? <><RefreshCw className="h-3.5 w-3.5 animate-spin" />A enviar…</> : <><Send className="h-3.5 w-3.5" />Enviar Email</>}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── FieldEditor ──────────────────────────────────────────────────────────────
const FieldEditor = ({ field, value, onChange, readOnly }: { field: any; value: any; onChange: (v: any) => void; readOnly: boolean }) => {
  if (field.type === "static") return <p className="text-xs text-muted-foreground italic">{field.label}</p>;
  if (readOnly) { const display = Array.isArray(value) ? value.join(", ") : (value ?? "—"); return <p className="text-sm">{display || "—"}</p>; }
  if (field.type === "textarea") return <Textarea value={value ?? ""} onChange={e => onChange(e.target.value)} rows={3} className="text-sm" placeholder="—" />;
  if (field.type === "select" || field.type === "radio") return (
    <div className="flex flex-wrap gap-2">{field.options?.map((opt: string) => (
      <button key={opt} type="button" onClick={() => onChange(opt)} className={`px-3 py-1.5 rounded-full text-sm border transition-all ${value === opt ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"}`}>{opt}</button>
    ))}</div>
  );
  if (field.type === "checkbox") return (
    <div className="flex flex-wrap gap-2">{field.options?.map((opt: string) => {
      const arr: string[] = Array.isArray(value) ? value : []; const checked = arr.includes(opt);
      return <button key={opt} type="button" onClick={() => onChange(checked ? arr.filter(v => v !== opt) : [...arr, opt])} className={`px-3 py-1.5 rounded-full text-sm border transition-all ${checked ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"}`}>{opt}</button>;
    })}</div>
  );
  if (field.type === "toggle") return (
    <div className="flex gap-2">{field.options?.map((opt: string) => (
      <button key={opt} type="button" onClick={() => onChange(opt)} className={`px-4 py-1.5 rounded-full text-sm border transition-all ${value === opt ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"}`}>{opt}</button>
    ))}</div>
  );
  return <Input type={field.type === "number" ? "number" : field.type === "date" ? "date" : field.type === "time" ? "time" : field.type === "email" ? "email" : field.type === "tel" ? "tel" : "text"} value={value ?? ""} onChange={e => onChange(e.target.value)} className="text-sm" placeholder="—" />;
};

// ─── OrcamentoItem ────────────────────────────────────────────────────────────
interface OrcamentoItem { id: string; descricao: string; quantidade: number; preco_unitario: number; iva: number; }
const newItem = (): OrcamentoItem => ({ id: crypto.randomUUID(), descricao: "", quantidade: 1, preco_unitario: 0, iva: 23 });

// ─── LancamentoOrcamento ──────────────────────────────────────────────────────
const LancamentoOrcamento = ({ q, onBack }: { q: any; onBack: () => void }) => {
  const [items, setItems]             = useState<OrcamentoItem[]>([newItem()]);
  const [notas, setNotas]             = useState("");
  const [validadeDias, setValidadeDias] = useState(30);
  const [saving, setSaving]           = useState(false);
  const [saved, setSaved]             = useState(false);
  const [enviarEmail, setEnviarEmail] = useState(true);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [localQ, setLocalQ]           = useState(q);
  const confirmado = q.status === "aprovado" && q.estado_pagamento && q.estado_pagamento !== "por_pagar";

  useEffect(() => {
    if (q.orcamento) {
      try {
        const data = typeof q.orcamento === "string" ? JSON.parse(q.orcamento) : q.orcamento;
        if (data.items?.length) setItems(data.items);
        if (data.notas) setNotas(data.notas);
        if (data.validade_dias) setValidadeDias(data.validade_dias);
      } catch { /* ignore */ }
    }
  }, [q.id]);

  const updateItem = (id: string, field: keyof OrcamentoItem, value: any) => {
    if (confirmado) return;
    setItems(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
    setSaved(false);
  };

  const subtotalSemIva = items.reduce((s, i) => s + i.quantidade * i.preco_unitario, 0);
  const totalIva = items.reduce((s, i) => s + i.quantidade * i.preco_unitario * (i.iva / 100), 0);
  const total = subtotalSemIva + totalIva;

  const guardar = async (finalizar = false) => {
    if (confirmado) return;
    setSaving(true);
    const orcamentoData = { items, notas, validade_dias: validadeDias, total, criado_em: new Date().toISOString() };
    const { error } = await (supabase as any).from("questionnaires").update({
      orcamento: orcamentoData, status: finalizar ? "aprovado" : q.status,
      ...(finalizar ? { confirmed_at: new Date().toISOString(), estado_pagamento: "por_pagar" } : {}),
      updated_at: new Date().toISOString(),
    }).eq("id", q.id);
    setSaving(false);
    if (error) { toast.error("Erro ao guardar: " + error.message); return; }
    setSaved(true);
    if (finalizar) {
      toast.success("Orçamento finalizado e aprovado!");
      const { data } = await supabase.from("questionnaires").select("*").eq("id", q.id).maybeSingle();
      if (data) setLocalQ({ ...data, profile: q.profile });
      if (enviarEmail && q.profile?.email) { setShowEmailModal(true); } else { onBack(); }
    } else { toast.success("Orçamento guardado!"); }
  };

  return (
    <>
      {showEmailModal && <EmailModal q={localQ} onClose={() => { setShowEmailModal(false); onBack(); }} onSent={() => { setShowEmailModal(false); onBack(); }} />}
      <div className="space-y-0">
        {/* Toolbar Apple */}
        <div className="bg-card/80 backdrop-blur-sm border border-border/60 rounded-2xl px-5 py-3 flex items-center gap-3 flex-wrap shadow-sm mb-1">
          <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-primary font-medium hover:opacity-70 transition-opacity">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </button>
          <div className="h-4 w-px bg-border/60" />
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <Receipt className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="font-semibold text-sm truncate">
              Lançar Orçamento — <span className="font-mono text-primary">{q.reference_number || "—"}</span>
            </span>
            <span className="text-xs text-muted-foreground hidden sm:block">{q.profile?.full_name || q.profile?.email || "—"}</span>
            {confirmado && <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-medium">Confirmado</span>}
          </div>
          {!confirmado && (
            <div className="flex gap-2 ml-auto">
              <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl" disabled={saving} onClick={() => guardar(false)}>
                <Save className="h-3 w-3 mr-1" /> {saved ? "Guardado ✓" : "Guardar"}
              </Button>
              <Button size="sm" className="h-8 text-xs rounded-xl bg-gradient-gold" disabled={saving || items.some(i => !i.descricao.trim())} onClick={() => guardar(true)}>
                <Send className="h-3 w-3 mr-1" /> Finalizar e Aprovar
              </Button>
              <Button size="sm" variant="ghost" className="h-8 text-xs rounded-xl" onClick={onBack}><X className="h-3 w-3" /></Button>
            </div>
          )}
          {confirmado && (
            <div className="flex gap-2 ml-auto">
              <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl gap-1.5 border-primary/30 text-primary" onClick={() => setShowEmailModal(true)}>
                <Mail className="h-3 w-3" /> Enviar Email
              </Button>
              <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-3">
                <ArrowLeft className="h-3.5 w-3.5" /> Voltar
              </button>
            </div>
          )}
        </div>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm overflow-hidden">
          {/* Info bar */}
          <div className="px-6 py-3 bg-muted/20 border-b border-border/40 flex items-center gap-6 flex-wrap">
            {[{ label:"Cliente", value:q.profile?.full_name||"—" }, { label:"NIF", value:q.profile?.nif||"—" }, { label:"Email", value:q.profile?.email||"—" }, { label:"Referência", value:q.reference_number||"—" }].map(f => (
              <div key={f.label} className="flex items-center gap-2">
                <span className="text-[11px] text-muted-foreground">{f.label}</span>
                <span className="text-sm font-medium">{f.value}</span>
              </div>
            ))}
            {!confirmado && (
              <div className="flex items-center gap-2 ml-auto">
                <span className="text-[11px] text-muted-foreground">Validade</span>
                <Input type="number" value={validadeDias} onChange={e => setValidadeDias(Number(e.target.value))} className="h-7 w-16 text-xs rounded-lg" min={1} />
                <span className="text-[11px] text-muted-foreground">dias</span>
              </div>
            )}
          </div>

          <div className="p-6 grid xl:grid-cols-[1fr_300px] gap-6 items-start">
            <div className="space-y-5">
              {/* Tabela itens */}
              <div className="rounded-2xl border border-border/60 overflow-hidden">
                <div className="px-5 py-3 border-b border-border/40 bg-muted/20 flex items-center justify-between">
                  <span className="text-xs font-semibold text-muted-foreground flex items-center gap-2 uppercase tracking-wider"><Calculator className="h-3.5 w-3.5" /> Itens do Orçamento</span>
                  {!confirmado && <Button size="sm" variant="outline" className="h-7 text-xs rounded-xl" onClick={() => setItems(p => [...p, newItem()])}><Plus className="h-3 w-3 mr-1" /> Linha</Button>}
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/40 bg-muted/10">
                        {["Descrição","Qtd","Preço Unit. (€)","IVA (%)","Total c/ IVA",""].map((h,i) => (
                          <th key={i} className={`px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground ${i===0?"text-left":i>=4?"text-right":"text-center"} ${i===1?"w-16":i===2?"w-28":i===3?"w-20":i===4?"w-28":i===5?"w-8":""}`}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/30">
                      {items.map(item => {
                        const linhaTotal = item.quantidade * item.preco_unitario * (1 + item.iva / 100);
                        return (
                          <tr key={item.id} className="hover:bg-muted/10 group">
                            <td className="px-3 py-2">{confirmado ? <span>{item.descricao}</span> : <Input value={item.descricao} onChange={e => updateItem(item.id,"descricao",e.target.value)} placeholder="Descrição..." className="h-8 text-sm border-border/40 bg-transparent rounded-lg" />}</td>
                            <td className="px-3 py-2 text-center">{confirmado ? <span>{item.quantidade}</span> : <Input type="number" value={item.quantidade} onChange={e => updateItem(item.id,"quantidade",Number(e.target.value))} className="h-8 text-sm text-center border-border/40 bg-transparent w-full rounded-lg" min={1} />}</td>
                            <td className="px-3 py-2 text-right">{confirmado ? <span>{fmt(item.preco_unitario)} €</span> : <Input type="number" value={item.preco_unitario} onChange={e => updateItem(item.id,"preco_unitario",Number(e.target.value))} className="h-8 text-sm text-right border-border/40 bg-transparent w-full rounded-lg" step="0.01" min={0} />}</td>
                            <td className="px-3 py-2 text-center">{confirmado ? <span>{item.iva}%</span> : <select value={item.iva} onChange={e => updateItem(item.id,"iva",Number(e.target.value))} className="h-8 w-full text-sm text-center border border-border/40 rounded-lg bg-transparent px-1"><option value={0}>0%</option><option value={6}>6%</option><option value={13}>13%</option><option value={23}>23%</option></select>}</td>
                            <td className="px-3 py-2 text-right font-semibold">{fmt(linhaTotal)} €</td>
                            {!confirmado && <td className="px-2 py-2"><button onClick={() => { if(items.length>1) setItems(p=>p.filter(i=>i.id!==item.id)); }} disabled={items.length===1} className="p-1 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors disabled:opacity-20 opacity-0 group-hover:opacity-100"><Trash2 className="h-3.5 w-3.5" /></button></td>}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {(notas || !confirmado) && (
                <div className="rounded-2xl border border-border/60 overflow-hidden">
                  <div className="px-5 py-3 border-b border-border/40 bg-muted/20"><span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Notas e Condições</span></div>
                  <div className="p-4">{confirmado ? <p className="text-sm text-muted-foreground">{notas || "—"}</p> : <Textarea value={notas} onChange={e => { setNotas(e.target.value); setSaved(false); }} rows={3} placeholder="Condições de pagamento, observações..." className="text-sm resize-none rounded-xl" />}</div>
                </div>
              )}

              {!confirmado && (
                <div className="rounded-2xl border border-border/60 p-4 flex items-start gap-3 bg-muted/10">
                  <input type="checkbox" id="enviar-email" checked={enviarEmail} onChange={e => setEnviarEmail(e.target.checked)} className="mt-0.5 h-4 w-4 accent-primary rounded" />
                  <div>
                    <label htmlFor="enviar-email" className="text-sm font-medium cursor-pointer">Notificar cliente por email ao aprovar</label>
                    <p className="text-xs text-muted-foreground mt-0.5">Ao clicar em "Finalizar e Aprovar", o email é enviado automaticamente via <strong>no-reply@md.lovable-app.email</strong>.</p>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar resumo */}
            <div className="space-y-4 sticky top-6">
              <div className="rounded-2xl border border-border/60 overflow-hidden bg-card">
                <div className="px-5 py-3 border-b border-border/40 bg-muted/20 flex items-center gap-2">
                  <Calculator className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Resumo Financeiro</span>
                </div>
                <div className="p-5 space-y-3">
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal (s/ IVA)</span><span className="font-medium">{fmt(subtotalSemIva)} €</span></div>
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">IVA total</span><span className="font-medium">{fmt(totalIva)} €</span></div>
                  {[0,6,13,23].map(taxa => { const base = items.filter(i=>i.iva===taxa).reduce((s,i)=>s+i.quantidade*i.preco_unitario,0); if(!base) return null; return <div key={taxa} className="flex justify-between text-xs text-muted-foreground pl-3"><span>IVA {taxa}% s/ {fmt(base)}€</span><span>{fmt(base*taxa/100)}€</span></div>; })}
                  <div className="border-t border-border/60 pt-3 flex justify-between items-center">
                    <span className="font-bold text-sm">Total</span>
                    <div><span className="font-black text-3xl text-primary">{fmt(total)}</span><span className="text-base font-bold text-primary ml-1">€</span></div>
                  </div>
                </div>
              </div>
              {!confirmado && (
                <>
                  <Button className="w-full bg-gradient-gold h-10 text-sm font-semibold rounded-xl" disabled={saving || items.some(i=>!i.descricao.trim())} onClick={() => guardar(true)}><Send className="h-4 w-4 mr-2" /> Finalizar e Aprovar</Button>
                  <Button variant="outline" className="w-full h-10 text-sm rounded-xl" disabled={saving} onClick={() => guardar(false)}><Save className="h-4 w-4 mr-2" /> {saved ? "Guardado ✓" : "Guardar Rascunho"}</Button>
                </>
              )}
              {q.profile?.email && (
                <Button variant="outline" className="w-full h-10 text-sm rounded-xl gap-2 border-primary/30 text-primary hover:bg-primary/5" onClick={() => setShowEmailModal(true)}>
                  <Mail className="h-4 w-4" /> Enviar Email ao Cliente
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

// ─── GestãoPagamento ──────────────────────────────────────────────────────────
const GestãoPagamento = ({ q, onSaved }: { q: any; onSaved: () => void }) => {
  const [estado, setEstado] = useState(q.estado_pagamento ?? "por_pagar");
  const [saving, setSaving] = useState(false);
  if (q.status !== "aprovado") return null;
  const opcoes = [
    { value:"por_pagar",     label:"Por Pagar",            icon:<Clock className="h-3.5 w-3.5" />,       color:"border-amber-300 bg-amber-50 text-amber-700" },
    { value:"em_pagamento",  label:"Em Pagamento",         icon:<Euro className="h-3.5 w-3.5" />,         color:"border-blue-300 bg-blue-50 text-blue-700" },
    { value:"pago",          label:"Pago",                 icon:<CheckCircle2 className="h-3.5 w-3.5" />, color:"border-emerald-300 bg-emerald-50 text-emerald-700" },
    { value:"cancelado",     label:"Orçamento Gratuito",   icon:<XCircle className="h-3.5 w-3.5" />,      color:"border-red-300 bg-red-50 text-red-700" },
    { value:"nao_atribuido", label:"Evento Não Atribuído", icon:<Ban className="h-3.5 w-3.5" />,          color:"border-border bg-muted text-muted-foreground" },
  ];
  const guardar = async () => {
    setSaving(true);
    const { error } = await (supabase as any).from("questionnaires").update({ estado_pagamento: estado, updated_at: new Date().toISOString() }).eq("id", q.id);
    setSaving(false);
    if (error) { toast.error("Erro: " + error.message); return; }
    toast.success("Estado de pagamento atualizado!"); onSaved();
  };
  return (
    <div className="mx-6 mt-4 rounded-2xl border border-border/60 overflow-hidden">
      <div className="px-5 py-3 bg-muted/20 border-b border-border/40 flex items-center gap-2">
        <Euro className="h-3.5 w-3.5 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Estado do Pagamento</span>
      </div>
      <div className="p-4 flex flex-wrap gap-2 items-center">
        {opcoes.map(op => (
          <button key={op.value} onClick={() => setEstado(op.value)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border-2 transition-all ${estado === op.value ? `${op.color} border-2` : "border-border bg-background text-muted-foreground hover:border-primary/40"}`}>
            {op.icon} {op.label}
          </button>
        ))}
        <Button size="sm" className="h-7 text-xs ml-auto rounded-xl" disabled={saving || estado === (q.estado_pagamento ?? "por_pagar")} onClick={guardar}>
          <Save className="h-3 w-3 mr-1" /> {saving ? "A guardar..." : "Guardar"}
        </Button>
      </div>
    </div>
  );
};

// ─── OrcamentoDetalhe ─────────────────────────────────────────────────────────
type SubPage = "detalhe" | "lancamento";

const OrcamentoDetalhe = ({ q, onBack, onSaved }: { q: any; onBack: () => void; onSaved: () => void }) => {
  const [subPage,        setSubPage]        = useState<SubPage>("detalhe");
  const [answers,        setAnswers]        = useState<Record<string,any>>(q.answers ?? {});
  const [status,         setStatus]         = useState(q.status ?? "rascunho");
  const [saving,         setSaving]         = useState(false);
  const [lastSaved,      setLastSaved]      = useState<Date|null>(null);
  const [dirty,          setDirty]          = useState(false);
  const [editing,        setEditing]        = useState(false);
  const [showPdfMenu,    setShowPdfMenu]    = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [localQ,         setLocalQ]         = useState(q);

  const setField = (id: string, value: any) => { setAnswers(prev => ({ ...prev, [id]: value })); setDirty(true); };

  useEffect(() => {
    if (!dirty) return;
    const timer = setTimeout(() => save(false), 30000);
    return () => clearTimeout(timer);
  }, [answers, dirty]);

  useEffect(() => {
    const ch = supabase.channel(`questionnaire-${q.id}`)
      .on("postgres_changes", { event:"UPDATE", schema:"public", table:"questionnaires", filter:`id=eq.${q.id}` },
        payload => { if (!dirty) { setAnswers(payload.new.answers ?? {}); setStatus(payload.new.status ?? "rascunho"); setLocalQ({ ...payload.new, profile: localQ.profile }); toast.info("Atualizado em tempo real"); } })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [q.id, dirty]);

  const save = async (showToast = true) => {
    setSaving(true);
    const { error } = await supabase.from("questionnaires").update({ answers, status, updated_at: new Date().toISOString() }).eq("id", q.id);
    setSaving(false);
    if (error) { toast.error("Erro ao guardar"); return; }
    setDirty(false); setLastSaved(new Date());
    if (showToast) { toast.success("Guardado!"); onSaved(); }
  };

  const exportPdf = async (mode: "interno" | "externo") => {
    setShowPdfMenu(false);
    await exportQuestionnairePDF({ clientName: q.profile?.full_name||q.profile?.email||"Cliente", clientEmail: q.profile?.email, clientNif: q.profile?.nif, referenceNumber: q.reference_number, answers, submittedAt: q.submitted_at ? format(new Date(q.submitted_at),"dd/MM/yyyy") : undefined, mode });
  };

  if (subPage === "lancamento") return <LancamentoOrcamento q={localQ} onBack={() => { setSubPage("detalhe"); onSaved(); }} />;

  const orcamento = (() => { try { const o = typeof q.orcamento==="string" ? JSON.parse(q.orcamento) : q.orcamento; return o ?? null; } catch { return null; } })();

  return (
    <>
      {showEmailModal && <EmailModal q={localQ} onClose={() => setShowEmailModal(false)} onSent={() => { setShowEmailModal(false); onSaved(); }} />}

      <div className="space-y-1">
        {/* Toolbar Apple */}
        <div className="bg-card/80 backdrop-blur-sm border border-border/60 rounded-2xl px-5 py-3 flex items-center gap-3 flex-wrap shadow-sm">
          <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-primary font-medium hover:opacity-70 transition-opacity">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </button>
          <div className="h-4 w-px bg-border/60" />
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="font-semibold text-sm truncate">
              <span className="font-mono text-primary">{q.reference_number || "—"}</span>
            </span>
            <span className="text-xs text-muted-foreground hidden sm:block">{q.profile?.full_name || q.profile?.email || "—"}</span>
            <span className={`text-xs px-2.5 py-0.5 rounded-full font-medium capitalize ${statusColor[status] ?? "bg-muted text-muted-foreground"}`}>{status}</span>
            {localQ.estado_pagamento && status === "aprovado" && (
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-medium border ${pagamentoColor[localQ.estado_pagamento] ?? ""}`}>{pagamentoLabel[localQ.estado_pagamento]}</span>
            )}
          </div>

          <div className="flex items-center gap-1.5 ml-auto flex-wrap">
            {lastSaved && <span className="text-[10px] text-muted-foreground flex items-center gap-1"><RefreshCw className="h-3 w-3" />{format(lastSaved,"HH:mm:ss")}</span>}
            {status === "aprovado" && localQ.orcamento && localQ.profile?.email && (
              <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl gap-1.5 border-primary/30 text-primary hover:bg-primary/5" onClick={() => setShowEmailModal(true)}>
                <Mail className="h-3 w-3" />
                {(localQ as any).email_enviado_em ? "Reenviar Email" : "Enviar Email"}
              </Button>
            )}
            <Button size="sm" className="h-8 text-xs rounded-xl font-semibold bg-primary text-primary-foreground" onClick={() => setSubPage("lancamento")}>
              <Receipt className="h-3 w-3 mr-1.5" />{q.orcamento ? "Ver Orçamento" : "Lançar Orçamento"}
            </Button>
            <select value={status} onChange={e => { setStatus(e.target.value); setDirty(true); }} className="border border-border/60 rounded-xl h-8 px-2 text-xs bg-background">
              {["pendente","rascunho","submetido","aprovado","rejeitado"].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
            </select>
            {editing ? (
              <>
                <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl" onClick={() => { setEditing(false); setAnswers(q.answers??{}); setDirty(false); }}><X className="h-3 w-3 mr-1" /> Cancelar</Button>
                <Button size="sm" className="h-8 text-xs rounded-xl bg-gradient-gold" disabled={saving} onClick={() => { save(); setEditing(false); }}><Check className="h-3 w-3 mr-1" />{saving ? "A guardar..." : "Guardar"}</Button>
              </>
            ) : (
              <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl" onClick={() => setEditing(true)}><Pencil className="h-3 w-3 mr-1" /> Editar</Button>
            )}
            <div className="relative">
              <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl" onClick={() => setShowPdfMenu(v => !v)}><Download className="h-3 w-3 mr-1" /> PDF</Button>
              {showPdfMenu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowPdfMenu(false)} />
                  <div className="absolute right-0 top-9 z-20 bg-card/95 backdrop-blur-xl border border-border/60 rounded-2xl shadow-xl overflow-hidden min-w-[190px]">
                    <button onClick={() => exportPdf("interno")} className="flex items-center gap-2.5 w-full px-4 py-3 text-sm hover:bg-muted/40 transition-colors text-left"><Lock className="h-3.5 w-3.5 text-purple-500" /><div><div className="font-medium">Interno</div><div className="text-xs text-muted-foreground">Com NIF, nº orçamento</div></div></button>
                    <div className="border-t border-border/40 mx-3" />
                    <button onClick={() => exportPdf("externo")} className="flex items-center gap-2.5 w-full px-4 py-3 text-sm hover:bg-muted/40 transition-colors text-left"><Globe className="h-3.5 w-3.5 text-blue-500" /><div><div className="font-medium">Externo</div><div className="text-xs text-muted-foreground">Para enviar ao cliente</div></div></button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border/60 shadow-sm overflow-hidden">
          {/* Info bar */}
          <div className="px-6 py-3 bg-muted/20 border-b border-border/40 flex items-center gap-6 flex-wrap">
            {[{ label:"Nº Cliente", value:q.profile?.client_number??"—" }, { label:"Nome", value:q.profile?.full_name||"—" }, { label:"Email", value:q.profile?.email||"—" }, { label:"NIF", value:q.profile?.nif||"—" }].map(f => (
              <div key={f.label} className="flex items-center gap-2"><span className="text-[11px] text-muted-foreground">{f.label}</span><span className="text-sm font-medium">{f.value}</span></div>
            ))}
            <div className="ml-auto text-[11px] text-muted-foreground">
              {q.submitted_at ? `Submetido: ${format(new Date(q.submitted_at),"dd/MM/yyyy HH:mm",{locale:pt})}` : `Atualizado: ${format(new Date(q.updated_at),"dd/MM/yyyy HH:mm",{locale:pt})}`}
            </div>
          </div>

          {/* Banner orçamento */}
          {orcamento?.total && (
            <div className="mx-6 mt-5 bg-emerald-50 border border-emerald-200/60 rounded-2xl px-5 py-3.5 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-emerald-700">Orçamento lançado · <strong>{fmt(orcamento.total)} €</strong></p>
                  <p className="text-xs text-emerald-600">
                    {orcamento.criado_em && format(new Date(orcamento.criado_em),"dd/MM/yyyy 'às' HH:mm")}
                    {(localQ as any).email_enviado_em && <span className="ml-2">· Email enviado em {format(new Date((localQ as any).email_enviado_em),"dd/MM HH:mm")}</span>}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                {status === "aprovado" && localQ.profile?.email && (
                  <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl gap-1.5 border-primary/30 text-primary hover:bg-primary/5" onClick={() => setShowEmailModal(true)}>
                    <Mail className="h-3 w-3" /> {(localQ as any).email_enviado_em ? "Reenviar" : "Notificar"}
                  </Button>
                )}
                <Button size="sm" variant="outline" className="h-8 text-xs rounded-xl border-emerald-300 text-emerald-700 hover:bg-emerald-100" onClick={() => setSubPage("lancamento")}>
                  <Pencil className="h-3 w-3 mr-1" /> {status === "aprovado" ? "Ver" : "Editar"}
                </Button>
              </div>
            </div>
          )}

          <GestãoPagamento q={localQ} onSaved={() => { onSaved(); supabase.from("questionnaires").select("*").eq("id",q.id).maybeSingle().then(({data}) => { if(data) setLocalQ({...data,profile:localQ.profile}); }); }} />

          {editing && (
            <div className="mx-6 mt-5 bg-amber-50 border border-amber-200/60 rounded-2xl px-5 py-3 flex items-center gap-2.5">
              <Pencil className="h-3.5 w-3.5 text-amber-600" />
              <span className="text-sm text-amber-700 font-medium">Modo de edição ativo — guarda antes de sair.</span>
            </div>
          )}

          <div className="p-6 space-y-8">
            {QUESTIONNAIRE_SECTIONS.map(section => (
              <div key={section.id}>
                <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4 pb-1.5 border-b border-border/40">{section.title}</div>
                <div className="grid md:grid-cols-2 gap-x-12 gap-y-4">
                  {section.fields.filter(f => f.type !== "static").map(field => (
                    <div key={field.id} className={field.type === "textarea" ? "md:col-span-2" : ""}>
                      <label className="text-xs font-medium text-muted-foreground mb-1.5 block uppercase tracking-wide">{field.label}</label>
                      <FieldEditor field={field} value={answers[field.id]} onChange={v => setField(field.id, v)} readOnly={!editing} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {editing && (
            <div className="px-6 py-4 border-t border-border/40 bg-muted/10 flex gap-3">
              <Button className="bg-gradient-gold h-10 rounded-xl" disabled={saving} onClick={() => { save(); setEditing(false); }}><Save className="h-4 w-4 mr-2" />{saving ? "A guardar..." : "Guardar Alterações"}</Button>
              <Button variant="outline" className="h-10 rounded-xl" onClick={() => { setEditing(false); setAnswers(q.answers??{}); setDirty(false); }}><X className="h-4 w-4 mr-2" /> Cancelar</Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

// ─── AdminQuestionarios — Lista principal Apple style ─────────────────────────
const AdminQuestionarios = () => {
  const [items,    setItems]    = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [search,   setSearch]   = useState("");
  const [filterStatus, setFilterStatus] = useState("todos");

  const load = useCallback(async () => {
    const { data: qs } = await supabase.from("questionnaires").select("*").order("updated_at", { ascending: false });
    const ids = Array.from(new Set((qs ?? []).map(q => q.client_id)));
    const { data: profs } = ids.length ? await supabase.from("profiles").select("id, full_name, email, client_number, nif").in("id", ids) : { data: [] as any[] };
    const map = Object.fromEntries((profs ?? []).map((p: any) => [p.id, p]));
    setItems((qs ?? []).map(q => ({ ...q, profile: map[q.client_id] })));
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const ch = supabase.channel("questionnaires-list").on("postgres_changes", { event:"*", schema:"public", table:"questionnaires" }, () => load()).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [load]);

  const itensFiltrados = items.filter(q => {
    const matchSearch = search === "" || q.reference_number?.toLowerCase().includes(search.toLowerCase()) || q.profile?.full_name?.toLowerCase().includes(search.toLowerCase()) || q.profile?.email?.toLowerCase().includes(search.toLowerCase()) || String(q.profile?.client_number ?? "").includes(search);
    const matchStatus = filterStatus === "todos" || q.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const counts = items.reduce((acc, q) => { acc[q.status] = (acc[q.status] || 0) + 1; return acc; }, {} as Record<string,number>);

  if (selected) return <OrcamentoDetalhe q={selected} onBack={() => { setSelected(null); load(); }} onSaved={() => load()} />;

  return (
    <div className="space-y-5">
      <PageHeader title="Orçamentos" description="Respostas e orçamentos dos clientes" />

      {/* Stats pills */}
      <div className="flex flex-wrap gap-2">
        {[
          { key:"todos",    label:"Todos",     count: items.length },
          { key:"submetido",label:"Submetidos",count: counts.submetido||0, color:"bg-emerald-100 text-emerald-700" },
          { key:"aprovado", label:"Aprovados", count: counts.aprovado||0,  color:"bg-emerald-100 text-emerald-700" },
          { key:"pendente", label:"Pendentes", count: counts.pendente||0,  color:"bg-amber-100 text-amber-700"     },
          { key:"rascunho", label:"Rascunhos", count: counts.rascunho||0,  color:"bg-blue-100 text-blue-700"       },
          { key:"rejeitado",label:"Rejeitados",count: counts.rejeitado||0, color:"bg-red-100 text-red-700"         },
        ].map(f => (
          <button key={f.key} onClick={() => setFilterStatus(f.key)}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full border text-xs font-medium transition-all ${filterStatus === f.key ? "bg-primary text-primary-foreground border-primary shadow-sm" : "bg-card border-border/60 text-muted-foreground hover:border-border hover:text-foreground"}`}>
            {f.label}
            <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${filterStatus === f.key ? "bg-primary-foreground/20" : (f.color ?? "bg-muted")}`}>{f.count}</span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Pesquisar por referência, cliente ou nº…" value={search} onChange={e => setSearch(e.target.value)}
            className="pl-10 h-9 rounded-xl border-border/60 bg-card" />
        </div>
        <span className="text-xs text-muted-foreground">{itensFiltrados.length} orçamento{itensFiltrados.length !== 1 ? "s" : ""}</span>
      </div>

      {/* Lista Apple — cards em vez de tabela */}
      <div className="space-y-2">
        {itensFiltrados.length === 0 ? (
          <div className="bg-card rounded-2xl border border-border/60 p-16 text-center">
            <div className="h-14 w-14 rounded-2xl bg-muted/40 flex items-center justify-center mx-auto mb-4">
              <FileText className="h-7 w-7 text-muted-foreground/30" />
            </div>
            <p className="text-sm font-medium text-muted-foreground">{search || filterStatus !== "todos" ? "Sem resultados para os filtros aplicados." : "Sem orçamentos."}</p>
          </div>
        ) : itensFiltrados.map(q => {
          const orcamento = (() => { try { const o = typeof q.orcamento==="string"?JSON.parse(q.orcamento):q.orcamento; return o??null; } catch { return null; } })();
          return (
            <div key={q.id} onClick={() => setSelected(q)}
              className="group bg-card rounded-2xl border border-border/60 hover:border-border hover:shadow-[0_4px_20px_rgba(0,0,0,0.06)] hover:-translate-y-0.5 transition-all duration-200 cursor-pointer overflow-hidden">
              <div className="flex items-center gap-4 px-5 py-4">
                {/* Icon */}
                <div className="h-11 w-11 rounded-xl bg-muted/40 flex items-center justify-center shrink-0 group-hover:bg-primary/5 transition-colors">
                  <FileText className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>

                {/* Info principal */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-semibold text-primary text-sm">{q.reference_number || "—"}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium capitalize ${statusColor[q.status] ?? "bg-muted text-muted-foreground"}`}>{q.status}</span>
                    {q.status === "aprovado" && q.estado_pagamento && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium border ${pagamentoColor[q.estado_pagamento] ?? ""}`}>{pagamentoLabel[q.estado_pagamento]}</span>
                    )}
                  </div>
                  <p className="text-sm font-medium text-foreground mt-0.5">{q.profile?.full_name || q.profile?.email || "—"}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    Nº {q.profile?.client_number ?? "—"} · Atualizado {format(new Date(q.updated_at),"dd/MM/yyyy HH:mm",{locale:pt})}
                    {q.submitted_at && ` · Submetido ${format(new Date(q.submitted_at),"dd/MM/yyyy",{locale:pt})}`}
                  </p>
                </div>

                {/* Valor + email status */}
                <div className="flex items-center gap-4 shrink-0">
                  {orcamento?.total && (
                    <div className="text-right hidden sm:block">
                      <p className="text-lg font-black text-primary">{fmt(orcamento.total)} €</p>
                      <p className="text-[10px] text-muted-foreground">Orçamento lançado</p>
                    </div>
                  )}
                  {q.status === "aprovado" && q.orcamento && q.profile?.email && (
                    <div className={`flex items-center gap-1.5 text-[11px] font-medium ${(q as any).email_enviado_em ? "text-emerald-600" : "text-muted-foreground/60"}`}>
                      <Mail className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">{(q as any).email_enviado_em ? "Enviado" : "Pendente"}</span>
                    </div>
                  )}
                  <ChevronRight className="h-4 w-4 text-muted-foreground/30 group-hover:text-primary/40 transition-colors" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AdminQuestionarios;
