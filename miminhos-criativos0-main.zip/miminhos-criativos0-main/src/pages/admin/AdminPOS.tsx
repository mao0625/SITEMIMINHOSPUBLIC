import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { pt } from "date-fns/locale";
import {
  ShoppingCart, Plus, Trash2, ArrowLeft, CheckCircle2,
  Euro, Settings, ToggleLeft, ToggleRight, Package, Receipt,
  Search, Banknote, CreditCard, Star, Percent,
  Loader2, Clock, Sparkles, PartyPopper,
  Flower2, Palette, Box, Music, Utensils, Camera,
  RefreshCw, TrendingUp, Hash, XCircle, Ban, Gift,
  FileSpreadsheet, BarChart3, Printer, FileText,
  AlertCircle, BadgePercent,
} from "lucide-react";
import { NovaOperacao } from "./NovaOperacao";

const ADMIN_EMAIL = "mao0625@outlook.pt";
const DEFAULT_SETTINGS = { loyalty_enabled: false, invoice_enabled: false };

// ─── Paleta — usa a mesma do NovaOperacao ─────────────────────────────────────
const P = {
  bg:        "#faf6f0",
  bgCard:    "#ffffff",
  bgSurf:    "#f5ede0",
  bgAccent:  "#ede0cc",
  bgDark:    "#3d2b1f",
  bgDarkHov: "#2e1f15",
  bgMid:     "#7a5c45",
  text:      "#1e1008",
  textSub:   "#5c3d28",
  textMuted: "#9a7258",
  textHint:  "#c4a882",
  border:    "#e8d5bc",
  borderMed: "#d4b896",
  gold:      "#c9a84c",
  goldL:     "#fdf5dc",
  goldB:     "#f0dfa0",
  green:     "#2d6a4f",
  greenL:    "#d8f3dc",
  amber:     "#b5680a",
  amberL:    "#fff0c7",
  amberB:    "#fcd34d",
  red:       "#9b2226",
  redL:      "#ffebed",
  blue:      "#1d4e89",
  blueL:     "#dbeafe",
};

const PAYMENT_STATUS = {
  pago:          { label:"Pago",          color:P.green, bg:P.greenL, border:`${P.green}40`, icon:CheckCircle2 },
  por_pagar:     { label:"Por Pagar",     color:P.amber, bg:P.amberL, border:`${P.amber}40`, icon:Clock        },
  em_pagamento:  { label:"Em Pagamento",  color:P.blue,  bg:P.blueL,  border:`${P.blue}40`,  icon:Euro         },
  nao_realizado: { label:"Não Realizado", color:P.red,   bg:P.redL,   border:`${P.red}40`,   icon:XCircle      },
  nao_atribuido: { label:"Não Atribuído", color:P.textMuted, bg:P.bgSurf, border:P.border,   icon:Ban          },
};

const EVENT_CATEGORIES = [
  { key:"decoracao",      label:"Decoração",     icon:Flower2,     color:"#7c3aed", bg:"#f5f3ff" },
  { key:"animacao",       label:"Animação",       icon:PartyPopper, color:"#be185d", bg:"#fdf2f8" },
  { key:"fotografia",     label:"Fotografia",     icon:Camera,      color:"#0e7490", bg:"#ecfeff" },
  { key:"catering",       label:"Catering",       icon:Utensils,    color:"#2d6a4f", bg:"#d8f3dc" },
  { key:"som_luz",        label:"Som & Luz",      icon:Music,       color:"#7c3aed", bg:"#f5f3ff" },
  { key:"materiais",      label:"Materiais",      icon:Box,         color:"#92400e", bg:"#fef3c7" },
  { key:"personalizados", label:"Personalizados", icon:Palette,     color:"#be185d", bg:"#fdf2f8" },
  { key:"baloes",         label:"Balões",         icon:Sparkles,    color:"#0369a1", bg:"#e0f2fe" },
  { key:"festas",         label:"Festas",         icon:Gift,        color:"#991b1b", bg:"#fee2e2" },
  { key:"outros",         label:"Outros",         icon:Package,     color:P.textMuted, bg:P.bgSurf },
];

const isPending = (s?: string | null) => !s || s === "por_pagar" || s === "em_pagamento";
const fmt = (n: number) => n.toLocaleString("pt-PT", { minimumFractionDigits:2, maximumFractionDigits:2 });

// ─── Primitivos de UI ──────────────────────────────────────────────────────────
const card        = { borderRadius:14, border:`1px solid ${P.border}`, background:P.bgCard, overflow:"hidden" as const };
const inp         = { height:34, fontSize:12, borderRadius:8, padding:"0 10px", border:`1px solid ${P.border}`, background:P.bgCard, color:P.text, outline:"none" } as any;
const sectionHdr  = { padding:"12px 18px", borderBottom:`1px solid ${P.border}`, background:P.bgSurf, display:"flex" as const, alignItems:"center" as const, justifyContent:"space-between" as const };

const PaymentBadge = ({ status }: { status: string }) => {
  const cfg = PAYMENT_STATUS[status as keyof typeof PAYMENT_STATUS] ?? PAYMENT_STATUS.por_pagar;
  const Icon = cfg.icon;
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:4, fontSize:11, fontWeight:700, padding:"3px 9px", borderRadius:20, background:cfg.bg, color:cfg.color, border:`1px solid ${cfg.border}` }}>
      <Icon size={10} />{cfg.label}
    </span>
  );
};

// ─── ExportacoesMensais ────────────────────────────────────────────────────────
const ExportacoesMensais = ({ operations, isAdmin, onBack }: { operations: any[]; isAdmin: boolean; onBack: () => void }) => {
  const [selectedMonth, setSelectedMonth] = useState(() => format(new Date(), "yyyy-MM"));
  const [filterStatus,  setFilterStatus]  = useState("todos");

  const months = Array.from({ length:12 }, (_,i) => {
    const d = subMonths(new Date(), i);
    return { value: format(d,"yyyy-MM"), label: format(d,"MMMM yyyy",{locale:pt}) };
  });

  const [year, month] = selectedMonth.split("-").map(Number);
  const periodStart = startOfMonth(new Date(year, month-1));
  const periodEnd   = endOfMonth(new Date(year, month-1));
  const periodOps   = operations.filter(o => {
    const d = new Date(o.created_at);
    return d >= periodStart && d <= periodEnd && (filterStatus==="todos" || o.payment_status===filterStatus);
  });

  const totalFaturado = periodOps.reduce((s,o) => s+(o.total||0), 0);
  const totalPago     = periodOps.filter(o => o.payment_status==="pago").reduce((s,o) => s+(o.total||0), 0);
  const totalPorPagar = periodOps.filter(o => o.payment_status==="por_pagar").reduce((s,o) => s+(o.total||0), 0);
  const totalNaoReal  = periodOps.filter(o => o.payment_status==="nao_realizado").reduce((s,o) => s+(o.total||0), 0);
  const byMethod = ["dinheiro","cartao","transferencia","mbway"].map(m => ({
    method:m, count:periodOps.filter(o=>o.payment_method===m).length,
    total:periodOps.filter(o=>o.payment_method===m).reduce((s,o)=>s+(o.total||0),0),
  })).filter(m => m.count > 0);

  const exportCSV = () => {
    const headers = ["Nº Operação","Data","Cliente","Total","Método","Estado","Desconto","Fidelização"];
    const rows = periodOps.map(o => [
      o.operation_number, format(new Date(o.created_at),"dd/MM/yyyy HH:mm"),
      o.client_name||"—", Number(o.total).toFixed(2), o.payment_method,
      PAYMENT_STATUS[o.payment_status as keyof typeof PAYMENT_STATUS]?.label??o.payment_status,
      Number(o.discount_value||0).toFixed(2), Number(o.loyalty_discount||0).toFixed(2),
    ]);
    const csv = [headers,...rows].map(r=>r.join(";")).join("\n");
    const blob = new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href=url; a.download=`pos_${selectedMonth}.csv`; a.click();
    URL.revokeObjectURL(url); toast.success("CSV exportado!");
  };

  const exportPDF = () => {
    const win = window.open("","_blank"); if (!win) return;
    win.document.write(`<!DOCTYPE html><html lang="pt"><head><meta charset="UTF-8"><title>Relatório POS</title>
    <style>body{font-family:Georgia,serif;padding:40px;color:#1e1008;background:#faf6f0;font-size:13px}
    h1{font-size:20px;font-weight:700;border-bottom:2px solid #c9a84c;padding-bottom:10px;margin-bottom:4px;color:#1e1008}
    .sub{color:#9a7258;font-size:12px;margin-bottom:24px}
    .kpi{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:20px 0}
    .kpi-box{border:1px solid #e8d5bc;border-radius:10px;padding:14px;background:#f5ede0}
    .kpi-label{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#9a7258}
    .kpi-value{font-size:24px;font-weight:700;margin-top:6px;color:#1e1008}
    .green{color:#2d6a4f}.amber{color:#b5680a}
    h2{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:#9a7258;margin:24px 0 10px}
    table{width:100%;border-collapse:collapse;font-size:12px}
    th{padding:8px 12px;text-align:left;border-bottom:2px solid #e8d5bc;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:#9a7258}
    td{padding:8px 12px;border-bottom:1px solid #f5ede0}
    .mono{font-family:monospace;font-weight:700;color:#c9a84c}
    .badge{display:inline-block;padding:2px 10px;border-radius:999px;font-size:10px;font-weight:600}
    .pago{background:#d8f3dc;color:#2d6a4f}.por_pagar{background:#fff0c7;color:#b5680a}
    .nao_realizado{background:#ffebed;color:#9b2226}.em_pagamento{background:#dbeafe;color:#1d4e89}
    .total-row td{font-weight:700;border-top:2px solid #c9a84c;background:#f5ede0}
    </style></head><body>
    <h1>Relatório POS — Miminhos Criativos</h1>
    <p class="sub">${format(periodStart,"MMMM yyyy",{locale:pt})} · Gerado em ${format(new Date(),"dd/MM/yyyy 'às' HH:mm")}</p>
    <div class="kpi">
      <div class="kpi-box"><div class="kpi-label">Operações</div><div class="kpi-value">${periodOps.length}</div></div>
      <div class="kpi-box"><div class="kpi-label">Faturado</div><div class="kpi-value">${fmt(totalFaturado)}€</div></div>
      <div class="kpi-box"><div class="kpi-label">Recebido</div><div class="kpi-value green">${fmt(totalPago)}€</div></div>
      <div class="kpi-box"><div class="kpi-label">Por Cobrar</div><div class="kpi-value amber">${fmt(totalPorPagar)}€</div></div>
    </div>
    <h2>Por Método</h2>
    <table><tr><th>Método</th><th>Operações</th><th>Total</th><th>%</th></tr>
    ${byMethod.map(m=>`<tr><td style="text-transform:capitalize;font-weight:500">${m.method}</td><td>${m.count}</td><td style="font-weight:700">${fmt(m.total)}€</td><td>${totalFaturado>0?((m.total/totalFaturado)*100).toFixed(1):0}%</td></tr>`).join("")}
    </table>
    <h2>Operações (${periodOps.length})</h2>
    <table><tr><th>Nº</th><th>Data</th><th>Cliente</th><th>Total</th><th>Método</th><th>Estado</th></tr>
    ${periodOps.map(o=>`<tr><td class="mono">${o.operation_number}</td><td>${format(new Date(o.created_at),"dd/MM/yy HH:mm")}</td><td>${o.client_name||"—"}</td><td style="font-weight:700">${fmt(Number(o.total))}€</td><td style="text-transform:capitalize">${o.payment_method}</td><td><span class="badge ${o.payment_status}">${PAYMENT_STATUS[o.payment_status as keyof typeof PAYMENT_STATUS]?.label??o.payment_status}</span></td></tr>`).join("")}
    <tr class="total-row"><td colspan="3">TOTAL DO PERÍODO</td><td>${fmt(totalFaturado)}€</td><td colspan="2"></td></tr></table>
    <script>window.onload=()=>{window.print()};window.onafterprint=()=>{window.close()}</script>
    </body></html>`);
    win.document.close();
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16, fontFamily:"inherit" }}>
      {/* Header */}
      <div style={{ ...card, padding:"14px 18px", display:"flex", alignItems:"center", gap:12 }}>
        <button onClick={onBack} style={{ display:"flex",alignItems:"center",gap:6,fontSize:13,fontWeight:600,background:"none",border:"none",color:P.gold,cursor:"pointer",padding:0 }}>
          <ArrowLeft size={15} />POS
        </button>
        <div style={{ width:1,height:18,background:P.border }} />
        <div style={{ width:34,height:34,borderRadius:10,background:P.bgDark,display:"flex",alignItems:"center",justifyContent:"center" }}>
          <BarChart3 size={15} color="#f5e6d3" />
        </div>
        <div>
          <p style={{ margin:0,fontSize:14,fontWeight:800,color:P.text }}>Exportações e Relatórios</p>
          <p style={{ margin:0,fontSize:11,color:P.textMuted }}>Análise e exportação de operações por período</p>
        </div>
      </div>

      {/* Filtros */}
      <div style={{ ...card, padding:18 }}>
        <div style={{ display:"flex",flexWrap:"wrap",gap:14,alignItems:"flex-end" }}>
          <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
            <label style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textMuted }}>Mês</label>
            <select value={selectedMonth} onChange={e=>setSelectedMonth(e.target.value)} style={{ ...inp,minWidth:180,textTransform:"capitalize" }}>
              {months.map(m=><option key={m.value} value={m.value} style={{textTransform:"capitalize"}}>{m.label}</option>)}
            </select>
          </div>
          <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
            <label style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textMuted }}>Estado</label>
            <select value={filterStatus} onChange={e=>setFilterStatus(e.target.value)} style={inp}>
              <option value="todos">Todos os estados</option>
              {Object.entries(PAYMENT_STATUS).map(([k,v])=><option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div style={{ display:"flex",gap:8,marginLeft:"auto" }}>
            <button onClick={exportCSV} disabled={periodOps.length===0}
              style={{ display:"flex",alignItems:"center",gap:6,height:36,padding:"0 16px",borderRadius:9,border:`1px solid ${P.border}`,background:P.bgSurf,color:P.textSub,fontSize:12,fontWeight:600,cursor:periodOps.length===0?"not-allowed":"pointer",opacity:periodOps.length===0?.4:1,transition:"all .15s" }}
              onMouseEnter={e=>{if(periodOps.length)(e.currentTarget as HTMLElement).style.borderColor=P.gold;}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.borderColor=P.border;}}>
              <FileSpreadsheet size={13} />CSV
            </button>
            {isAdmin && (
              <button onClick={exportPDF} disabled={periodOps.length===0}
                style={{ display:"flex",alignItems:"center",gap:6,height:36,padding:"0 16px",borderRadius:9,border:"none",background:P.bgDark,color:"#f5e6d3",fontSize:12,fontWeight:700,cursor:periodOps.length===0?"not-allowed":"pointer",opacity:periodOps.length===0?.4:1,transition:"opacity .15s",boxShadow:"0 3px 10px rgba(61,43,31,.25)" }}
                onMouseEnter={e=>{if(periodOps.length)(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
                <Printer size={13} />PDF / Imprimir
              </button>
            )}
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:12 }}>
        {[
          { label:"Operações",  value:String(periodOps.length).padStart(2,"0"), suffix:"",  color:P.gold,  barColor:P.gold,  icon:Hash         },
          { label:"Faturado",   value:fmt(totalFaturado),                       suffix:"€", color:P.text,  barColor:P.border,icon:TrendingUp   },
          { label:"Recebido",   value:fmt(totalPago),                           suffix:"€", color:P.green, barColor:P.green, icon:CheckCircle2 },
          { label:"Por Cobrar", value:fmt(totalPorPagar),                       suffix:"€", color:totalPorPagar>0?P.amber:P.textMuted, barColor:totalPorPagar>0?P.amber:P.border, icon:Clock },
        ].map(s => { const Icon = s.icon; return (
          <div key={s.label} style={{ ...card }}>
            <div style={{ height:3, background:s.barColor }} />
            <div style={{ padding:"16px 18px" }}>
              <div style={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:10 }}>
                <p style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textMuted,margin:0 }}>{s.label}</p>
                <Icon size={14} color={s.barColor} style={{ opacity:.4 }} />
              </div>
              <p style={{ fontSize:26,fontWeight:800,color:s.color,margin:0,lineHeight:1,fontVariantNumeric:"tabular-nums" }}>
                {s.value}<span style={{ fontSize:14,fontWeight:500,color:P.textMuted,marginLeft:3 }}>{s.suffix}</span>
              </p>
            </div>
          </div>
        ); })}
      </div>

      {/* Charts */}
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:14 }}>
        <div style={{ ...card }}>
          <div style={{ ...sectionHdr }}>
            <div style={{ display:"flex",alignItems:"center",gap:8 }}>
              <CreditCard size={13} color={P.gold} />
              <span style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",color:P.textMuted }}>Por Método de Pagamento</span>
            </div>
          </div>
          {byMethod.length===0
            ? <p style={{ textAlign:"center",padding:"36px 0",fontSize:12,color:P.textHint,margin:0 }}>Sem dados no período.</p>
            : byMethod.map(m => { const pct = totalFaturado>0?(m.total/totalFaturado)*100:0; return (
              <div key={m.method} style={{ padding:"12px 18px",borderBottom:`1px solid ${P.border}` }}>
                <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8 }}>
                  <span style={{ fontSize:13,fontWeight:500,color:P.text,textTransform:"capitalize" }}>{m.method}</span>
                  <span style={{ fontSize:13,fontWeight:700,color:P.gold }}>{fmt(m.total)}€</span>
                </div>
                <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                  <div style={{ flex:1,height:5,borderRadius:3,background:P.bgSurf,overflow:"hidden" }}>
                    <div style={{ height:"100%",borderRadius:3,background:P.gold,width:`${pct}%`,transition:"width .4s" }} />
                  </div>
                  <span style={{ fontSize:10,color:P.textHint,flexShrink:0,width:60,textAlign:"right" }}>{m.count} op · {pct.toFixed(0)}%</span>
                </div>
              </div>
            ); })
          }
        </div>

        <div style={{ ...card }}>
          <div style={{ ...sectionHdr }}>
            <div style={{ display:"flex",alignItems:"center",gap:8 }}>
              <AlertCircle size={13} color={P.amber} />
              <span style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",color:P.textMuted }}>Cobranças Pendentes</span>
            </div>
            {totalPorPagar>0 && (
              <span style={{ fontSize:10,fontWeight:700,padding:"3px 10px",borderRadius:20,background:P.amberL,border:`1px solid ${P.amberB}50`,color:P.amber }}>{fmt(totalPorPagar)}€</span>
            )}
          </div>
          {periodOps.filter(o=>isPending(o.payment_status)).length===0
            ? <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"40px 0",gap:8,color:P.green }}>
                <CheckCircle2 size={28} style={{ opacity:.5 }} />
                <p style={{ fontSize:13,margin:0,fontWeight:600 }}>Sem cobranças pendentes!</p>
              </div>
            : periodOps.filter(o=>isPending(o.payment_status)).map(o => (
              <div key={o.id} style={{ display:"flex",alignItems:"center",gap:10,padding:"10px 18px",borderBottom:`1px solid ${P.border}`,transition:"background .15s" }}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgSurf;}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>
                <div style={{ flex:1,minWidth:0 }}>
                  <p style={{ fontSize:13,fontWeight:500,color:P.text,margin:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{o.client_name}</p>
                  <p style={{ fontSize:10,color:P.textHint,margin:0 }}>{o.operation_number} · {format(new Date(o.created_at),"dd/MM/yyyy")}</p>
                </div>
                <PaymentBadge status={o.payment_status} />
                <span style={{ fontSize:13,fontWeight:700,color:P.amber,flexShrink:0 }}>{fmt(Number(o.total))}€</span>
              </div>
            ))
          }
          {totalNaoReal>0 && (
            <div style={{ padding:"10px 18px",borderTop:`1px solid ${P.red}30`,background:P.redL,display:"flex",alignItems:"center",gap:6 }}>
              <XCircle size={13} color={P.red} style={{ flexShrink:0 }} />
              <p style={{ fontSize:11,color:P.red,margin:0 }}>{fmt(totalNaoReal)}€ em operações não realizadas no período</p>
            </div>
          )}
        </div>
      </div>

      {/* Tabela de operações */}
      <div style={{ ...card }}>
        <div style={{ ...sectionHdr }}>
          <div style={{ display:"flex",alignItems:"center",gap:8 }}>
            <FileText size={13} color={P.gold} />
            <span style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",color:P.textMuted }}>
              Operações de {format(periodStart,"MMMM yyyy",{locale:pt})} ({periodOps.length})
            </span>
          </div>
        </div>
        {periodOps.length===0
          ? <p style={{ textAlign:"center",padding:"48px 0",fontSize:13,color:P.textHint,margin:0 }}>Sem operações no período selecionado.</p>
          : <>
              <div style={{ display:"grid",gridTemplateColumns:"130px 1fr 120px 90px 110px 140px",gap:12,padding:"8px 18px",background:P.bgSurf,borderBottom:`1px solid ${P.border}` }}>
                {["Nº Op.","Cliente","Data","Total","Método","Estado"].map(h=>(
                  <span key={h} style={{ fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textHint }}>{h}</span>
                ))}
              </div>
              {periodOps.map((op,i)=>(
                <div key={op.id} style={{ display:"grid",gridTemplateColumns:"130px 1fr 120px 90px 110px 140px",gap:12,padding:"12px 18px",alignItems:"center",borderBottom:`1px solid ${P.border}`,background:i%2!==0?P.bgSurf:"transparent",transition:"background .15s" }}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgAccent;}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=i%2!==0?P.bgSurf:"transparent";}}>
                  <span style={{ fontFamily:"monospace",fontWeight:700,fontSize:12,color:P.gold,letterSpacing:".5px" }}>{op.operation_number}</span>
                  <p style={{ fontSize:12,fontWeight:500,color:P.text,margin:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{op.client_name||"—"}</p>
                  <span style={{ fontSize:11,color:P.textMuted }}>{format(new Date(op.created_at),"dd MMM yy · HH:mm",{locale:pt})}</span>
                  <span style={{ fontSize:14,fontWeight:800,color:P.green }}>{fmt(Number(op.total))}€</span>
                  <span style={{ fontSize:11,color:P.textSub,textTransform:"capitalize" }}>{op.payment_method}</span>
                  <PaymentBadge status={op.payment_status??"por_pagar"} />
                </div>
              ))}
              <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 18px",borderTop:`2px solid ${P.borderMed}`,background:P.bgSurf }}>
                <span style={{ fontSize:12,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textMuted }}>Total do Período</span>
                <span style={{ fontSize:22,fontWeight:900,color:P.text }}>{fmt(totalFaturado)}€</span>
              </div>
            </>
        }
      </div>
    </div>
  );
};

// ─── POSConfiguracoes ──────────────────────────────────────────────────────────
const POSConfiguracoes = ({ onBack, isAdmin }: { onBack: () => void; isAdmin: boolean }) => {
  const [settings,   setSettings]   = useState<any>(null);
  const [products,   setProducts]   = useState<any[]>([]);
  const [promotions, setPromotions] = useState<any[]>([]);
  const [newProduct, setNewProduct] = useState({ name:"", price:"", category:"outros" });
  const [newPromo,   setNewPromo]   = useState({ name:"", description:"", discount_type:"percent", discount_value:"" });
  const [loading,    setLoading]    = useState(true);
  const [saving,     setSaving]     = useState<string|null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data:s } = await supabase.from("pos_settings").select("*").maybeSingle();
    const [{ data:p },{ data:pr }] = await Promise.all([
      supabase.from("pos_products").select("*").order("name"),
      supabase.from("pos_promotions").select("*").order("name"),
    ]);
    setSettings(s??DEFAULT_SETTINGS); setProducts(p??[]); setPromotions(pr??[]);
    setLoading(false);
  }, []);
  useEffect(()=>{ load(); },[load]);

  const toggleSetting = async (key: string, val: boolean) => {
    if (!settings?.id) return; setSaving(key);
    await supabase.from("pos_settings").update({ [key]:val, updated_at:new Date().toISOString() } as any).eq("id",settings.id);
    setSaving(null); setSettings((s:any)=>({...s,[key]:val})); toast.success("Atualizado!");
  };
  const addProduct = async () => {
    const name=newProduct.name.trim(); const price=parseFloat(newProduct.price);
    if (!name) return toast.error("Nome obrigatório");
    if (isNaN(price)||price<0) return toast.error("Preço inválido");
    setSaving("product");
    await supabase.from("pos_products").insert({ name, price, category:newProduct.category, active:true });
    setSaving(null); setNewProduct({ name:"", price:"", category:"outros" }); toast.success("Produto adicionado!"); load();
  };
  const addPromo = async () => {
    const name=newPromo.name.trim(); const val=parseFloat(newPromo.discount_value);
    if (!name) return toast.error("Nome obrigatório");
    if (isNaN(val)||val<=0) return toast.error("Valor inválido");
    setSaving("promo");
    await supabase.from("pos_promotions").insert({ name, description:newPromo.description||null, discount_type:newPromo.discount_type, discount_value:val, active:true });
    setSaving(null); setNewPromo({ name:"", description:"", discount_type:"percent", discount_value:"" }); toast.success("Promoção criada!"); load();
  };

  if (loading) return (
    <div style={{ display:"flex",alignItems:"center",justifyContent:"center",padding:"80px 0",gap:10,color:P.textMuted }}>
      <Loader2 size={22} color={P.gold} style={{ animation:"spin 1s linear infinite" }} />
      <span style={{ fontSize:13 }}>A carregar…</span>
    </div>
  );

  const SectionWrap = ({ icon:Icon, label, right, children }: any) => (
    <div style={{ ...card }}>
      <div style={{ ...sectionHdr }}>
        <div style={{ display:"flex",alignItems:"center",gap:10 }}>
          <div style={{ width:32,height:32,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",background:P.bgDark }}>
            <Icon size={14} color="#f5e6d3" />
          </div>
          <span style={{ fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textMuted }}>{label}</span>
        </div>
        {right}
      </div>
      {children}
    </div>
  );

  return (
    <div style={{ display:"flex",flexDirection:"column",gap:16,fontFamily:"inherit" }}>
      <div style={{ ...card, padding:"14px 18px", display:"flex", alignItems:"center", gap:12 }}>
        <button onClick={onBack} style={{ display:"flex",alignItems:"center",gap:6,fontSize:13,fontWeight:600,background:"none",border:"none",color:P.gold,cursor:"pointer",padding:0 }}>
          <ArrowLeft size={15} />POS
        </button>
        <div style={{ width:1,height:18,background:P.border }} />
        <div style={{ width:34,height:34,borderRadius:10,background:P.bgDark,display:"flex",alignItems:"center",justifyContent:"center" }}>
          <Settings size={15} color="#f5e6d3" />
        </div>
        <div>
          <p style={{ margin:0,fontSize:14,fontWeight:800,color:P.text }}>Configurações POS</p>
          <p style={{ margin:0,fontSize:11,color:P.textMuted }}>Funcionalidades, produtos e promoções</p>
        </div>
      </div>

      {!isAdmin && (
        <div style={{ display:"flex",alignItems:"center",gap:10,padding:"12px 16px",borderRadius:10,border:`1px solid ${P.amberB}50`,background:P.amberL }}>
          <AlertCircle size={15} color={P.amber} style={{ flexShrink:0 }} />
          <p style={{ fontSize:13,color:P.amber,margin:0 }}>Funcionalidades principais só podem ser alteradas pelo administrador.</p>
        </div>
      )}

      <SectionWrap icon={Settings} label="Funcionalidades" right={!isAdmin&&<span style={{ fontSize:10,fontWeight:600,padding:"2px 10px",borderRadius:20,border:`1px solid ${P.border}`,color:P.textHint,background:P.bgSurf }}>Só Admin</span>}>
        {[
          { key:"loyalty_enabled", label:"Programa de Fidelização", desc:"Cada 10 eventos = €15 desconto automático no 10.º", icon:Star,        adminOnly:true },
          { key:"invoice_enabled", label:"Exportação de Fatura",    desc:"Gera PDF/fatura após finalizar operação",          icon:FileText,    adminOnly:true },
        ].map(f => {
          const isOn=!!settings?.[f.key]; const blocked=f.adminOnly&&!isAdmin;
          return (
            <div key={f.key} style={{ display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,padding:"14px 18px",borderBottom:`1px solid ${P.border}`,opacity:blocked?.35:1,pointerEvents:blocked?"none":"auto",transition:"background .15s" }}
              onMouseEnter={e=>{if(!blocked)(e.currentTarget as HTMLElement).style.background=P.bgSurf;}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>
              <div style={{ display:"flex",alignItems:"flex-start",gap:12 }}>
                <f.icon size={16} color={isOn?P.gold:P.textHint} style={{ marginTop:2,flexShrink:0 }} />
                <div>
                  <p style={{ fontSize:14,fontWeight:500,color:P.text,margin:0 }}>{f.label}</p>
                  <p style={{ fontSize:12,color:P.textMuted,margin:"3px 0 0" }}>{f.desc}</p>
                </div>
              </div>
              <button onClick={()=>!blocked&&toggleSetting(f.key,!isOn)} disabled={saving===f.key||blocked} style={{ border:"none",background:"none",cursor:"pointer",padding:0,flexShrink:0 }}>
                {saving===f.key
                  ? <Loader2 size={28} color={P.gold} style={{ animation:"spin 1s linear infinite" }} />
                  : isOn
                    ? <ToggleRight size={34} color={P.gold} />
                    : <ToggleLeft  size={34} color={P.textHint} />
                }
              </button>
            </div>
          );
        })}
      </SectionWrap>

      <SectionWrap icon={Package} label="Catálogo de Produtos" right={<span style={{ fontSize:11,fontWeight:600,color:P.textMuted,padding:"2px 10px",borderRadius:20,border:`1px solid ${P.border}`,background:P.bgSurf }}>{products.length} produto(s)</span>}>
        <div style={{ padding:"12px 16px",borderBottom:`1px solid ${P.border}`,display:"flex",gap:8,flexWrap:"wrap",background:P.bgSurf }}>
          <input value={newProduct.name} onChange={e=>setNewProduct(p=>({...p,name:e.target.value}))} placeholder="Nome do produto…" style={{ ...inp,flex:1,minWidth:140 }} />
          <select value={newProduct.category} onChange={e=>setNewProduct(p=>({...p,category:e.target.value}))} style={{ ...inp,padding:"0 8px" }}>
            {EVENT_CATEGORIES.map(c=><option key={c.key} value={c.key}>{c.label}</option>)}
          </select>
          <div style={{ position:"relative",width:100 }}>
            <span style={{ position:"absolute",left:9,top:"50%",transform:"translateY(-50%)",fontSize:12,color:P.textHint }}>€</span>
            <input type="number" step="0.01" min="0" value={newProduct.price} onChange={e=>setNewProduct(p=>({...p,price:e.target.value}))} placeholder="0.00" style={{ ...inp,width:"100%",paddingLeft:22,paddingRight:6,boxSizing:"border-box" }} />
          </div>
          <button onClick={addProduct} disabled={saving==="product"}
            style={{ height:34,padding:"0 16px",borderRadius:8,border:"none",background:P.bgDark,color:"#f5e6d3",fontSize:12,fontWeight:700,cursor:saving==="product"?"not-allowed":"pointer",display:"flex",alignItems:"center",gap:6,transition:"background .15s" }}
            onMouseEnter={e=>{if(saving!=="product")(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
            {saving==="product"?<Loader2 size={12} style={{ animation:"spin 1s linear infinite" }} />:<><Plus size={12} />Adicionar</>}
          </button>
        </div>
        <div style={{ maxHeight:260,overflowY:"auto" }}>
          {products.length===0 && <p style={{ textAlign:"center",padding:"32px 0",fontSize:12,color:P.textHint,margin:0 }}>Nenhum produto ainda.</p>}
          {products.map(p=>{
            const cat=EVENT_CATEGORIES.find(c=>c.key===p.category); const CatIcon=cat?.icon??Package;
            return (
              <div key={p.id} style={{ display:"flex",alignItems:"center",gap:12,padding:"10px 18px",borderBottom:`1px solid ${P.border}`,transition:"background .15s" }}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgSurf;}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>
                <div style={{ width:30,height:30,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",background:cat?.bg??P.bgSurf,border:`1.5px solid ${P.border}`,flexShrink:0 }}>
                  <CatIcon size={13} color={cat?.color??P.textMuted} />
                </div>
                <span style={{ fontSize:13,fontWeight:500,flex:1,color:P.text }}>{p.name}</span>
                {cat && <span style={{ fontSize:10,color:P.textHint,background:P.bgSurf,padding:"2px 8px",borderRadius:20,border:`1px solid ${P.border}` }}>{cat.label}</span>}
                <span style={{ fontSize:13,fontWeight:800,color:P.gold }}>{Number(p.price).toFixed(2)}€</span>
                <button onClick={async()=>{if(!confirm(`Remover "${p.name}"?`))return;await supabase.from("pos_products").delete().eq("id",p.id);load();}}
                  style={{ border:"none",background:"transparent",cursor:"pointer",color:P.border,padding:"4px",borderRadius:6,transition:"all .15s",display:"flex" }}
                  onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.color=P.red;el.style.background=P.redL;}}
                  onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.color=P.border;el.style.background="transparent";}}>
                  <Trash2 size={13} />
                </button>
              </div>
            );
          })}
        </div>
      </SectionWrap>

      {isAdmin && (
        <SectionWrap icon={BadgePercent} label="Promoções" right={<span style={{ fontSize:11,fontWeight:600,color:P.textMuted,padding:"2px 10px",borderRadius:20,border:`1px solid ${P.border}`,background:P.bgSurf }}>{promotions.filter(p=>p.active).length} ativa(s)</span>}>
          <div style={{ padding:"12px 16px",borderBottom:`1px solid ${P.border}`,background:P.bgSurf }}>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
              <input value={newPromo.name} onChange={e=>setNewPromo(p=>({...p,name:e.target.value}))} placeholder="Nome da promoção…" style={inp} />
              <input value={newPromo.description} onChange={e=>setNewPromo(p=>({...p,description:e.target.value}))} placeholder="Descrição (opcional)…" style={inp} />
              <select value={newPromo.discount_type} onChange={e=>setNewPromo(p=>({...p,discount_type:e.target.value}))} style={{ ...inp,padding:"0 8px" }}>
                <option value="percent">Percentagem (%)</option>
                <option value="fixed">Valor fixo (€)</option>
              </select>
              <div style={{ display:"flex",gap:8 }}>
                <div style={{ position:"relative",flex:1 }}>
                  <span style={{ position:"absolute",left:9,top:"50%",transform:"translateY(-50%)",fontSize:12,color:P.textHint }}>{newPromo.discount_type==="percent"?"%":"€"}</span>
                  <input type="number" step="0.01" min="0" value={newPromo.discount_value} onChange={e=>setNewPromo(p=>({...p,discount_value:e.target.value}))} placeholder="0" style={{ ...inp,width:"100%",paddingLeft:22,paddingRight:6,boxSizing:"border-box" }} />
                </div>
                <button onClick={addPromo} disabled={saving==="promo"}
                  style={{ height:34,padding:"0 16px",borderRadius:8,border:"none",background:P.bgDark,color:"#f5e6d3",fontSize:12,fontWeight:700,cursor:saving==="promo"?"not-allowed":"pointer",display:"flex",alignItems:"center",gap:6,flexShrink:0,transition:"background .15s" }}
                  onMouseEnter={e=>{if(saving!=="promo")(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
                  {saving==="promo"?<Loader2 size={12} style={{ animation:"spin 1s linear infinite" }} />:<><Plus size={12} />Criar</>}
                </button>
              </div>
            </div>
          </div>
          <div>
            {promotions.length===0 && <p style={{ textAlign:"center",padding:"32px 0",fontSize:12,color:P.textHint,margin:0 }}>Nenhuma promoção criada.</p>}
            {promotions.map(p=>(
              <div key={p.id} style={{ display:"flex",alignItems:"center",gap:12,padding:"12px 18px",borderBottom:`1px solid ${P.border}`,transition:"background .15s" }}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgSurf;}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>
                <div style={{ width:30,height:30,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",background:p.active?P.goldL:P.bgSurf,border:`1.5px solid ${p.active?P.goldB:P.border}`,flexShrink:0 }}>
                  <BadgePercent size={13} color={p.active?P.gold:P.textHint} />
                </div>
                <div style={{ flex:1,minWidth:0 }}>
                  <p style={{ fontSize:13,fontWeight:600,color:P.text,margin:0 }}>{p.name}</p>
                  {p.description && <p style={{ fontSize:11,color:P.textHint,margin:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{p.description}</p>}
                </div>
                <span style={{ fontSize:13,fontWeight:800,color:P.gold }}>{p.discount_type==="percent"?`${p.discount_value}%`:`${Number(p.discount_value).toFixed(2)}€`}</span>
                <button onClick={async()=>{await supabase.from("pos_promotions").update({active:!p.active}).eq("id",p.id);load();}}
                  style={{ fontSize:10,fontWeight:700,padding:"3px 12px",borderRadius:20,border:`1.5px solid ${p.active?P.green+"40":P.border}`,background:p.active?P.greenL:P.bgSurf,color:p.active?P.green:P.textMuted,cursor:"pointer",flexShrink:0,transition:"all .15s" }}>
                  {p.active?"ATIVA":"INATIVA"}
                </button>
                <button onClick={async()=>{if(!confirm(`Remover "${p.name}"?`))return;await supabase.from("pos_promotions").delete().eq("id",p.id);load();}}
                  style={{ border:"none",background:"transparent",cursor:"pointer",color:P.border,padding:"4px",borderRadius:6,transition:"all .15s",display:"flex" }}
                  onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.color=P.red;el.style.background=P.redL;}}
                  onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.color=P.border;el.style.background="transparent";}}>
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
          </div>
        </SectionWrap>
      )}
    </div>
  );
};

// ─── AdminPOS Main ─────────────────────────────────────────────────────────────
type MainView = "list" | "nova" | "config" | "exportacoes";

const AdminPOS = () => {
  const { user } = useAuth(["admin","colaborador"], "/colaborador/login");
  const [view,       setView]       = useState<MainView>("list");
  const [operations, setOperations] = useState<any[]>([]);
  const [settings,   setSettings]   = useState<any>(null);
  const [isAdmin,    setIsAdmin]    = useState(false);
  const [loading,    setLoading]    = useState(true);
  const [searchOp,   setSearchOp]   = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data:ops },{ data:s }] = await Promise.all([
      supabase.from("pos_operations").select("*").order("created_at",{ascending:false}).limit(200),
      supabase.from("pos_settings").select("*").maybeSingle(),
    ]);
    setOperations(ops??[]); setSettings(s??DEFAULT_SETTINGS); setLoading(false);
  }, []);

  useEffect(()=>{ if(!user)return; setIsAdmin(user.email===ADMIN_EMAIL); load(); },[user,load]);

  const updatePaymentStatus = async (id: string, newStatus: string) => {
    const { error } = await supabase.from("pos_operations").update({ payment_status:newStatus }).eq("id",id);
    if (error) return toast.error("Erro: "+error.message);
    toast.success("Estado atualizado!");
    setOperations(prev=>prev.map(o=>o.id===id?{...o,payment_status:newStatus}:o));
  };

  if (view==="nova"&&settings) return <NovaOperacao user={user} settings={settings} onBack={()=>setView("list")} onFinalized={()=>{ setView("list"); load(); }} />;
  if (view==="config")         return <POSConfiguracoes isAdmin={isAdmin} onBack={()=>{ setView("list"); load(); }} />;
  if (view==="exportacoes")    return <ExportacoesMensais operations={operations} isAdmin={isAdmin} onBack={()=>setView("list")} />;

  const today    = new Date().toDateString();
  const todayOps = operations.filter(o=>new Date(o.created_at).toDateString()===today);
  const pending  = operations.filter(o=>isPending(o.payment_status));
  const filtered = operations.filter(o=>
    !searchOp ||
    o.operation_number?.toLowerCase().includes(searchOp.toLowerCase()) ||
    o.client_name?.toLowerCase().includes(searchOp.toLowerCase()) ||
    o.payment_method?.toLowerCase().includes(searchOp.toLowerCase())
  );

  const stats = [
    { label:"Operações Hoje", value:String(todayOps.length).padStart(2,"0"),                suffix:"",  color:P.gold,  barColor:P.gold,  icon:Hash       },
    { label:"Faturado Hoje",  value:fmt(todayOps.reduce((s,o)=>s+(o.total||0),0)),          suffix:"€", color:P.green, barColor:P.green, icon:TrendingUp },
    { label:"Por Cobrar",     value:fmt(pending.reduce((s,o)=>s+(o.total||0),0)),            suffix:"€", color:pending.length>0?P.amber:P.textMuted, barColor:pending.length>0?P.amber:P.border, icon:Clock },
    { label:"Total Acumulado",value:fmt(operations.reduce((s,o)=>s+(o.total||0),0)),         suffix:"€", color:P.text,  barColor:P.border, icon:Euro      },
  ];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:20, fontFamily:"inherit" }}>

      {/* Page header */}
      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", flexWrap:"wrap", gap:14 }}>
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <div style={{ width:46,height:46,borderRadius:14,background:P.bgDark,border:`2px solid ${P.borderMed}`,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 4px 14px rgba(61,43,31,.25)" }}>
            <ShoppingCart size={20} color="#f5e6d3" />
          </div>
          <div>
            <h1 style={{ fontSize:22,fontWeight:900,color:P.text,margin:0,lineHeight:1.1,letterSpacing:"-0.02em" }}>Ponto de Venda</h1>
            <p style={{ fontSize:12,color:P.textMuted,margin:"3px 0 0",textTransform:"capitalize" }}>
              {format(new Date(),"EEEE, d 'de' MMMM 'de' yyyy",{locale:pt})}
            </p>
          </div>
        </div>
        <div style={{ display:"flex",gap:8,flexWrap:"wrap",alignItems:"center" }}>
          {[
            { label:"Atualizar",  icon:RefreshCw, onClick:load,                      disabled:loading, spin:loading },
            { label:"Relatórios", icon:BarChart3,  onClick:()=>setView("exportacoes") },
            ...(isAdmin?[{ label:"Configurações", icon:Settings, onClick:()=>setView("config") }]:[]),
          ].map(b=>{ const Icon=b.icon; return (
            <button key={b.label} onClick={b.onClick} disabled={(b as any).disabled}
              style={{ display:"flex",alignItems:"center",gap:7,height:36,padding:"0 14px",borderRadius:9,border:`1px solid ${P.border}`,background:P.bgCard,color:P.textSub,fontSize:12,fontWeight:600,cursor:(b as any).disabled?"not-allowed":"pointer",opacity:(b as any).disabled?.5:1,transition:"all .15s" }}
              onMouseEnter={e=>{ if(!(b as any).disabled){const el=e.currentTarget as HTMLElement;el.style.background=P.bgSurf;el.style.borderColor=P.gold;el.style.color=P.gold;} }}
              onMouseLeave={e=>{ const el=e.currentTarget as HTMLElement;el.style.background=P.bgCard;el.style.borderColor=P.border;el.style.color=P.textSub; }}>
              <Icon size={13} style={(b as any).spin?{animation:"spin 1s linear infinite"}:{}} />{b.label}
            </button>
          ); })}
          <button onClick={()=>setView("nova")}
            style={{ display:"flex",alignItems:"center",gap:8,height:36,padding:"0 18px",borderRadius:9,border:"none",background:P.bgDark,color:"#f5e6d3",fontSize:13,fontWeight:800,cursor:"pointer",transition:"background .15s",boxShadow:"0 4px 14px rgba(61,43,31,.3)",letterSpacing:"0.01em" }}
            onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
            <Plus size={15} />Nova Operação
          </button>
        </div>
      </div>

      {/* KPI tiles */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))",gap:12 }}>
        {stats.map(s=>{ const Icon=s.icon; return (
          <div key={s.label} style={{ ...card }}>
            <div style={{ height:3,background:s.barColor }} />
            <div style={{ padding:"16px 18px" }}>
              <div style={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:10 }}>
                <p style={{ fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textMuted,margin:0 }}>{s.label}</p>
                <Icon size={15} color={s.barColor} style={{ opacity:.35 }} />
              </div>
              <p style={{ fontSize:28,fontWeight:900,color:s.color,margin:0,lineHeight:1,fontVariantNumeric:"tabular-nums",letterSpacing:"-0.02em" }}>
                {s.value}<span style={{ fontSize:15,fontWeight:500,color:P.textMuted,marginLeft:3 }}>{s.suffix}</span>
              </p>
            </div>
          </div>
        ); })}
      </div>

      {/* Pending alert */}
      {pending.length>0 && (
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",gap:14,padding:"12px 18px",borderRadius:12,border:`1px solid ${P.amberB}60`,background:P.amberL }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <AlertCircle size={16} color={P.amber} style={{ flexShrink:0 }} />
            <p style={{ fontSize:13,fontWeight:600,color:P.amber,margin:0 }}>
              {pending.length} operaç{pending.length===1?"ão":"ões"} por cobrar — total de <strong>{fmt(pending.reduce((s,o)=>s+(o.total||0),0))}€</strong>
            </p>
          </div>
          <button onClick={()=>setView("exportacoes")}
            style={{ height:28,padding:"0 14px",borderRadius:20,border:`1.5px solid ${P.amberB}80`,background:"transparent",fontSize:12,fontWeight:700,color:P.amber,cursor:"pointer",flexShrink:0,transition:"background .15s" }}
            onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.amberB+"60";}}
            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>
            Ver detalhes →
          </button>
        </div>
      )}

      {/* Operations table */}
      <div style={{ ...card }}>
        {/* Table header */}
        <div style={{ ...sectionHdr }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <div style={{ width:30,height:30,borderRadius:9,background:P.bgDark,display:"flex",alignItems:"center",justifyContent:"center" }}>
              <Receipt size={13} color="#f5e6d3" />
            </div>
            <div>
              <span style={{ fontSize:13,fontWeight:700,color:P.text }}>Histórico de Operações</span>
              <span style={{ fontSize:11,color:P.textMuted,marginLeft:8 }}>{filtered.length} de {operations.length}</span>
            </div>
          </div>
          <div style={{ position:"relative" }}>
            <Search size={12} style={{ position:"absolute",left:9,top:"50%",transform:"translateY(-50%)",color:P.textHint,pointerEvents:"none" }} />
            <input value={searchOp} onChange={e=>setSearchOp(e.target.value)} placeholder="Pesquisar operação…"
              style={{ ...inp, height:30, paddingLeft:28, paddingRight:10, width:200 }} />
          </div>
        </div>

        {/* Col headers */}
        <div style={{ display:"grid",gridTemplateColumns:"150px 1fr 135px 95px 125px 160px 165px",gap:12,padding:"8px 18px",background:P.bgSurf,borderBottom:`1px solid ${P.border}` }}>
          {["Nº Operação","Cliente","Data","Total","Pagamento","Estado","Alterar Estado"].map(h=>(
            <span key={h} style={{ fontSize:9,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.12em",color:P.textHint }}>{h}</span>
          ))}
        </div>

        {loading
          ? <div style={{ display:"flex",alignItems:"center",justifyContent:"center",padding:"64px 0",gap:10,color:P.textMuted }}>
              <Loader2 size={20} color={P.gold} style={{ animation:"spin 1s linear infinite" }} />
              <span style={{ fontSize:13 }}>A carregar operações…</span>
            </div>
          : filtered.length===0
          ? <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"64px 0",color:P.textHint,gap:10 }}>
              <ShoppingCart size={42} style={{ opacity:.1 }} />
              <p style={{ fontSize:13,margin:0 }}>{searchOp?"Nenhuma operação encontrada.":"Sem operações registadas."}</p>
            </div>
          : filtered.map((op,i)=>(
            <div key={op.id}
              style={{ display:"grid",gridTemplateColumns:"150px 1fr 135px 95px 125px 160px 165px",gap:12,padding:"12px 18px",alignItems:"center",borderBottom:`1px solid ${P.border}`,background:i%2!==0?P.bgSurf:"transparent",transition:"background .15s" }}
              onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgAccent;}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=i%2!==0?P.bgSurf:"transparent";}}>
              <span style={{ fontFamily:"monospace",fontWeight:700,fontSize:13,color:P.gold,letterSpacing:".5px" }}>{op.operation_number}</span>
              <p style={{ fontSize:13,fontWeight:500,color:P.text,margin:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{op.client_name||"—"}</p>
              <span style={{ fontSize:11,color:P.textMuted }}>{format(new Date(op.created_at),"dd MMM yy · HH:mm",{locale:pt})}</span>
              <span style={{ fontSize:14,fontWeight:800,color:P.green }}>{Number(op.total).toFixed(2)}€</span>
              <span style={{ fontSize:11,color:P.textSub,textTransform:"capitalize" }}>
                {op.payment_method}{op.mbway_number?` · ${op.mbway_number.slice(-4)}`:""}
              </span>
              <PaymentBadge status={op.payment_status??"por_pagar"} />
              <select value={op.payment_status??"por_pagar"} onChange={e=>updatePaymentStatus(op.id,e.target.value)}
                style={{ height:30,fontSize:11,borderRadius:8,border:`1.5px solid ${P.border}`,padding:"0 8px",background:P.bgCard,color:P.textSub,outline:"none",width:"100%",cursor:"pointer",transition:"border-color .15s" }}
                onFocus={e=>{(e.currentTarget as HTMLElement).style.borderColor=P.gold;}}
                onBlur={e=>{(e.currentTarget as HTMLElement).style.borderColor=P.border;}}>
                {Object.entries(PAYMENT_STATUS).map(([key,cfg])=><option key={key} value={key}>{cfg.label}</option>)}
              </select>
            </div>
          ))
        }
      </div>
    </div>
  );
};

export default AdminPOS;
