import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, TrendingUp, TrendingDown, DollarSign, Calendar, Tag, FileText, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

const AdminFinanceiro = () => {
  const [events, setEvents] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [form, setForm] = useState({ description: "", amount: 0, category: "", expense_date: format(new Date(), "yyyy-MM-dd") });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from("events")
      .select("id, title, budget, event_date")
      .order("event_date", { ascending: false })
      .then(({ data }) => {
        setEvents(data ?? []);
        if (data && data.length && !selected) setSelected(data[0].id);
      });
  }, []);

  const loadExpenses = async (id: string) => {
    setLoading(true);
    const { data } = await supabase
      .from("event_expenses")
      .select("*")
      .eq("event_id", id)
      .order("expense_date", { ascending: false });
    setExpenses(data ?? []);
    setLoading(false);
  };

  useEffect(() => { 
    if (selected) loadExpenses(selected); 
  }, [selected]);

  const add = async () => {
    if (!form.description.trim()) return toast.error("Por favor, introduza uma descrição para a despesa.");
    if (form.amount <= 0) return toast.error("O valor da despesa deve ser superior a zero.");
    
    const { error } = await supabase.from("event_expenses").insert({ 
      ...form, 
      description: form.description.trim(),
      category: form.category.trim() || "Geral",
      event_id: selected 
    });

    if (error) return toast.error("Erro ao adicionar despesa: " + error.message);
    
    toast.success("Despesa adicionada com sucesso!");
    setForm({ description: "", amount: 0, category: "", expense_date: format(new Date(), "yyyy-MM-dd") });
    loadExpenses(selected);
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("event_expenses").delete().eq("id", id);
    if (error) return toast.error("Erro ao eliminar despesa.");
    
    toast.success("Despesa removida.");
    loadExpenses(selected);
  };

  const ev = events.find((e) => e.id === selected);
  const totalExp = expenses.reduce((s, e) => s + Number(e.amount), 0);
  const receita = Number(ev?.budget || 0);
  const lucro = receita - totalExp;
  const margemLucro = receita > 0 ? (lucro / receita) * 100 : 0;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <PageHeader 
        title="Gestão Financeira" 
        description="Controlo absoluto de orçamentos, despesas operacionais e margens de lucro por evento." 
      />

      {/* Seletor de Evento Ativo */}
      <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm max-w-xl">
        <div className="space-y-2">
          <Label className="text-sm font-semibold flex items-center gap-1.5 text-foreground">
            <FileText className="h-4 w-4 text-primary" /> Evento em Análise
          </Label>
          <Select value={selected} onValueChange={setSelected}>
            <SelectTrigger className="bg-background border-border/60 shadow-inner">
              <SelectValue placeholder="Escolha um evento para carregar o balanço..." />
            </SelectTrigger>
            <SelectContent>
              {events.map((e) => (
                <SelectItem key={e.id} value={e.id}>
                  {e.title} {e.event_date && `· (${format(new Date(e.event_date), "dd/MM/yyyy")})`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Cartões de Indicadores Financeiros - Estilo SAP Fiori KPI Tiles */}
      {ev && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Card Receita / Orçamento */}
          <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm relative overflow-hidden group">
            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
              <DollarSign className="h-16 w-16 text-primary" />
            </div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Orçamento Inicial</p>
            <p className="text-3xl font-black text-foreground mt-2">
              {receita.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}
            </p>
            <div className="text-[11px] text-muted-foreground mt-2 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-primary inline-block"></span>
              Plafond máximo atribuído ao evento
            </div>
          </div>

          {/* Card Despesas */}
          <div className="bg-card border border-border/60 rounded-xl p-5 shadow-sm relative overflow-hidden group">
            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
              <TrendingDown className="h-16 w-16 text-destructive" />
            </div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Total de Custos</p>
            <p className="text-3xl font-black text-destructive mt-2">
              {totalExp.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}
            </p>
            <div className="text-[11px] text-muted-foreground mt-2 flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full inline-block ${totalExp > receita ? "bg-red-500 animate-pulse" : "bg-destructive"}`}></span>
              Consumido: {receita > 0 ? ((totalExp / receita) * 100).toFixed(1) : 0}% do orçamento
            </div>
          </div>

          {/* Card Lucro Líquido */}
          <div className={`bg-card border rounded-xl p-5 shadow-sm relative overflow-hidden group transition-all border-l-4 ${
            lucro >= 0 ? "border-l-emerald-500 border-border/60" : "border-l-red-500 border-border/60"
          }`}>
            <div className="absolute right-0 top-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
              {lucro >= 0 ? <TrendingUp className="h-16 w-16 text-emerald-500" /> : <AlertCircle className="h-16 w-16 text-red-500" />}
            </div>
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Balanço Estimado (Lucro)</p>
            <p className={`text-3xl font-black mt-2 ${lucro >= 0 ? "text-emerald-600" : "text-red-600"}`}>
              {lucro.toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}
            </p>
            <div className="text-[11px] text-muted-foreground mt-2 font-medium">
              Margem de rendimento: <span className={lucro >= 0 ? "text-emerald-600" : "text-red-600"}>{margemLucro.toFixed(1)}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Formulário - WordPress Meta Box Style */}
      <div className="bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-border/60 bg-muted/20 flex items-center gap-2">
          <Plus className="h-4 w-4 text-primary" />
          <h3 className="font-bold text-sm text-foreground">Registar Novo Movimento de Despesa</h3>
        </div>
        <div className="p-5">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
            <div className="space-y-1.5 md:col-span-4">
              <Label className="text-xs font-medium text-muted-foreground">Descrição do Item / Serviço</Label>
              <Input 
                placeholder="Ex: Aluguer de Audiovisuais" 
                value={form.description} 
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="bg-background"
              />
            </div>
            
            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-xs font-medium text-muted-foreground">Valor Bruto (€)</Label>
              <Input 
                type="number" 
                step="0.01" 
                placeholder="0,00" 
                value={form.amount || ""} 
                onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })}
                className="bg-background font-mono"
              />
            </div>

            <div className="space-y-1.5 md:col-span-3">
              <Label className="text-xs font-medium text-muted-foreground">Categoria / Fornecedor</Label>
              <Input 
                placeholder="Ex: Catering, Logística" 
                value={form.category} 
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="bg-background"
              />
            </div>

            <div className="space-y-1.5 md:col-span-2">
              <Label className="text-xs font-medium text-muted-foreground">Data do Gasto</Label>
              <Input 
                type="date" 
                value={form.expense_date} 
                onChange={(e) => setForm({ ...form, expense_date: e.target.value })}
                className="bg-background"
              />
            </div>

            <div className="md:col-span-1 w-full">
              <Button onClick={add} className="bg-gradient-gold w-full shadow-sm hover:shadow-md transition-all">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Lista de Despesas - Tabela Corporativa Limpa */}
      <div className="bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b border-border/60 bg-muted/10 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Histórico de Custos Associados</span>
          <span className="text-xs font-semibold bg-background border px-2 py-0.5 rounded-md text-muted-foreground">
            {expenses.length} lançamentos
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left border-collapse">
            <thead>
              <tr className="bg-muted/40 border-b border-border/60 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                <th className="p-4 w-[15%]"><span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5"/> Data</span></th>
                <th className="p-4 w-[40%]"><span className="flex items-center gap-1.5"><FileText className="h-3.5 w-3.5"/> Descrição</span></th>
                <th className="p-4 w-[25%]"><span className="flex items-center gap-1.5"><Tag className="h-3.5 w-3.5"/> Categoria</span></th>
                <th className="p-4 w-[15%] text-right"><span className="flex items-center gap-1.5 justify-end"><DollarSign className="h-3.5 w-3.5"/> Custo</span></th>
                <th className="p-4 w-[5%]"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {loading ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-sm text-muted-foreground">
                    A atualizar fluxos financeiros...
                  </td>
                </tr>
              ) : expenses.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-16 text-muted-foreground">
                    <DollarSign className="h-10 w-10 mx-auto mb-3 opacity-20 text-muted-foreground" />
                    <p className="font-medium text-base">Nenhum custo anexado.</p>
                    <p className="text-xs mt-1 max-w-xs mx-auto opacity-75">Todas as despesas inseridas acima serão listadas e abatidas do saldo final do evento em tempo real.</p>
                  </td>
                </tr>
              ) : (
                expenses.map((x) => (
                  <tr key={x.id} className="hover:bg-muted/30 transition-colors group">
                    <td className="p-4 font-medium text-foreground">
                      {format(new Date(x.expense_date), "dd/MM/yyyy")}
                    </td>
                    <td className="p-4 font-semibold text-foreground/90">
                      {x.description}
                    </td>
                    <td className="p-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-muted text-muted-foreground border border-border/30">
                        {x.category || "Geral"}
                      </span>
                    </td>
                    <td className="p-4 text-right font-mono font-bold text-foreground">
                      {Number(x.amount).toLocaleString("pt-PT", { style: "currency", currency: "EUR" })}
                    </td>
                    <td className="p-4 text-right">
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        onClick={() => remove(x.id)}
                        className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-all rounded-md"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminFinanceiro;
