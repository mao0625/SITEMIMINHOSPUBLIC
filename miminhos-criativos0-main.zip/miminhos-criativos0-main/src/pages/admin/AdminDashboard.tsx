import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import {
  Inbox, Calendar, FileText, Users, MessageSquare,
  Plus, Image as ImageIcon, Settings,
  ArrowRight, Clock, AlertCircle, CheckCircle2,
  ChevronRight, Bell, LayoutDashboard, TrendingUp,
  Zap, Package, Euro, Activity,
} from "lucide-react";
import { format, isToday, isTomorrow, differenceInDays } from "date-fns";
import { pt } from "date-fns/locale";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const statusColor: Record<string, string> = {
  pendente:    "bg-amber-100 text-amber-700",
  confirmado:  "bg-emerald-100 text-emerald-700",
  planeamento: "bg-blue-100 text-blue-700",
  concluido:   "bg-gray-100 text-gray-500",
  cancelado:   "bg-red-100 text-red-600",
  submetido:   "bg-violet-100 text-violet-700",
  aprovado:    "bg-emerald-100 text-emerald-700",
};

const statusDot: Record<string, string> = {
  pendente:    "bg-amber-400",
  confirmado:  "bg-emerald-500",
  planeamento: "bg-blue-400",
  concluido:   "bg-gray-300",
  cancelado:   "bg-red-400",
  submetido:   "bg-violet-400",
  aprovado:    "bg-emerald-400",
};

const eventDateLabel = (dateStr: string) => {
  const d = new Date(dateStr);
  if (isToday(d))     return { label: "Hoje",        color: "text-red-500 font-semibold"   };
  if (isTomorrow(d))  return { label: "Amanhã",      color: "text-amber-500 font-semibold" };
  const diff = differenceInDays(d, new Date());
  if (diff <= 7)      return { label: `${diff}d`,    color: "text-amber-400 font-medium"   };
  return { label: format(d, "dd MMM", { locale: pt }), color: "text-muted-foreground" };
};

// ─── KPI Card — Apple style ───────────────────────────────────────────────────
const KpiCard = ({ icon: Icon, label, value, to, color, sublabel, urgent, trend }: any) => (
  <Link to={to} className="group relative bg-card rounded-2xl border border-border/60 overflow-hidden hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)] hover:border-border hover:-translate-y-0.5 transition-all duration-200 flex flex-col">
    <div className="p-5 flex flex-col flex-1 gap-3">
      {/* Icon */}
      <div className="flex items-start justify-between">
        <div className={`h-10 w-10 rounded-xl flex items-center justify-center ${urgent && Number(value) > 0 ? "bg-amber-100" : `${color ?? "bg-muted"}`}`}>
          <Icon className={`h-5 w-5 ${urgent && Number(value) > 0 ? "text-amber-600" : "text-muted-foreground"}`} />
        </div>
        {urgent && Number(value) > 0 && (
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400 ring-2 ring-amber-100 animate-pulse" />
        )}
      </div>
      {/* Value */}
      <div>
        <p className={`font-bold text-3xl leading-none tracking-tight tabular-nums ${urgent && Number(value) > 0 ? "text-amber-600" : ""}`}>
          {String(value).padStart(2, "0")}
        </p>
        <p className="text-xs font-medium text-muted-foreground mt-1.5 leading-tight">{label}</p>
        {sublabel && <p className="text-[10px] text-muted-foreground/50 mt-0.5">{sublabel}</p>}
      </div>
    </div>
    {/* Bottom arrow */}
    <div className="px-5 py-2.5 border-t border-border/40 flex items-center justify-between bg-muted/20">
      <span className="text-[10px] text-muted-foreground font-medium">Ver detalhes</span>
      <ArrowRight className="h-3 w-3 text-muted-foreground/40 group-hover:text-primary group-hover:translate-x-0.5 transition-all duration-150" />
    </div>
  </Link>
);

// ─── Quick Action ─────────────────────────────────────────────────────────────
const QuickAction = ({ to, icon: Icon, label, desc }: any) => (
  <Link to={to} className="group flex items-center gap-3 px-4 py-3 rounded-xl border border-border/60 bg-card hover:bg-primary hover:text-primary-foreground hover:border-primary hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
    <div className="h-8 w-8 rounded-lg bg-muted group-hover:bg-primary-foreground/20 flex items-center justify-center transition-colors shrink-0">
      <Icon className="h-4 w-4 text-muted-foreground group-hover:text-primary-foreground transition-colors" />
    </div>
    <div className="min-w-0">
      <p className="text-xs font-semibold leading-tight">{label}</p>
      {desc && <p className="text-[10px] text-muted-foreground group-hover:text-primary-foreground/70 transition-colors truncate mt-0.5">{desc}</p>}
    </div>
  </Link>
);

// ─── Alert Notice ─────────────────────────────────────────────────────────────
const AlertNotice = ({ to, icon: Icon, message, count, variant }: any) => {
  const styles = {
    amber: "border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100",
    blue:  "border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100",
    violet:"border-violet-200 bg-violet-50 text-violet-700 hover:bg-violet-100",
  }[variant ?? "amber"];
  return (
    <Link to={to} className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border text-xs font-medium transition-colors group ${styles}`}>
      <div className="h-6 w-6 rounded-lg flex items-center justify-center bg-white/60 shrink-0">
        <Icon className="h-3.5 w-3.5" />
      </div>
      <span className="flex-1">{message}</span>
      {count > 0 && (
        <span className="h-5 min-w-[20px] px-1 rounded-full bg-current/20 text-[10px] font-bold flex items-center justify-center">{count}</span>
      )}
      <ChevronRight className="h-3.5 w-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
    </Link>
  );
};

// ─── Panel ────────────────────────────────────────────────────────────────────
const Panel = ({ title, linkTo, linkLabel, count, children, icon: Icon }: any) => (
  <div className="bg-card rounded-2xl border border-border/60 overflow-hidden flex flex-col shadow-sm">
    <div className="px-5 py-3.5 border-b border-border/40 flex items-center justify-between bg-muted/20">
      <div className="flex items-center gap-2.5">
        {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
        <span className="text-sm font-semibold text-foreground">{title}</span>
        {count !== undefined && count > 0 && (
          <span className="h-5 min-w-[20px] px-1.5 rounded-full bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center">{count}</span>
        )}
      </div>
      {linkTo && (
        <Link to={linkTo} className="text-[11px] text-primary hover:underline flex items-center gap-0.5 font-medium">
          {linkLabel ?? "Ver todos"} <ChevronRight className="h-3 w-3" />
        </Link>
      )}
    </div>
    <div className="flex-1">{children}</div>
  </div>
);

// ─── Pedido Row ───────────────────────────────────────────────────────────────
const PedidoRow = ({ p }: { p: any }) => (
  <Link to="/admin/pedidos" className="flex items-center gap-3 px-5 py-3 hover:bg-muted/30 transition-colors border-b border-border/30 last:border-0 group">
    <span className={`h-2 w-2 rounded-full shrink-0 ${statusDot[p.status] ?? "bg-muted-foreground"}`} />
    <div className="min-w-0 flex-1">
      <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{p.name}</p>
      <p className="text-[11px] text-muted-foreground truncate">{p.event_type || "—"} · {p.email}</p>
    </div>
    <div className="text-right shrink-0">
      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium capitalize ${statusColor[p.status] ?? "bg-muted text-muted-foreground"}`}>{p.status}</span>
      <p className="text-[10px] text-muted-foreground/50 mt-0.5 flex items-center gap-0.5 justify-end">
        <Clock className="h-2.5 w-2.5" />
        {p.created_at ? format(new Date(p.created_at), "dd/MM HH:mm") : "—"}
      </p>
    </div>
  </Link>
);

// ─── Evento Row ───────────────────────────────────────────────────────────────
const EventoRow = ({ ev }: { ev: any }) => {
  const dl = ev.event_date ? eventDateLabel(ev.event_date) : null;
  return (
    <Link to="/admin/eventos" className="flex items-center gap-3 px-5 py-3 hover:bg-muted/30 transition-colors border-b border-border/30 last:border-0 group">
      <div className="shrink-0 w-11 h-11 rounded-xl bg-muted/50 border border-border/40 flex flex-col items-center justify-center">
        {ev.event_date ? (
          <>
            <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground leading-none">{format(new Date(ev.event_date), "MMM", { locale: pt })}</p>
            <p className="text-base font-bold leading-tight">{format(new Date(ev.event_date), "dd")}</p>
          </>
        ) : <Calendar className="h-4 w-4 text-muted-foreground" />}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{ev.title}</p>
        <div className="flex items-center gap-1.5">
          {dl && <span className={`text-[11px] ${dl.color}`}>{dl.label}</span>}
          {ev.location && <span className="text-[11px] text-muted-foreground truncate">· {ev.location}</span>}
        </div>
      </div>
      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium capitalize shrink-0 ${statusColor[ev.status] ?? "bg-muted text-muted-foreground"}`}>{ev.status}</span>
    </Link>
  );
};

// ─── Skeleton ─────────────────────────────────────────────────────────────────
const Skeleton = ({ rows = 4, type = "pedido" }: { rows?: number; type?: "pedido" | "evento" }) => (
  <div className="divide-y divide-border/30">
    {[...Array(rows)].map((_, i) => (
      <div key={i} className="px-5 py-3 flex gap-3 items-center animate-pulse">
        {type === "evento"
          ? <div className="h-11 w-11 rounded-xl bg-muted" />
          : <div className="h-2 w-2 rounded-full bg-muted" />
        }
        <div className="flex-1 space-y-1.5">
          <div className="h-3 bg-muted rounded-full w-2/3" />
          <div className="h-2.5 bg-muted rounded-full w-1/2" />
        </div>
        <div className="h-5 w-16 bg-muted rounded-full" />
      </div>
    ))}
  </div>
);

// ─── Dashboard ────────────────────────────────────────────────────────────────
const AdminDashboard = () => {
  const [stats, setStats] = useState({ pedidos: 0, eventos: 0, questionarios: 0, clientes: 0, mensagens: 0 });
  const [pedidos, setPedidos] = useState<any[]>([]);
  const [proximos, setProximos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const today = new Date().toISOString().slice(0, 10);
      const [p, e, q, c, m, lista, ev] = await Promise.all([
        supabase.from("quote_requests").select("id", { count: "exact", head: true }).eq("status", "pendente"),
        supabase.from("events").select("id", { count: "exact", head: true }),
        supabase.from("questionnaires").select("id", { count: "exact", head: true }).eq("status", "submetido"),
        supabase.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "cliente"),
        supabase.from("messages").select("id", { count: "exact", head: true }).eq("read", false),
        supabase.from("quote_requests").select("*").order("created_at", { ascending: false }).limit(6),
        supabase.from("events").select("*").gte("event_date", today).order("event_date", { ascending: true }).limit(6),
      ]);
      setStats({ pedidos: p.count ?? 0, eventos: e.count ?? 0, questionarios: q.count ?? 0, clientes: c.count ?? 0, mensagens: m.count ?? 0 });
      setPedidos(lista.data ?? []);
      setProximos(ev.data ?? []);
      setLoading(false);
    })();
  }, []);

  const now = new Date();
  const greeting = now.getHours() < 12 ? "Bom dia" : now.getHours() < 19 ? "Boa tarde" : "Boa noite";
  const hasAlerts = !loading && (stats.pedidos > 0 || stats.mensagens > 0 || stats.questionarios > 0);

  return (
    <div className="space-y-6 max-w-[1400px]">

      {/* ── Header ── */}
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1">
            <LayoutDashboard className="h-3 w-3" />
            <span>Painel</span>
            <ChevronRight className="h-2.5 w-2.5" />
            <span className="font-medium text-foreground">Vista Geral</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">{greeting}</h1>
          <p className="text-sm text-muted-foreground mt-0.5 capitalize">
            {format(now, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: pt })}
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-border/60 bg-card text-xs text-muted-foreground">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Sistema operacional</span>
          <span className="text-muted-foreground/30">·</span>
          <span className="font-mono font-medium">{format(now, "HH:mm")}</span>
        </div>
      </div>

      {/* ── Alertas ── */}
      {hasAlerts && (
        <div className="bg-card rounded-2xl border border-border/60 overflow-hidden shadow-sm">
          <div className="px-5 py-3 border-b border-border/40 bg-muted/20 flex items-center gap-2">
            <div className="h-6 w-6 rounded-lg bg-amber-100 flex items-center justify-center">
              <Bell className="h-3.5 w-3.5 text-amber-600" />
            </div>
            <span className="text-sm font-semibold">Notificações</span>
            <span className="ml-auto text-[11px] text-muted-foreground">{[stats.pedidos, stats.mensagens, stats.questionarios].filter(Boolean).length} alerta(s)</span>
          </div>
          <div className="p-4 flex flex-wrap gap-2.5">
            {stats.pedidos > 0 && (
              <AlertNotice to="/admin/pedidos" icon={Inbox} variant="amber"
                message={`${stats.pedidos} pedido${stats.pedidos > 1 ? "s" : ""} pendente${stats.pedidos > 1 ? "s" : ""}`}
                count={stats.pedidos} />
            )}
            {stats.mensagens > 0 && (
              <AlertNotice to="/admin/mensagens" icon={MessageSquare} variant="amber"
                message={`${stats.mensagens} mensagem${stats.mensagens > 1 ? "ns" : ""} não lida${stats.mensagens > 1 ? "s" : ""}`}
                count={stats.mensagens} />
            )}
            {stats.questionarios > 0 && (
              <AlertNotice to="/admin/questionarios" icon={FileText} variant="blue"
                message={`${stats.questionarios} orçamento${stats.questionarios > 1 ? "s" : ""} para revisão`}
                count={stats.questionarios} />
            )}
          </div>
        </div>
      )}

      {/* ── KPI Grid ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <KpiCard icon={Inbox}        label="Pedidos Pendentes"  value={stats.pedidos}       to="/admin/pedidos"       color="bg-amber-100"   urgent />
        <KpiCard icon={Calendar}     label="Eventos Totais"     value={stats.eventos}       to="/admin/eventos"       color="bg-blue-100"    />
        <KpiCard icon={FileText}     label="Orçamentos"         value={stats.questionarios} to="/admin/questionarios" color="bg-violet-100"  sublabel="submetidos" urgent />
        <KpiCard icon={Users}        label="Clientes"           value={stats.clientes}      to="/admin/utilizadores"  color="bg-emerald-100" />
        <KpiCard icon={MessageSquare}label="Mensagens Novas"    value={stats.mensagens}     to="/admin/mensagens"     color="bg-rose-100"    urgent />
      </div>

      {/* ── Ações Rápidas ── */}
      <div className="bg-card rounded-2xl border border-border/60 overflow-hidden shadow-sm">
        <div className="px-5 py-3 border-b border-border/40 bg-muted/20 flex items-center gap-2">
          <div className="h-6 w-6 rounded-lg bg-primary/10 flex items-center justify-center">
            <Zap className="h-3.5 w-3.5 text-primary" />
          </div>
          <span className="text-sm font-semibold">Ações Rápidas</span>
        </div>
        <div className="p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          <QuickAction to="/admin/eventos"      icon={Plus}      label="Novo Evento"       desc="Criar evento" />
          <QuickAction to="/admin/utilizadores" icon={Users}     label="Novo Cliente"      desc="Adicionar cliente" />
          <QuickAction to="/admin/galeria"      icon={ImageIcon} label="Galeria"           desc="Adicionar imagem" />
          <QuickAction to="/admin/blog"         icon={FileText}  label="Novo Artigo"       desc="Escrever artigo" />
          <QuickAction to="/admin/definicoes"   icon={Settings}  label="Definições"        desc="Configurações" />
        </div>
      </div>

      {/* ── Tabelas ── */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Panel title="Últimos Pedidos" linkTo="/admin/pedidos" count={stats.pedidos} icon={Inbox}>
          {loading ? <Skeleton rows={4} type="pedido" /> : pedidos.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-14 text-muted-foreground gap-3">
              <div className="h-12 w-12 rounded-2xl bg-emerald-50 flex items-center justify-center">
                <CheckCircle2 className="h-6 w-6 text-emerald-400" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium">Sem pedidos pendentes</p>
                <p className="text-xs text-muted-foreground/60 mt-0.5">Tudo em dia!</p>
              </div>
            </div>
          ) : pedidos.map(p => <PedidoRow key={p.id} p={p} />)}
        </Panel>

        <Panel title="Próximos Eventos" linkTo="/admin/eventos" icon={Calendar}>
          {loading ? <Skeleton rows={4} type="evento" /> : proximos.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-14 text-muted-foreground gap-3">
              <div className="h-12 w-12 rounded-2xl bg-muted/50 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-muted-foreground/30" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium">Sem eventos agendados</p>
                <Link to="/admin/eventos" className="text-xs text-primary hover:underline mt-0.5 block">Criar um evento</Link>
              </div>
            </div>
          ) : proximos.map(ev => <EventoRow key={ev.id} ev={ev} />)}
        </Panel>
      </div>

      {/* ── Rodapé ── */}
      <div className="border-t border-border/40 pt-4 flex items-center justify-between text-[11px] text-muted-foreground/40">
        <span>Miminhos Criativos · Portal de Gestão</span>
        <span className="font-mono">{format(now, "dd/MM/yyyy HH:mm:ss")}</span>
      </div>

    </div>
  );
};

export default AdminDashboard;
