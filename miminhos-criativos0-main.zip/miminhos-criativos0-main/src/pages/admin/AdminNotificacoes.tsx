import { useEffect, useMemo, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { formatDistanceToNow } from "date-fns";
import { pt } from "date-fns/locale";
import {
  Bell, Inbox, FileText, Bug, MessageSquare, Calendar,
  CheckCheck, ChevronRight, Filter, Send, Shield, ToggleLeft, ToggleRight,
  ArrowLeft, RefreshCw, X,
} from "lucide-react";

const SUPER_ADMIN = "mao0625@outlook.pt";

type NotifKind = "pedido" | "questionario" | "problema" | "mensagem" | "evento" | "broadcast";
interface Notif {
  id: string; kind: NotifKind; title: string; subtitle?: string; date: string; href: string;
}
const kindConfig: Record<NotifKind, { label: string; icon: React.ElementType; color: string; bg: string; border: string }> = {
  pedido:       { label: "Pedido",         icon: Inbox,         color: "text-amber-700",   bg: "bg-amber-50",   border: "border-amber-200" },
  questionario: { label: "Questionário",   icon: FileText,      color: "text-violet-700",  bg: "bg-violet-50",  border: "border-violet-200" },
  problema:     { label: "Problema",       icon: Bug,           color: "text-red-700",     bg: "bg-red-50",     border: "border-red-200" },
  mensagem:     { label: "Mensagem",       icon: MessageSquare, color: "text-blue-700",    bg: "bg-blue-50",    border: "border-blue-200" },
  evento:       { label: "Evento",         icon: Calendar,      color: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-200" },
  broadcast:    { label: "Comunicado",     icon: Bell,          color: "text-primary",     bg: "bg-primary/10", border: "border-primary/20" },
};

// ─── SAP Toolbar ──────────────────────────────────────────────────────────
const SapToolbar = ({ title, subtitle, onBack, backLabel = "Voltar", actions }: {
  title: string; subtitle?: string; onBack?: () => void; backLabel?: string; actions?: React.ReactNode;
}) => (
  <div className="bg-[#f7f3eb] dark:bg-muted/60 border border-border rounded-t-lg">
    <div className="flex items-center gap-3 px-4 py-2 border-b border-border/50">
      {onBack && <>
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-primary font-semibold hover:underline shrink-0">
          <ArrowLeft className="h-3.5 w-3.5" />{backLabel}
        </button>
        <div className="h-4 w-px bg-border/60" />
      </>}
      <div className="flex-1 min-w-0">
        <span className="font-bold text-sm">{title}</span>
        {subtitle && <span className="text-xs text-muted-foreground ml-3">{subtitle}</span>}
      </div>
      {actions && <div className="flex items-center gap-1.5 ml-auto">{actions}</div>}
    </div>
  </div>
);

const SapRow = ({ label, last, children }: { label: string; last?: boolean; children: React.ReactNode }) => (
  <div className={`flex items-start ${!last ? "border-b border-border/40" : ""} hover:bg-primary/3 transition-colors`}>
    <span className="text-xs text-muted-foreground bg-muted/30 px-4 py-3 w-40 shrink-0 border-r border-border/30 font-medium">{label}</span>
    <div className="flex-1 px-4 py-2.5">{children}</div>
  </div>
);

// ─── Enviar Comunicado ────────────────────────────────────────────────────────
const EnviarComunicado = ({ onBack, onSent, user }: { onBack: () => void; onSent: () => void; user: any }) => {
  const [form, setForm] = useState({ title: "", body: "", target: "all" });
  const [sending, setSending] = useState(false);

  const enviar = async () => {
    if (!form.title.trim() || !form.body.trim()) return;
    setSending(true);
    await supabase.from("staff_broadcasts").insert({
      sender_id: user.id,
      sender_name: user.user_metadata?.full_name || user.email?.split("@")[0],
      title: form.title,
      body: form.body,
      target: form.target,
    });
    setSending(false);
    onSent();
  };

  return (
    <div>
      <SapToolbar title="Enviar Comunicado à Equipa" onBack={onBack} backLabel="Notificações"
        actions={
          <>
            <Button size="sm" variant="outline" onClick={onBack} className="h-7 text-xs"><X className="h-3 w-3 mr-1" />Cancelar</Button>
            <Button size="sm" className="h-7 text-xs bg-gradient-gold" onClick={enviar} disabled={sending || !form.title || !form.body}>
              <Send className="h-3 w-3 mr-1" />{sending ? "A enviar…" : "Enviar"}
            </Button>
          </>
        }
      />
      <div className="border border-t-0 border-border rounded-b-lg bg-background">
        <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
          <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Novo Comunicado</span>
        </div>
        <SapRow label="Destinatários">
          <select value={form.target} onChange={e => setForm({ ...form, target: e.target.value })}
            className="h-8 text-xs border border-border/50 rounded px-2 bg-background">
            <option value="all">Toda a equipa</option>
            <option value="admin">Apenas Admins</option>
            <option value="colaborador">Apenas Colaboradores</option>
          </select>
        </SapRow>
        <SapRow label="Título *">
          <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })}
            placeholder="Título do comunicado…"
            className="h-8 text-sm border-border/50 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/20" />
        </SapRow>
        <SapRow label="Mensagem *" last>
          <Textarea value={form.body} onChange={e => setForm({ ...form, body: e.target.value })}
            rows={5} placeholder="Escreva o comunicado aqui…"
            className="text-sm resize-none border-border/50 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/20" />
        </SapRow>
        <div className="px-5 py-3 border-t border-border/40 bg-muted/10 flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onBack} className="h-8 text-xs">Cancelar</Button>
          <Button size="sm" className="h-8 text-xs bg-gradient-gold shadow-gold" onClick={enviar} disabled={sending || !form.title || !form.body}>
            <Send className="h-3.5 w-3.5 mr-1.5" />{sending ? "A enviar…" : "Enviar Comunicado"}
          </Button>
        </div>
      </div>
    </div>
  );
};

// ─── Gestão de Permissões ─────────────────────────────────────────────────────
const GestaoPermissoes = ({ onBack, user }: { onBack: () => void; user: any }) => {
  const [staff, setStaff] = useState<any[]>([]);
  const [perms, setPerms] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState<string | null>(null);

  const load = async () => {
    const { data: roles } = await supabase.from("user_roles").select("user_id, role").in("role", ["admin", "colaborador"]);
    const ids = [...new Set((roles ?? []).map(r => r.user_id))];
    if (!ids.length) return;
    const { data: profs } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
    const { data: perm } = await supabase.from("notification_permissions").select("*").in("user_id", ids);
    const roleMap: Record<string, string[]> = {};
    (roles ?? []).forEach(r => { (roleMap[r.user_id] ||= []).push(r.role); });
    const permMap: Record<string, boolean> = {};
    (perm ?? []).forEach(p => { permMap[p.user_id] = p.can_send; });
    setStaff((profs ?? []).map(p => ({ ...p, roles: roleMap[p.id] || [] })));
    setPerms(permMap);
  };

  useEffect(() => { load(); }, []);

  const toggle = async (uid: string, val: boolean) => {
    setSaving(uid);
    const existing = await supabase.from("notification_permissions").select("id").eq("user_id", uid).single();
    if (existing.data) {
      await supabase.from("notification_permissions").update({ can_send: val }).eq("user_id", uid);
    } else {
      await supabase.from("notification_permissions").insert({ user_id: uid, can_send: val, granted_by: user.id });
    }
    setPerms(p => ({ ...p, [uid]: val }));
    setSaving(null);
  };

  return (
    <div>
      <SapToolbar title="Permissões de Envio de Notificações" onBack={onBack} backLabel="Notificações"
        subtitle="Definir quem pode enviar comunicados à equipa" />
      <div className="border border-t-0 border-border rounded-b-lg bg-background">
        <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
          <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Equipa</span>
        </div>
        {staff.map((s, i) => (
          <div key={s.id} className={`flex items-center gap-4 px-5 py-3.5 hover:bg-primary/3 transition-colors ${i < staff.length - 1 ? "border-b border-border/30" : ""}`}>
            <div className="h-8 w-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
              <span className="text-xs font-bold text-primary">{(s.full_name || s.email || "?").substring(0, 2).toUpperCase()}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">{s.full_name || s.email}</p>
              <div className="flex gap-1 mt-0.5">
                {s.roles.map((r: string) => (
                  <span key={r} className={`text-[10px] px-1.5 py-0.5 rounded border font-medium capitalize ${r === "admin" ? "bg-purple-50 text-purple-700 border-purple-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
                    {r}
                  </span>
                ))}
              </div>
            </div>
            {s.email === SUPER_ADMIN
              ? <span className="text-xs text-primary font-bold flex items-center gap-1"><Shield className="h-3 w-3" />Super Admin</span>
              : (
                <button onClick={() => toggle(s.id, !perms[s.id])} disabled={saving === s.id}>
                  {perms[s.id]
                    ? <ToggleRight className="h-8 w-8 text-primary" />
                    : <ToggleLeft className="h-8 w-8 text-muted-foreground/40" />}
                </button>
              )}
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Página Principal ────────────────────────────────────────────────────────
export default function AdminNotificacoes() {
  const { user } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const navigate = useNavigate();
  const [view, setView] = useState<"list" | "comunicado" | "permissoes">("list");
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<Notif[]>([]);
  const [filter, setFilter] = useState<"todas" | NotifKind>("todas");
  const [canSend, setCanSend] = useState(false);
  const [readIds, setReadIds] = useState<Set<string>>(() => {
    try { return new Set(JSON.parse(localStorage.getItem("admin_notif_read") || "[]")); } catch { return new Set(); }
  });

  const isSuperAdmin = user?.email === SUPER_ADMIN;
  const persistRead = (s: Set<string>) => localStorage.setItem("admin_notif_read", JSON.stringify(Array.from(s)));

  const loadItems = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [pedidos, quests, bugs, msgs, eventos, broadcasts, permResult] = await Promise.all([
      supabase.from("quote_requests").select("id, name, event_type, created_at, status").eq("status", "pendente").order("created_at", { ascending: false }).limit(30),
      supabase.from("questionnaires").select("id, reference_number, submitted_at, status").eq("status", "submetido").order("submitted_at", { ascending: false }).limit(30),
      supabase.from("bug_reports").select("id, title, type, status, created_at").eq("status", "pendente").order("created_at", { ascending: false }).limit(30),
      supabase.from("messages").select("id, body, created_at, read").eq("recipient_id", user.id).eq("read", false).order("created_at", { ascending: false }).limit(30),
      supabase.from("events").select("id, title, created_at, status").order("created_at", { ascending: false }).limit(10),
      supabase.from("staff_broadcasts").select("*").order("created_at", { ascending: false }).limit(20),
      supabase.from("notification_permissions").select("can_send").eq("user_id", user.id).single(),
    ]);

    setCanSend(isSuperAdmin || (permResult.data?.can_send ?? false));

    const list: Notif[] = [];
    const cutoff = Date.now() - 1000 * 60 * 60 * 24 * 7;
    (pedidos.data || []).forEach(q => list.push({ id: `pedido-${q.id}`, kind: "pedido", title: q.name || "Novo pedido", subtitle: q.event_type || "Pendente", date: q.created_at, href: "/admin/pedidos" }));
    (quests.data || []).forEach(q => list.push({ id: `quest-${q.id}`, kind: "questionario", title: q.reference_number ? `Questionário ${q.reference_number}` : "Novo questionário", subtitle: "Aguarda análise", date: q.submitted_at, href: "/admin/questionarios" }));
    (bugs.data || []).forEach(b => list.push({ id: `bug-${b.id}`, kind: "problema", title: b.title, subtitle: `Tipo: ${b.type}`, date: b.created_at, href: "/admin/problemas" }));
    (msgs.data || []).forEach(m => list.push({ id: `msg-${m.id}`, kind: "mensagem", title: "Nova mensagem", subtitle: (m.body || "").slice(0, 90), date: m.created_at, href: "/admin/mensagens" }));
    (eventos.data || []).forEach(e => {
      if (new Date(e.created_at).getTime() < cutoff) return;
      list.push({ id: `evento-${e.id}`, kind: "evento", title: e.title, subtitle: `Novo evento · ${e.status}`, date: e.created_at, href: "/admin/eventos" });
    });
    (broadcasts.data || []).forEach(b => list.push({ id: `bc-${b.id}`, kind: "broadcast", title: b.title, subtitle: `${b.sender_name || "Admin"}: ${b.body.slice(0, 80)}`, date: b.created_at, href: "/admin/comunicados" }));
    list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setItems(list);
    setLoading(false);
  }, [user, isSuperAdmin]);

  useEffect(() => { loadItems(); }, [loadItems]);

  const filtered = useMemo(() => filter === "todas" ? items : items.filter(i => i.kind === filter), [items, filter]);
  const unreadCount = items.filter(i => !readIds.has(i.id)).length;
  const markRead = (id: string) => { const s = new Set(readIds); s.add(id); setReadIds(s); persistRead(s); };
  const markAllRead = () => { const s = new Set(readIds); items.forEach(i => s.add(i.id)); setReadIds(s); persistRead(s); };
  const counts = useMemo(() => { const c: Record<string, number> = { todas: items.length }; items.forEach(i => { c[i.kind] = (c[i.kind] || 0) + 1; }); return c; }, [items]);

  if (view === "comunicado") return <EnviarComunicado user={user} onBack={() => setView("list")} onSent={() => { setView("list"); loadItems(); }} />;
  if (view === "permissoes") return <GestaoPermissoes user={user} onBack={() => setView("list")} />;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Notificações"
        description={`${unreadCount} não lida${unreadCount !== 1 ? "s" : ""} de ${items.length} no total`}
        action={
          <div className="flex gap-2">
            {(canSend || isSuperAdmin) && (
              <Button size="sm" className="h-8 text-xs bg-gradient-gold" onClick={() => setView("comunicado")}>
                <Bell className="h-3.5 w-3.5 mr-1.5" />Enviar Comunicado
              </Button>
            )}
            {isSuperAdmin && (
              <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => setView("permissoes")}>
                <Shield className="h-3.5 w-3.5 mr-1.5" />Permissões
              </Button>
            )}
          </div>
        }
      />

      {/* Filtros */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          {(["todas", "pedido", "questionario", "problema", "mensagem", "evento", "broadcast"] as const).map(k => {
            const active = filter === k;
            const label = k === "todas" ? "Todas" : kindConfig[k as NotifKind].label;
            return (
              <button key={k} onClick={() => setFilter(k)}
                className={`text-xs font-medium px-3 py-1.5 rounded-lg border transition-colors ${active ? "bg-primary text-primary-foreground border-primary" : "bg-background text-foreground/70 border-border/50 hover:border-border"}`}>
                {label} <span className={`ml-1 ${active ? "opacity-80" : "text-muted-foreground"}`}>({counts[k] || 0})</span>
              </button>
            );
          })}
        </div>
        <button onClick={markAllRead} disabled={unreadCount === 0}
          className="text-xs font-medium px-3 py-1.5 rounded-lg border border-border bg-background hover:bg-muted disabled:opacity-40 flex items-center gap-1.5">
          <CheckCheck className="h-3.5 w-3.5" />Marcar todas como lidas
        </button>
      </div>

      {/* Lista SAP */}
      <SapToolbar title="Centro de Notificações" subtitle={`${filtered.length} notificação(ões)`}
        actions={<button onClick={() => loadItems()} className="text-muted-foreground hover:text-primary"><RefreshCw className="h-3.5 w-3.5" /></button>} />
      <div className="border border-t-0 border-border rounded-b-lg bg-background overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-12 text-center text-sm text-muted-foreground">A carregar notificações…</div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center">
            <Bell className="h-10 w-10 mx-auto text-muted-foreground/40 mb-3" />
            <p className="text-sm text-muted-foreground">Sem notificações para mostrar.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border/30">
            {filtered.map((n, i) => {
              const cfg = kindConfig[n.kind];
              const Icon = cfg.icon;
              const unread = !readIds.has(n.id);
              return (
                <li key={n.id}>
                  <button onClick={() => { markRead(n.id); navigate(n.href); }}
                    className={`w-full text-left flex items-start gap-3 px-5 py-3.5 hover:bg-primary/5 transition-colors ${unread ? "bg-primary/[0.03]" : ""} ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                    <div className={`h-9 w-9 rounded-lg ${cfg.bg} ${cfg.border} border flex items-center justify-center shrink-0`}>
                      <Icon className={`h-4 w-4 ${cfg.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        {unread && <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />}
                        <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{cfg.label}</span>
                        <span className="text-[10px] text-muted-foreground ml-auto">{formatDistanceToNow(new Date(n.date), { addSuffix: true, locale: pt })}</span>
                      </div>
                      <p className={`text-sm mt-0.5 truncate ${unread ? "font-semibold text-foreground" : "text-foreground/80"}`}>{n.title}</p>
                      {n.subtitle && <p className="text-xs text-muted-foreground truncate mt-0.5">{n.subtitle}</p>}
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground self-center shrink-0" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
