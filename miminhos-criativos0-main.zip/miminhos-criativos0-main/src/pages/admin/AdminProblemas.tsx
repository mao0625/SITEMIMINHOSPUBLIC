import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/admin/PageHeader";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { format, differenceInHours } from "date-fns";
import { pt } from "date-fns/locale";
import {
  Bug, AlertTriangle, HelpCircle, ArrowLeft, Send,
  Clock, CheckCircle2, AlertCircle, ChevronRight,
  Wrench, Plus, User, Calendar, Tag,
} from "lucide-react";

const TECH_EMAIL = "mao0625@outlook.pt";

const typeConfig: Record<string, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  bug: { label: "BUG", icon: Bug, color: "text-red-600", bg: "bg-red-50 border-red-200" },
  problema: { label: "Problema", icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-50 border-amber-200" },
  outro: { label: "Outro", icon: HelpCircle, color: "text-blue-600", bg: "bg-blue-50 border-blue-200" },
};

const statusConfig: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  pendente: { label: "Pendente", color: "bg-amber-50 text-amber-700 border-amber-200", icon: Clock },
  resolvido: { label: "Resolvido", color: "bg-blue-50 text-blue-700 border-blue-200", icon: AlertCircle },
  concluido: { label: "Concluído", color: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
};

// ─── SAP Toolbar ──────────────────────────────────────────────────────────────
const SapToolbar = ({ title, subtitle, onBack, backLabel = "Voltar", actions }: {
  title: string; subtitle?: string; onBack?: () => void; backLabel?: string; actions?: React.ReactNode;
}) => (
  <div className="bg-[#f7f3eb] dark:bg-muted/60 border border-border rounded-t-lg">
    <div className="flex items-center gap-3 px-4 py-2 border-b border-border/50">
      {onBack && (
        <>
          <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-primary font-semibold hover:underline shrink-0">
            <ArrowLeft className="h-3.5 w-3.5" />{backLabel}
          </button>
          <div className="h-4 w-px bg-border/60" />
        </>
      )}
      <div className="flex-1 min-w-0">
        <span className="font-bold text-sm">{title}</span>
        {subtitle && <span className="text-xs text-muted-foreground ml-3">{subtitle}</span>}
      </div>
      {actions && <div className="flex items-center gap-1.5 ml-auto">{actions}</div>}
    </div>
  </div>
);

// ─── SAP Row ──────────────────────────────────────────────────────────────────
const SapRow = ({ label, last, children }: { label: string; last?: boolean; children: React.ReactNode }) => (
  <div className={`flex items-start gap-0 ${!last ? "border-b border-border/40" : ""} hover:bg-primary/3 transition-colors`}>
    <span className="text-xs text-muted-foreground bg-muted/30 px-4 py-3 w-36 shrink-0 border-r border-border/30 font-medium">{label}</span>
    <div className="flex-1 px-4 py-2.5">{children}</div>
  </div>
);

// ─── Enviar Relatório ─────────────────────────────────────────────────────────
const EnviarRelatorio = ({ onBack, onSent, user, profile }: {
  onBack: () => void; onSent: () => void; user: any; profile: any;
}) => {
  const [form, setForm] = useState({ title: "", type: "bug", type_other: "", description: "" });
  const [sending, setSending] = useState(false);

  const enviar = async () => {
    if (!form.title.trim()) return toast.error("Título obrigatório");
    if (!form.description.trim()) return toast.error("Descrição obrigatória");
    if (form.type === "outro" && !form.type_other.trim()) return toast.error("Especifique o tipo de problema");

    setSending(true);
    const { error } = await supabase.from("bug_reports").insert({
      title: form.title,
      type: form.type,
      type_other: form.type === "outro" ? form.type_other : null,
      description: form.description,
      reporter_id: user.id,
      reporter_email: user.email,
      reporter_name: profile?.full_name || user.email?.split("@")[0] || "Desconhecido",
      status: "pendente",
    });
    setSending(false);
    if (error) { toast.error("Erro ao enviar: " + error.message); return; }
    toast.success("Relatório enviado ao técnico!");
    onSent();
  };

  return (
    <div>
      <SapToolbar
        title="Reportar Problema ao Técnico"
        subtitle="O técnico será notificado"
        onBack={onBack}
        backLabel="Problemas"
        actions={
          <>
            <Button size="sm" variant="outline" onClick={onBack} className="h-7 text-xs"><ArrowLeft className="h-3 w-3 mr-1" />Cancelar</Button>
            <Button size="sm" className="h-7 text-xs bg-gradient-gold" onClick={enviar} disabled={sending}>
              <Send className="h-3 w-3 mr-1" />{sending ? "A enviar…" : "Enviar ao Técnico"}
            </Button>
          </>
        }
      />
      <div className="border border-t-0 border-border rounded-b-lg bg-background">
        {/* Identificação */}
        <div className="flex items-center gap-6 px-5 py-2.5 bg-muted/20 border-b border-border/50 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground font-medium">Reportado por</span>
            <span className="text-xs font-bold text-primary">{profile?.full_name || user.email?.split("@")[0]}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground font-medium">Para</span>
            <span className="text-xs font-bold text-primary">{TECH_EMAIL}</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border/40">
          {/* Coluna esquerda */}
          <div>
            <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
              <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Detalhes do Problema</span>
            </div>

            {/* Título */}
            <div className="flex items-start border-b border-border/30 hover:bg-primary/3 transition-colors">
              <span className="text-xs text-muted-foreground bg-muted/30 px-4 py-3 w-36 shrink-0 border-r border-border/30 font-medium pt-3.5">Título *</span>
              <div className="flex-1 px-4 py-2.5">
                <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })}
                  placeholder="Resumo curto do problema…"
                  className="h-8 text-sm border-border/50 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/20" />
              </div>
            </div>

            {/* Tipo */}
            <div className="flex items-start border-b border-border/30">
              <span className="text-xs text-muted-foreground bg-muted/30 px-4 py-3 w-36 shrink-0 border-r border-border/30 font-medium pt-3.5">Tipo *</span>
              <div className="flex-1 px-4 py-3 space-y-2">
                <div className="flex gap-2">
                  {[
                    { key: "bug", label: "BUG", icon: Bug, color: "border-red-300 bg-red-50 text-red-700" },
                    { key: "problema", label: "Problema", icon: AlertTriangle, color: "border-amber-300 bg-amber-50 text-amber-700" },
                    { key: "outro", label: "Outro", icon: HelpCircle, color: "border-blue-300 bg-blue-50 text-blue-700" },
                  ].map(opt => (
                    <button key={opt.key} onClick={() => setForm({ ...form, type: opt.key })}
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg border-2 text-xs font-semibold transition-all ${form.type === opt.key ? `border-primary bg-primary/10 text-primary` : `border-border/50 text-muted-foreground hover:${opt.color}`}`}>
                      <opt.icon className="h-3.5 w-3.5" />{opt.label}
                    </button>
                  ))}
                </div>
                {form.type === "outro" && (
                  <Input value={form.type_other} onChange={e => setForm({ ...form, type_other: e.target.value })}
                    placeholder="Especifique o tipo…"
                    className="h-8 text-sm border-border/50 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/20" />
                )}
              </div>
            </div>

            {/* Descrição */}
            <div className="flex items-start border-border/30">
              <span className="text-xs text-muted-foreground bg-muted/30 px-4 py-3 w-36 shrink-0 border-r border-border/30 font-medium pt-3.5">Descrição *</span>
              <div className="flex-1 px-4 py-2.5">
                <Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                  rows={6} placeholder="Descreva o problema com o máximo de detalhe possível…&#10;&#10;Ex: Quando clico em X acontece Y, mas era esperado Z."
                  className="text-sm resize-none border-border/50 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/20" />
              </div>
            </div>
          </div>

          {/* Coluna direita — info */}
          <div>
            <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
              <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Informação do Reporte</span>
            </div>
            {[
              { label: "Reportado por", value: profile?.full_name || user.email?.split("@")[0] || "—" },
              { label: "Email", value: user.email || "—" },
              { label: "Data", value: format(new Date(), "dd/MM/yyyy HH:mm", { locale: pt }) },
              { label: "Enviado para", value: TECH_EMAIL },
              { label: "Estado inicial", value: "Pendente" },
            ].map((f, i, arr) => (
              <SapRow key={f.label} label={f.label} last={i === arr.length - 1}>
                <span className="text-sm font-medium">{f.value}</span>
              </SapRow>
            ))}

            <div className="m-4 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <p className="text-xs text-amber-700 dark:text-amber-300 flex items-start gap-2">
                <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                O técnico <strong>{TECH_EMAIL}</strong> receberá uma notificação imediata. Será notificado quando o problema for concluído.
              </p>
            </div>
          </div>
        </div>

        {/* Rodapé */}
        <div className="px-5 py-3 border-t border-border/40 bg-muted/10 flex gap-2 justify-end">
          <Button variant="outline" size="sm" onClick={onBack} className="h-8 text-xs"><ArrowLeft className="h-3.5 w-3.5 mr-1.5" />Cancelar</Button>
          <Button size="sm" className="h-8 text-xs bg-gradient-gold shadow-gold" onClick={enviar} disabled={sending}>
            <Send className="h-3.5 w-3.5 mr-1.5" />{sending ? "A enviar…" : "Enviar ao Técnico"}
          </Button>
        </div>
      </div>
    </div>
  );
};

// ─── Detalhe do Problema (Técnico) ────────────────────────────────────────────
const DetalheProblema = ({ report, onBack, onUpdated }: { report: any; onBack: () => void; onUpdated: () => void }) => {
  const [status, setStatus] = useState(report.status);
  const [saving, setSaving] = useState(false);

  const updateStatus = async (newStatus: string) => {
    setSaving(true);
    const patch: any = { status: newStatus };
    if (newStatus === "concluido") patch.concluded_at = new Date().toISOString();

    const { error } = await supabase.from("bug_reports").update(patch).eq("id", report.id);
    setSaving(false);
    if (error) { toast.error("Erro: " + error.message); return; }
    setStatus(newStatus);
    if (newStatus === "concluido") {
      toast.success(`Problema marcado como concluído. ${report.reporter_email ? `Notificação enviada a ${report.reporter_email}` : ""}`);
    } else {
      toast.success("Estado atualizado!");
    }
    onUpdated();
  };

  const sc = statusConfig[status] ?? statusConfig.pendente;
  const tc = typeConfig[report.type] ?? typeConfig.outro;

  return (
    <div>
      <SapToolbar
        title={`Problema: ${report.title}`}
        subtitle={`Reportado por ${report.reporter_name || "—"}`}
        onBack={onBack}
        backLabel="Lista de Problemas"
        actions={
          <div className="flex gap-1.5">
            {["pendente", "resolvido", "concluido"].map(s => (
              <button key={s} onClick={() => updateStatus(s)} disabled={saving || status === s}
                className={`h-7 px-3 text-xs rounded border font-medium transition-all capitalize ${status === s ? statusConfig[s].color + " border-current" : "border-border/50 text-muted-foreground hover:border-border hover:bg-muted/30"}`}>
                {statusConfig[s].label}
              </button>
            ))}
          </div>
        }
      />
      <div className="border border-t-0 border-border rounded-b-lg bg-background">
        {/* Cabeçalho */}
        <div className="flex items-center gap-6 px-5 py-2.5 bg-muted/20 border-b border-border/50 flex-wrap">
          <div className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded border ${tc.bg} ${tc.color}`}>
            <tc.icon className="h-3 w-3" />{report.type === "outro" ? (report.type_other || "Outro") : tc.label}
          </div>
          <div className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded border ${sc.color}`}>
            <sc.icon className="h-3 w-3" />{sc.label}
          </div>
          <span className="text-xs text-muted-foreground">{format(new Date(report.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: pt })}</span>
        </div>

        <div className="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border/40">
          {/* Detalhes */}
          <div>
            <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
              <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Detalhes do Problema</span>
            </div>
            <SapRow label="Título"><span className="text-sm font-bold">{report.title}</span></SapRow>
            <SapRow label="Tipo">
              <div className={`inline-flex items-center gap-1.5 text-xs font-bold px-2 py-0.5 rounded border ${tc.bg} ${tc.color}`}>
                <tc.icon className="h-3 w-3" />{report.type === "outro" ? (report.type_other || "Outro") : tc.label}
              </div>
            </SapRow>
            <SapRow label="Descrição" last>
              <p className="text-sm whitespace-pre-wrap leading-relaxed">{report.description}</p>
            </SapRow>
          </div>

          {/* Info */}
          <div>
            <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
              <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Informação do Reporte</span>
            </div>
            <SapRow label="Reportado por">
              <div className="flex items-center gap-2">
                <div className="h-6 w-6 rounded bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <span className="text-[10px] font-bold text-primary">{(report.reporter_name || "?").substring(0, 2).toUpperCase()}</span>
                </div>
                <div>
                  <p className="text-sm font-medium">{report.reporter_name || "—"}</p>
                  <p className="text-xs text-muted-foreground">{report.reporter_email || "—"}</p>
                </div>
              </div>
            </SapRow>
            <SapRow label="Data de Criação"><span className="text-sm font-mono">{format(new Date(report.created_at), "dd/MM/yyyy HH:mm:ss")}</span></SapRow>
            <SapRow label="Estado Atual">
              <div className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded border ${sc.color}`}>
                <sc.icon className="h-3 w-3" />{sc.label}
              </div>
            </SapRow>
            {report.concluded_at && (
              <SapRow label="Concluído em" last><span className="text-sm font-mono text-emerald-600">{format(new Date(report.concluded_at), "dd/MM/yyyy HH:mm")}</span></SapRow>
            )}
          </div>
        </div>

        {/* Mudança de estado */}
        <div className="px-5 py-4 border-t border-border/40 bg-muted/10">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3">Alterar Estado</p>
          <div className="flex gap-2 flex-wrap">
            {[
              { key: "pendente", label: "Pendente", desc: "Aguarda análise" },
              { key: "resolvido", label: "Resolvido", desc: "Em análise / corrigido" },
              { key: "concluido", label: "Concluído", desc: "Notifica o utilizador" },
            ].map(s => (
              <button key={s.key} onClick={() => updateStatus(s.key)} disabled={saving || status === s.key}
                className={`flex flex-col items-start px-4 py-3 rounded-lg border-2 text-left transition-all ${status === s.key ? "border-primary bg-primary/5" : "border-border/50 hover:border-border hover:bg-muted/20 disabled:opacity-50"}`}>
                <span className="text-xs font-bold">{s.label}</span>
                <span className="text-[10px] text-muted-foreground mt-0.5">{s.desc}</span>
              </button>
            ))}
          </div>
          {status !== "concluido" && (
            <p className="text-xs text-muted-foreground mt-3">
              Ao marcar como <strong>Concluído</strong>, o utilizador <strong>{report.reporter_email}</strong> recebe uma notificação. O reporte desaparecerá automaticamente após 24 horas.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Página Principal ─────────────────────────────────────────────────────────
const AdminProblemas = () => {
  const { user } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const [reports, setReports] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  const [view, setView] = useState<"list" | "reportar" | "detalhe">("list");
  const [selected, setSelected] = useState<any>(null);
  const [isTech, setIsTech] = useState(false);
  const [techMode, setTechMode] = useState(false);

  const load = async () => {
    const { data } = await supabase.from("bug_reports").select("*").order("created_at", { ascending: false });
    const filtered = (data ?? []).filter(r => {
      if (r.status === "concluido" && r.concluded_at) {
        return differenceInHours(new Date(), new Date(r.concluded_at)) < 24;
      }
      return true;
    });
    setReports(filtered);
  };

  useEffect(() => {
    if (!user) return;
    setIsTech(user.email === TECH_EMAIL);
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => setProfile(data));
    load();

    const ch = supabase.channel("bug_reports_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "bug_reports" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const myReports = reports.filter(r => r.reporter_id === user?.id);
  const allReports = reports;

  if (view === "reportar") return (
    <EnviarRelatorio user={user} profile={profile} onBack={() => setView("list")} onSent={() => { setView("list"); load(); }} />
  );

  if (view === "detalhe" && selected) return (
    <DetalheProblema report={selected} onBack={() => setView("list")} onUpdated={() => { load(); setView("list"); }} />
  );

  const displayReports = techMode ? allReports : myReports;

  return (
    <div>
      <PageHeader
        title="Problemas e Suporte"
        description="Reporte erros e problemas ao técnico do sistema."
        action={
          <div className="flex gap-2">
            {isTech && (
              <Button size="sm" variant={techMode ? "default" : "outline"}
                onClick={() => setTechMode(v => !v)}
                className={`h-8 text-xs ${techMode ? "bg-primary text-primary-foreground" : "border-primary/30 text-primary hover:bg-primary/5"}`}>
                <Wrench className="h-3.5 w-3.5 mr-1.5" />
                {techMode ? "Vista Técnica Ativa" : "Técnico"}
              </Button>
            )}
            <Button size="sm" className="h-8 text-xs bg-gradient-gold shadow-gold" onClick={() => setView("reportar")}>
              <Plus className="h-3.5 w-3.5 mr-1.5" />Reportar Problema
            </Button>
          </div>
        }
      />

      {techMode && isTech && (
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { label: "Pendentes", value: allReports.filter(r => r.status === "pendente").length, color: "text-amber-600", bg: "border-amber-200" },
            { label: "Resolvidos", value: allReports.filter(r => r.status === "resolvido").length, color: "text-blue-600", bg: "border-blue-200" },
            { label: "Concluídos", value: allReports.filter(r => r.status === "concluido").length, color: "text-emerald-600", bg: "border-emerald-200" },
          ].map(s => (
            <div key={s.label} className={`bg-card border ${s.bg} rounded-lg px-4 py-3 shadow-sm`}>
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>
      )}

      <SapToolbar
        title={techMode ? "Vista Técnica — Todos os Problemas" : "Os Meus Reportes"}
        subtitle={`${displayReports.length} reporte${displayReports.length !== 1 ? "s" : ""}`}
      />
      <div className="border border-t-0 border-border rounded-b-lg bg-background overflow-hidden shadow-sm">
        <div className="grid grid-cols-[2fr_1fr_1fr_1fr_auto] gap-4 px-5 py-2 bg-[#f7f3eb] dark:bg-muted/40 border-b border-border text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
          <span>Título</span>
          <span>Tipo</span>
          {techMode && <span>Reportado por</span>}
          {!techMode && <span>Data</span>}
          <span>Estado</span>
          <span />
        </div>

        {displayReports.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <Bug className="h-10 w-10 mx-auto mb-3 opacity-20" />
            <p className="text-sm">{techMode ? "Sem problemas reportados." : "Ainda não reportou nenhum problema."}</p>
            <button onClick={() => setView("reportar")} className="text-xs text-primary hover:underline mt-2">
              Reportar um problema agora
            </button>
          </div>
        )}

        {displayReports.map((r, i) => {
          const tc = typeConfig[r.type] ?? typeConfig.outro;
          const sc = statusConfig[r.status] ?? statusConfig.pendente;
          return (
            <div key={r.id}
              onClick={() => { if (techMode && isTech) { setSelected(r); setView("detalhe"); } }}
              className={`grid grid-cols-[2fr_1fr_1fr_1fr_auto] gap-4 px-5 py-3.5 items-center border-b border-border/30 last:border-0 transition-colors ${techMode && isTech ? "cursor-pointer hover:bg-primary/5 group" : "hover:bg-muted/20"} ${i % 2 === 0 ? "" : "bg-muted/10"}`}>

              <div className="min-w-0">
                <p className={`text-sm font-semibold truncate ${techMode && isTech ? "group-hover:text-primary transition-colors" : ""}`}>{r.title}</p>
                <p className="text-xs text-muted-foreground truncate mt-0.5">{r.description.substring(0, 60)}…</p>
              </div>

              <div className={`inline-flex items-center gap-1.5 text-xs font-bold px-2 py-0.5 rounded border self-start w-fit ${tc.bg} ${tc.color}`}>
                <tc.icon className="h-3 w-3" />
                {r.type === "outro" ? (r.type_other || "Outro") : tc.label}
              </div>

              {techMode ? (
                <div className="flex items-center gap-2 min-w-0">
                  <div className="h-6 w-6 rounded bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                    <span className="text-[9px] font-bold text-primary">{(r.reporter_name || "?").substring(0, 2).toUpperCase()}</span>
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-medium truncate">{r.reporter_name || "—"}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{format(new Date(r.created_at), "dd/MM HH:mm")}</p>
                  </div>
                </div>
              ) : (
                <span className="text-xs text-muted-foreground">{format(new Date(r.created_at), "dd/MM/yyyy HH:mm", { locale: pt })}</span>
              )}

              <div className={`inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded border self-start w-fit ${sc.color}`}>
                <sc.icon className="h-3 w-3" />{sc.label}
              </div>

              {techMode && isTech && (
                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
              )}
              {!techMode && <span />}
            </div>
          );
        })}
      </div>

      {!techMode && (
        <p className="text-xs text-muted-foreground mt-3 text-center">
          Os reportes concluídos desaparecem automaticamente 24 horas após conclusão.
        </p>
      )}
    </div>
  );
};

export default AdminProblemas;
