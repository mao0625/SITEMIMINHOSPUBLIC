import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { toast } from "sonner";
import {
  Plus, Edit, Trash2, Calendar as CalIcon, ArrowLeft, Save, X,
  ChevronRight, Package, Check, Search, Users, MapPin, Euro,
  ClipboardList, UserCheck, Building2, Activity, Clock,
  CheckCircle2, AlertCircle, Tag, Info,
} from "lucide-react";

const STATUS = ["planeamento", "confirmado", "em_curso", "concluido", "cancelado"];
const TYPES = ["Casamento", "Batismo", "Aniversário", "Comunhão", "Evento Corporativo", "Festa Temática", "Outro"];

const statusConfig: Record<string, { label: string; color: string; icon: React.ElementType; dot: string; ring: string }> = {
  planeamento: { label: "Planeamento", color: "bg-blue-50 text-blue-700 border-blue-200",     icon: Clock,        dot: "bg-blue-400",    ring: "ring-blue-200"    },
  confirmado:  { label: "Confirmado",  color: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2, dot: "bg-emerald-500", ring: "ring-emerald-200" },
  em_curso:    { label: "Em Curso",    color: "bg-violet-50 text-violet-700 border-violet-200", icon: Activity,     dot: "bg-violet-500",  ring: "ring-violet-200"  },
  concluido:   { label: "Concluído",   color: "bg-slate-50 text-slate-600 border-slate-200",   icon: Check,        dot: "bg-slate-400",   ring: "ring-slate-200"   },
  cancelado:   { label: "Cancelado",   color: "bg-red-50 text-red-700 border-red-200",         icon: X,            dot: "bg-red-400",     ring: "ring-red-200"     },
};

const empty = {
  title: "", event_type: "", event_type_other: "", event_date: "", event_time: "",
  location: "", delivery_address: "", guests_count: "", budget: "",
  client_id: "", assigned_collaborator_id: "", notes: "", status: "planeamento",
};

type Material        = { id: string; name: string; category: string | null; unit: string | null; quantity: number };
type SelectedMaterial = { material_id: string; quantity_needed: number };

// ─── Status Badge ─────────────────────────────────────────────────────────────
const StatusBadge = ({ status }: { status: string }) => {
  const cfg = statusConfig[status] ?? statusConfig.planeamento;
  return (
    <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2.5 py-[3px] rounded-full border ${cfg.color}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
};

// ─── Materiais Page ───────────────────────────────────────────────────────────
const MateriaisPage = ({
  materials, selected, onBack, onSave,
}: {
  materials: Material[]; selected: SelectedMaterial[];
  onBack: () => void; onSave: (sel: SelectedMaterial[]) => void;
}) => {
  const [local, setLocal]   = useState<SelectedMaterial[]>(selected);
  const [search, setSearch] = useState("");

  const filtered   = materials.filter(m => m.name.toLowerCase().includes(search.toLowerCase()) || (m.category ?? "").toLowerCase().includes(search.toLowerCase()));
  const categories = Array.from(new Set(materials.map(m => m.category ?? "Outro")));
  const isSel      = (id: string) => local.some(s => s.material_id === id);
  const toggle     = (mat: Material) => isSel(mat.id) ? setLocal(l => l.filter(s => s.material_id !== mat.id)) : setLocal(l => [...l, { material_id: mat.id, quantity_needed: 1 }]);
  const setQty     = (id: string, qty: number) => setLocal(l => l.map(s => s.material_id === id ? { ...s, quantity_needed: qty } : s));

  return (
    <div className="max-w-5xl mx-auto space-y-0 animate-in fade-in duration-300">
      {/* Topbar */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors">
          <ArrowLeft className="h-4 w-4" /> Voltar ao Evento
        </button>
        <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/40" />
        <span className="text-sm font-semibold text-foreground">Materiais Necessários</span>
        <div className="flex-1" />
        <span className="text-xs text-muted-foreground">{local.length} selecionados</span>
        <Button size="sm" className="bg-gradient-gold h-8 text-xs px-4" onClick={() => { onSave(local); onBack(); }}>
          <Save className="h-3.5 w-3.5 mr-1.5" /> Guardar
        </Button>
      </div>

      <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
        {/* Search */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-muted/20">
          <div className="flex items-center gap-2.5 bg-background border border-border rounded-xl px-3.5 py-2 flex-1 max-w-sm">
            <Search className="h-4 w-4 text-muted-foreground shrink-0" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Pesquisar materiais…"
              className="bg-transparent text-sm outline-none flex-1 placeholder:text-muted-foreground/50" />
          </div>
          {local.length > 0 && (
            <span className="text-xs bg-primary/10 text-primary border border-primary/20 px-3 py-1.5 rounded-full font-medium">
              {local.length} {local.length === 1 ? "material" : "materiais"}
            </span>
          )}
        </div>

        <div className="grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
          {/* Catálogo */}
          <div>
            <div className="px-5 py-3 border-b border-border">
              <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Catálogo</p>
            </div>
            {categories.map(cat => {
              const catMats = filtered.filter(m => (m.category ?? "Outro") === cat);
              if (!catMats.length) return null;
              return (
                <div key={cat}>
                  <div className="px-5 py-2 bg-muted/10 border-b border-border/40">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{cat}</p>
                  </div>
                  {catMats.map(mat => {
                    const sel = local.find(s => s.material_id === mat.id);
                    return (
                      <div key={mat.id} onClick={() => toggle(mat)}
                        className={`flex items-center gap-3.5 px-5 py-3.5 border-b border-border/20 last:border-0 transition-colors cursor-pointer ${sel ? "bg-primary/5" : "hover:bg-muted/30"}`}>
                        <div className={`h-5 w-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all ${sel ? "bg-primary border-primary" : "border-border"}`}>
                          {sel && <Check className="h-3 w-3 text-white" strokeWidth={3} />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{mat.name}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">Stock: {mat.quantity} {mat.unit}</p>
                        </div>
                        {sel && (
                          <div className="flex items-center gap-1.5 shrink-0" onClick={e => e.stopPropagation()}>
                            <button onClick={() => setQty(mat.id, Math.max(1, sel.quantity_needed - 1))}
                              className="h-6 w-6 rounded-md border border-border flex items-center justify-center text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors">−</button>
                            <input type="number" min={1} value={sel.quantity_needed}
                              onChange={e => setQty(mat.id, Math.max(1, Number(e.target.value)))}
                              className="w-10 h-6 text-center text-sm font-semibold border border-border rounded-md bg-background focus:outline-none focus:border-primary" />
                            <button onClick={() => setQty(mat.id, sel.quantity_needed + 1)}
                              className="h-6 w-6 rounded-md border border-border flex items-center justify-center text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors">+</button>
                            <span className="text-xs text-muted-foreground w-7">{mat.unit}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
            {filtered.length === 0 && (
              <div className="text-center py-16 text-muted-foreground">
                <Package className="h-8 w-8 mx-auto mb-3 opacity-20" />
                <p className="text-sm">Nenhum material encontrado.</p>
              </div>
            )}
          </div>

          {/* Seleção */}
          <div>
            <div className="px-5 py-3 border-b border-border">
              <p className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">Seleção Atual</p>
            </div>
            {local.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground">
                <Package className="h-8 w-8 mx-auto mb-3 opacity-20" />
                <p className="text-sm">Nenhum material selecionado.</p>
              </div>
            ) : (
              <>
                {local.map(sel => {
                  const mat = materials.find(m => m.id === sel.material_id);
                  if (!mat) return null;
                  return (
                    <div key={sel.material_id} className="flex items-center gap-3.5 px-5 py-3.5 border-b border-border/20 hover:bg-muted/20 transition-colors">
                      <div className="h-6 w-6 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                        <Check className="h-3.5 w-3.5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{mat.name}</p>
                        <p className="text-xs text-muted-foreground">{mat.category}</p>
                      </div>
                      <span className="text-sm font-bold text-primary">{sel.quantity_needed}</span>
                      <span className="text-xs text-muted-foreground">{mat.unit}</span>
                      <button onClick={() => setLocal(l => l.filter(s => s.material_id !== sel.material_id))}
                        className="text-muted-foreground hover:text-destructive transition-colors p-1 rounded-md">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
                <div className="px-5 py-3 bg-muted/10">
                  <p className="text-xs text-muted-foreground">{local.length} {local.length === 1 ? "material selecionado" : "materiais selecionados"}</p>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="px-5 py-4 border-t border-border bg-muted/10 flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onBack} className="h-8 text-xs">Cancelar</Button>
          <Button size="sm" className="h-8 text-xs bg-gradient-gold" onClick={() => { onSave(local); onBack(); }}>
            <Save className="h-3.5 w-3.5 mr-1.5" /> Guardar ({local.length})
          </Button>
        </div>
      </div>
    </div>
  );
};

// ─── Field Row ────────────────────────────────────────────────────────────────
const FieldRow = ({ label, required, hint, children }: {
  label: string; required?: boolean; hint?: string; children: React.ReactNode;
}) => (
  <div className="grid grid-cols-[180px_1fr] gap-6 px-6 py-4 items-start border-b border-border/40 last:border-0 hover:bg-muted/20 transition-colors group">
    <div className="pt-[7px]">
      <p className="text-sm text-foreground font-medium leading-none">
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </p>
      {hint && <p className="text-[11px] text-muted-foreground mt-1 leading-tight">{hint}</p>}
    </div>
    <div className="min-w-0">{children}</div>
  </div>
);

// ─── Card Section ─────────────────────────────────────────────────────────────
const Card = ({ icon: Icon, title, children, action, noDivide }: {
  icon: React.ElementType; title: string; children: React.ReactNode; action?: React.ReactNode; noDivide?: boolean;
}) => (
  <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
    <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-muted/20">
      <div className="flex items-center gap-2.5">
        <div className="h-7 w-7 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="h-3.5 w-3.5 text-primary" />
        </div>
        <span className="text-sm font-semibold text-foreground">{title}</span>
      </div>
      {action}
    </div>
    <div className={noDivide ? "" : "divide-y divide-border/30"}>{children}</div>
  </div>
);

// ─── Evento Form ──────────────────────────────────────────────────────────────
const EventoForm = ({
  edit, clients, collabs, onBack, onSubmit, onOpenMaterials, selectedMaterials, allMaterials, onRemoveMaterial,
}: {
  edit: any; clients: any[]; collabs: any[];
  onBack: () => void; onSubmit: (form: any) => Promise<void>;
  onOpenMaterials: () => void; selectedMaterials: SelectedMaterial[]; allMaterials: Material[];
  onRemoveMaterial: (id: string) => void;
}) => {
  const [form, setForm]   = useState<any>(edit ? { ...empty, ...edit, event_date: edit.event_date || "", client_id: edit.client_id || "", assigned_collaborator_id: edit.assigned_collaborator_id || "", guests_count: edit.guests_count ?? "", budget: edit.budget ?? "", event_type_other: edit.event_type_other || "" } : empty);
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    if (!form.title.trim()) return toast.error("O título do evento é obrigatório.");
    if (form.event_type === "Outro" && !form.event_type_other.trim()) return toast.error("Especifique o tipo de evento.");
    setSaving(true); await onSubmit(form); setSaving(false);
  };

  const matById = Object.fromEntries(allMaterials.map(m => [m.id, m]));

  return (
    <div className="max-w-5xl mx-auto animate-in fade-in duration-300">

      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6">
        <button onClick={onBack} className="hover:text-primary transition-colors">Eventos</button>
        <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/40" />
        <span className="text-foreground font-medium">{edit ? "Editar Evento" : "Novo Evento"}</span>
      </nav>

      {/* Top action bar */}
      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-foreground truncate">
            {edit ? edit.title || "Editar Evento" : "Marcar Novo Evento"}
          </h1>
          {edit && <p className="text-sm text-muted-foreground mt-0.5">ID: <span className="font-mono text-xs">{edit.id?.slice(0, 8)}…</span></p>}
        </div>
        <Button variant="outline" size="sm" onClick={onBack} className="h-9 text-sm gap-1.5">
          <X className="h-3.5 w-3.5" /> Cancelar
        </Button>
        <Button size="sm" className="h-9 text-sm bg-gradient-gold gap-1.5 px-5" onClick={handleSubmit} disabled={saving}>
          {saving ? <span className="animate-pulse">A guardar…</span> : <><Save className="h-3.5 w-3.5" />{edit ? "Guardar" : "Criar Evento"}</>}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-5">

        {/* ── Main ── */}
        <div className="space-y-4">

          {/* Informações Principais */}
          <Card icon={ClipboardList} title="Informações Principais">
            <FieldRow label="Título" required hint="Nome descritivo do evento">
              <Input value={form.title} onChange={e => set("title", e.target.value)}
                placeholder="Ex: Casamento Ana & João"
                className="h-10 text-sm rounded-xl border-border/60 bg-background focus-visible:ring-1 focus-visible:ring-primary/30" />
            </FieldRow>

            <FieldRow label="Tipo de Evento" hint="Categoria do evento">
              <div className="space-y-3">
                <div className="flex gap-2 flex-wrap">
                  {TYPES.map(t => (
                    <button key={t} onClick={() => set("event_type", form.event_type === t ? "" : t)}
                      className={`text-sm px-3.5 py-1.5 rounded-xl border transition-all font-medium ${form.event_type === t ? "border-primary bg-primary/10 text-primary" : "border-border/60 text-muted-foreground hover:border-border hover:text-foreground bg-background"}`}>
                      {t}
                    </button>
                  ))}
                </div>
                {form.event_type === "Outro" && (
                  <div className="flex items-center gap-2.5 animate-in fade-in slide-in-from-top-1 duration-200">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/40 border border-border/50 rounded-lg px-2.5 py-2 shrink-0">
                      <Tag className="h-3 w-3" /> Qual o tipo?
                    </div>
                    <Input value={form.event_type_other} onChange={e => set("event_type_other", e.target.value)}
                      placeholder="Ex: Formatura, Gala, Retiro…"
                      className="h-9 text-sm flex-1 rounded-xl" autoFocus />
                  </div>
                )}
              </div>
            </FieldRow>

            <FieldRow label="Data & Hora">
              <div className="flex items-center gap-3">
                <Input type="date" value={form.event_date} onChange={e => set("event_date", e.target.value)}
                  className="w-44 h-10 text-sm rounded-xl" />
                <Input type="time" value={form.event_time} onChange={e => set("event_time", e.target.value)}
                  className="w-32 h-10 text-sm rounded-xl" />
              </div>
            </FieldRow>

            <FieldRow label="Estado">
              <div className="flex gap-2 flex-wrap">
                {STATUS.map(s => {
                  const cfg = statusConfig[s]; const active = form.status === s;
                  return (
                    <button key={s} onClick={() => set("status", s)}
                      className={`flex items-center gap-1.5 text-sm px-3.5 py-1.5 rounded-xl border transition-all font-medium ${active ? cfg.color + " ring-1 " + cfg.ring : "border-border/60 text-muted-foreground hover:border-border bg-background"}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />{cfg.label}
                    </button>
                  );
                })}
              </div>
            </FieldRow>
          </Card>

          {/* Local & Logística */}
          <Card icon={MapPin} title="Local & Logística">
            <FieldRow label="Local do Evento">
              <Input value={form.location} onChange={e => set("location", e.target.value)}
                placeholder="Quinta, hotel, espaço…" className="h-10 text-sm rounded-xl" />
            </FieldRow>
            <FieldRow label="Morada de Entrega">
              <Input value={form.delivery_address} onChange={e => set("delivery_address", e.target.value)}
                placeholder="Rua, n.º, código postal…" className="h-10 text-sm rounded-xl" />
            </FieldRow>
            <div className="grid grid-cols-2 divide-x divide-border/40">
              <div className="px-6 py-4 flex items-center gap-4">
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-1.5"><Users className="h-3.5 w-3.5 text-muted-foreground" />Convidados</p>
                  <div className="flex items-center gap-2">
                    <Input type="number" value={form.guests_count} onChange={e => set("guests_count", e.target.value)}
                      placeholder="0" className="w-28 h-10 text-sm rounded-xl" />
                    <span className="text-sm text-muted-foreground">pax</span>
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 flex items-center gap-4">
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-1.5"><Euro className="h-3.5 w-3.5 text-muted-foreground" />Orçamento</p>
                  <div className="flex items-center gap-2">
                    <Input type="number" step="0.01" value={form.budget} onChange={e => set("budget", e.target.value)}
                      placeholder="0.00" className="w-36 h-10 text-sm rounded-xl" />
                    <span className="text-sm text-muted-foreground">€</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Envolvidos */}
          <Card icon={UserCheck} title="Envolvidos">
            <FieldRow label="Cliente">
              <select className="w-full border border-border/60 bg-background rounded-xl h-10 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 focus:border-primary"
                value={form.client_id} onChange={e => set("client_id", e.target.value)}>
                <option value="">— Sem cliente associado —</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.full_name || c.email}</option>)}
              </select>
            </FieldRow>
            <FieldRow label="Colaborador">
              <select className="w-full border border-border/60 bg-background rounded-xl h-10 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 focus:border-primary"
                value={form.assigned_collaborator_id} onChange={e => set("assigned_collaborator_id", e.target.value)}>
                <option value="">— Não atribuído —</option>
                {collabs.map(c => <option key={c.id} value={c.id}>{c.full_name || c.email}</option>)}
              </select>
            </FieldRow>
          </Card>

          {/* Materiais */}
          <Card icon={Package} title="Materiais Necessários"
            action={
              <button onClick={onOpenMaterials}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-primary/30 text-primary hover:bg-primary/10 transition-colors font-medium">
                <Package className="h-3.5 w-3.5" />
                {selectedMaterials.length > 0 ? `Gerir (${selectedMaterials.length})` : "Selecionar"}
              </button>
            } noDivide>
            {selectedMaterials.length === 0 ? (
              <div className="px-6 py-10 text-center">
                <div className="h-12 w-12 rounded-2xl bg-muted/50 flex items-center justify-center mx-auto mb-3">
                  <Package className="h-5 w-5 text-muted-foreground/40" />
                </div>
                <p className="text-sm text-muted-foreground font-medium">Nenhum material selecionado</p>
                <button onClick={onOpenMaterials} className="text-xs text-primary hover:underline mt-2">Clique para adicionar materiais</button>
              </div>
            ) : (
              <div className="divide-y divide-border/30">
                {selectedMaterials.map(sel => {
                  const mat = matById[sel.material_id]; if (!mat) return null;
                  return (
                    <div key={sel.material_id} className="flex items-center gap-4 px-6 py-3.5 hover:bg-muted/20 transition-colors">
                      <div className="h-7 w-7 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                        <Check className="h-3.5 w-3.5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{mat.name}</p>
                        {mat.category && <p className="text-xs text-muted-foreground">{mat.category}</p>}
                      </div>
                      <span className="text-sm font-bold text-primary">{sel.quantity_needed}</span>
                      <span className="text-xs text-muted-foreground">{mat.unit}</span>
                      <button onClick={() => onRemoveMaterial(sel.material_id)}
                        className="text-muted-foreground hover:text-destructive transition-colors p-1 rounded-md">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
                <div className="px-6 py-3">
                  <button onClick={onOpenMaterials} className="text-xs text-primary hover:underline flex items-center gap-1">
                    <Plus className="h-3 w-3" /> Adicionar / remover materiais
                  </button>
                </div>
              </div>
            )}
          </Card>

          {/* Notas */}
          <Card icon={Building2} title="Notas Internas" noDivide>
            <div className="p-6">
              <Textarea rows={4} value={form.notes} onChange={e => set("notes", e.target.value)}
                placeholder="Requisitos especiais, contactos de fornecedores, observações…"
                className="resize-none text-sm rounded-xl" />
            </div>
          </Card>
        </div>

        {/* ── Sidebar ── */}
        <div className="space-y-4">
          {/* Sticky summary */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm sticky top-4">
            <div className="px-5 py-4 border-b border-border bg-muted/20">
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Resumo</p>
            </div>
            <div className="px-5 py-1">
              {[
                { label: "Título",      value: form.title || "—" },
                { label: "Tipo",        value: form.event_type === "Outro" ? (form.event_type_other || "Outro") : (form.event_type || "—") },
                { label: "Data",        value: form.event_date ? format(new Date(form.event_date), "dd/MM/yyyy") : "—" },
                { label: "Local",       value: form.location || "—" },
                { label: "Convidados",  value: form.guests_count ? `${form.guests_count} pax` : "—" },
                { label: "Orçamento",   value: form.budget ? `${Number(form.budget).toFixed(2)} €` : "—" },
                { label: "Materiais",   value: `${selectedMaterials.length} selecionados` },
              ].map(f => (
                <div key={f.label} className="flex justify-between items-center py-3 border-b border-border/30 last:border-0">
                  <span className="text-xs text-muted-foreground">{f.label}</span>
                  <span className="text-xs font-semibold text-right max-w-[140px] truncate">{f.value}</span>
                </div>
              ))}
              <div className="flex justify-between items-center py-3">
                <span className="text-xs text-muted-foreground">Estado</span>
                <StatusBadge status={form.status} />
              </div>
            </div>
            <div className="p-4 border-t border-border">
              <Button onClick={handleSubmit} disabled={saving} className="w-full bg-gradient-gold h-10 text-sm rounded-xl">
                <Save className="h-4 w-4 mr-2" />
                {saving ? "A guardar…" : edit ? "Guardar Alterações" : "Criar Evento"}
              </Button>
            </div>
          </div>

          {/* Tipo personalizado hint */}
          {form.event_type === "Outro" && form.event_type_other && (
            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 rounded-2xl p-4">
              <div className="flex gap-2.5">
                <Info className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700">Tipo personalizado: <strong>{form.event_type_other}</strong></p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Admin Eventos ────────────────────────────────────────────────────────────
const AdminEventos = () => {
  const [items,             setItems]             = useState<any[]>([]);
  const [clients,           setClients]           = useState<any[]>([]);
  const [collabs,           setCollabs]           = useState<any[]>([]);
  const [allMaterials,      setAllMaterials]      = useState<Material[]>([]);
  const [selectedMaterials, setSelectedMaterials] = useState<SelectedMaterial[]>([]);
  const [view,              setView]              = useState<"list" | "form" | "materiais">("list");
  const [editItem,          setEditItem]          = useState<any>(null);
  const [filter,            setFilter]            = useState<string>("all");
  const [search,            setSearch]            = useState("");

  const load = async () => {
    const { data } = await supabase.from("events").select("*").order("event_date", { ascending: true });
    setItems(data ?? []);
    supabase.from("materials").select("*").order("name").then(({ data }) => setAllMaterials((data ?? []) as Material[]));
    const [{ data: cliRoles }, { data: colRoles }] = await Promise.all([
      supabase.from("user_roles").select("user_id").eq("role", "cliente"),
      supabase.from("user_roles").select("user_id").eq("role", "colaborador"),
    ]);
    const cliIds = (cliRoles ?? []).map(r => r.user_id);
    const colIds = (colRoles ?? []).map(r => r.user_id);
    const allIds = Array.from(new Set([...cliIds, ...colIds]));
    if (allIds.length) {
      const { data: profs } = await supabase.from("profiles").select("id,full_name,email").in("id", allIds);
      setClients((profs ?? []).filter(p => cliIds.includes(p.id)));
      setCollabs((profs ?? []).filter(p => colIds.includes(p.id)));
    }
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (form: any) => {
    const payload: any = { ...form };
    if (!payload.client_id) payload.client_id = null;
    if (!payload.assigned_collaborator_id) payload.assigned_collaborator_id = null;
    if (!payload.event_date) payload.event_date = null;
    payload.guests_count = payload.guests_count ? Number(payload.guests_count) : null;
    payload.budget = payload.budget ? Number(payload.budget) : null;
    delete payload.event_time; delete payload.created_at; delete payload.updated_at; delete payload.id;
    const res = editItem
      ? await supabase.from("events").update(payload).eq("id", editItem.id)
      : await supabase.from("events").insert(payload);
    if (res.error) { toast.error(res.error.message); return; }
    if (selectedMaterials.length) {
      const eventId = editItem?.id ?? (await supabase.from("events").select("id").order("created_at", { ascending: false }).limit(1).single()).data?.id;
      if (eventId) {
        if (editItem) await (supabase as any).from("event_materials").delete().eq("event_id", eventId);
        await (supabase as any).from("event_materials").insert(selectedMaterials.map(m => ({ event_id: eventId, material_id: m.material_id, quantity_needed: m.quantity_needed })));
      }
    }
    toast.success(editItem ? "Evento atualizado!" : "Evento criado!");
    setView("list"); setEditItem(null); setSelectedMaterials([]); load();
  };

  const remove = async (id: string) => {
    if (!confirm("Eliminar este evento?")) return;
    await supabase.from("events").delete().eq("id", id); load();
  };

  const updateStatus = async (id: string, status: string) => {
    await supabase.from("events").update({ status }).eq("id", id); load();
  };

  if (view === "materiais") return <MateriaisPage materials={allMaterials} selected={selectedMaterials} onBack={() => setView("form")} onSave={setSelectedMaterials} />;
  if (view === "form")      return <EventoForm edit={editItem} clients={clients} collabs={collabs} onBack={() => { setView("list"); setEditItem(null); setSelectedMaterials([]); }} onSubmit={handleSubmit} onOpenMaterials={() => setView("materiais")} selectedMaterials={selectedMaterials} allMaterials={allMaterials} onRemoveMaterial={id => setSelectedMaterials(l => l.filter(s => s.material_id !== id))} />;

  const profilesById: Record<string, any> = Object.fromEntries([...clients, ...collabs].map(p => [p.id, p]));
  const filtered = items.filter(i => {
    const matchStatus = filter === "all" || i.status === filter;
    const matchSearch = !search || i.title?.toLowerCase().includes(search.toLowerCase()) || i.location?.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">

      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold">Gestão de Eventos</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Painel central de coordenação e agenda.</p>
        </div>
        <Button onClick={() => { setEditItem(null); setSelectedMaterials([]); setView("form"); }}
          className="bg-gradient-gold shadow-sm hover:shadow-md transition-all h-9 px-4 text-sm gap-2">
          <Plus className="h-4 w-4" /> Marcar Evento
        </Button>
      </div>

      {/* KPI cards */}
      {items.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Total */}
          <div className="bg-card border border-border rounded-2xl px-4 py-4 shadow-sm col-span-1">
            <p className="text-[11px] font-medium text-muted-foreground mb-1">Total</p>
            <p className="text-3xl font-bold tracking-tight">{items.length}</p>
          </div>
          {STATUS.map(s => {
            const cfg = statusConfig[s]; const count = items.filter(i => i.status === s).length;
            return (
              <button key={s} onClick={() => setFilter(filter === s ? "all" : s)}
                className={`bg-card border rounded-2xl px-4 py-4 shadow-sm text-left transition-all hover:shadow-md ${filter === s ? "border-primary ring-2 ring-primary/20" : "border-border hover:border-primary/40"}`}>
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span className={`h-2 w-2 rounded-full ${cfg.dot}`} />
                  <p className="text-[11px] font-medium text-muted-foreground">{cfg.label}</p>
                </div>
                <p className="text-3xl font-bold tracking-tight">{count}</p>
              </button>
            );
          })}
        </div>
      )}

      {/* Filter + Search bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48 max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Pesquisar eventos…"
            className="w-full h-10 pl-10 pr-4 text-sm rounded-xl border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/40 transition-all" />
        </div>

        <div className="flex items-center gap-1 bg-muted/40 rounded-xl p-1 border border-border">
          <button onClick={() => setFilter("all")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${filter === "all" ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            Todos
          </button>
          {STATUS.map(s => (
            <button key={s} onClick={() => setFilter(filter === s ? "all" : s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${filter === s ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
              {statusConfig[s].label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">

        {/* Column headers */}
        <div className="grid grid-cols-[2fr_1fr_1fr_140px_80px] gap-4 px-6 py-3.5 border-b border-border bg-muted/20">
          {["Evento", "Data & Local", "Envolvidos", "Estado", ""].map((h, i) => (
            <span key={i} className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">{h}</span>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="h-16 w-16 rounded-3xl bg-muted/40 flex items-center justify-center mx-auto mb-4">
              <CalIcon className="h-7 w-7 text-muted-foreground/30" />
            </div>
            <p className="font-semibold text-base">Nenhum evento encontrado</p>
            <p className="text-sm text-muted-foreground mt-1 mb-5">Ajuste os filtros ou crie um novo evento.</p>
            <Button size="sm" onClick={() => { setEditItem(null); setView("form"); }} className="bg-gradient-gold gap-2">
              <Plus className="h-4 w-4" /> Marcar primeiro evento
            </Button>
          </div>
        ) : (
          filtered.map((e, i) => {
            const cfg = statusConfig[e.status] ?? statusConfig.planeamento;
            const typeLabel = e.event_type === "Outro" ? (e.event_type_other || "Outro") : e.event_type;
            return (
              <div key={e.id}
                className={`grid grid-cols-[2fr_1fr_1fr_140px_80px] gap-4 px-6 py-4 items-center border-b border-border/40 last:border-0 hover:bg-muted/30 transition-colors group ${i % 2 === 1 ? "bg-muted/5" : ""}`}>

                {/* Evento */}
                <div className="min-w-0">
                  <p className="font-semibold text-sm truncate group-hover:text-primary transition-colors">{e.title}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    {typeLabel && (
                      <span className="text-[11px] bg-muted/60 border border-border/60 px-2 py-0.5 rounded-md text-muted-foreground font-medium">{typeLabel}</span>
                    )}
                    {e.guests_count && <span className="text-[11px] text-muted-foreground">{e.guests_count} conv.</span>}
                    {e.budget && <span className="text-[11px] text-muted-foreground">{Number(e.budget).toFixed(0)} €</span>}
                  </div>
                </div>

                {/* Data & Local */}
                <div>
                  <p className="text-sm font-medium">{e.event_date ? format(new Date(e.event_date), "dd/MM/yyyy") : "—"}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 truncate">{e.location || "Local a definir"}</p>
                </div>

                {/* Envolvidos */}
                <div>
                  <p className="text-xs text-muted-foreground">Cl: <span className="text-foreground font-medium">{profilesById[e.client_id]?.full_name || "—"}</span></p>
                  <p className="text-xs text-muted-foreground mt-0.5">Col: <span className="text-foreground font-medium">{profilesById[e.assigned_collaborator_id]?.full_name || "—"}</span></p>
                </div>

                {/* Estado */}
                <div>
                  <select value={e.status} onChange={ev => { ev.stopPropagation(); updateStatus(e.id, ev.target.value); }}
                    className={`text-[11px] px-2.5 py-1 rounded-full border font-semibold cursor-pointer bg-transparent focus:outline-none transition-colors ${cfg.color}`}>
                    {STATUS.map(s => <option key={s} value={s}>{statusConfig[s].label}</option>)}
                  </select>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-0.5 justify-end">
                  <button onClick={() => { setEditItem(e); setSelectedMaterials([]); setView("form"); }}
                    className="h-8 w-8 rounded-xl flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
                    <Edit className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => remove(e.id)}
                    className="h-8 w-8 rounded-xl flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default AdminEventos;
