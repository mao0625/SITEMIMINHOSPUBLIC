import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { toast } from "sonner";
import {
  Plus, Trash2, Edit, Upload, BookOpen, ArrowLeft,
  Eye, EyeOff, Save, FileText, Share2, Facebook, Instagram,
  Copy, CheckCircle2, ExternalLink, X, Bold, Italic, Link,
  AlignLeft, List, Quote, Heading, Image as ImageIcon, Sparkles,
  Tag, Hash, Settings, Globe, Lock, Clock, Calendar, Search,
  ChevronDown, ChevronRight, MoreVertical, Filter, RefreshCw,
  Loader2, Type, AlignCenter, AlignRight, Underline, Strikethrough,
  Code, Minus, CornerDownLeft, Maximize2, Minimize2, HelpCircle,
  Layers, Folder, FolderPlus, Palette, Pen, LayoutGrid, List as ListIcon,
} from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

const slugify = (s: string) =>
  s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

const SITE_URL = typeof window !== "undefined" ? window.location.origin : "";

// ─── Types ────────────────────────────────────────────────────────────────────
type BlogPost = {
  id: string; title: string; slug: string; excerpt?: string;
  content: string; cover_url?: string; published: boolean;
  published_at?: string; created_at: string; updated_at?: string;
  category_id?: string; tags?: string[]; seo_title?: string;
  seo_description?: string; featured?: boolean; reading_time?: number;
};

type BlogCategory = {
  id: string; name: string; slug: string; description?: string;
  color?: string; created_at: string;
};

type FormState = {
  title: string; slug: string; excerpt: string; content: string;
  cover_url: string; published: boolean; published_at?: string;
  category_id: string; tags: string; seo_title: string;
  seo_description: string; featured: boolean;
};

const emptyForm: FormState = {
  title: "", slug: "", excerpt: "", content: "", cover_url: "",
  published: false, category_id: "", tags: "", seo_title: "",
  seo_description: "", featured: false,
};

const CAT_COLORS = ["#c17f4a","#7c3aed","#0369a1","#166534","#be185d","#92400e","#0c4a6e","#7d7055","#9d174d","#1e40af"];

const wordCount = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;
const readTime   = (s: string) => Math.max(1, Math.ceil(wordCount(s) / 200));

// ─── Share Modal ──────────────────────────────────────────────────────────────
const ShareModal = ({ post, onClose }: { post: BlogPost; onClose: () => void }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const postUrl = `${SITE_URL}/blog/${post.slug}`;
  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key); setTimeout(() => setCopied(null), 2000);
    toast.success("Copiado!");
  };
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postUrl)}`;
  const instagramCaption = `${post.title}\n\n${post.excerpt || post.content.slice(0, 200).replace(/<[^>]+>/g, "")}...\n\n🔗 ${postUrl}\n\n#miminhoscriativos #eventos #decoracao`;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-muted/30">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Share2 className="h-4 w-4 text-white" />
            </div>
            <div>
              <p className="font-semibold text-sm">Partilhar nas Redes Sociais</p>
              <p className="text-xs text-muted-foreground truncate max-w-xs">{post.title}</p>
            </div>
          </div>
          <button onClick={onClose} className="h-7 w-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground block mb-2">Link</label>
            <div className="flex items-center gap-2 bg-muted/40 border border-border rounded-lg px-3 py-2">
              <span className="text-xs font-mono flex-1 truncate">{postUrl}</span>
              <button onClick={() => copy(postUrl, "url")} className="text-muted-foreground hover:text-primary">
                {copied === "url" ? <CheckCircle2 className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <a href={facebookUrl} target="_blank" rel="noreferrer"
            className="flex items-center justify-center gap-2 w-full py-2.5 bg-[#1877f2] hover:bg-[#1565c0] text-white text-sm font-semibold rounded-lg transition-colors">
            <Facebook className="h-4 w-4" /> Publicar no Facebook
          </a>
          <div className="space-y-2">
            <pre className="text-xs bg-muted/40 border border-border rounded-lg p-3 whitespace-pre-wrap font-sans max-h-24 overflow-y-auto">{instagramCaption}</pre>
            <button onClick={() => copy(instagramCaption, "ig")}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-[#f58529] via-[#dd2a7b] to-[#8134af] text-white text-sm font-semibold rounded-lg hover:opacity-90">
              <Copy className="h-3.5 w-3.5" />{copied === "ig" ? "Copiado!" : "Copiar legenda Instagram"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Category Manager Modal ───────────────────────────────────────────────────
const CategoryModal = ({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) => {
  const [cats, setCats] = useState<BlogCategory[]>([]);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [color, setColor] = useState(CAT_COLORS[0]);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase.from("blog_categories").select("*").order("name");
    setCats((data ?? []) as BlogCategory[]);
  }, []);

  useEffect(() => { load(); }, [load]);

  const add = async () => {
    if (!name.trim()) return toast.error("Nome obrigatório");
    setSaving(true);
    const { error } = await supabase.from("blog_categories").insert({ name: name.trim(), slug: slugify(name), description: desc || null, color });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Categoria criada!"); setName(""); setDesc(""); load(); onSaved();
  };

  const remove = async (id: string) => {
    if (!confirm("Eliminar categoria?")) return;
    await supabase.from("blog_categories").delete().eq("id", id);
    load(); onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-muted/30">
          <div className="flex items-center gap-2">
            <Folder className="h-4 w-4 text-primary" />
            <span className="font-semibold text-sm">Gerir Categorias</span>
          </div>
          <button onClick={onClose} className="h-7 w-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground"><X className="h-4 w-4" /></button>
        </div>
        <div className="p-5 space-y-4">
          {/* Add form */}
          <div className="border border-border rounded-xl p-4 bg-muted/20 space-y-3">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Nova Categoria</p>
            <div className="flex gap-2">
              <input value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === "Enter" && add()}
                placeholder="Nome da categoria…"
                className="flex-1 h-9 text-sm px-3 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
              <div className="flex gap-1.5">
                {CAT_COLORS.slice(0, 5).map(c => (
                  <button key={c} onClick={() => setColor(c)} style={{ background: c }}
                    className={`w-7 h-9 rounded-lg transition-all ${color === c ? "ring-2 ring-offset-1 ring-foreground scale-110" : ""}`} />
                ))}
              </div>
            </div>
            <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Descrição (opcional)…"
              className="w-full h-9 text-sm px-3 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <button onClick={add} disabled={saving}
              className="w-full h-9 rounded-lg bg-primary text-primary-foreground text-sm font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}Adicionar
            </button>
          </div>

          {/* List */}
          <div className="space-y-1.5 max-h-64 overflow-y-auto">
            {cats.length === 0
              ? <p className="text-center py-6 text-sm text-muted-foreground">Sem categorias ainda.</p>
              : cats.map(c => (
                <div key={c.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border bg-card hover:bg-muted/20 transition-colors group">
                  <div style={{ background: c.color ?? "#c17f4a" }} className="w-3 h-3 rounded-full shrink-0" />
                  <span className="text-sm font-medium flex-1">{c.name}</span>
                  <span className="text-xs text-muted-foreground font-mono">/blog/categoria/{c.slug}</span>
                  <button onClick={() => remove(c.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Rich Toolbar ─────────────────────────────────────────────────────────────
const RichToolbar = ({ textareaRef, onChange, fullscreen, setFullscreen }: {
  textareaRef: React.RefObject<HTMLTextAreaElement>;
  onChange: (v: string) => void;
  fullscreen: boolean;
  setFullscreen: (v: boolean) => void;
}) => {
  const wrap = (before: string, after = before) => {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart; const e = el.selectionEnd;
    const sel = el.value.substring(s, e) || "texto";
    const nv = el.value.substring(0, s) + before + sel + after + el.value.substring(e);
    onChange(nv);
    setTimeout(() => { el.focus(); el.setSelectionRange(s + before.length, s + before.length + sel.length); }, 0);
  };
  const insert = (text: string) => {
    const el = textareaRef.current; if (!el) return;
    const p = el.selectionStart;
    onChange(el.value.substring(0, p) + text + el.value.substring(p));
    setTimeout(() => { el.focus(); el.setSelectionRange(p + text.length, p + text.length); }, 0);
  };

  const groups = [
    [
      { icon: Bold,          tip: "Negrito (Ctrl+B)",    fn: () => wrap("**") },
      { icon: Italic,        tip: "Itálico (Ctrl+I)",    fn: () => wrap("_") },
      { icon: Underline,     tip: "Sublinhado",          fn: () => wrap("<u>", "</u>") },
      { icon: Strikethrough, tip: "Riscado",             fn: () => wrap("~~") },
      { icon: Code,          tip: "Código inline",       fn: () => wrap("`") },
    ],
    [
      { label: "H1", tip: "Título 1", fn: () => insert("\n# ") },
      { label: "H2", tip: "Título 2", fn: () => insert("\n## ") },
      { label: "H3", tip: "Título 3", fn: () => insert("\n### ") },
    ],
    [
      { icon: List,           tip: "Lista",         fn: () => insert("\n- ") },
      { icon: Quote,          tip: "Citação",       fn: () => wrap("\n> ", "") },
      { icon: Minus,          tip: "Separador",     fn: () => insert("\n\n---\n\n") },
      { icon: CornerDownLeft, tip: "Quebra linha",  fn: () => insert("  \n") },
    ],
    [
      { icon: Link,      tip: "Link",    fn: () => wrap("[", "](https://)") },
      { icon: ImageIcon, tip: "Imagem",  fn: () => insert('\n![descrição](https://)\n') },
    ],
  ];

  return (
    <div className="flex items-center gap-0.5 px-2 py-1.5 border-b border-border bg-muted/10 flex-wrap">
      {groups.map((grp, gi) => (
        <div key={gi} className="flex items-center gap-0.5">
          {gi > 0 && <div className="h-4 w-px bg-border mx-1" />}
          {grp.map((t, ti) => (
            <button key={ti} title={t.tip} onClick={t.fn}
              className="h-7 min-w-7 px-1.5 rounded flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors text-xs font-bold">
              {"icon" in t && t.icon ? <t.icon className="h-3.5 w-3.5" /> : ("label" in t ? t.label : null)}
            </button>
          ))}
        </div>
      ))}
      <div className="ml-auto">
        <button onClick={() => setFullscreen(!fullscreen)} title={fullscreen ? "Sair ecrã completo" : "Ecrã completo"}
          className="h-7 w-7 rounded flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors">
          {fullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
        </button>
      </div>
    </div>
  );
};

// ─── Article Editor ───────────────────────────────────────────────────────────
function ArticleEditor({ initial, onBack, onSaved, categories }: {
  initial: BlogPost | null; onBack: () => void; onSaved: (post: BlogPost) => void; categories: BlogCategory[];
}) {
  const [form, setForm] = useState<FormState>(
    initial ? {
      title: initial.title, slug: initial.slug, excerpt: initial.excerpt ?? "",
      content: initial.content, cover_url: initial.cover_url ?? "", published: initial.published,
      published_at: initial.published_at, category_id: initial.category_id ?? "",
      tags: (initial.tags ?? []).join(", "), seo_title: initial.seo_title ?? "",
      seo_description: initial.seo_description ?? "", featured: initial.featured ?? false,
    } : emptyForm
  );
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [sharePost, setSharePost] = useState<BlogPost | null>(null);
  const [editorMode, setEditorMode] = useState<"write" | "preview">("write");
  const [fullscreen, setFullscreen] = useState(false);
  const [openPanel, setOpenPanel] = useState<string[]>(["publicar", "categoria", "imagem"]);
  const [tagInput, setTagInput] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const set = (key: keyof FormState, value: any) => setForm(f => ({ ...f, [key]: value }));
  const togglePanel = (p: string) => setOpenPanel(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  const isOpen = (p: string) => openPanel.includes(p);

  const wc  = wordCount(form.content);
  const rt  = readTime(form.content);

  const uploadCover = async (file: File) => {
    setUploading(true);
    const path = `${Date.now()}_${file.name.replace(/[^\w.-]/g, "_")}`;
    const { error } = await supabase.storage.from("blog").upload(path, file);
    setUploading(false);
    if (error) return toast.error(error.message);
    const { data: { publicUrl } } = supabase.storage.from("blog").getPublicUrl(path);
    set("cover_url", publicUrl);
  };

  const addTag = () => {
    const t = tagInput.trim().toLowerCase().replace(/\s+/g, "-");
    if (!t) return;
    const existing = form.tags.split(",").map(x => x.trim()).filter(Boolean);
    if (!existing.includes(t)) set("tags", [...existing, t].join(", "));
    setTagInput("");
  };

  const removeTag = (tag: string) => {
    const existing = form.tags.split(",").map(x => x.trim()).filter(Boolean).filter(t => t !== tag);
    set("tags", existing.join(", "));
  };

  const save = async () => {
    if (!form.title.trim()) return toast.error("Título é obrigatório");
    if (!form.content.trim()) return toast.error("Conteúdo é obrigatório");
    setSaving(true);
    const wasPublished = initial?.published ?? false;
    const tags = form.tags.split(",").map(t => t.trim()).filter(Boolean);
    const payload = {
      title: form.title, slug: form.slug || slugify(form.title), excerpt: form.excerpt || null,
      content: form.content, cover_url: form.cover_url || null, published: form.published,
      published_at: form.published ? (form.published_at || new Date().toISOString()) : null,
      category_id: form.category_id || null, tags, seo_title: form.seo_title || null,
      seo_description: form.seo_description || null, featured: form.featured,
      reading_time: rt, updated_at: new Date().toISOString(),
    };
    const res = initial
      ? await supabase.from("blog_posts").update(payload).eq("id", initial.id).select().single()
      : await supabase.from("blog_posts").insert(payload).select().single();
    setSaving(false);
    if (res.error) return toast.error(res.error.message);
    const savedPost = res.data as BlogPost;
    toast.success(initial ? "Artigo atualizado!" : "Artigo criado!");
    if (form.published && !wasPublished) setSharePost(savedPost);
    else onSaved(savedPost);
  };

  const renderPreview = (text: string) =>
    text
      .replace(/^### (.+)$/gm, '<h3 style="font-size:1.1rem;font-weight:700;margin:1.5rem 0 .5rem">$1</h3>')
      .replace(/^## (.+)$/gm, '<h2 style="font-size:1.3rem;font-weight:700;margin:1.8rem 0 .6rem">$1</h2>')
      .replace(/^# (.+)$/gm, '<h1 style="font-size:1.6rem;font-weight:800;margin:2rem 0 .8rem">$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/~~(.+?)~~/g, '<s>$1</s>')
      .replace(/_(.+?)_/g, '<em>$1</em>')
      .replace(/`(.+?)`/g, '<code style="background:#f3f0ff;padding:2px 6px;border-radius:4px;font-size:.85em">$1</code>')
      .replace(/^> (.+)$/gm, '<blockquote style="border-left:4px solid #c17f4a;padding:4px 12px;color:#7a5c45;font-style:italic;margin:8px 0">$1</blockquote>')
      .replace(/^- (.+)$/gm, '<li style="margin-left:1.5rem;list-style-type:disc;margin-bottom:4px">$1</li>')
      .replace(/^---$/gm, '<hr style="border:1px solid #e8d5bc;margin:1.5rem 0"/>')
      .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" style="color:#c17f4a;text-decoration:underline">$1</a>')
      .replace(/!\[(.+?)\]\((.+?)\)/g, '<img src="$2" alt="$1" style="max-width:100%;border-radius:8px;margin:12px 0" />')
      .replace(/\n\n/g, '</p><p style="margin-bottom:1rem;line-height:1.8">')
      .replace(/\n/g, "<br/>");

  const tagsList = form.tags.split(",").map(t => t.trim()).filter(Boolean);

  // ── Panel helper ──
  const Panel = ({ id, title, icon: Icon, children }: { id: string; title: string; icon: any; children: React.ReactNode }) => (
    <div className="border border-border rounded-xl overflow-hidden bg-card">
      <button onClick={() => togglePanel(id)} className="w-full flex items-center justify-between px-4 py-3 bg-muted/20 hover:bg-muted/40 transition-colors">
        <div className="flex items-center gap-2">
          <Icon className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{title}</span>
        </div>
        <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform duration-200 ${isOpen(id) ? "" : "-rotate-90"}`} />
      </button>
      {isOpen(id) && <div className="p-4">{children}</div>}
    </div>
  );

  const editorClasses = fullscreen
    ? "fixed inset-0 z-50 bg-card flex flex-col"
    : "";

  return (
    <>
      {sharePost && <ShareModal post={sharePost} onClose={() => { setSharePost(null); onSaved(sharePost); }} />}

      <div className={editorClasses || "min-h-screen bg-background"}>

        {/* ── Top bar ── */}
        <div className={`${fullscreen ? "" : "sticky top-0 z-10"} bg-card border-b border-border shadow-sm`}>
          <div className="h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent" />
          <div className="flex items-center justify-between px-4 h-12 gap-3">
            {/* Left */}
            <div className="flex items-center gap-3 min-w-0">
              {!fullscreen && (
                <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors shrink-0">
                  <ArrowLeft className="h-3.5 w-3.5" /> Blog
                </button>
              )}
              {!fullscreen && <span className="text-muted-foreground/30 shrink-0">›</span>}
              <span className="text-sm text-muted-foreground shrink-0">{initial ? "Editar" : "Novo artigo"}</span>
              {form.title && <span className="hidden md:block text-sm font-medium text-foreground truncate">— {form.title}</span>}
            </div>

            {/* Centre — quick status */}
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] text-muted-foreground tabular-nums">{wc} pal. · {rt} min</span>
              <div className="h-4 w-px bg-border" />
              {/* Write / Preview */}
              <div className="flex items-center rounded-lg border border-border overflow-hidden text-xs">
                {(["write","preview"] as const).map(m => (
                  <button key={m} onClick={() => setEditorMode(m)} className={`px-3 py-1.5 font-medium transition-colors ${editorMode===m?"bg-primary/10 text-primary":"text-muted-foreground hover:text-foreground"} ${m==="preview"?"border-l border-border":""}`}>
                    {m === "write" ? "Escrever" : "Pré-ver"}
                  </button>
                ))}
              </div>
              {/* Status */}
              <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full font-medium border ${form.published ? "bg-green-50 text-green-700 border-green-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>
                {form.published ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                {form.published ? "Publicado" : "Rascunho"}
              </div>
            </div>

            {/* Right */}
            <div className="flex items-center gap-2 shrink-0">
              {initial?.published && (
                <button onClick={() => setSharePost(initial)} className="flex items-center gap-1.5 h-8 px-3 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors">
                  <Share2 className="h-3.5 w-3.5" /> Partilhar
                </button>
              )}
              <button onClick={() => { set("published", false); setTimeout(save, 0); }} disabled={saving}
                className="flex items-center gap-1.5 h-8 px-3 rounded-lg border border-border text-xs font-medium text-muted-foreground hover:bg-muted/50 transition-colors disabled:opacity-50">
                <Save className="h-3.5 w-3.5" /> Rascunho
              </button>
              <button onClick={save} disabled={saving}
                className="flex items-center gap-1.5 h-8 px-4 rounded-lg bg-gradient-gold text-white text-xs font-semibold hover:opacity-90 transition-opacity disabled:opacity-50">
                {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                {form.published ? "Publicar" : "Guardar"}
              </button>
            </div>
          </div>
        </div>

        {/* ── Body ── */}
        <div className={`${fullscreen ? "flex-1 overflow-auto" : "max-w-screen-xl mx-auto px-4 py-6"}`}>
          <div className={`${fullscreen ? "h-full flex" : "grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-5"}`}>

            {/* ── Main editor column ── */}
            <div className={`space-y-4 ${fullscreen ? "flex-1 flex flex-col p-4 overflow-auto" : ""}`}>

              {/* Title card */}
              <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
                <div className="px-4 py-2 border-b border-border bg-muted/20 flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Título</span>
                  <code className="text-[10px] text-muted-foreground bg-muted/50 px-2 py-0.5 rounded">/blog/{form.slug || slugify(form.title) || "slug"}</code>
                </div>
                <input
                  value={form.title}
                  onChange={e => { const t = e.target.value; setForm(f => ({ ...f, title: t, slug: f.slug && f.slug !== slugify(f.title) ? f.slug : slugify(t) })); }}
                  placeholder="Escreva o título do artigo aqui…"
                  className="w-full text-2xl font-bold px-4 py-4 bg-transparent border-none outline-none placeholder:text-muted-foreground/25 text-foreground"
                />
                {/* Featured toggle inline */}
                <div className="flex items-center gap-2 px-4 pb-3">
                  <button onClick={() => set("featured", !form.featured)}
                    className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border font-medium transition-all ${form.featured ? "bg-amber-50 text-amber-700 border-amber-300" : "text-muted-foreground border-border hover:border-amber-300"}`}>
                    <Sparkles className="h-3 w-3" />
                    {form.featured ? "Artigo em destaque" : "Marcar como destaque"}
                  </button>
                </div>
              </div>

              {/* Excerpt */}
              <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
                <div className="px-4 py-2 border-b border-border bg-muted/20">
                  <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Resumo / Excerto</span>
                </div>
                <textarea rows={2} value={form.excerpt} onChange={e => set("excerpt", e.target.value)}
                  placeholder="Uma ou duas frases que resumem o artigo. Aparece nas listagens e no SEO."
                  className="w-full resize-none border-none outline-none text-sm px-4 py-3 bg-transparent text-foreground placeholder:text-muted-foreground/40" />
              </div>

              {/* Content editor */}
              <div className={`bg-card border border-border rounded-xl overflow-hidden shadow-sm ${fullscreen ? "flex-1 flex flex-col" : ""}`}>
                <div className="px-4 py-2 border-b border-border bg-muted/20 flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Conteúdo</span>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-muted-foreground">{wc} palavras · {rt} min leitura</span>
                    <span className="text-[10px] text-muted-foreground">{form.content.length} car.</span>
                  </div>
                </div>

                {editorMode === "write" ? (
                  <div className={`flex flex-col ${fullscreen ? "flex-1" : ""}`}>
                    <RichToolbar textareaRef={textareaRef} onChange={v => set("content", v)} fullscreen={fullscreen} setFullscreen={setFullscreen} />
                    <textarea
                      ref={textareaRef}
                      value={form.content}
                      onChange={e => set("content", e.target.value)}
                      placeholder={"Comece a escrever...\n\nSuporta Markdown:\n# Título 1\n## Título 2\n**negrito** _itálico_ `código`\n> Citação\n- Lista\n[Link](https://)\n![Imagem](https://)"}
                      className={`resize-none font-mono text-sm leading-relaxed border-none outline-none bg-transparent text-foreground placeholder:text-muted-foreground/30 p-4 ${fullscreen ? "flex-1" : "min-h-[500px]"}`}
                      style={{ fontFamily: "'Fira Code', 'Cascadia Code', 'JetBrains Mono', monospace" }}
                    />
                  </div>
                ) : (
                  <div className={`px-6 py-5 prose prose-sm max-w-none text-foreground ${fullscreen ? "flex-1 overflow-auto" : "min-h-[500px]"}`}
                    dangerouslySetInnerHTML={{ __html: `<p style="margin-bottom:1rem;line-height:1.8">${renderPreview(form.content)}</p>` }} />
                )}
              </div>
            </div>

            {/* ── Sidebar panels ── */}
            {!fullscreen && (
              <div className="space-y-3">

                {/* Publicar */}
                <Panel id="publicar" title="Publicar" icon={Globe}>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between py-1">
                      <div className="flex items-center gap-2 text-sm">
                        {form.published ? <Eye className="h-3.5 w-3.5 text-green-600" /> : <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />}
                        <span className="text-muted-foreground">Estado</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium">{form.published ? "Publicado" : "Rascunho"}</span>
                        <button onClick={() => set("published", !form.published)}
                          className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${form.published ? "bg-green-500" : "bg-muted-foreground/30"}`}>
                          <span className={`pointer-events-none inline-block h-4 w-4 rounded-full bg-white shadow-lg transition-transform ${form.published ? "translate-x-4" : "translate-x-0"}`} />
                        </button>
                      </div>
                    </div>
                    <div className="h-px bg-border" />
                    <button onClick={save} disabled={saving}
                      className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-gold text-white text-sm font-semibold rounded-lg hover:opacity-90 disabled:opacity-50 transition-opacity">
                      {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : form.published ? <Sparkles className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                      {saving ? "A guardar…" : form.published ? "Publicar artigo" : "Guardar Rascunho"}
                    </button>
                    {initial?.published && (
                      <a href={`${SITE_URL}/blog/${initial.slug}`} target="_blank" rel="noreferrer"
                        className="w-full flex items-center justify-center gap-1.5 py-2 border border-border rounded-lg text-xs text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors">
                        <ExternalLink className="h-3 w-3" /> Ver artigo publicado
                      </a>
                    )}
                  </div>
                </Panel>

                {/* Categoria */}
                <Panel id="categoria" title="Categoria" icon={Folder}>
                  <select value={form.category_id} onChange={e => set("category_id", e.target.value)}
                    className="w-full h-9 text-sm px-3 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30">
                    <option value="">Sem categoria</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  {categories.length === 0 && (
                    <p className="text-xs text-muted-foreground mt-2 text-center">Sem categorias. Crie uma no botão "Categorias" acima.</p>
                  )}
                </Panel>

                {/* Tags */}
                <Panel id="tags" title="Tags" icon={Tag}>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <input value={tagInput} onChange={e => setTagInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addTag(); }}}
                        placeholder="Adicionar tag…"
                        className="flex-1 h-8 text-sm px-3 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                      <button onClick={addTag} className="h-8 px-3 rounded-lg bg-primary/10 text-primary text-xs font-semibold hover:bg-primary/20 transition-colors">
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {tagsList.map(tag => (
                        <span key={tag} className="inline-flex items-center gap-1 text-xs bg-muted/50 border border-border px-2 py-0.5 rounded-full">
                          #{tag}
                          <button onClick={() => removeTag(tag)} className="text-muted-foreground hover:text-destructive">
                            <X className="h-2.5 w-2.5" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                </Panel>

                {/* Imagem de capa */}
                <Panel id="imagem" title="Imagem de Capa" icon={ImageIcon}>
                  {form.cover_url ? (
                    <div className="relative group rounded-lg overflow-hidden border border-border">
                      <img src={form.cover_url} alt="Capa" className="w-full aspect-video object-cover" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button onClick={() => fileRef.current?.click()} className="bg-card text-xs px-2.5 py-1.5 rounded-lg font-medium border hover:bg-muted transition-colors">Alterar</button>
                        <button onClick={() => set("cover_url", "")} className="bg-destructive text-destructive-foreground text-xs px-2.5 py-1.5 rounded-lg font-medium">Remover</button>
                      </div>
                    </div>
                  ) : (
                    <div onClick={() => fileRef.current?.click()}
                      className="aspect-video rounded-lg border-2 border-dashed border-border hover:border-primary/40 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-primary/5 transition-all">
                      <div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
                        <Upload className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <span className="text-xs text-muted-foreground">Clique para carregar</span>
                    </div>
                  )}
                  <input ref={fileRef} type="file" accept="image/*" onChange={e => e.target.files?.[0] && uploadCover(e.target.files[0])} className="hidden" />
                  {uploading && <p className="text-xs text-muted-foreground text-center mt-2 animate-pulse">A carregar…</p>}
                  {/* URL manual */}
                  <div className="mt-3">
                    <input value={form.cover_url} onChange={e => set("cover_url", e.target.value)}
                      placeholder="Ou cole URL da imagem…"
                      className="w-full h-8 text-xs px-3 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                </Panel>

                {/* Permalink */}
                <Panel id="permalink" title="Permalink" icon={Link}>
                  <div className="flex items-center gap-1 bg-muted/40 border border-border rounded-lg px-3 py-2">
                    <span className="text-[11px] text-muted-foreground shrink-0">/blog/</span>
                    <input value={form.slug} onChange={e => set("slug", e.target.value)}
                      placeholder="slug"
                      className="text-[11px] bg-transparent border-none outline-none flex-1 font-mono text-foreground" />
                  </div>
                </Panel>

                {/* SEO */}
                <Panel id="seo" title="SEO" icon={Search}>
                  <div className="space-y-3">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground block mb-1">Título SEO</label>
                      <input value={form.seo_title} onChange={e => set("seo_title", e.target.value)}
                        placeholder={form.title || "Título para motores de pesquisa…"}
                        className="w-full h-8 text-sm px-3 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                      <div className="flex justify-between mt-1">
                        <span className="text-[9px] text-muted-foreground">Recomendado: 50-60 car.</span>
                        <span className={`text-[9px] font-medium ${(form.seo_title || form.title).length > 60 ? "text-red-500" : "text-muted-foreground"}`}>{(form.seo_title || form.title).length}/60</span>
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground block mb-1">Descrição SEO</label>
                      <textarea rows={3} value={form.seo_description} onChange={e => set("seo_description", e.target.value)}
                        placeholder={form.excerpt || "Descrição para motores de pesquisa…"}
                        className="w-full resize-none text-sm px-3 py-2 rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                      <div className="flex justify-between mt-1">
                        <span className="text-[9px] text-muted-foreground">Recomendado: 120-160 car.</span>
                        <span className={`text-[9px] font-medium ${(form.seo_description || form.excerpt).length > 160 ? "text-red-500" : "text-muted-foreground"}`}>{(form.seo_description || form.excerpt).length}/160</span>
                      </div>
                    </div>

                    {/* Google preview */}
                    <div className="mt-2 p-3 bg-white border border-border rounded-lg text-left shadow-sm">
                      <p className="text-[11px] text-[#1a0dab] font-medium line-clamp-1 leading-snug">{form.seo_title || form.title || "Título do artigo"}</p>
                      <p className="text-[10px] text-[#006621] mt-0.5">{SITE_URL}/blog/{form.slug || "slug"}</p>
                      <p className="text-[10px] text-[#545454] mt-0.5 line-clamp-2 leading-relaxed">{form.seo_description || form.excerpt || "Descrição do artigo aparece aqui nos resultados do Google…"}</p>
                    </div>
                  </div>
                </Panel>

                {/* Info */}
                {initial && (
                  <Panel id="info" title="Informações" icon={HelpCircle}>
                    <div className="space-y-2 text-xs text-muted-foreground">
                      <div className="flex justify-between"><span>Criado</span><span>{format(new Date(initial.created_at), "dd/MM/yyyy HH:mm", { locale: pt })}</span></div>
                      {initial.updated_at && <div className="flex justify-between"><span>Atualizado</span><span>{format(new Date(initial.updated_at), "dd/MM/yyyy HH:mm", { locale: pt })}</span></div>}
                      {initial.published_at && <div className="flex justify-between"><span>Publicado</span><span>{format(new Date(initial.published_at), "dd/MM/yyyy HH:mm", { locale: pt })}</span></div>}
                      <div className="flex justify-between"><span>Palavras</span><span>{wc}</span></div>
                      <div className="flex justify-between"><span>Leitura</span><span>{rt} min</span></div>
                    </div>
                  </Panel>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// ─── Main list ────────────────────────────────────────────────────────────────
export const AdminBlog = () => {
  const [items, setItems] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [view, setView] = useState<"list" | "editor">("list");
  const [editing, setEditing] = useState<BlogPost | null>(null);
  const [sharePost, setSharePost] = useState<BlogPost | null>(null);
  const [showCatModal, setShowCatModal] = useState(false);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<"todos" | "publicado" | "rascunho">("todos");
  const [filterCat, setFilterCat] = useState("");
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: posts }, { data: cats }] = await Promise.all([
      supabase.from("blog_posts").select("*").order("created_at", { ascending: false }),
      supabase.from("blog_categories").select("*").order("name"),
    ]);
    setItems((posts as BlogPost[]) ?? []);
    setCategories((cats as BlogCategory[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleBack = () => { setView("list"); setEditing(null); load(); };
  const remove = async (id: string) => {
    if (!confirm("Eliminar este artigo?")) return;
    await supabase.from("blog_posts").delete().eq("id", id);
    toast.success("Artigo eliminado"); load();
  };
  const togglePublish = async (post: BlogPost) => {
    const next = !post.published;
    await supabase.from("blog_posts").update({ published: next, published_at: next ? new Date().toISOString() : null }).eq("id", post.id);
    toast.success(next ? "Artigo publicado!" : "Artigo revertido para rascunho");
    if (next) setSharePost({ ...post, published: true });
    load();
  };

  if (view === "editor") {
    return <ArticleEditor initial={editing} onBack={handleBack} onSaved={() => { load(); setView("list"); setEditing(null); }} categories={categories} />;
  }

  const filtered = items.filter(p => {
    const matchSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || (p.excerpt ?? "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "todos" ? true : filterStatus === "publicado" ? p.published : !p.published;
    const matchCat    = !filterCat || p.category_id === filterCat;
    return matchSearch && matchStatus && matchCat;
  });

  const published = items.filter(i => i.published).length;
  const drafts    = items.filter(i => !i.published).length;
  const featured  = items.filter(i => i.featured).length;

  const getCatName = (id?: string) => categories.find(c => c.id === id)?.name ?? null;
  const getCatColor = (id?: string) => categories.find(c => c.id === id)?.color ?? "#c17f4a";

  return (
    <>
      {sharePost && <ShareModal post={sharePost} onClose={() => setSharePost(null)} />}
      {showCatModal && <CategoryModal onClose={() => setShowCatModal(false)} onSaved={load} />}

      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-xl font-bold">Blog</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Gestão de artigos, categorias e conteúdo</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={() => setShowCatModal(true)}
              className="flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors">
              <Folder className="h-4 w-4" /> Categorias
              {categories.length > 0 && <span className="text-xs bg-muted rounded-full px-1.5">{categories.length}</span>}
            </button>
            <button onClick={() => { setEditing(null); setView("editor"); }}
              className="flex items-center gap-2 h-9 px-4 rounded-lg bg-gradient-gold text-white text-sm font-semibold hover:opacity-90 transition-opacity">
              <Plus className="h-4 w-4" /> Novo artigo
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Total",       value: items.length,  color: "border-t-border" },
            { label: "Publicados",  value: published,     color: "border-t-green-400" },
            { label: "Rascunhos",   value: drafts,        color: "border-t-amber-400" },
            { label: "Destaques",   value: featured,      color: "border-t-primary" },
          ].map(s => (
            <div key={s.label} className={`bg-card border border-border rounded-xl overflow-hidden border-t-4 ${s.color}`}>
              <div className="px-4 py-3">
                <p className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">{s.label}</p>
                <p className="text-2xl font-bold font-mono">{String(s.value).padStart(2, "0")}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filters bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Pesquisar artigos…"
              className="w-full h-9 pl-9 pr-3 text-sm rounded-lg border border-border bg-card text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
          </div>
          {/* Status filter */}
          {(["todos","publicado","rascunho"] as const).map(s => (
            <button key={s} onClick={() => setFilterStatus(s)}
              className={`h-9 px-3 text-xs font-medium rounded-lg border transition-colors capitalize ${filterStatus===s?"bg-primary/10 text-primary border-primary/30":"border-border text-muted-foreground hover:border-border"}`}>
              {s === "todos" ? "Todos" : s === "publicado" ? "Publicados" : "Rascunhos"}
            </button>
          ))}
          {/* Cat filter */}
          {categories.length > 0 && (
            <select value={filterCat} onChange={e => setFilterCat(e.target.value)}
              className="h-9 text-xs px-3 rounded-lg border border-border bg-card text-foreground outline-none">
              <option value="">Todas as categorias</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          )}
          <div className="ml-auto flex gap-1">
            {(["list","grid"] as const).map(m => {
              const Icon = m === "list" ? ListIcon : LayoutGrid;
              return (
                <button key={m} onClick={() => setViewMode(m)}
                  className={`h-9 w-9 rounded-lg border flex items-center justify-center transition-colors ${viewMode===m?"bg-primary/10 text-primary border-primary/30":"border-border text-muted-foreground hover:border-border"}`}>
                  <Icon className="h-4 w-4" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex items-center justify-center py-20 gap-3 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" /><span className="text-sm">A carregar…</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="border-2 border-dashed border-border/60 rounded-2xl p-16 text-center bg-muted/10">
            <div className="bg-primary/8 rounded-2xl p-5 w-fit mx-auto mb-4">
              <BookOpen className="h-9 w-9 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{items.length === 0 ? "Nenhum artigo ainda" : "Sem resultados"}</h3>
            <p className="text-muted-foreground mb-5 max-w-xs mx-auto text-sm">
              {items.length === 0 ? "Crie o seu primeiro artigo." : "Tente mudar os filtros de pesquisa."}
            </p>
            {items.length === 0 && (
              <button onClick={() => { setEditing(null); setView("editor"); }}
                className="flex items-center gap-2 mx-auto px-4 py-2.5 bg-gradient-gold text-white rounded-lg text-sm font-semibold">
                <Plus className="h-4 w-4" /> Criar primeiro artigo
              </button>
            )}
          </div>
        ) : viewMode === "list" ? (
          /* ── LIST VIEW ── */
          <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
            <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-0 px-4 py-2.5 bg-muted/30 border-b border-border">
              {["","Artigo","Categoria","Estado","Data","Ações"].map((h, i) => (
                <span key={i} className={`text-[10px] font-bold uppercase tracking-widest text-muted-foreground ${i > 0 ? "px-3" : ""}`}>{h}</span>
              ))}
            </div>
            {filtered.map((p, i) => (
              <div key={p.id}
                className={`grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-0 items-center px-4 py-3 border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors ${i%2!==0?"bg-muted/5":""}`}>

                {/* Thumb */}
                <div className="shrink-0 pr-3">
                  {p.cover_url
                    ? <img src={p.cover_url} alt="" className="h-10 w-16 object-cover rounded-lg border border-border" />
                    : <div className="h-10 w-16 bg-muted/50 rounded-lg border border-border flex items-center justify-center"><FileText className="h-4 w-4 text-muted-foreground/30" /></div>
                  }
                </div>

                {/* Title */}
                <div className="px-3 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm truncate">{p.title}</p>
                    {p.featured && <Sparkles className="h-3 w-3 text-amber-500 shrink-0" title="Destaque" />}
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-0.5 font-mono truncate">/blog/{p.slug}</p>
                  {p.tags && p.tags.length > 0 && (
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {p.tags.slice(0, 3).map(t => (
                        <span key={t} className="text-[9px] bg-muted/50 border border-border px-1.5 py-0.5 rounded-full text-muted-foreground">#{t}</span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Category */}
                <div className="px-3">
                  {p.category_id ? (
                    <span style={{ background: `${getCatColor(p.category_id)}20`, color: getCatColor(p.category_id), borderColor: `${getCatColor(p.category_id)}40` }}
                      className="text-[10px] px-2 py-0.5 rounded-full border font-medium whitespace-nowrap">
                      {getCatName(p.category_id)}
                    </span>
                  ) : <span className="text-[10px] text-muted-foreground">—</span>}
                </div>

                {/* Status */}
                <div className="px-3">
                  <button onClick={() => togglePublish(p)}
                    className={`inline-flex items-center gap-1.5 text-[10px] px-2.5 py-1 rounded-full font-medium border transition-colors ${p.published?"bg-green-50 text-green-700 border-green-200 hover:bg-green-100":"bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100"}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${p.published?"bg-green-500":"bg-amber-500"}`} />
                    {p.published ? "Publicado" : "Rascunho"}
                  </button>
                </div>

                {/* Date */}
                <div className="px-3 text-right">
                  <span className="text-xs text-muted-foreground">{format(new Date(p.created_at), "dd/MM/yy")}</span>
                </div>

                {/* Actions */}
                <div className="pl-3 flex items-center gap-0.5">
                  {p.published && (
                    <button onClick={() => setSharePost(p)} title="Partilhar"
                      className="h-8 w-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors">
                      <Share2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                  <button onClick={() => { setEditing(p); setView("editor"); }} title="Editar"
                    className="h-8 w-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/8 transition-colors">
                    <Edit className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => remove(p.id)} title="Eliminar"
                    className="h-8 w-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/8 transition-colors">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* ── GRID VIEW ── */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map(p => (
              <div key={p.id} className="bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5 group">
                {/* Thumb */}
                <div className="aspect-video bg-muted relative overflow-hidden">
                  {p.cover_url
                    ? <img src={p.cover_url} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    : <div className="flex items-center justify-center h-full"><FileText className="h-8 w-8 text-muted-foreground/20" /></div>
                  }
                  {p.featured && (
                    <div className="absolute top-2 left-2">
                      <span className="inline-flex items-center gap-1 text-[9px] font-bold bg-amber-100 text-amber-700 border border-amber-300 px-1.5 py-0.5 rounded-full">
                        <Sparkles className="h-2.5 w-2.5" /> Destaque
                      </span>
                    </div>
                  )}
                  <div className="absolute top-2 right-2">
                    <button onClick={() => togglePublish(p)}
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${p.published?"bg-green-50 text-green-700 border-green-300":"bg-amber-50 text-amber-700 border-amber-300"}`}>
                      {p.published ? "Publicado" : "Rascunho"}
                    </button>
                  </div>
                </div>
                {/* Body */}
                <div className="p-3">
                  {p.category_id && (
                    <span style={{ color: getCatColor(p.category_id) }} className="text-[10px] font-bold uppercase tracking-wider">{getCatName(p.category_id)}</span>
                  )}
                  <h3 className="text-sm font-semibold mt-0.5 line-clamp-2 leading-snug">{p.title}</h3>
                  {p.excerpt && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.excerpt}</p>}
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-[10px] text-muted-foreground">{format(new Date(p.created_at), "dd/MM/yyyy")}</span>
                    <div className="flex gap-0.5">
                      {p.published && <button onClick={() => setSharePost(p)} className="h-7 w-7 rounded flex items-center justify-center text-muted-foreground hover:text-primary transition-colors"><Share2 className="h-3 w-3" /></button>}
                      <button onClick={() => { setEditing(p); setView("editor"); }} className="h-7 w-7 rounded flex items-center justify-center text-muted-foreground hover:text-primary transition-colors"><Edit className="h-3 w-3" /></button>
                      <button onClick={() => remove(p.id)} className="h-7 w-7 rounded flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="h-3 w-3" /></button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};
