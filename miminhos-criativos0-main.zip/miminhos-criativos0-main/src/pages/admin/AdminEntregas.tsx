import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { format, startOfWeek, endOfWeek, addWeeks, isSameDay, parseISO } from "date-fns";
import { pt } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import {
  MapPin, Users, ExternalLink, Calendar as Cal,
  ChevronLeft, ChevronRight, Package, Clock,
  Navigation, Truck, RefreshCw, Hash, Tag, FileText,
} from "lucide-react";

// Dias do fim de semana (sex, sáb, dom)
const WEEKEND_DAYS = [5, 6, 0]; // 5=sexta, 6=sáb, 0=dom

const dayLabel: Record<number, string> = {
  5: "Sexta-feira",
  6: "Sábado",
  0: "Domingo",
};

const typeColors: Record<string, string> = {
  Casamento: "bg-rose-50 text-rose-700 border-rose-200",
  Batismo: "bg-sky-50 text-sky-700 border-sky-200",
  Aniversário: "bg-amber-50 text-amber-700 border-amber-200",
  Comunhão: "bg-violet-50 text-violet-700 border-violet-200",
  "Evento Corporativo": "bg-slate-50 text-slate-700 border-slate-200",
  "Festa Temática": "bg-emerald-50 text-emerald-700 border-emerald-200",
};

const getTypeColor = (type: string) =>
  typeColors[type] ?? "bg-muted text-muted-foreground border-border/60";

// ─── Ticket ID ────────────────────────────────────────────────────────────────
const TicketId = ({ id }: { id: string }) => (
  <span className="inline-flex items-center gap-1 font-mono text-[10px] bg-muted/50 border border-border/50 px-1.5 py-0.5 rounded text-muted-foreground">
    <Hash className="h-2.5 w-2.5" />{id.substring(0, 8).toUpperCase()}
  </span>
);

// ─── SAP Toolbar ──────────────────────────────────────────────────────────────
const SapToolbar = ({ title, subtitle, actions }: {
  title: string; subtitle?: string; actions?: React.ReactNode;
}) => (
  <div className="bg-[#f7f3eb] dark:bg-muted/60 border border-border rounded-t-lg">
    <div className="flex items-center gap-3 px-4 py-2 border-b border-border/50 min-h-[40px]">
      <span className="font-bold text-sm flex-1">{title}</span>
      {subtitle && <span className="text-xs text-muted-foreground">{subtitle}</span>}
      {actions && <div className="flex items-center gap-1.5 ml-auto">{actions}</div>}
    </div>
  </div>
);

// ─── Cartão de Entrega ────────────────────────────────────────────────────────
const EntregaCard = ({ event, index }: { event: any; index: number }) => {
  const addr = event.delivery_address || event.location;
  const mapUrl = addr
    ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}`
    : null;
  const typeColor = getTypeColor(event.event_type);
  const eventType = event.event_type === "Outro"
    ? (event.event_type_other || "Outro")
    : event.event_type;

  return (
    <div className="bg-background border border-border/60 rounded-lg shadow-sm hover:shadow-md transition-all overflow-hidden group">
      {/* Card header */}
      <div className="flex items-stretch">
        {/* Index number */}
        <div className="flex items-center justify-center w-12 bg-primary/5 border-r border-border/40 text-primary font-bold text-lg shrink-0">
          {String(index + 1).padStart(2, "0")}
        </div>

        <div className="flex-1 px-4 py-3">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="font-bold text-sm truncate group-hover:text-primary transition-colors">
                {event.title}
              </h3>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <TicketId id={event.id} />
                {event.event_date && (
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {format(parseISO(event.event_date), "EEEE, dd 'de' MMMM", { locale: pt })}
                  </span>
                )}
              </div>
            </div>
            {eventType && (
              <span className={`shrink-0 inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border ${typeColor}`}>
                <Tag className="h-2.5 w-2.5" />{eventType}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="h-px bg-border/40 mx-4" />

      {/* Body */}
      <div className="px-4 py-3 space-y-3">
        {/* Morada */}
        {addr ? (
          <div className="rounded-lg border border-border/50 bg-muted/20 p-3">
            <div className="flex items-start gap-2.5">
              <div className="h-7 w-7 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                <MapPin className="h-3.5 w-3.5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-0.5">
                  {event.delivery_address ? "Morada de Entrega" : "Local do Evento"}
                </p>
                <p className="text-sm font-medium leading-snug">{addr}</p>
                {mapUrl && (
                  <a href={mapUrl} target="_blank" rel="noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-1.5 font-medium">
                    <Navigation className="h-3 w-3" />
                    Abrir no Google Maps
                    <ExternalLink className="h-2.5 w-2.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-lg border border-dashed border-border/50 p-3 flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-3.5 w-3.5" />
            <span className="text-xs">Morada não definida</span>
          </div>
        )}

        {/* Meta info */}
        <div className="flex items-center gap-4 flex-wrap">
          {event.guests_count && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Users className="h-3.5 w-3.5" />
              <span><strong className="text-foreground">{event.guests_count}</strong> convidados</span>
            </div>
          )}
          {event.location && event.delivery_address && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span>Local: <strong className="text-foreground">{event.location}</strong></span>
            </div>
          )}
        </div>

        {/* Notas */}
        {event.notes && (
          <div className="flex items-start gap-2 text-xs text-muted-foreground bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-md p-2.5">
            <FileText className="h-3.5 w-3.5 text-amber-600 shrink-0 mt-0.5" />
            <span className="italic">{event.notes}</span>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Página Principal ─────────────────────────────────────────────────────────
const AdminEntregas = () => {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [weekOffset, setWeekOffset] = useState(0);
  const [dayFilter, setDayFilter] = useState<number | "all">("all");

  const start = startOfWeek(addWeeks(new Date(), weekOffset), { weekStartsOn: 5 });
  const end = endOfWeek(addWeeks(new Date(), weekOffset), { weekStartsOn: 5 });

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("events")
      .select("id,title,event_date,event_type,event_type_other,location,delivery_address,guests_count,notes")
      .gte("event_date", format(start, "yyyy-MM-dd"))
      .lte("event_date", format(end, "yyyy-MM-dd"))
      .order("event_date");
    setEvents(data ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [weekOffset]);

  // Agrupar por dia
  const byDay = WEEKEND_DAYS.map(dayNum => {
    const dayEvents = events.filter(e => {
      if (!e.event_date) return false;
      return new Date(e.event_date).getDay() === dayNum;
    });
    // Calcular a data real deste dia no weekOffset atual
    const date = [0, 1, 2, 3, 4, 5, 6]
      .map(i => { const d = new Date(start); d.setDate(start.getDate() + i); return d; })
      .find(d => d.getDay() === dayNum);
    return { dayNum, label: dayLabel[dayNum], date, events: dayEvents };
  });

  const displayEvents = dayFilter === "all"
    ? events
    : events.filter(e => e.event_date && new Date(e.event_date).getDay() === dayFilter);

  const isCurrentWeek = weekOffset === 0;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Mapa de Entregas"
        description="Eventos do fim-de-semana e respetivas moradas de entrega."
        action={
          <Button size="sm" variant="outline" onClick={load} className="h-8 text-xs gap-1.5" disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
        }
      />

      {/* Navegação de semana */}
      <div className="bg-card border border-border/60 rounded-lg shadow-sm px-4 py-3 flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1">
          <Button size="sm" variant="outline" onClick={() => setWeekOffset(w => w - 1)} className="h-8 w-8 p-0">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="px-4 py-1.5 bg-muted/30 border border-border/50 rounded-md min-w-[200px] text-center">
            <p className="text-xs text-muted-foreground">Fim de semana</p>
            <p className="text-sm font-bold">
              {format(start, "dd/MM", { locale: pt })} – {format(end, "dd/MM/yyyy", { locale: pt })}
            </p>
          </div>
          <Button size="sm" variant="outline" onClick={() => setWeekOffset(w => w + 1)} className="h-8 w-8 p-0">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {!isCurrentWeek && (
          <Button size="sm" variant="ghost" onClick={() => setWeekOffset(0)} className="h-8 text-xs text-primary">
            <Cal className="h-3.5 w-3.5 mr-1.5" />Este fim-de-semana
          </Button>
        )}
        {isCurrentWeek && (
          <span className="text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full font-semibold">
            Semana atual
          </span>
        )}

        <div className="ml-auto flex items-center gap-1.5 text-xs text-muted-foreground">
          <Truck className="h-3.5 w-3.5" />
          <span><strong className="text-foreground">{events.length}</strong> entrega{events.length !== 1 ? "s" : ""}</span>
        </div>
      </div>

      {/* Resumo por dia */}
      {events.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          {byDay.map(({ dayNum, label, date, events: dayEvts }) => (
            <button key={dayNum}
              onClick={() => setDayFilter(dayFilter === dayNum ? "all" : dayNum)}
              className={`bg-card border rounded-lg px-4 py-3 text-left transition-all shadow-sm hover:shadow-md ${dayFilter === dayNum ? "border-primary ring-1 ring-primary/30 bg-primary/5" : "border-border/60 hover:border-border"}`}>
              <p className="text-xs text-muted-foreground font-medium">{label}</p>
              {date && <p className="text-[10px] text-muted-foreground/70">{format(date, "dd/MM/yyyy")}</p>}
              <p className={`text-2xl font-bold mt-1 ${dayEvts.length > 0 ? "text-primary" : "text-muted-foreground/40"}`}>
                {dayEvts.length}
              </p>
              {dayEvts.length > 0 && (
                <p className="text-[10px] text-muted-foreground mt-0.5">entrega{dayEvts.length !== 1 ? "s" : ""}</p>
              )}
            </button>
          ))}
        </div>
      )}

      {/* Filtro de dia ativo */}
      {dayFilter !== "all" && (
        <div className="flex items-center gap-2">
          <span className="text-xs bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full font-medium flex items-center gap-1.5">
            <Cal className="h-3 w-3" />
            A mostrar: {dayLabel[dayFilter as number]}
          </span>
          <button onClick={() => setDayFilter("all")} className="text-xs text-muted-foreground hover:text-foreground transition-colors">
            Mostrar todos
          </button>
        </div>
      )}

      {/* Toolbar + lista */}
      <div>
        <SapToolbar
          title={dayFilter === "all" ? "Todas as Entregas" : `Entregas — ${dayLabel[dayFilter as number]}`}
          subtitle={`${displayEvents.length} evento${displayEvents.length !== 1 ? "s" : ""}`}
        />
        <div className="border border-t-0 border-border rounded-b-lg bg-muted/20 p-4">
          {loading && (
            <div className="text-center py-12 text-muted-foreground">
              <RefreshCw className="h-6 w-6 mx-auto mb-2 animate-spin opacity-40" />
              <p className="text-sm">A carregar…</p>
            </div>
          )}

          {!loading && displayEvents.length === 0 && (
            <div className="text-center py-14 text-muted-foreground">
              <div className="inline-flex bg-muted/40 rounded-2xl p-5 mb-3">
                <Truck className="h-9 w-9 opacity-20" />
              </div>
              <p className="font-semibold text-base">Sem entregas neste período</p>
              <p className="text-sm opacity-60 mt-1">Não há eventos agendados para {dayFilter === "all" ? "este fim-de-semana" : dayLabel[dayFilter as number].toLowerCase()}.</p>
            </div>
          )}

          {!loading && displayEvents.length > 0 && (
            <div className="grid md:grid-cols-2 gap-4">
              {displayEvents.map((e, i) => (
                <EntregaCard key={e.id} event={e} index={i} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Legenda de tipos */}
      {events.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Tipos:</span>
          {Array.from(new Set(events.map(e => e.event_type === "Outro" ? (e.event_type_other || "Outro") : e.event_type).filter(Boolean))).map(type => (
            <span key={type} className={`text-xs px-2 py-0.5 rounded-full border font-medium ${getTypeColor(type)}`}>{type}</span>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminEntregas;
