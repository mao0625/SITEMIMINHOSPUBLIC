import { useEffect, useState, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { exportDocumentPDF, ContentBlock, DocType } from "@/lib/pdf";
import { toast } from "sonner";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import {
  Bold, Italic, Underline, Strikethrough, AlignLeft, AlignCenter,
  AlignRight, AlignJustify, List, ListOrdered, Indent, Outdent,
  Link, Image as ImageIcon, Table2, Minus, Plus, Trash2, Save,
  Download, Eye, Pencil, ArrowLeft, FilePlus, FileText, Search,
  FileCheck, FileSignature, FileArchive, Clock, ChevronDown,
  ZoomIn, ZoomOut, Grid3X3, LayoutList, LayoutTemplate, Quote,
  Heading, Superscript, Subscript, RemoveFormatting, Highlighter,
  SeparatorHorizontal, Columns, ChevronUp, Type, Palette,
  Settings, BookOpen, Printer, Copy, Scissors, Clipboard,
  RotateCcw, RotateCw, Find, FileImage, Code, User, Hash,
  ChevronRight, X, Check, Maximize2, Minimize2,
} from "lucide-react";

// ─── Brand ────────────────────────────────────────────────────────────────────
const C = {
  brown:      "#6b4c2a",
  brownLight: "#8b6340",
  brownPale:  "#c9a87c",
  cream:      "#fdf8f3",
  creamDark:  "#f5ede0",
  creamBorder:"#e8d9c5",
  white:      "#ffffff",
  text:       "#2c1a0e",
  textMuted:  "#8a6a50",
  gold:       "#d4af37",
  surface:    "#faf6f0",
  ribbon:     "#f0e6d3",
  ribbonTab:  "#e8d5bb",
};

// ─── Types ────────────────────────────────────────────────────────────────────
interface Block {
  id: string;
  type: "paragraph" | "heading1" | "heading2" | "heading3" | "spacer";
  text: string;
  bold?: boolean; italic?: boolean; underline?: boolean; strikethrough?: boolean;
  align?: "left" | "center" | "right" | "justify";
  fontSize?: number; fontFamily?: string; color?: string; highlight?: string;
  lineHeight?: number; indent?: number;
  listStyle?: "none" | "bullet" | "numbered";
  superscript?: boolean; subscript?: boolean;
  isTable?: boolean; tableRows?: string[][]; tableCols?: number;
  isDivider?: boolean; dividerStyle?: "solid" | "dashed" | "double";
  isCallout?: boolean; calloutType?: "info" | "warning" | "success" | "tip";
  isTwoCol?: boolean; col1?: string; col2?: string;
  isImage?: boolean; imageUrl?: string; imageAlt?: string; imageWidth?: number;
}

interface SavedDoc {
  id: string; name: string; docType: string;
  blocks: Block[]; category: string;
  created_at: string; updated_at: string; created_by?: string;
  client_name?: string; client_nif?: string; client_reference?: string;
  page_size?: "A4" | "A3" | "Letter";
  orientation?: "portrait" | "landscape";
  margins?: { top: number; bottom: number; left: number; right: number };
  header_text?: string; footer_text?: string; show_page_numbers?: boolean;
}

interface DocTemplate {
  id: string; name: string; docType: string; category: string;
  description: string; blocks: Block[];
}

// ─── Constants ────────────────────────────────────────────────────────────────
const uid = () => Math.random().toString(36).slice(2, 9);

const FONT_FAMILIES = [
  { label: "Georgia (Padrão)",   value: "Georgia, 'Times New Roman', serif" },
  { label: "Times New Roman",    value: "'Times New Roman', Times, serif" },
  { label: "Palatino",           value: "'Palatino Linotype', Palatino, serif" },
  { label: "Arial",              value: "Arial, Helvetica, sans-serif" },
  { label: "Trebuchet MS",       value: "'Trebuchet MS', Helvetica, sans-serif" },
  { label: "Courier New",        value: "'Courier New', monospace" },
];

const FONT_SIZES = [8,9,10,11,12,13,14,16,18,20,22,24,28,32,36,48,60,72];

const TEXT_COLORS = [
  "#1a1a1a","#6b4c2a","#c0392b","#e74c3c","#e67e22","#f39c12",
  "#27ae60","#2980b9","#8e44ad","#7f8c8d","#ffffff","#d4af37",
];
const HIGHLIGHT_COLORS = [
  "transparent","#fff9c4","#ffd7d7","#d1ecf1","#d4edda",
  "#e2d9f3","#ffe0cc","#f5ede0","#c8e6c9",
];

const TEMPLATE_DEFS: DocTemplate[] = [
  { id:"semass",     name:"Documento Geral",          docType:"semass",            category:"Geral",      description:"Documento simples sem assinatura",             blocks:[{ id:uid(), type:"paragraph", text:"", fontSize:11 }] },
  { id:"comass",     name:"Documento com Assinatura", docType:"comass",            category:"Geral",      description:"Documento formal com espaço para assinaturas", blocks:[{ id:uid(), type:"paragraph", text:"", fontSize:11 }] },
  { id:"orc_ext",    name:"Orçamento — Cliente",      docType:"orcamento_externo", category:"Orçamentos", description:"Orçamento para enviar ao cliente",             blocks:[{ id:uid(), type:"paragraph", text:"Prezado/a cliente,", fontSize:11 }, { id:uid(), type:"spacer", text:"", fontSize:10 }, { id:uid(), type:"paragraph", text:"Apresentamos o orçamento conforme solicitado.", fontSize:11 }] },
  { id:"orc_int",    name:"Orçamento — Interno",      docType:"orcamento_interno", category:"Orçamentos", description:"Versão interna com NIF e referência",           blocks:[{ id:uid(), type:"heading1", text:"Documento Interno", bold:true, fontSize:18 }, { id:uid(), type:"spacer", text:"", fontSize:10 }, { id:uid(), type:"paragraph", text:"", fontSize:11 }] },
  { id:"carta",      name:"Carta Formal",             docType:"semass",            category:"Geral",      description:"Carta com cabeçalho e corpo formatados",        blocks:[{ id:uid(), type:"paragraph", text:format(new Date(),"dd/MM/yyyy"), fontSize:11, align:"right" }, { id:uid(), type:"spacer", text:"", fontSize:16 }, { id:uid(), type:"heading2", text:"Assunto:", fontSize:13, bold:true }, { id:uid(), type:"spacer", text:"", fontSize:8 }, { id:uid(), type:"paragraph", text:"Exmo(a). Sr(a),", fontSize:11 }, { id:uid(), type:"spacer", text:"", fontSize:8 }, { id:uid(), type:"paragraph", text:"", fontSize:11 }] },
  { id:"minuta",     name:"Minuta de Reunião",        docType:"semass",            category:"Geral",      description:"Registo de reunião com participantes e pontos", blocks:[{ id:uid(), type:"heading1", text:"Minuta de Reunião", fontSize:20, bold:true }, { id:uid(), type:"spacer", text:"", fontSize:8 }, { id:uid(), type:"paragraph", text:`Data: ${format(new Date(),"dd/MM/yyyy")}`, fontSize:11 }, { id:uid(), type:"paragraph", text:"Participantes:", fontSize:11 }, { id:uid(), type:"spacer", text:"", fontSize:8 }, { id:uid(), type:"heading2", text:"Pontos da Agenda", fontSize:14, bold:true }, { id:uid(), type:"paragraph", text:"1. ", fontSize:11 }] },
];

const HEADING_STYLES: Record<string, React.CSSProperties> = {
  heading1: { fontSize: 26, fontWeight: 700, color: C.brown, borderBottom: `2px solid ${C.creamBorder}`, paddingBottom: 6, marginBottom: 10, fontFamily: "'Segoe UI', system-ui, sans-serif" },
  heading2: { fontSize: 18, fontWeight: 700, color: C.brownLight, marginBottom: 6, fontFamily: "'Segoe UI', system-ui, sans-serif" },
  heading3: { fontSize: 14, fontWeight: 600, color: C.brownLight, marginBottom: 4, fontFamily: "'Segoe UI', system-ui, sans-serif" },
  paragraph: { fontSize: 11, fontWeight: 400, color: "#1a1a1a", fontFamily: "Georgia, 'Times New Roman', serif" },
};

// ─── Small helpers ─────────────────────────────────────────────────────────────
const mkBlock = (type: Block["type"] = "paragraph"): Block => ({
  id: uid(), type, text: "", fontSize: type === "heading1" ? 26 : type === "heading2" ? 18 : type === "heading3" ? 14 : 11,
  align: "left", lineHeight: 1.8,
  fontFamily: type.startsWith("heading") ? "'Segoe UI', system-ui, sans-serif" : "Georgia, 'Times New Roman', serif",
  bold: type.startsWith("heading"),
});

// ─── DropMenu ─────────────────────────────────────────────────────────────────
const DropMenu = ({ show, onClose, children, minW = 180 }: {
  show: boolean; onClose: () => void; children: React.ReactNode; minW?: number;
}) => {
  if (!show) return null;
  return (
    <>
      <div style={{ position: "fixed", inset: 0, zIndex: 998 }} onClick={onClose} />
      <div style={{
        position: "absolute", top: "100%", left: 0, zIndex: 999, marginTop: 2,
        background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 6,
        boxShadow: "0 8px 32px rgba(107,76,42,0.2)", minWidth: minW, padding: "4px 0",
      }}>
        {children}
      </div>
    </>
  );
};

const MenuItem = ({ label, shortcut, onClick, icon, disabled, checked }: {
  label: string; shortcut?: string; onClick: () => void;
  icon?: React.ReactNode; disabled?: boolean; checked?: boolean;
}) => (
  <button onClick={onClick} disabled={disabled}
    style={{
      display: "flex", alignItems: "center", gap: 8, width: "100%",
      padding: "6px 16px", border: "none", background: "transparent",
      textAlign: "left", fontSize: 12.5, color: disabled ? "#ccc" : C.text,
      cursor: disabled ? "default" : "pointer",
    }}
    onMouseEnter={e => !disabled && ((e.currentTarget as HTMLElement).style.background = C.creamDark)}
    onMouseLeave={e => ((e.currentTarget as HTMLElement).style.background = "transparent")}
  >
    {checked !== undefined && (
      <span style={{ width: 14, color: C.brown }}>{checked ? "✓" : ""}</span>
    )}
    {icon && <span style={{ width: 16, color: C.brown }}>{icon}</span>}
    <span style={{ flex: 1 }}>{label}</span>
    {shortcut && <span style={{ fontSize: 11, color: C.textMuted, marginLeft: 20 }}>{shortcut}</span>}
  </button>
);

const MenuSep = () => <div style={{ height: 1, background: C.creamBorder, margin: "3px 0" }} />;

// ─── Find & Replace Dialog ────────────────────────────────────────────────────
const FindReplaceDialog = ({ onClose, blocks, onBlocks }: {
  onClose: () => void; blocks: Block[]; onBlocks: (b: Block[]) => void;
}) => {
  const [find, setFind] = useState("");
  const [replace, setReplace] = useState("");
  const [caseSensitive, setCaseSensitive] = useState(false);

  const doReplace = () => {
    if (!find) return;
    const updated = blocks.map(b => ({
      ...b,
      text: caseSensitive
        ? b.text.replaceAll(find, replace)
        : b.text.replace(new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), "gi"), replace),
    }));
    onBlocks(updated);
    toast.success(`Substituições feitas!`);
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 500, background: "rgba(0,0,0,0.4)",
      display: "flex", alignItems: "center", justifyContent: "center",
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: C.white, borderRadius: 10, boxShadow: "0 20px 60px rgba(107,76,42,0.3)",
        border: `1px solid ${C.creamBorder}`, width: 360, overflow: "hidden",
      }}>
        <div style={{ background: `linear-gradient(to bottom,${C.brown},${C.brownLight})`, color: C.white, padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontWeight: 700, fontSize: 13 }}>Localizar e Substituir</span>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.7)", cursor: "pointer" }}><X size={14} /></button>
        </div>
        <div style={{ padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
          {[
            { label: "Localizar:", value: find, set: setFind, ph: "Texto a encontrar…" },
            { label: "Substituir por:", value: replace, set: setReplace, ph: "Texto de substituição…" },
          ].map(f => (
            <div key={f.label}>
              <label style={{ fontSize: 11, color: C.textMuted, display: "block", marginBottom: 4 }}>{f.label}</label>
              <input value={f.value} onChange={e => f.set(e.target.value)} placeholder={f.ph}
                style={{ width: "100%", boxSizing: "border-box", padding: "7px 10px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, fontSize: 12, color: C.text, outline: "none" }}
                onFocus={e => (e.currentTarget.style.borderColor = C.brown)}
                onBlur={e => (e.currentTarget.style.borderColor = C.creamBorder)}
              />
            </div>
          ))}
          <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: C.textMuted, cursor: "pointer" }}>
            <input type="checkbox" checked={caseSensitive} onChange={e => setCaseSensitive(e.target.checked)} />
            Distinguir maiúsculas/minúsculas
          </label>
          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <button onClick={onClose} style={{ flex: 1, padding: "8px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, background: "transparent", color: C.textMuted, cursor: "pointer", fontSize: 12 }}>Cancelar</button>
            <button onClick={doReplace} style={{ flex: 2, padding: "8px", border: "none", borderRadius: 5, background: `linear-gradient(135deg,${C.brown},${C.brownLight})`, color: C.white, cursor: "pointer", fontWeight: 700, fontSize: 12 }}>Substituir Tudo</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Page Settings Dialog ─────────────────────────────────────────────────────
const PageSettingsDialog = ({ settings, onSave, onClose }: {
  settings: Partial<SavedDoc>; onSave: (s: Partial<SavedDoc>) => void; onClose: () => void;
}) => {
  const [size, setSize] = useState(settings.page_size ?? "A4");
  const [orient, setOrient] = useState(settings.orientation ?? "portrait");
  const [margins, setMargins] = useState(settings.margins ?? { top: 25, bottom: 25, left: 25, right: 25 });
  const [header, setHeader] = useState(settings.header_text ?? "");
  const [footer, setFooter] = useState(settings.footer_text ?? "Miminhos Criativos · 926 992 352 · site.miminhoscriativos@gmail.com");
  const [pageNums, setPageNums] = useState(settings.show_page_numbers ?? false);

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 500, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center" }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.white, borderRadius: 10, boxShadow: "0 20px 60px rgba(107,76,42,0.3)", border: `1px solid ${C.creamBorder}`, width: 420, overflow: "hidden", maxHeight: "90vh", overflowY: "auto" }}>
        <div style={{ background: `linear-gradient(to bottom,${C.brown},${C.brownLight})`, color: C.white, padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0 }}>
          <span style={{ fontWeight: 700, fontSize: 13 }}>Configuração da Página</span>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "rgba(255,255,255,0.7)", cursor: "pointer" }}><X size={14} /></button>
        </div>
        <div style={{ padding: 20, display: "flex", flexDirection: "column", gap: 18 }}>
          {/* Page size + orientation */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 8px" }}>Tamanho e Orientação</p>
            <div style={{ display: "flex", gap: 8 }}>
              <select value={size} onChange={e => setSize(e.target.value as any)} style={{ flex: 1, padding: "7px 10px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, fontSize: 12, color: C.text }}>
                <option value="A4">A4 (210 × 297 mm)</option>
                <option value="A3">A3 (297 × 420 mm)</option>
                <option value="Letter">Letter (216 × 279 mm)</option>
              </select>
              <select value={orient} onChange={e => setOrient(e.target.value as any)} style={{ flex: 1, padding: "7px 10px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, fontSize: 12, color: C.text }}>
                <option value="portrait">Vertical (Portrait)</option>
                <option value="landscape">Horizontal (Landscape)</option>
              </select>
            </div>
          </div>
          {/* Margins */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 8px" }}>Margens (mm)</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {(["top","bottom","left","right"] as const).map(side => (
                <div key={side}>
                  <label style={{ fontSize: 11, color: C.textMuted, display: "block", marginBottom: 3, textTransform: "capitalize" }}>
                    {side === "top" ? "Superior" : side === "bottom" ? "Inferior" : side === "left" ? "Esquerda" : "Direita"}
                  </label>
                  <input type="number" min={0} max={80} value={margins[side]}
                    onChange={e => setMargins(m => ({ ...m, [side]: Number(e.target.value) }))}
                    style={{ width: "100%", boxSizing: "border-box", padding: "6px 10px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, fontSize: 12 }}
                  />
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
              {[
                { label: "Normal", vals: { top:25, bottom:25, left:25, right:25 } },
                { label: "Estreita", vals: { top:13, bottom:13, left:13, right:13 } },
                { label: "Larga", vals: { top:25, bottom:25, left:50, right:50 } },
              ].map(preset => (
                <button key={preset.label} onClick={() => setMargins(preset.vals)} style={{ flex: 1, padding: "5px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, background: C.cream, color: C.textMuted, cursor: "pointer", fontSize: 11 }}>
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
          {/* Header / Footer */}
          <div>
            <p style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 8px" }}>Cabeçalho e Rodapé</p>
            {[
              { label: "Cabeçalho:", value: header, set: setHeader, ph: "Texto do cabeçalho…" },
              { label: "Rodapé:", value: footer, set: setFooter, ph: "Texto do rodapé…" },
            ].map(f => (
              <div key={f.label} style={{ marginBottom: 8 }}>
                <label style={{ fontSize: 11, color: C.textMuted, display: "block", marginBottom: 3 }}>{f.label}</label>
                <input value={f.value} onChange={e => f.set(e.target.value)} placeholder={f.ph}
                  style={{ width: "100%", boxSizing: "border-box", padding: "7px 10px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, fontSize: 12, color: C.text, outline: "none" }} />
              </div>
            ))}
            <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: C.textMuted, cursor: "pointer" }}>
              <input type="checkbox" checked={pageNums} onChange={e => setPageNums(e.target.checked)} />
              Mostrar numeração de páginas
            </label>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={onClose} style={{ flex: 1, padding: "8px", border: `1px solid ${C.creamBorder}`, borderRadius: 5, background: "transparent", color: C.textMuted, cursor: "pointer", fontSize: 12 }}>Cancelar</button>
            <button onClick={() => { onSave({ page_size: size as any, orientation: orient as any, margins, header_text: header, footer_text: footer, show_page_numbers: pageNums }); onClose(); }}
              style={{ flex: 2, padding: "8px", border: "none", borderRadius: 5, background: `linear-gradient(135deg,${C.brown},${C.brownLight})`, color: C.white, cursor: "pointer", fontWeight: 700, fontSize: 12 }}>
              Aplicar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Block render (for preview) ───────────────────────────────────────────────
const BlockPreview = ({ b }: { b: Block }) => {
  if (b.type === "spacer") return <div style={{ height: `${b.fontSize ?? 10}px` }} />;
  if (b.isDivider) {
    const s = b.dividerStyle ?? "solid";
    return <div style={{ margin: "10px 0", borderTop: s === "double" ? `4px double ${C.brown}` : `2px ${s} ${C.brownPale}` }} />;
  }
  if (b.isImage && b.imageUrl) return (
    <div style={{ textAlign: (b.align ?? "left") as any, margin: "8px 0" }}>
      <img src={b.imageUrl} alt={b.imageAlt ?? ""} style={{ maxWidth: b.imageWidth ? `${b.imageWidth}%` : "100%", borderRadius: 4 }} />
    </div>
  );
  if (b.isTable && b.tableRows) return (
    <table style={{ width: "100%", borderCollapse: "collapse", margin: "8px 0", fontSize: `${b.fontSize ?? 11}px` }}>
      <tbody>
        {b.tableRows.map((row, ri) => (
          <tr key={ri}>
            {row.map((cell, ci) => (
              <td key={ci} style={{ border: `1px solid ${C.creamBorder}`, padding: "5px 8px", background: ri === 0 ? C.creamDark : C.white, fontWeight: ri === 0 ? 700 : 400, color: C.text }}>{cell}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
  if (b.isTwoCol) return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, margin: "6px 0" }}>
      {[b.col1 ?? "", b.col2 ?? ""].map((col, i) => (
        <div key={i} style={{ fontSize: `${b.fontSize ?? 11}px`, lineHeight: b.lineHeight ?? 1.8, fontFamily: b.fontFamily ?? "Georgia, serif", color: b.color ?? "#1a1a1a" }}>
          {col || <span style={{ color: "#ccc", fontStyle: "italic" }}>(vazio)</span>}
        </div>
      ))}
    </div>
  );

  const hs = HEADING_STYLES[b.type] ?? HEADING_STYLES.paragraph;
  const fs = b.fontSize ?? (hs.fontSize as number);
  const prefix = b.listStyle === "bullet" ? "• " : b.listStyle === "numbered" ? "1. " : "";
  const lines = (b.text || "").split("\n");

  return (
    <div style={{ margin: "2px 0", paddingLeft: b.indent ? `${b.indent * 20}px` : 0 }}>
      {b.listStyle === "numbered" ? (
        <ol style={{ margin: 0, paddingLeft: 18, fontSize: `${fs}px`, fontFamily: b.fontFamily ?? (hs.fontFamily as string), lineHeight: b.lineHeight ?? 1.8 }}>
          {lines.filter(Boolean).map((l, i) => (
            <li key={i} style={{ fontWeight: b.bold ? "bold" : hs.fontWeight as any, fontStyle: b.italic ? "italic" : "normal", textDecoration: [b.underline && "underline", b.strikethrough && "line-through"].filter(Boolean).join(" ") || undefined, color: b.color ?? (hs.color as string), background: b.highlight && b.highlight !== "transparent" ? b.highlight : undefined }}>{l}</li>
          ))}
        </ol>
      ) : (
        <p style={{
          fontSize: `${fs}px`, margin: 0,
          fontWeight: b.bold ? "bold" : hs.fontWeight as any,
          fontStyle: b.italic ? "italic" : "normal",
          textDecoration: [b.underline && "underline", b.strikethrough && "line-through"].filter(Boolean).join(" ") || undefined,
          textAlign: (b.align ?? "left") as any,
          lineHeight: b.lineHeight ?? 1.8,
          fontFamily: b.fontFamily ?? (hs.fontFamily as string),
          color: b.type.startsWith("heading") ? (hs.color as string) : (b.color ?? "#1a1a1a"),
          background: b.highlight && b.highlight !== "transparent" ? b.highlight : undefined,
          borderBottom: hs.borderBottom as any,
          paddingBottom: hs.paddingBottom as any,
          marginBottom: hs.marginBottom as any,
          verticalAlign: b.superscript ? "super" : b.subscript ? "sub" : undefined,
          fontSize: b.superscript || b.subscript ? `${Math.round(fs * 0.75)}px` : `${fs}px`,
        } as any}>
          {prefix}{b.text || <span style={{ color: "#ccc", fontStyle: "italic" }}>(vazio)</span>}
        </p>
      )}
    </div>
  );
};

// ─── EDITOR COMPONENT ─────────────────────────────────────────────────────────
const Editor = ({ doc, onBack, currentUser }: { doc: SavedDoc; onBack: (d: SavedDoc) => void; currentUser: any }) => {
  const [blocks, setBlocks] = useState<Block[]>((doc.blocks as Block[]).map(b => ({ ...b, id: b.id ?? uid() })));
  const [name, setName] = useState(doc.name || "");
  const [clientName, setClientName] = useState(doc.client_name ?? "");
  const [clientNif, setClientNif] = useState(doc.client_nif ?? "");
  const [clientRef, setClientRef] = useState(doc.client_reference ?? "");
  const [pageSettings, setPageSettings] = useState<Partial<SavedDoc>>({
    page_size: doc.page_size ?? "A4",
    orientation: doc.orientation ?? "portrait",
    margins: doc.margins ?? { top: 25, bottom: 25, left: 25, right: 25 },
    header_text: doc.header_text ?? "",
    footer_text: doc.footer_text ?? "Miminhos Criativos · 926 992 352 · site.miminhoscriativos@gmail.com",
    show_page_numbers: doc.show_page_numbers ?? false,
  });

  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [zoom, setZoom] = useState(100);
  const [showPreview, setShowPreview] = useState(true);
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [showPageSettings, setShowPageSettings] = useState(false);
  const [showRuler, setShowRuler] = useState(true);
  const [showGridLines, setShowGridLines] = useState(false);
  const [activeRibbonTab, setActiveRibbonTab] = useState("Início");
  const [undoStack, setUndoStack] = useState<Block[][]>([]);
  const [redoStack, setRedoStack] = useState<Block[][]>([]);
  const [clipboard, setClipboard] = useState<Block | null>(null);
  const [wordCount, setWordCount] = useState(0);

  const editorRef = useRef<HTMLDivElement>(null);
  const isOrc = doc.docType === "orcamento_interno" || doc.docType === "orcamento_externo";

  useEffect(() => {
    const wc = blocks.reduce((s, b) => s + (b.text?.split(/\s+/).filter(Boolean).length ?? 0), 0);
    setWordCount(wc);
  }, [blocks]);

  const pushUndo = useCallback((prev: Block[]) => {
    setUndoStack(s => [...s.slice(-30), prev]);
    setRedoStack([]);
  }, []);

  const updateBlocks = (newBlocks: Block[]) => {
    pushUndo(blocks);
    setBlocks(newBlocks);
  };

  const undo = () => {
    if (!undoStack.length) return;
    setRedoStack(r => [blocks, ...r]);
    setBlocks(undoStack[undoStack.length - 1]);
    setUndoStack(s => s.slice(0, -1));
  };
  const redo = () => {
    if (!redoStack.length) return;
    setUndoStack(s => [...s, blocks]);
    setBlocks(redoStack[0]);
    setRedoStack(r => r.slice(1));
  };

  const selBlock = selectedBlockId ? blocks.find(b => b.id === selectedBlockId) : null;

  const updateBlock = (id: string, updates: Partial<Block>) => {
    pushUndo(blocks);
    setBlocks(prev => prev.map(b => b.id === id ? { ...b, ...updates } : b));
  };

  const addBlock = (type: Block["type"] | "table" | "divider" | "callout" | "twocol" | "image", afterId?: string) => {
    let nb: Block;
    if (type === "table") nb = { id: uid(), type: "paragraph", text: "", isTable: true, tableCols: 3, tableRows: [["Cabeçalho 1","Cabeçalho 2","Cabeçalho 3"],["","",""],["","",""]] };
    else if (type === "divider") nb = { id: uid(), type: "paragraph", text: "", isDivider: true, dividerStyle: "solid" };
    else if (type === "twocol") nb = { id: uid(), type: "paragraph", text: "", isTwoCol: true, col1: "", col2: "", fontSize: 11 };
    else if (type === "image") nb = { id: uid(), type: "paragraph", text: "", isImage: true, imageUrl: "", imageAlt: "", imageWidth: 80 };
    else nb = mkBlock(type as Block["type"]);

    pushUndo(blocks);
    if (afterId) {
      setBlocks(prev => {
        const idx = prev.findIndex(b => b.id === afterId);
        const n = [...prev];
        n.splice(idx + 1, 0, nb);
        return n;
      });
    } else {
      setBlocks(prev => [...prev, nb]);
    }
    setSelectedBlockId(nb.id);
  };

  const removeBlock = (id: string) => {
    pushUndo(blocks);
    setBlocks(prev => prev.filter(b => b.id !== id));
    if (selectedBlockId === id) setSelectedBlockId(null);
  };

  const moveBlock = (id: string, dir: -1 | 1) => {
    pushUndo(blocks);
    setBlocks(prev => {
      const i = prev.findIndex(b => b.id === id);
      const j = i + dir;
      if (j < 0 || j >= prev.length) return prev;
      const n = [...prev];
      [n[i], n[j]] = [n[j], n[i]];
      return n;
    });
  };

  // Formatting helpers for selected block
  const fmt = (updates: Partial<Block>) => selBlock && updateBlock(selBlock.id, updates);
  const toggleFmt = (key: keyof Block) => selBlock && updateBlock(selBlock.id, { [key]: !selBlock[key] });

  const buildPayload = () => ({
    name: name || "Sem título", docType: doc.docType, blocks,
    category: doc.category, client_name: clientName || null,
    client_nif: clientNif || null, client_reference: clientRef || null,
    ...pageSettings, updated_at: new Date().toISOString(),
  });

  const save = async () => {
    setSaving(true);
    const payload = buildPayload();
    let error: any;
    if (doc.id.startsWith("new-")) {
      const res = await (supabase as any).from("documents").insert({ ...payload, created_by: currentUser?.id });
      error = res.error;
      if (!error) {
        const { data } = await (supabase as any).from("documents").select("*").order("created_at", { ascending: false }).limit(1).single();
        if (data) { setSaving(false); setLastSaved(new Date()); toast.success("Guardado!"); onBack(data as SavedDoc); return; }
      }
    } else {
      const res = await (supabase as any).from("documents").update(payload).eq("id", doc.id);
      error = res.error;
    }
    setSaving(false);
    if (error) { toast.error("Erro: " + error.message); return; }
    setLastSaved(new Date());
    toast.success("Guardado!");
    onBack({ ...doc, ...payload } as SavedDoc);
  };

  const handleExport = () => {
    if (!name.trim()) { toast.error("Dá um nome ao documento."); return; }
    try {
      exportDocumentPDF({ docTitle: name, contentBlocks: blocks as any, docType: doc.docType as DocType, clientName: clientName || undefined, clientNif: clientNif || undefined, clientReference: clientRef || undefined, clientNameForFile: clientName || undefined });
      toast.success("PDF exportado!");
    } catch { toast.error("Erro ao exportar PDF."); }
  };

  const handlePrint = () => window.print();

  const insertImage = () => {
    const url = prompt("URL da imagem:");
    if (!url) return;
    const alt = prompt("Texto alternativo (opcional):") ?? "";
    addBlock("image", selectedBlockId ?? undefined);
    // update the newly added block
    setTimeout(() => {
      setBlocks(prev => {
        const last = prev[prev.length - 1];
        if (last?.isImage) return prev.map(b => b.id === last.id ? { ...b, imageUrl: url, imageAlt: alt } : b);
        return prev;
      });
    }, 50);
  };

  // ─── Menu definitions ────────────────────────────────────────────────────────
  const menus: Record<string, React.ReactNode> = {
    Ficheiro: (
      <DropMenu show={activeMenu === "Ficheiro"} onClose={() => setActiveMenu(null)}>
        <MenuItem label="Guardar" shortcut="Ctrl+S" icon={<Save size={13} />} onClick={() => { save(); setActiveMenu(null); }} />
        <MenuItem label="Exportar PDF" shortcut="Ctrl+E" icon={<Download size={13} />} onClick={() => { handleExport(); setActiveMenu(null); }} />
        <MenuItem label="Imprimir" shortcut="Ctrl+P" icon={<Printer size={13} />} onClick={() => { handlePrint(); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Configuração da Página" icon={<Settings size={13} />} onClick={() => { setShowPageSettings(true); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Fechar" icon={<X size={13} />} onClick={() => onBack({ ...doc, ...buildPayload() } as SavedDoc)} />
      </DropMenu>
    ),
    Editar: (
      <DropMenu show={activeMenu === "Editar"} onClose={() => setActiveMenu(null)}>
        <MenuItem label="Desfazer" shortcut="Ctrl+Z" icon={<RotateCcw size={13} />} onClick={() => { undo(); setActiveMenu(null); }} disabled={!undoStack.length} />
        <MenuItem label="Refazer" shortcut="Ctrl+Y" icon={<RotateCw size={13} />} onClick={() => { redo(); setActiveMenu(null); }} disabled={!redoStack.length} />
        <MenuSep />
        <MenuItem label="Copiar bloco" shortcut="Ctrl+C" icon={<Copy size={13} />} onClick={() => { if (selBlock) { setClipboard({ ...selBlock, id: uid() }); toast.success("Copiado!"); } setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Colar bloco" shortcut="Ctrl+V" icon={<Clipboard size={13} />} onClick={() => { if (clipboard) { pushUndo(blocks); setBlocks(prev => [...prev, { ...clipboard, id: uid() }]); } setActiveMenu(null); }} disabled={!clipboard} />
        <MenuItem label="Cortar bloco" shortcut="Ctrl+X" icon={<Scissors size={13} />} onClick={() => { if (selBlock) { setClipboard({ ...selBlock, id: uid() }); removeBlock(selBlock.id); } setActiveMenu(null); }} disabled={!selBlock} />
        <MenuSep />
        <MenuItem label="Localizar e Substituir" shortcut="Ctrl+H" icon={<Search size={13} />} onClick={() => { setShowFindReplace(true); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Selecionar tudo" shortcut="Ctrl+A" onClick={() => setActiveMenu(null)} />
      </DropMenu>
    ),
    Ver: (
      <DropMenu show={activeMenu === "Ver"} onClose={() => setActiveMenu(null)} minW={220}>
        <MenuItem label="Mostrar Pré-visualização" checked={showPreview} onClick={() => { setShowPreview(v => !v); setActiveMenu(null); }} />
        <MenuItem label="Mostrar Régua" checked={showRuler} onClick={() => { setShowRuler(v => !v); setActiveMenu(null); }} />
        <MenuItem label="Mostrar Grelha" checked={showGridLines} onClick={() => { setShowGridLines(v => !v); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Zoom 75%" onClick={() => { setZoom(75); setActiveMenu(null); }} checked={zoom === 75} />
        <MenuItem label="Zoom 100%" onClick={() => { setZoom(100); setActiveMenu(null); }} checked={zoom === 100} />
        <MenuItem label="Zoom 125%" onClick={() => { setZoom(125); setActiveMenu(null); }} checked={zoom === 125} />
        <MenuItem label="Zoom 150%" onClick={() => { setZoom(150); setActiveMenu(null); }} checked={zoom === 150} />
        <MenuSep />
        <MenuItem label="Modo Leitura" onClick={() => { setShowPreview(true); setActiveMenu(null); }} icon={<BookOpen size={13} />} />
        <MenuItem label="Esquema de Impressão" onClick={() => { setActiveMenu(null); }} icon={<Printer size={13} />} />
      </DropMenu>
    ),
    Inserir: (
      <DropMenu show={activeMenu === "Inserir"} onClose={() => setActiveMenu(null)} minW={230}>
        <MenuItem label="Parágrafo" icon={<Type size={13} />} onClick={() => { addBlock("paragraph", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuItem label="Título H1" icon={<Heading size={13} />} onClick={() => { addBlock("heading1", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuItem label="Título H2" icon={<Heading size={13} />} onClick={() => { addBlock("heading2", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuItem label="Título H3" icon={<Heading size={13} />} onClick={() => { addBlock("heading3", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Tabela" icon={<Table2 size={13} />} onClick={() => { addBlock("table", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuItem label="Imagem" icon={<ImageIcon size={13} />} onClick={() => { insertImage(); setActiveMenu(null); }} />
        <MenuItem label="Linha Separadora" icon={<SeparatorHorizontal size={13} />} onClick={() => { addBlock("divider", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuItem label="Duas Colunas" icon={<Columns size={13} />} onClick={() => { addBlock("twocol", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuItem label="Espaço em Branco" icon={<Minus size={13} />} onClick={() => { addBlock("spacer", selectedBlockId ?? undefined); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Data de Hoje" icon={<Hash size={13} />} onClick={() => {
          if (selBlock) updateBlock(selBlock.id, { text: selBlock.text + format(new Date(), "dd/MM/yyyy") });
          setActiveMenu(null);
        }} />
        <MenuItem label="Quebra de Página" onClick={() => { addBlock("spacer", selectedBlockId ?? undefined); setActiveMenu(null); toast.info("Quebra de página inserida"); }} />
      </DropMenu>
    ),
    Formatar: (
      <DropMenu show={activeMenu === "Formatar"} onClose={() => setActiveMenu(null)} minW={230}>
        <MenuItem label="Negrito" shortcut="Ctrl+B" icon={<Bold size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { bold: !selBlock.bold }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Itálico" shortcut="Ctrl+I" icon={<Italic size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { italic: !selBlock.italic }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Sublinhado" shortcut="Ctrl+U" icon={<Underline size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { underline: !selBlock.underline }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Rasurado" icon={<Strikethrough size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { strikethrough: !selBlock.strikethrough }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuSep />
        <MenuItem label="Remover Formatação" icon={<RemoveFormatting size={13} />} onClick={() => {
          if (selBlock) updateBlock(selBlock.id, { bold: false, italic: false, underline: false, strikethrough: false, color: undefined, highlight: undefined });
          setActiveMenu(null);
        }} disabled={!selBlock} />
        <MenuSep />
        <MenuItem label="Parágrafo — Alinhar Esquerda" icon={<AlignLeft size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { align: "left" }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Parágrafo — Centrar" icon={<AlignCenter size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { align: "center" }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Parágrafo — Alinhar Direita" icon={<AlignRight size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { align: "right" }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuItem label="Parágrafo — Justificar" icon={<AlignJustify size={13} />} onClick={() => { if (selBlock) updateBlock(selBlock.id, { align: "justify" }); setActiveMenu(null); }} disabled={!selBlock} />
        <MenuSep />
        <MenuItem label="Configuração da Página…" icon={<Settings size={13} />} onClick={() => { setShowPageSettings(true); setActiveMenu(null); }} />
      </DropMenu>
    ),
    Design: (
      <DropMenu show={activeMenu === "Design"} onClose={() => setActiveMenu(null)} minW={200}>
        <MenuItem label="Aplicar Estilo — Título" onClick={() => { if (selBlock) updateBlock(selBlock.id, { type: "heading1", fontSize: 26, bold: true, fontFamily: "'Segoe UI',system-ui,sans-serif" }); setActiveMenu(null); }} />
        <MenuItem label="Aplicar Estilo — Subtítulo" onClick={() => { if (selBlock) updateBlock(selBlock.id, { type: "heading2", fontSize: 18, bold: true }); setActiveMenu(null); }} />
        <MenuItem label="Aplicar Estilo — Corpo" onClick={() => { if (selBlock) updateBlock(selBlock.id, { type: "paragraph", fontSize: 11, bold: false, fontFamily: "Georgia,'Times New Roman',serif" }); setActiveMenu(null); }} />
        <MenuSep />
        <MenuItem label="Tema Claro (Padrão)" onClick={() => setActiveMenu(null)} checked={true} />
        <MenuItem label="Tema Formal" onClick={() => setActiveMenu(null)} />
        <MenuItem label="Tema Moderno" onClick={() => setActiveMenu(null)} />
      </DropMenu>
    ),
  };

  // ─── Ribbon tabs ─────────────────────────────────────────────────────────────
  const tbStyle = (active: boolean): React.CSSProperties => ({
    background: active ? C.white : "transparent", border: "none",
    borderBottom: active ? `2px solid ${C.white}` : "2px solid transparent",
    padding: "6px 14px", fontSize: 12.5, cursor: "pointer",
    color: active ? C.brown : C.brownLight, fontWeight: active ? 700 : 400,
    transition: "all 0.15s",
  });

  const toolB = (title: string, active: boolean, onClick: () => void, children: React.ReactNode): React.ReactNode => (
    <button title={title} onClick={onClick}
      style={{
        height: 26, minWidth: 26, padding: "0 5px", borderRadius: 3,
        display: "flex", alignItems: "center", justifyContent: "center",
        border: `1px solid ${active ? C.brown : "transparent"}`,
        background: active ? `rgba(107,76,42,0.12)` : "transparent",
        color: active ? C.brown : C.text, cursor: "pointer",
        transition: "all 0.12s", flexShrink: 0,
      }}
      onMouseEnter={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = C.creamBorder; } }}
      onMouseLeave={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = "transparent"; } }}
    >{children}</button>
  );

  const RibbonSep = () => <div style={{ width: 1, height: 20, background: C.creamBorder, margin: "0 4px", flexShrink: 0 }} />;

  const RibbonGroup = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div style={{ display: "flex", flexDirection: "column", borderRight: `1px solid ${C.creamBorder}`, paddingRight: 8, marginRight: 4 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 2, flex: 1 }}>{children}</div>
      <span style={{ fontSize: 9, color: C.brownPale, textAlign: "center", marginTop: 2, letterSpacing: "0.08em" }}>{label}</span>
    </div>
  );

  const ribbonInicio = (
    <div style={{ display: "flex", alignItems: "stretch", gap: 0, padding: "4px 8px", flexWrap: "wrap" }}>
      {/* Clipboard */}
      <RibbonGroup label="Área de Transferência">
        {toolB("Colar (Ctrl+V)", false, () => { if (clipboard) { pushUndo(blocks); setBlocks(p => [...p, { ...clipboard, id: uid() }]); } }, <><Clipboard size={14} /><span style={{ fontSize: 11, marginLeft: 3 }}>Colar</span></>)}
        {toolB("Cortar (Ctrl+X)", false, () => { if (selBlock) { setClipboard({ ...selBlock, id: uid() }); removeBlock(selBlock.id); } }, <Scissors size={13} />)}
        {toolB("Copiar (Ctrl+C)", false, () => { if (selBlock) { setClipboard({ ...selBlock, id: uid() }); toast.success("Copiado!"); } }, <Copy size={13} />)}
      </RibbonGroup>

      {/* Font */}
      <RibbonGroup label="Tipo de Letra">
        <select value={selBlock?.fontFamily ?? FONT_FAMILIES[0].value} onChange={e => selBlock && updateBlock(selBlock.id, { fontFamily: e.target.value })}
          style={{ height: 22, fontSize: 11, border: `1px solid ${C.creamBorder}`, borderRadius: 3, color: C.text, padding: "0 4px", maxWidth: 110, cursor: "pointer" }}>
          {FONT_FAMILIES.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
        </select>
        <select value={selBlock?.fontSize ?? 11} onChange={e => selBlock && updateBlock(selBlock.id, { fontSize: Number(e.target.value) })}
          style={{ height: 22, width: 44, fontSize: 11, border: `1px solid ${C.creamBorder}`, borderRadius: 3, color: C.text, padding: "0 2px", cursor: "pointer" }}>
          {FONT_SIZES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <RibbonSep />
        {toolB("Negrito (Ctrl+B)", !!selBlock?.bold, () => selBlock && updateBlock(selBlock.id, { bold: !selBlock.bold }), <Bold size={13} />)}
        {toolB("Itálico (Ctrl+I)", !!selBlock?.italic, () => selBlock && updateBlock(selBlock.id, { italic: !selBlock.italic }), <Italic size={13} />)}
        {toolB("Sublinhado (Ctrl+U)", !!selBlock?.underline, () => selBlock && updateBlock(selBlock.id, { underline: !selBlock.underline }), <Underline size={13} />)}
        {toolB("Rasurado", !!selBlock?.strikethrough, () => selBlock && updateBlock(selBlock.id, { strikethrough: !selBlock.strikethrough }), <Strikethrough size={13} />)}
        <RibbonSep />
        {toolB("Sobrescrito", !!selBlock?.superscript, () => selBlock && updateBlock(selBlock.id, { superscript: !selBlock.superscript, subscript: false }), <Superscript size={13} />)}
        {toolB("Subscrito", !!selBlock?.subscript, () => selBlock && updateBlock(selBlock.id, { subscript: !selBlock.subscript, superscript: false }), <Subscript size={13} />)}
        {toolB("Remover Formatação", false, () => selBlock && updateBlock(selBlock.id, { bold: false, italic: false, underline: false, strikethrough: false, color: undefined, highlight: undefined }), <RemoveFormatting size={13} />)}
      </RibbonGroup>

      {/* Paragraph */}
      <RibbonGroup label="Parágrafo">
        {toolB("Marcadores", selBlock?.listStyle === "bullet", () => selBlock && updateBlock(selBlock.id, { listStyle: selBlock.listStyle === "bullet" ? "none" : "bullet" }), <List size={13} />)}
        {toolB("Numeração", selBlock?.listStyle === "numbered", () => selBlock && updateBlock(selBlock.id, { listStyle: selBlock.listStyle === "numbered" ? "none" : "numbered" }), <ListOrdered size={13} />)}
        <RibbonSep />
        {toolB("Alinhar à Esquerda", selBlock?.align === "left" || !selBlock?.align, () => selBlock && updateBlock(selBlock.id, { align: "left" }), <AlignLeft size={13} />)}
        {toolB("Centrar", selBlock?.align === "center", () => selBlock && updateBlock(selBlock.id, { align: "center" }), <AlignCenter size={13} />)}
        {toolB("Alinhar à Direita", selBlock?.align === "right", () => selBlock && updateBlock(selBlock.id, { align: "right" }), <AlignRight size={13} />)}
        {toolB("Justificar", selBlock?.align === "justify", () => selBlock && updateBlock(selBlock.id, { align: "justify" }), <AlignJustify size={13} />)}
        <RibbonSep />
        {toolB("Aumentar Recuo", false, () => selBlock && updateBlock(selBlock.id, { indent: Math.min(5, (selBlock.indent ?? 0) + 1) }), <Indent size={13} />)}
        {toolB("Diminuir Recuo", false, () => selBlock && updateBlock(selBlock.id, { indent: Math.max(0, (selBlock.indent ?? 0) - 1) }), <Outdent size={13} />)}
        <RibbonSep />
        <select value={selBlock?.lineHeight ?? 1.8} onChange={e => selBlock && updateBlock(selBlock.id, { lineHeight: Number(e.target.value) })}
          style={{ height: 22, fontSize: 11, border: `1px solid ${C.creamBorder}`, borderRadius: 3, color: C.text, padding: "0 3px", cursor: "pointer" }}
          title="Espaçamento entre linhas">
          {[1.0,1.15,1.5,1.8,2.0,2.5,3.0].map(lh => <option key={lh} value={lh}>{lh}×</option>)}
        </select>
      </RibbonGroup>

      {/* Styles */}
      <RibbonGroup label="Estilos">
        {(["heading1","heading2","heading3","paragraph"] as const).map(t => (
          <button key={t} onClick={() => selBlock && updateBlock(selBlock.id, { type: t, ...mkBlock(t) })}
            style={{ fontSize: 11, padding: "3px 8px", borderRadius: 3, border: `1px solid ${selBlock?.type === t ? C.brown : C.creamBorder}`, background: selBlock?.type === t ? `rgba(107,76,42,0.1)` : "transparent", color: C.text, cursor: "pointer" }}>
            {t === "heading1" ? "T1" : t === "heading2" ? "T2" : t === "heading3" ? "T3" : "§"}
          </button>
        ))}
      </RibbonGroup>

      {/* Editing */}
      <RibbonGroup label="Edição">
        {toolB("Localizar e Substituir", false, () => setShowFindReplace(true), <><Search size={13} /><span style={{ fontSize: 11, marginLeft: 3 }}>Localizar</span></>)}
        {toolB("Desfazer", false, undo, <RotateCcw size={13} />)}
        {toolB("Refazer", false, redo, <RotateCw size={13} />)}
      </RibbonGroup>
    </div>
  );

  const ribbonInserir = (
    <div style={{ display: "flex", alignItems: "stretch", gap: 0, padding: "4px 8px", flexWrap: "wrap" }}>
      <RibbonGroup label="Blocos">
        {[
          { label: "Parágrafo", type: "paragraph" as const, icon: <Type size={13} /> },
          { label: "Título 1",  type: "heading1" as const,  icon: <Heading size={13} /> },
          { label: "Título 2",  type: "heading2" as const,  icon: <span style={{ fontSize: 11, fontWeight: 700 }}>H2</span> },
          { label: "Título 3",  type: "heading3" as const,  icon: <span style={{ fontSize: 11, fontWeight: 700 }}>H3</span> },
          { label: "Espaço",    type: "spacer" as const,    icon: <Minus size={13} /> },
        ].map(b => (
          <button key={b.label} onClick={() => addBlock(b.type, selectedBlockId ?? undefined)}
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "4px 8px", border: `1px solid transparent`, borderRadius: 4, background: "transparent", cursor: "pointer", color: C.text, fontSize: 10 }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = C.creamBorder}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}
          >
            <span style={{ color: C.brown }}>{b.icon}</span>
            <span>{b.label}</span>
          </button>
        ))}
      </RibbonGroup>
      <RibbonGroup label="Tabelas">
        <button onClick={() => addBlock("table", selectedBlockId ?? undefined)}
          style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "4px 10px", border: `1px solid transparent`, borderRadius: 4, background: "transparent", cursor: "pointer", color: C.text, fontSize: 10 }}
          onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = C.creamBorder}
          onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}
        >
          <Table2 size={16} style={{ color: C.brown }} />
          <span>Tabela</span>
        </button>
      </RibbonGroup>
      <RibbonGroup label="Ilustrações">
        <button onClick={insertImage}
          style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "4px 10px", border: `1px solid transparent`, borderRadius: 4, background: "transparent", cursor: "pointer", color: C.text, fontSize: 10 }}
          onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = C.creamBorder}
          onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}
        >
          <ImageIcon size={16} style={{ color: C.brown }} />
          <span>Imagem</span>
        </button>
      </RibbonGroup>
      <RibbonGroup label="Layout">
        {[
          { label: "Divisor", type: "divider" as const, icon: <SeparatorHorizontal size={14} /> },
          { label: "2 Colunas", type: "twocol" as const, icon: <Columns size={14} /> },
        ].map(b => (
          <button key={b.label} onClick={() => addBlock(b.type, selectedBlockId ?? undefined)}
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "4px 8px", border: `1px solid transparent`, borderRadius: 4, background: "transparent", cursor: "pointer", color: C.text, fontSize: 10 }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = C.creamBorder}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}
          >
            <span style={{ color: C.brown }}>{b.icon}</span>
            <span>{b.label}</span>
          </button>
        ))}
      </RibbonGroup>
      <RibbonGroup label="Cabeçalho e Rodapé">
        <button onClick={() => setShowPageSettings(true)}
          style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, padding: "4px 10px", border: `1px solid transparent`, borderRadius: 4, background: "transparent", cursor: "pointer", color: C.text, fontSize: 10 }}
          onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = C.creamBorder}
          onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}
        >
          <Settings size={16} style={{ color: C.brown }} />
          <span>Cabeçalho</span>
        </button>
      </RibbonGroup>
    </div>
  );

  const ribbonLayout = (
    <div style={{ display: "flex", alignItems: "stretch", gap: 0, padding: "4px 8px", flexWrap: "wrap" }}>
      <RibbonGroup label="Margens">
        {[
          { label: "Normal",   m: { top: 25, bottom: 25, left: 25, right: 25 } },
          { label: "Estreita", m: { top: 13, bottom: 13, left: 13, right: 13 } },
          { label: "Larga",    m: { top: 25, bottom: 25, left: 50, right: 50 } },
        ].map(preset => (
          <button key={preset.label} onClick={() => setPageSettings(s => ({ ...s, margins: preset.m }))}
            style={{ fontSize: 11, padding: "4px 8px", borderRadius: 3, border: `1px solid ${C.creamBorder}`, background: C.cream, color: C.text, cursor: "pointer" }}>
            {preset.label}
          </button>
        ))}
      </RibbonGroup>
      <RibbonGroup label="Orientação">
        {[
          { label: "Vertical",     val: "portrait" as const },
          { label: "Horizontal",   val: "landscape" as const },
        ].map(o => (
          <button key={o.val} onClick={() => setPageSettings(s => ({ ...s, orientation: o.val }))}
            style={{ fontSize: 11, padding: "4px 8px", borderRadius: 3, border: `1px solid ${pageSettings.orientation === o.val ? C.brown : C.creamBorder}`, background: pageSettings.orientation === o.val ? `rgba(107,76,42,0.1)` : C.cream, color: C.text, cursor: "pointer" }}>
            {o.label}
          </button>
        ))}
      </RibbonGroup>
      <RibbonGroup label="Tamanho">
        {(["A4","A3","Letter"] as const).map(s => (
          <button key={s} onClick={() => setPageSettings(ps => ({ ...ps, page_size: s }))}
            style={{ fontSize: 11, padding: "4px 8px", borderRadius: 3, border: `1px solid ${pageSettings.page_size === s ? C.brown : C.creamBorder}`, background: pageSettings.page_size === s ? `rgba(107,76,42,0.1)` : C.cream, color: C.text, cursor: "pointer" }}>
            {s}
          </button>
        ))}
      </RibbonGroup>
      <RibbonGroup label="Configuração">
        <button onClick={() => setShowPageSettings(true)}
          style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, padding: "4px 10px", borderRadius: 3, border: `1px solid ${C.creamBorder}`, background: C.cream, color: C.text, cursor: "pointer" }}>
          <Settings size={12} /> Mais Opções
        </button>
      </RibbonGroup>
    </div>
  );

  const ribbonRevision = (
    <div style={{ display: "flex", alignItems: "stretch", gap: 0, padding: "4px 8px", flexWrap: "wrap" }}>
      <RibbonGroup label="Verificação">
        {toolB("Localizar e Substituir", false, () => setShowFindReplace(true), <><Search size={13} /><span style={{ fontSize: 11, marginLeft: 4 }}>Localizar</span></>)}
        {toolB("Contar Palavras", false, () => toast.info(`${wordCount} palavras · ${blocks.reduce((s, b) => s + (b.text?.length ?? 0), 0)} caracteres`), <Hash size={13} />)}
      </RibbonGroup>
      <RibbonGroup label="Alterações">
        {toolB("Desfazer", false, undo, <><RotateCcw size={13} /><span style={{ fontSize: 11, marginLeft: 4 }}>Desfazer</span></>)}
        {toolB("Refazer", false, redo, <><RotateCw size={13} /><span style={{ fontSize: 11, marginLeft: 4 }}>Refazer</span></>)}
      </RibbonGroup>
      <RibbonGroup label="Estatísticas">
        <div style={{ display: "flex", flexDirection: "column", gap: 2, padding: "0 6px", fontSize: 11, color: C.textMuted }}>
          <span>{wordCount} palavras</span>
          <span>{blocks.filter(b => !b.isDivider && b.type !== "spacer").length} blocos</span>
        </div>
      </RibbonGroup>
    </div>
  );

  const ribbonTabContent: Record<string, React.ReactNode> = {
    "Início": ribbonInicio,
    "Inserir": ribbonInserir,
    "Esquema": ribbonLayout,
    "Revisão": ribbonRevision,
  };

  // ─── Block editor inline ──────────────────────────────────────────────────────
  const renderBlockEditor = (b: Block, idx: number) => {
    const isSelected = selectedBlockId === b.id;

    if (b.type === "spacer") return (
      <div key={b.id} onClick={() => setSelectedBlockId(b.id)}
        style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 8px", background: isSelected ? `rgba(107,76,42,0.06)` : "transparent", borderRadius: 4, marginBottom: 2, cursor: "pointer", border: `1px dashed ${isSelected ? C.brownPale : "transparent"}` }}>
        <Minus size={12} style={{ color: C.brownPale }} />
        <span style={{ fontSize: 10, color: C.brownPale, flex: 1 }}>Espaço — {b.fontSize ?? 10}px</span>
        <input type="range" min={2} max={80} value={b.fontSize ?? 10} onChange={e => updateBlock(b.id, { fontSize: Number(e.target.value) })} style={{ width: 70, accentColor: C.brown }} onClick={e => e.stopPropagation()} />
        {isSelected && (
          <button onClick={() => removeBlock(b.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c0392b", padding: 2 }}><Trash2 size={12} /></button>
        )}
      </div>
    );

    if (b.isDivider) return (
      <div key={b.id} onClick={() => setSelectedBlockId(b.id)}
        style={{ padding: "6px 0", cursor: "pointer", background: isSelected ? `rgba(107,76,42,0.06)` : "transparent", borderRadius: 4, marginBottom: 2 }}>
        <div style={{ borderTop: b.dividerStyle === "double" ? `4px double ${C.brown}` : `2px ${b.dividerStyle ?? "solid"} ${C.brownPale}` }} />
        {isSelected && (
          <div style={{ display: "flex", gap: 6, marginTop: 4, justifyContent: "center" }}>
            {(["solid","dashed","double"] as const).map(s => (
              <button key={s} onClick={() => updateBlock(b.id, { dividerStyle: s })}
                style={{ fontSize: 10, padding: "2px 8px", border: `1px solid ${b.dividerStyle === s ? C.brown : C.creamBorder}`, borderRadius: 3, background: b.dividerStyle === s ? `rgba(107,76,42,0.1)` : "transparent", cursor: "pointer", color: C.text }}>{s}</button>
            ))}
            <button onClick={() => removeBlock(b.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c0392b", padding: 2 }}><Trash2 size={12} /></button>
          </div>
        )}
      </div>
    );

    if (b.isImage) return (
      <div key={b.id} onClick={() => setSelectedBlockId(b.id)}
        style={{ marginBottom: 6, border: `1px solid ${isSelected ? C.brown : "transparent"}`, borderRadius: 4, padding: 4, cursor: "pointer" }}>
        {b.imageUrl ? (
          <img src={b.imageUrl} alt={b.imageAlt} style={{ maxWidth: `${b.imageWidth ?? 80}%`, display: "block", margin: b.align === "center" ? "0 auto" : b.align === "right" ? "0 0 0 auto" : "0" }} />
        ) : (
          <div style={{ height: 80, background: C.creamDark, border: `1px dashed ${C.creamBorder}`, display: "flex", alignItems: "center", justifyContent: "center", borderRadius: 4 }}>
            <button onClick={() => { const url = prompt("URL da imagem:"); if (url) updateBlock(b.id, { imageUrl: url }); }}
              style={{ fontSize: 11, color: C.brown, background: "none", border: "none", cursor: "pointer" }}>Clica para adicionar imagem</button>
          </div>
        )}
        {isSelected && (
          <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
            <input type="range" min={10} max={100} value={b.imageWidth ?? 80} onChange={e => updateBlock(b.id, { imageWidth: Number(e.target.value) })} style={{ flex: 1, accentColor: C.brown }} />
            <span style={{ fontSize: 10, color: C.textMuted }}>{b.imageWidth ?? 80}%</span>
            {[
              { label: "←", align: "left" }, { label: "○", align: "center" }, { label: "→", align: "right" }
            ].map(a => (
              <button key={a.label} onClick={() => updateBlock(b.id, { align: a.align as any })}
                style={{ fontSize: 11, padding: "2px 6px", border: `1px solid ${b.align === a.align ? C.brown : C.creamBorder}`, borderRadius: 3, background: "transparent", cursor: "pointer" }}>{a.label}</button>
            ))}
            <button onClick={() => removeBlock(b.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c0392b", padding: 2 }}><Trash2 size={12} /></button>
          </div>
        )}
      </div>
    );

    if (b.isTable && b.tableRows) {
      const rows = b.tableRows;
      const cols = b.tableCols ?? 2;
      return (
        <div key={b.id} onClick={() => setSelectedBlockId(b.id)}
          style={{ marginBottom: 6, border: `1px solid ${isSelected ? C.brown : C.creamBorder}`, borderRadius: 4, overflow: "hidden" }}>
          {isSelected && (
            <div style={{ display: "flex", gap: 4, padding: "4px 8px", background: C.creamDark, borderBottom: `1px solid ${C.creamBorder}` }}>
              <button onClick={() => updateBlock(b.id, { tableRows: [...rows, Array(cols).fill("")] })} style={{ fontSize: 10, padding: "2px 8px", border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: "pointer", color: C.text }}>+ Linha</button>
              <button onClick={() => updateBlock(b.id, { tableCols: cols + 1, tableRows: rows.map(r => [...r, ""]) })} style={{ fontSize: 10, padding: "2px 8px", border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: "pointer", color: C.text }}>+ Coluna</button>
              <button onClick={() => rows.length > 1 && updateBlock(b.id, { tableRows: rows.slice(0, -1) })} style={{ fontSize: 10, padding: "2px 8px", border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: "pointer", color: "#c0392b" }}>− Linha</button>
              <button onClick={() => cols > 1 && updateBlock(b.id, { tableCols: cols - 1, tableRows: rows.map(r => r.slice(0, -1)) })} style={{ fontSize: 10, padding: "2px 8px", border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: "pointer", color: "#c0392b" }}>− Coluna</button>
              <div style={{ flex: 1 }} />
              <button onClick={() => removeBlock(b.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c0392b" }}><Trash2 size={12} /></button>
            </div>
          )}
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <tbody>
              {rows.map((row, ri) => (
                <tr key={ri}>
                  {row.map((cell, ci) => (
                    <td key={ci} style={{ border: `1px solid ${C.creamBorder}`, padding: 2, background: ri === 0 ? C.creamDark : C.white, minWidth: 60 }}>
                      <input value={cell} onChange={e => {
                        const nr = rows.map((r, ri2) => ri2 === ri ? r.map((c, ci2) => ci2 === ci ? e.target.value : c) : r);
                        updateBlock(b.id, { tableRows: nr });
                      }} style={{ width: "100%", border: "none", outline: "none", background: "transparent", fontSize: 11, padding: "4px 6px", fontWeight: ri === 0 ? 700 : 400, color: C.text, boxSizing: "border-box" }} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    if (b.isTwoCol) return (
      <div key={b.id} onClick={() => setSelectedBlockId(b.id)}
        style={{ marginBottom: 6, border: `1px solid ${isSelected ? C.brown : C.creamBorder}`, borderRadius: 4, overflow: "hidden" }}>
        {isSelected && (
          <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 8px", background: C.creamDark, borderBottom: `1px solid ${C.creamBorder}` }}>
            <Columns size={12} style={{ color: C.brown }} />
            <span style={{ fontSize: 11, color: C.textMuted, flex: 1 }}>Duas colunas</span>
            <button onClick={() => removeBlock(b.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c0392b" }}><Trash2 size={12} /></button>
          </div>
        )}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }}>
          {[b.col1 ?? "", b.col2 ?? ""].map((col, i) => (
            <textarea key={i} value={col} onChange={e => updateBlock(b.id, i === 0 ? { col1: e.target.value } : { col2: e.target.value })}
              placeholder={`Coluna ${i + 1}…`} rows={4}
              style={{ border: "none", outline: "none", borderLeft: i === 1 ? `1px solid ${C.creamBorder}` : "none", resize: "vertical", padding: "10px 14px", fontSize: 11, lineHeight: 1.7, background: "transparent", color: C.text, boxSizing: "border-box", width: "100%" }} />
          ))}
        </div>
      </div>
    );

    // Standard text block
    const hs = HEADING_STYLES[b.type] ?? HEADING_STYLES.paragraph;
    return (
      <div key={b.id}
        onClick={() => setSelectedBlockId(b.id)}
        style={{ position: "relative", marginBottom: 2, borderRadius: 4, border: `1px solid ${isSelected ? C.brownPale : "transparent"}`, transition: "border-color 0.15s" }}>
        {isSelected && (
          <div style={{ position: "absolute", right: -30, top: 0, display: "flex", flexDirection: "column", gap: 1 }}>
            <button disabled={idx === 0} onClick={() => moveBlock(b.id, -1)} style={{ width: 22, height: 22, border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: idx === 0 ? "default" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", opacity: idx === 0 ? 0.3 : 1 }}><ChevronUp size={11} /></button>
            <button disabled={idx === blocks.length - 1} onClick={() => moveBlock(b.id, 1)} style={{ width: 22, height: 22, border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: idx === blocks.length - 1 ? "default" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", opacity: idx === blocks.length - 1 ? 0.3 : 1 }}><ChevronDown size={11} /></button>
            <button onClick={() => removeBlock(b.id)} style={{ width: 22, height: 22, border: `1px solid #fcc`, borderRadius: 3, background: C.white, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: "#c0392b" }}><Trash2 size={11} /></button>
          </div>
        )}
        <textarea
          value={b.text ?? ""}
          onChange={e => updateBlock(b.id, { text: e.target.value })}
          onKeyDown={e => {
            if (e.ctrlKey || e.metaKey) {
              if (e.key === "b") { e.preventDefault(); updateBlock(b.id, { bold: !b.bold }); }
              if (e.key === "i") { e.preventDefault(); updateBlock(b.id, { italic: !b.italic }); }
              if (e.key === "u") { e.preventDefault(); updateBlock(b.id, { underline: !b.underline }); }
              if (e.key === "z") { e.preventDefault(); undo(); }
              if (e.key === "y") { e.preventDefault(); redo(); }
              if (e.key === "s") { e.preventDefault(); save(); }
            }
            if (e.key === "Enter" && e.shiftKey) {
              e.preventDefault();
              addBlock("paragraph", b.id);
            }
          }}
          placeholder={b.type === "heading1" ? "Título principal…" : b.type === "heading2" ? "Subtítulo…" : b.type === "heading3" ? "Título 3…" : "Escreva aqui… (Ctrl+B negrito, Ctrl+I itálico, Shift+Enter novo bloco)"}
          rows={b.type.startsWith("heading") ? 1 : 5}
          style={{
            width: "100%", boxSizing: "border-box",
            padding: b.type.startsWith("heading") ? "10px 14px" : "10px 14px",
            fontSize: `${b.fontSize ?? (hs.fontSize as number ?? 11)}px`,
            fontWeight: b.bold ? "bold" : (hs.fontWeight as any ?? "normal"),
            fontStyle: b.italic ? "italic" : "normal",
            textDecoration: [b.underline && "underline", b.strikethrough && "line-through"].filter(Boolean).join(" ") || undefined,
            textAlign: (b.align ?? "left") as any,
            lineHeight: b.lineHeight ?? 1.8,
            fontFamily: b.fontFamily ?? (hs.fontFamily as string ?? "Georgia, serif"),
            color: b.type.startsWith("heading") ? (hs.color as string) : (b.color ?? "#1a1a1a"),
            background: b.highlight && b.highlight !== "transparent" ? b.highlight : C.white,
            paddingLeft: `${14 + (b.indent ?? 0) * 20}px`,
            resize: "vertical", outline: "none", border: "none",
            borderBottom: hs.borderBottom as any,
          }}
        />
      </div>
    );
  };

  const margins = pageSettings.margins ?? { top: 25, bottom: 25, left: 25, right: 25 };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", margin: "-24px -28px", background: C.surface, overflow: "hidden" }}>
      <style>{`
        textarea { font-variant-ligatures: none; }
        @media print {
          .no-print { display: none !important; }
          .print-only { display: block !important; }
        }
      `}</style>

      {showFindReplace && <FindReplaceDialog onClose={() => setShowFindReplace(false)} blocks={blocks} onBlocks={updateBlocks} />}
      {showPageSettings && <PageSettingsDialog settings={pageSettings} onSave={s => setPageSettings(ps => ({ ...ps, ...s }))} onClose={() => setShowPageSettings(false)} />}

      {/* ── Menu bar (File, Edit, View…) ── */}
      <div className="no-print" style={{ background: `linear-gradient(to bottom,${C.brown},${C.brownLight})`, display: "flex", alignItems: "center", height: 34, flexShrink: 0 }}>
        <button onClick={() => onBack({ ...doc, ...buildPayload() } as SavedDoc)}
          style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: "rgba(255,255,255,0.8)", background: "none", border: "none", cursor: "pointer", padding: "0 10px", height: "100%" }}>
          <ArrowLeft size={14} /> Documentos
        </button>
        <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.2)", margin: "0 2px" }} />

        {Object.keys(menus).map(m => (
          <div key={m} style={{ position: "relative" }}>
            <button
              onClick={() => setActiveMenu(activeMenu === m ? null : m)}
              style={{ fontSize: 12.5, color: activeMenu === m ? C.brown : "rgba(255,255,255,0.82)", background: activeMenu === m ? C.white : "none", border: "none", cursor: "pointer", padding: "0 10px", height: 34, fontWeight: activeMenu === m ? 700 : 400, borderRadius: activeMenu === m ? "4px 4px 0 0" : 0 }}>
              {m}
            </button>
            {menus[m]}
          </div>
        ))}

        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 6, paddingRight: 12 }}>
          {lastSaved && <span style={{ fontSize: 11, color: "rgba(255,255,255,0.45)" }}>Guardado às {format(lastSaved, "HH:mm")}</span>}
          <button onClick={handleExport} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "rgba(255,255,255,0.8)", background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 4, cursor: "pointer", padding: "4px 10px" }}>
            <Download size={12} /> PDF
          </button>
          <button onClick={save} disabled={saving} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, fontWeight: 700, color: C.brown, background: C.white, border: "none", borderRadius: 4, cursor: saving ? "wait" : "pointer", padding: "5px 12px" }}>
            <Save size={12} />{saving ? "A guardar…" : "Guardar"}
          </button>
        </div>
      </div>

      {/* ── Ribbon ── */}
      <div className="no-print" style={{ background: C.ribbon, borderBottom: `1px solid ${C.creamBorder}`, flexShrink: 0 }}>
        {/* Tab bar */}
        <div style={{ display: "flex", background: C.ribbonTab, borderBottom: `1px solid ${C.creamBorder}` }}>
          {Object.keys(ribbonTabContent).map(tab => (
            <button key={tab} onClick={() => setActiveRibbonTab(tab)} style={tbStyle(activeRibbonTab === tab)}>{tab}</button>
          ))}
          <div style={{ flex: 1 }} />
          {/* Document title in ribbon */}
          <div style={{ display: "flex", alignItems: "center", paddingRight: 12 }}>
            <span style={{ fontSize: 12, color: C.brownPale, fontStyle: "italic" }}>{name || "Sem título"}</span>
          </div>
        </div>
        {/* Tab content */}
        {ribbonTabContent[activeRibbonTab]}
      </div>

      {/* ── Ruler ── */}
      {showRuler && (
        <div className="no-print" style={{ height: 18, background: C.creamDark, borderBottom: `1px solid ${C.creamBorder}`, display: "flex", alignItems: "center", paddingLeft: 280, flexShrink: 0, overflow: "hidden" }}>
          {Array.from({ length: 20 }, (_, i) => (
            <div key={i} style={{ display: "flex", alignItems: "flex-end", width: 38, flexShrink: 0 }}>
              <div style={{ height: i % 2 === 0 ? 8 : 5, width: 1, background: C.brownPale }} />
              {i % 2 === 0 && <span style={{ fontSize: 8, color: C.brownPale, marginLeft: 2 }}>{i + 1}</span>}
            </div>
          ))}
        </div>
      )}

      {/* ── Main editing area ── */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        {/* Paper area */}
        <div ref={editorRef} style={{ flex: 1, overflow: "auto", background: "#d4c9b8", backgroundImage: showGridLines ? "linear-gradient(rgba(107,76,42,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(107,76,42,0.05) 1px,transparent 1px)" : undefined, backgroundSize: showGridLines ? "20px 20px" : undefined, padding: "24px 20px" }}>
          {pageSettings.header_text && (
            <div style={{ maxWidth: 800, margin: "0 auto 0", textAlign: "center", fontSize: 10, color: C.textMuted, paddingBottom: 8, borderBottom: `1px solid ${C.creamBorder}`, marginBottom: 8 }}>
              {pageSettings.header_text}
            </div>
          )}
          <div style={{
            background: C.white, maxWidth: showPreview ? "calc(50% - 16px)" : 820, margin: "0 auto",
            boxShadow: "0 4px 32px rgba(107,76,42,0.2)",
            paddingTop: `${margins.top}mm`, paddingBottom: `${margins.bottom}mm`,
            paddingLeft: `${margins.left}mm`, paddingRight: `${margins.right}mm`,
            transform: `scale(${zoom / 100})`, transformOrigin: "top center",
            width: showPreview ? undefined : 820,
            minHeight: 900,
          }}>
            {/* Doc logo header */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, paddingBottom: 12, borderBottom: `1px solid ${C.creamBorder}` }}>
              <div style={{ width: 44, height: 28, background: C.brown, borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", flexShrink: 0 }}>
                <img src="/MM23.jpeg" alt="Logo" style={{ width: "100%", height: "100%", objectFit: "cover" }} onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
              </div>
              <div style={{ flex: 1 }}>
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Título do documento…"
                  style={{ width: "100%", boxSizing: "border-box", fontSize: 22, fontWeight: 700, color: C.brown, border: "none", background: "transparent", outline: "none", fontFamily: "'Segoe UI', system-ui, sans-serif" }} />
                {isOrc && clientName && <p style={{ margin: 0, fontSize: 10, color: C.textMuted }}>Cliente: {clientName}</p>}
              </div>
              <span style={{ fontSize: 10, color: C.brownPale }}>{format(new Date(), "dd/MM/yyyy")}</span>
            </div>

            {/* Blocks */}
            <div style={{ position: "relative" }}>
              {blocks.map((b, idx) => renderBlockEditor(b, idx))}
              {blocks.length === 0 && (
                <div style={{ textAlign: "center", paddingTop: 80, color: C.brownPale }}>
                  <FileText size={32} style={{ marginBottom: 10, opacity: 0.4 }} />
                  <p style={{ fontSize: 13 }}>Documento vazio</p>
                  <button onClick={() => addBlock("paragraph")} style={{ marginTop: 10, padding: "6px 16px", background: C.brown, color: C.white, border: "none", borderRadius: 5, cursor: "pointer", fontSize: 12 }}>Adicionar parágrafo</button>
                </div>
              )}
            </div>

            {/* Signatures */}
            {doc.docType === "comass" && (
              <div style={{ marginTop: 80, display: "flex", justifyContent: "space-between" }}>
                {["Assinatura do Cliente", "Assinatura da Miminhos Criativos"].map(label => (
                  <div key={label} style={{ textAlign: "center" }}>
                    <div style={{ borderTop: `1px solid ${C.brownPale}`, width: 160, paddingTop: 6, fontSize: 10, color: C.textMuted, marginTop: 40 }}>{label}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Footer */}
            <div style={{ marginTop: 40, paddingTop: 8, borderTop: `1px solid ${C.creamBorder}`, textAlign: "center", fontSize: 9, color: C.brownPale }}>
              {pageSettings.footer_text ?? "Miminhos Criativos · 926 992 352 · site.miminhoscriativos@gmail.com"}
              {pageSettings.show_page_numbers && <span style={{ marginLeft: 20 }}>Pág. 1</span>}
            </div>
          </div>

          {/* Add block button below paper */}
          <div style={{ maxWidth: showPreview ? "calc(50% - 16px)" : 820, margin: "12px auto 0", display: "flex", justifyContent: "center" }}>
            <button onClick={() => addBlock("paragraph")}
              style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 16px", border: `1px dashed ${C.creamBorder}`, borderRadius: 20, background: "transparent", color: C.brownPale, cursor: "pointer", fontSize: 11, transition: "all 0.15s" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = C.brown; (e.currentTarget as HTMLElement).style.color = C.brown; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = C.creamBorder; (e.currentTarget as HTMLElement).style.color = C.brownPale; }}>
              <Plus size={13} /> Adicionar bloco
            </button>
          </div>
        </div>

        {/* ── Live Preview ── */}
        {showPreview && (
          <div style={{ flex: 1, overflow: "auto", background: "#c8bdb0", padding: "24px 20px", borderLeft: `2px solid ${C.creamBorder}` }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 12, textAlign: "center" }}>Pré-visualização</div>
            <div style={{
              background: C.white, maxWidth: 820, margin: "0 auto",
              boxShadow: "0 4px 24px rgba(107,76,42,0.2)",
              paddingTop: `${margins.top}mm`, paddingBottom: `${margins.bottom}mm`,
              paddingLeft: `${margins.left}mm`, paddingRight: `${margins.right}mm`,
              transform: `scale(${zoom / 100})`, transformOrigin: "top center",
              minHeight: 900,
            }}>
              {/* Header */}
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, paddingBottom: 12, borderBottom: `1px solid ${C.creamBorder}` }}>
                <div style={{ width: 44, height: 28, background: C.brown, borderRadius: 4, overflow: "hidden", flexShrink: 0 }}>
                  <img src="/MM23.jpeg" alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
                </div>
                <div style={{ flex: 1 }}>
                  {name && <p style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.brown, fontFamily: "'Segoe UI',system-ui,sans-serif" }}>{name}</p>}
                  {isOrc && clientName && <p style={{ margin: 0, fontSize: 10, color: C.textMuted }}>Cliente: {clientName}</p>}
                </div>
                <span style={{ fontSize: 10, color: C.brownPale }}>{format(new Date(), "dd/MM/yyyy")}</span>
              </div>
              {blocks.map((b, i) => <BlockPreview key={i} b={b} />)}
              {doc.docType === "comass" && (
                <div style={{ marginTop: 80, display: "flex", justifyContent: "space-between" }}>
                  {["Assinatura do Cliente", "Assinatura da Miminhos Criativos"].map(label => (
                    <div key={label} style={{ textAlign: "center" }}>
                      <div style={{ borderTop: `1px solid ${C.brownPale}`, width: 160, paddingTop: 6, fontSize: 10, color: C.textMuted, marginTop: 40 }}>{label}</div>
                    </div>
                  ))}
                </div>
              )}
              <div style={{ marginTop: 40, paddingTop: 8, borderTop: `1px solid ${C.creamBorder}`, textAlign: "center", fontSize: 9, color: C.brownPale }}>
                {pageSettings.footer_text}
              </div>
            </div>
          </div>
        )}

        {/* ── Sidebar ── */}
        <div className="no-print" style={{ width: 200, flexShrink: 0, background: C.cream, borderLeft: `1px solid ${C.creamBorder}`, overflowY: "auto", display: "flex", flexDirection: "column" }}>
          {/* Save */}
          <div style={{ padding: 12, borderBottom: `1px solid ${C.creamBorder}` }}>
            <button onClick={save} disabled={saving}
              style={{ width: "100%", padding: "8px", background: `linear-gradient(135deg,${C.brown},${C.brownLight})`, color: C.white, border: "none", borderRadius: 5, fontSize: 12, fontWeight: 700, cursor: saving ? "wait" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 5, marginBottom: 6 }}>
              <Save size={13} />{saving ? "A guardar…" : "Guardar"}
            </button>
            <div style={{ display: "flex", gap: 4 }}>
              <button onClick={handleExport} style={{ flex: 1, padding: "5px", background: C.white, color: C.brown, border: `1px solid ${C.creamBorder}`, borderRadius: 4, fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                <Download size={11} /> PDF
              </button>
              <button onClick={() => setShowPreview(v => !v)} style={{ flex: 1, padding: "5px", background: showPreview ? `rgba(107,76,42,0.1)` : C.white, color: C.brown, border: `1px solid ${showPreview ? C.brown : C.creamBorder}`, borderRadius: 4, fontSize: 11, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                <Eye size={11} /> {showPreview ? "Ocultar" : "Preview"}
              </button>
            </div>
          </div>

          {/* Zoom */}
          <div style={{ padding: "10px 12px", borderBottom: `1px solid ${C.creamBorder}` }}>
            <p style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 6px" }}>Zoom</p>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <button onClick={() => setZoom(z => Math.max(50, z - 10))} style={{ width: 22, height: 22, border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><ZoomOut size={11} /></button>
              <span style={{ flex: 1, textAlign: "center", fontSize: 12, fontWeight: 700, color: C.brown }}>{zoom}%</span>
              <button onClick={() => setZoom(z => Math.min(150, z + 10))} style={{ width: 22, height: 22, border: `1px solid ${C.creamBorder}`, borderRadius: 3, background: C.white, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><ZoomIn size={11} /></button>
            </div>
          </div>

          {/* Client info */}
          {isOrc && (
            <div style={{ padding: "10px 12px", borderBottom: `1px solid ${C.creamBorder}` }}>
              <p style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 8px", display: "flex", alignItems: "center", gap: 4 }}>
                <User size={11} /> Cliente
              </p>
              {[
                { label: "Nome", value: clientName, set: setClientName, ph: "Nome do cliente" },
                ...(doc.docType === "orcamento_interno" ? [
                  { label: "NIF", value: clientNif, set: setClientNif, ph: "123456789" },
                  { label: "Ref.", value: clientRef, set: setClientRef, ph: "Referência" },
                ] : []),
              ].map(f => (
                <div key={f.label} style={{ marginBottom: 6 }}>
                  <label style={{ fontSize: 10, color: C.textMuted, display: "block", marginBottom: 2 }}>{f.label}</label>
                  <input value={f.value} onChange={e => f.set(e.target.value)} placeholder={f.ph}
                    style={{ width: "100%", boxSizing: "border-box", height: 26, fontSize: 11, border: `1px solid ${C.creamBorder}`, borderRadius: 4, padding: "0 7px", color: C.text, outline: "none" }}
                    onFocus={e => (e.currentTarget.style.borderColor = C.brown)}
                    onBlur={e => (e.currentTarget.style.borderColor = C.creamBorder)} />
                </div>
              ))}
            </div>
          )}

          {/* Stats */}
          <div style={{ padding: "10px 12px" }}>
            <p style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "0 0 8px" }}>Estatísticas</p>
            {[
              ["Palavras", wordCount],
              ["Blocos", blocks.filter(b => !b.isDivider && b.type !== "spacer").length],
              ["Tabelas", blocks.filter(b => b.isTable).length],
              ["Imagens", blocks.filter(b => b.isImage).length],
            ].map(([l, v]) => (
              <div key={l as string} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 11, color: C.textMuted }}>{l}</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: C.brown }}>{v}</span>
              </div>
            ))}
          </div>

          {/* Shortcuts */}
          <div style={{ padding: "0 12px 12px", borderTop: `1px solid ${C.creamBorder}`, marginTop: "auto" }}>
            <p style={{ fontSize: 10, fontWeight: 700, color: C.textMuted, textTransform: "uppercase", letterSpacing: "0.1em", margin: "10px 0 6px" }}>Atalhos</p>
            {[["Ctrl+S","Guardar"],["Ctrl+B","Negrito"],["Ctrl+I","Itálico"],["Ctrl+U","Sublinhado"],["Ctrl+Z","Desfazer"],["Ctrl+Y","Refazer"],["Shift+↵","Novo bloco"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <kbd style={{ fontSize: 9, background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 3, padding: "1px 4px", color: C.brown, fontFamily: "monospace" }}>{k}</kbd>
                <span style={{ fontSize: 10, color: C.textMuted }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Status bar ── */}
      <div className="no-print" style={{ height: 22, background: `linear-gradient(to bottom,${C.brown},${C.brownLight})`, display: "flex", alignItems: "center", paddingLeft: 12, paddingRight: 12, gap: 16, flexShrink: 0 }}>
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>{wordCount} palavras</span>
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>{blocks.length} blocos</span>
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>{pageSettings.page_size} · {pageSettings.orientation === "portrait" ? "Vertical" : "Horizontal"}</span>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>Zoom {zoom}%</span>
        {selectedBlockId && <span style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>Bloco: {selBlock?.type}</span>}
      </div>
    </div>
  );
};

// ─── Template Gallery ─────────────────────────────────────────────────────────
const TemplateGallery = ({ onSelect, onBack }: { onSelect: (t: DocTemplate) => void; onBack: () => void }) => {
  const categories = Array.from(new Set(TEMPLATE_DEFS.map(t => t.category)));
  const ICONS: Record<string, React.ReactNode> = {
    semass:    <FileText size={20} />,
    comass:    <FileSignature size={20} />,
    orc_ext:   <FileCheck size={20} />,
    orc_int:   <FileArchive size={20} />,
    carta:     <FileText size={20} />,
    minuta:    <FileText size={20} />,
  };
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 20 }}>
        <button onClick={onBack} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: C.textMuted, background: C.creamDark, border: `1px solid ${C.creamBorder}`, borderRadius: 6, padding: "6px 12px", cursor: "pointer" }}>
          <ArrowLeft size={13} /> Voltar
        </button>
        <span style={{ fontSize: 14, fontWeight: 600, color: C.brown }}>Escolher Modelo</span>
      </div>
      {categories.map(cat => (
        <div key={cat} style={{ marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
            <span style={{ fontSize: 11, fontWeight: 700, padding: "2px 10px", borderRadius: 20, background: "rgba(107,76,42,0.08)", color: C.brown, border: `1px solid rgba(107,76,42,0.15)` }}>{cat}</span>
            <div style={{ flex: 1, height: 1, background: C.creamBorder }} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))", gap: 12 }}>
            {TEMPLATE_DEFS.filter(t => t.category === cat).map(t => (
              <button key={t.id} onClick={() => onSelect(t)}
                style={{ textAlign: "left", border: `1px solid ${C.creamBorder}`, borderRadius: 8, padding: 16, cursor: "pointer", background: C.cream, transition: "all 0.2s" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = C.brown; (e.currentTarget as HTMLElement).style.boxShadow = `0 4px 16px rgba(107,76,42,0.12)`; (e.currentTarget as HTMLElement).style.background = C.white; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = C.creamBorder; (e.currentTarget as HTMLElement).style.boxShadow = "none"; (e.currentTarget as HTMLElement).style.background = C.cream; }}>
                <div style={{ width: 40, height: 40, borderRadius: 8, background: "rgba(107,76,42,0.08)", border: `1px solid rgba(107,76,42,0.12)`, display: "flex", alignItems: "center", justifyContent: "center", color: C.brown, marginBottom: 10 }}>
                  {ICONS[t.id] ?? <FileText size={20} />}
                </div>
                <p style={{ margin: "0 0 4px", fontSize: 13, fontWeight: 600, color: C.brown }}>{t.name}</p>
                <p style={{ margin: 0, fontSize: 11, color: C.textMuted, lineHeight: 1.5 }}>{t.description}</p>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

// ─── Main Page ────────────────────────────────────────────────────────────────
type View = "list" | "gallery" | "editor";

const AdminDocumentos = () => {
  const { user } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const [view, setView]         = useState<View>("list");
  const [docs, setDocs]         = useState<SavedDoc[]>([]);
  const [activeDoc, setActiveDoc] = useState<SavedDoc | null>(null);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState("");
  const [listMode, setListMode] = useState<"grid" | "list">("list");

  const load = async () => {
    setLoading(true);
    const { data, error } = await (supabase as any).from("documents").select("*").order("updated_at", { ascending: false });
    if (!error) setDocs((data ?? []) as SavedDoc[]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const selectTemplate = (t: DocTemplate) => {
    const doc: SavedDoc = { id: `new-${Date.now()}`, name: t.name, docType: t.docType, blocks: t.blocks, category: t.category, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), created_by: user?.id };
    setActiveDoc(doc); setView("editor");
  };
  const openDoc = (d: SavedDoc) => { setActiveDoc(d); setView("editor"); };
  const handleSaved = (_: SavedDoc) => { load(); setActiveDoc(null); setView("list"); };
  const deleteDoc = async (id: string, name: string) => {
    if (!confirm(`Eliminar "${name}"?`)) return;
    await (supabase as any).from("documents").delete().eq("id", id);
    toast.success("Eliminado."); load();
  };

  if (view === "gallery") return <TemplateGallery onSelect={selectTemplate} onBack={() => setView("list")} />;
  if (view === "editor" && activeDoc) return <Editor doc={activeDoc} onBack={handleSaved} currentUser={user} />;

  const filtered = docs.filter(d => !search || d.name?.toLowerCase().includes(search.toLowerCase()) || d.category?.toLowerCase().includes(search.toLowerCase()));

  const ICONS: Record<string, React.ReactNode> = {
    semass: <FileText size={16} />, comass: <FileSignature size={16} />,
    orcamento_externo: <FileCheck size={16} />, orcamento_interno: <FileArchive size={16} />,
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <style>{`.doc-row:hover { background: rgba(107,76,42,0.04) !important; } .doc-row:hover .doc-nm { color: ${C.brown} !important; }`}</style>

      <PageHeader title="Documentos" description="Editor de documentos com exportação PDF"
        action={
          <Button onClick={() => setView("gallery")} style={{ background: `linear-gradient(135deg,${C.brown},${C.brownLight})`, color: C.white, border: "none" }}>
            <FilePlus size={14} style={{ marginRight: 6 }} /> Criar Documento
          </Button>
        }
      />

      {docs.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(130px,1fr))", gap: 10 }}>
          {[
            { label: "Total", value: docs.length, icon: <FileText size={16} /> },
            { label: "Geral", value: docs.filter(d => d.category === "Geral").length, icon: <FileArchive size={16} /> },
            { label: "Orçamentos", value: docs.filter(d => d.category === "Orçamentos").length, icon: <FileCheck size={16} /> },
          ].map(s => (
            <div key={s.label} style={{ background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 10, padding: "10px 14px", display: "flex", alignItems: "center", gap: 10, boxShadow: "0 1px 4px rgba(107,76,42,0.06)" }}>
              <div style={{ background: "rgba(107,76,42,0.08)", borderRadius: 7, padding: 8, color: C.brown }}>{s.icon}</div>
              <div>
                <p style={{ margin: 0, fontSize: 11, color: C.textMuted }}>{s.label}</p>
                <p style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.brown }}>{s.value}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 8, padding: "7px 12px", boxShadow: "0 1px 4px rgba(107,76,42,0.06)" }}>
        <Search size={14} style={{ color: C.brownPale, flexShrink: 0 }} />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Pesquisar documentos…"
          style={{ flex: 1, border: "none", outline: "none", fontSize: 13, color: C.text, background: "transparent" }} />
        {search && <button onClick={() => setSearch("")} style={{ fontSize: 11, color: C.textMuted, background: "none", border: "none", cursor: "pointer" }}>Limpar</button>}
        <span style={{ fontSize: 11, color: C.brownPale }}>{filtered.length} doc{filtered.length !== 1 ? "s" : ""}</span>
        <div style={{ width: 1, height: 16, background: C.creamBorder }} />
        <button onClick={() => setListMode("list")} style={{ padding: 4, border: "none", background: "none", cursor: "pointer", color: listMode === "list" ? C.brown : C.brownPale }}><LayoutList size={14} /></button>
        <button onClick={() => setListMode("grid")} style={{ padding: 4, border: "none", background: "none", cursor: "pointer", color: listMode === "grid" ? C.brown : C.brownPale }}><Grid3X3 size={14} /></button>
      </div>

      {loading ? (
        <div style={{ textAlign: "center", padding: 60, color: C.textMuted }}>A carregar…</div>
      ) : filtered.length === 0 ? (
        <div style={{ background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 10, padding: 60, textAlign: "center" }}>
          <FileText size={40} style={{ color: C.brownPale, opacity: 0.3, marginBottom: 12 }} />
          <p style={{ fontSize: 14, fontWeight: 600, color: C.brown, marginBottom: 6 }}>{search ? "Nenhum resultado" : "Ainda não há documentos"}</p>
          <p style={{ fontSize: 12, color: C.textMuted, marginBottom: 20 }}>{search ? "Tenta outros termos." : "Cria o primeiro documento."}</p>
          {!search && (
            <button onClick={() => setView("gallery")} style={{ background: `linear-gradient(135deg,${C.brown},${C.brownLight})`, color: C.white, border: "none", borderRadius: 6, padding: "8px 20px", fontSize: 12, fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}>
              <FilePlus size={13} /> Criar Documento
            </button>
          )}
        </div>
      ) : listMode === "list" ? (
        <div style={{ background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 10, overflow: "hidden", boxShadow: "0 1px 4px rgba(107,76,42,0.06)" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 120px 150px 80px", gap: 10, padding: "9px 14px", background: C.creamDark, borderBottom: `1px solid ${C.creamBorder}` }}>
            {["Documento", "Categoria", "Modificado", ""].map(h => <span key={h} style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: C.textMuted }}>{h}</span>)}
          </div>
          {filtered.map(doc => (
            <div key={doc.id} className="doc-row"
              style={{ display: "grid", gridTemplateColumns: "1fr 120px 150px 80px", gap: 10, padding: "11px 14px", alignItems: "center", borderBottom: `1px solid ${C.creamBorder}`, cursor: "pointer", transition: "background 0.12s" }}
              onClick={() => openDoc(doc)}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                <div style={{ width: 30, height: 30, borderRadius: 6, background: "rgba(107,76,42,0.07)", border: `1px solid rgba(107,76,42,0.12)`, display: "flex", alignItems: "center", justifyContent: "center", color: C.brown, flexShrink: 0 }}>
                  {ICONS[doc.docType] ?? <FileText size={14} />}
                </div>
                <div style={{ minWidth: 0 }}>
                  <p className="doc-nm" style={{ margin: 0, fontSize: 13, fontWeight: 600, color: C.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", transition: "color 0.12s" }}>{doc.name || "Sem título"}</p>
                  <p style={{ margin: 0, fontSize: 11, color: C.brownPale }}>{(doc.blocks as Block[])?.filter(b => b.type !== "spacer" && !b.isDivider).length ?? 0} bloco(s)</p>
                </div>
              </div>
              <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 20, background: "rgba(107,76,42,0.07)", color: C.brown, border: `1px solid rgba(107,76,42,0.12)`, fontWeight: 600, display: "inline-block" }}>{doc.category}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: C.brownPale }}>
                <Clock size={11} />
                {doc.updated_at ? format(new Date(doc.updated_at), "dd/MM/yy HH:mm", { locale: pt }) : "—"}
              </div>
              <div style={{ display: "flex", gap: 2, justifyContent: "flex-end" }} onClick={e => e.stopPropagation()}>
                <button onClick={() => openDoc(doc)} style={{ width: 26, height: 26, borderRadius: 4, border: "none", background: "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: C.textMuted }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = C.creamDark; (e.currentTarget as HTMLElement).style.color = C.brown; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = C.textMuted; }}>
                  <Pencil size={12} />
                </button>
                <button onClick={() => deleteDoc(doc.id, doc.name)} style={{ width: 26, height: 26, borderRadius: 4, border: "none", background: "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: C.textMuted }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#feeeed"; (e.currentTarget as HTMLElement).style.color = "#c0392b"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = C.textMuted; }}>
                  <Trash2 size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(190px,1fr))", gap: 12 }}>
          {filtered.map(doc => (
            <div key={doc.id}
              style={{ background: C.white, border: `1px solid ${C.creamBorder}`, borderRadius: 10, overflow: "hidden", cursor: "pointer", boxShadow: "0 1px 4px rgba(107,76,42,0.06)", transition: "all 0.2s" }}
              onClick={() => openDoc(doc)}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = `0 6px 20px rgba(107,76,42,0.14)`; (e.currentTarget as HTMLElement).style.borderColor = C.brownPale; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 1px 4px rgba(107,76,42,0.06)"; (e.currentTarget as HTMLElement).style.borderColor = C.creamBorder; }}>
              <div style={{ height: 90, background: C.creamDark, display: "flex", alignItems: "center", justifyContent: "center", borderBottom: `1px solid ${C.creamBorder}`, color: C.brownPale }}>
                {ICONS[doc.docType] ?? <FileText size={28} />}
              </div>
              <div style={{ padding: "10px 12px" }}>
                <p style={{ margin: "0 0 3px", fontSize: 12, fontWeight: 600, color: C.brown, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{doc.name || "Sem título"}</p>
                <p style={{ margin: "0 0 4px", fontSize: 10, color: C.textMuted }}>{doc.category}</p>
                <p style={{ margin: 0, fontSize: 10, color: C.brownPale }}>{doc.updated_at ? format(new Date(doc.updated_at), "dd/MM/yy", { locale: pt }) : "—"}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminDocumentos;
