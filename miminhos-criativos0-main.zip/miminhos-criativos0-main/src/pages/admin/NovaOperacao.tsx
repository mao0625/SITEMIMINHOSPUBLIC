import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import {
  ArrowLeft, X, Plus, Minus, Search, User, CreditCard,
  Banknote, Receipt, Euro, Star, Loader2, Check, Delete,
  Flower2, PartyPopper, Camera, Utensils, Music, Box,
  Palette, Sparkles, Gift, Package, Tag, ShoppingCart,
  Hash, Calendar, CheckCircle2,
  XCircle, ChevronDown, LayoutGrid, FileText,
  Percent, RotateCcw, ChevronRight, Users, Zap, FileDigit,
  Ticket, BadgePercent, Clock, AlertTriangle,
} from "lucide-react";

// ─── Paleta castanho quente (inalterada) ─────────────────────────────────────
const P = {
  bg:        "#faf6f0",
  bgCard:    "#ffffff",
  bgSurf:    "#f5ede0",
  bgAccent:  "#ede0cc",
  bgDark:    "#3d2b1f",
  bgDarkHov: "#2e1f15",
  bgMid:     "#7a5c45",
  text:      "#1e1008",
  textSub:   "#5c3d28",
  textMuted: "#9a7258",
  textHint:  "#c4a882",
  border:    "#e8d5bc",
  borderMed: "#d4b896",
  gold:      "#c9a84c",
  goldL:     "#fdf5dc",
  goldB:     "#f0dfa0",
  green:     "#2d6a4f",
  greenL:    "#d8f3dc",
  amber:     "#b5680a",
  amberL:    "#fff0c7",
  amberB:    "#fcd34d",
  red:       "#9b2226",
  redL:      "#ffebed",
  blue:      "#1d4e89",
  blueL:     "#dbeafe",
};

const CATS = [
  { key: "decoracao",      label: "Decoração",     icon: Flower2,     color: "#7c3aed", bg: "#f5f3ff" },
  { key: "animacao",       label: "Animação",       icon: PartyPopper, color: "#be185d", bg: "#fdf2f8" },
  { key: "fotografia",     label: "Fotografia",     icon: Camera,      color: "#0369a1", bg: "#e0f2fe" },
  { key: "catering",       label: "Catering",       icon: Utensils,    color: "#166534", bg: "#dcfce7" },
  { key: "som_luz",        label: "Som & Luz",      icon: Music,       color: "#7e22ce", bg: "#faf5ff" },
  { key: "materiais",      label: "Materiais",      icon: Box,         color: "#92400e", bg: "#fef3c7" },
  { key: "personalizados", label: "Personalizados", icon: Palette,     color: "#9d174d", bg: "#fce7f3" },
  { key: "baloes",         label: "Balões",         icon: Sparkles,    color: "#0c4a6e", bg: "#e0f2fe" },
  { key: "festas",         label: "Festas",         icon: Gift,        color: "#991b1b", bg: "#fee2e2" },
  { key: "outros",         label: "Outros",         icon: Package,     color: "#78350f", bg: "#fef3c7" },
];
const getCat = (key: string) => CATS.find(c => c.key === key) ?? CATS[CATS.length - 1];

const PAYMENT_STATUS_OPTS = [
  { key: "pago",          label: "Pago",          color: P.green,  bg: P.greenL },
  { key: "por_pagar",     label: "Por Pagar",     color: P.amber,  bg: P.amberL },
  { key: "em_pagamento",  label: "Em Pagamento",  color: P.blue,   bg: P.blueL  },
  { key: "nao_realizado", label: "Não Realizado", color: P.red,    bg: P.redL   },
];

interface CartItem {
  id: string; name: string; price: number; qty: number;
  category: string; type: "product" | "event" | "promotion"; eventId?: string; promoId?: string;
}
interface Client {
  id: string; full_name?: string; email?: string;
  client_number?: number; phone?: string; nif?: string;
}
interface EventItem {
  id: string; title: string; event_date?: string; event_type?: string;
  status: string; estado_pagamento?: string;
  payment_value?: number; budget?: number; guests_count?: number;
}

const fmt = (n: number) => n.toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const getEventValue = (ev: EventItem): number => {
  if (ev.payment_value && Number(ev.payment_value) > 0) return Number(ev.payment_value);
  if (ev.budget        && Number(ev.budget)        > 0) return Number(ev.budget);
  return 0;
};
const generateOpNumber = async () => {
  const { count } = await supabase.from("pos_operations").select("*", { count: "exact", head: true });
  return `OPR-${((count ?? 0) + 1).toString().padStart(4, "0")}`;
};

// ─── NIF Modal ────────────────────────────────────────────────────────────────
const NifModal = ({ client, onOk, onAssociar }: {
  client: Client; onOk: () => void; onAssociar: (nif: string) => void;
}) => {
  const [step, setStep]         = useState<"ask" | "input">("ask");
  const [nifInput, setNifInput] = useState(client.nif || "");
  const [nifError, setNifError] = useState("");
  const hasNif = !!client.nif;

  const handleAssociar = () => { if (hasNif) { onAssociar(client.nif!); return; } setStep("input"); };
  const handleSubmitNif = () => {
    const cleaned = nifInput.replace(/\D/g, "");
    if (cleaned.length !== 9) { setNifError("O NIF deve ter 9 dígitos."); return; }
    setNifError(""); onAssociar(cleaned);
  };

  return (
    <div style={{ position:"fixed",inset:0,zIndex:70,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(10,6,3,.75)",backdropFilter:"blur(16px)" }}>
      <div style={{ width:"100%",maxWidth:580,margin:"0 20px",borderRadius:0,overflow:"hidden",background:"#fff",boxShadow:"0 60px 120px rgba(0,0,0,.5)" }}>
        {step === "ask" ? (
          <>
            <div style={{ background:"#f04040",padding:"52px 40px 44px",textAlign:"center" }}>
              <p style={{ margin:0,fontSize:52,fontWeight:900,color:"#fff",letterSpacing:"-1px",lineHeight:1,fontFamily:"Georgia, serif" }}>Atenção</p>
              <p style={{ margin:"18px 0 0",fontSize:28,fontWeight:700,color:"#fff",lineHeight:1.3,fontFamily:"Georgia, serif" }}>Pergunte ao cliente<br />se deseja NIF</p>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr" }}>
              <button onClick={onOk} style={{ padding:"52px 20px",background:"#c8c8c8",border:"none",borderRight:"1px solid #b0b0b0",cursor:"pointer",transition:"background .15s",display:"flex",alignItems:"center",justifyContent:"center" }}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="#b8b8b8";}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="#c8c8c8";}}>
                <span style={{ fontSize:44,fontWeight:900,color:"#1a1a1a",fontFamily:"Georgia, serif" }}>OK</span>
              </button>
              <button onClick={handleAssociar} style={{ padding:"52px 20px",background:"#c8c8c8",border:"none",cursor:"pointer",transition:"background .15s",display:"flex",alignItems:"center",justifyContent:"center" }}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="#b8b8b8";}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="#c8c8c8";}}>
                <span style={{ fontSize:44,fontWeight:900,color:"#1a1a1a",fontFamily:"Georgia, serif",textAlign:"center",lineHeight:1.1 }}>Associar NIF</span>
              </button>
            </div>
            {hasNif && (
              <div style={{ background:"#f7f7f7",padding:"14px 24px",textAlign:"center",borderTop:"1px solid #ddd" }}>
                <p style={{ margin:0,fontSize:13,color:"#888" }}>NIF registado na conta: <strong style={{ color:"#333" }}>{client.nif}</strong></p>
              </div>
            )}
          </>
        ) : (
          <>
            <div style={{ background:P.bgDark,padding:"32px 40px 28px" }}>
              <div style={{ display:"flex",alignItems:"center",gap:14,marginBottom:6 }}>
                <div style={{ width:44,height:44,borderRadius:12,background:"rgba(255,255,255,.1)",display:"flex",alignItems:"center",justifyContent:"center" }}>
                  <FileDigit style={{ width:22,height:22,color:"#f5e6d3" }} />
                </div>
                <div>
                  <p style={{ margin:0,fontSize:20,fontWeight:800,color:"#f5e6d3" }}>Inserir NIF do Cliente</p>
                  <p style={{ margin:0,fontSize:12,color:"rgba(255,255,255,.4)" }}>O NIF será associado a esta operação</p>
                </div>
              </div>
            </div>
            <div style={{ padding:"32px 40px 28px",display:"flex",flexDirection:"column",gap:20 }}>
              <div>
                <label style={{ fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.14em",color:P.textMuted,display:"block",marginBottom:10 }}>Número de Identificação Fiscal (NIF)</label>
                <input value={nifInput} onChange={e=>{setNifInput(e.target.value);setNifError("");}} onKeyDown={e=>e.key==="Enter"&&handleSubmitNif()} placeholder="123 456 789" maxLength={11} autoFocus
                  style={{ width:"100%",padding:"16px 18px",fontSize:28,fontWeight:800,letterSpacing:"0.1em",borderRadius:12,border:`2px solid ${nifError?P.red:P.border}`,background:P.bgSurf,color:P.text,outline:"none",boxSizing:"border-box",textAlign:"center",transition:"border-color .15s" } as any} />
                {nifError && <p style={{ margin:"8px 0 0",fontSize:12,color:P.red,fontWeight:600 }}>{nifError}</p>}
              </div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                <button onClick={()=>setStep("ask")} style={{ padding:"16px 0",borderRadius:12,border:`2px solid ${P.border}`,background:P.bgSurf,color:P.textSub,fontSize:14,fontWeight:700,cursor:"pointer" }}>Voltar</button>
                <button onClick={handleSubmitNif} style={{ padding:"16px 0",borderRadius:12,border:"none",background:P.bgDark,color:"#f5e6d3",fontSize:14,fontWeight:800,cursor:"pointer" }}>Confirmar NIF</button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// ─── Numpad ───────────────────────────────────────────────────────────────────
const Numpad = ({ value, onChange }: { value: string; onChange: (v: string) => void }) => {
  const press = (k: string) => {
    if (k === "C")  return onChange("");
    if (k === "⌫") return onChange(value.slice(0, -1) || "");
    if (k === "." && value.includes(".")) return;
    if (value.length >= 9) return;
    onChange(value + k);
  };
  const keys = [["7","8","9"],["4","5","6"],["1","2","3"],["C","0","⌫"]];
  return (
    <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
      {keys.map((row, ri) => (
        <div key={ri} style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6 }}>
          {row.map(k => (
            <button key={k} onClick={()=>press(k)} style={{ height:44,borderRadius:10,fontSize:15,fontWeight:700,cursor:"pointer",border:"1.5px solid",transition:"all .1s",background:k==="C"?P.redL:k==="⌫"?P.amberL:P.bgSurf,color:k==="C"?P.red:k==="⌫"?P.amber:P.text,borderColor:k==="C"?"#f4b8bb":k==="⌫"?P.amberB:P.border }}>
              {k==="⌫"?<Delete style={{ width:14,height:14,margin:"0 auto" }} />:k}
            </button>
          ))}
        </div>
      ))}
    </div>
  );
};

// ─── PayModal ─────────────────────────────────────────────────────────────────
const PayModal = ({ total, saving, onConfirm, onClose, clientPhone, nifAssociado }: {
  total: number; saving: boolean;
  onConfirm: (method: string, status: string, paid: number, mbway: string) => void;
  onClose: () => void; clientPhone?: string; nifAssociado?: string;
}) => {
  const [method, setMethod] = useState("dinheiro");
  const [status, setStatus] = useState("pago");
  const [paid,   setPaid]   = useState(total.toFixed(2));
  const [mbway,  setMbway]  = useState(clientPhone || "");
  const troco = method==="dinheiro" && status==="pago" ? Math.max(0, Number(paid)-total) : 0;
  const methods = [
    { key:"dinheiro",      label:"Dinheiro",     icon:Banknote   },
    { key:"cartao",        label:"Cartão",        icon:CreditCard },
    { key:"mbway",         label:"MB Way",        icon:Receipt    },
    { key:"transferencia", label:"Transferência", icon:Euro       },
  ];
  return (
    <div style={{ position:"fixed",inset:0,zIndex:60,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(30,16,8,.5)",backdropFilter:"blur(10px)" }} onClick={onClose}>
      <div style={{ width:"100%",maxWidth:440,margin:"0 16px",borderRadius:22,overflow:"hidden",boxShadow:"0 40px 100px rgba(30,16,8,.35)",background:P.bgCard,border:`1.5px solid ${P.border}` }} onClick={e=>e.stopPropagation()}>
        <div style={{ padding:"20px 24px 16px",background:P.bgDark,display:"flex",alignItems:"center",justifyContent:"space-between" }}>
          <div>
            <p style={{ margin:0,fontSize:15,fontWeight:800,color:"#f5e6d3" }}>Confirmar Pagamento</p>
            <p style={{ margin:"2px 0 0",fontSize:11,color:"rgba(255,255,255,.4)" }}>{nifAssociado?`NIF: ${nifAssociado}`:"Sem NIF associado"}</p>
          </div>
          <button onClick={onClose} style={{ width:32,height:32,borderRadius:10,border:"1px solid rgba(255,255,255,.15)",background:"rgba(255,255,255,.07)",color:"rgba(255,255,255,.5)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>
            <X style={{ width:14,height:14 }} />
          </button>
        </div>
        <div style={{ padding:"20px 24px",display:"flex",flexDirection:"column",gap:18 }}>
          <div style={{ borderRadius:16,padding:"20px 24px",textAlign:"center",background:P.bgSurf,border:`1.5px solid ${P.border}` }}>
            <p style={{ margin:"0 0 4px",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.16em",color:P.textHint }}>Total a Cobrar</p>
            <p style={{ margin:0,fontSize:56,fontWeight:900,color:P.text,lineHeight:1 }}>{fmt(total)}<span style={{ fontSize:24,color:P.textMuted,marginLeft:4 }}>€</span></p>
          </div>
          <div>
            <p style={{ margin:"0 0 10px",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.14em",color:P.textMuted }}>Método de Pagamento</p>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
              {methods.map(m=>{const Icon=m.icon;const active=method===m.key;return(
                <button key={m.key} onClick={()=>setMethod(m.key)} style={{ display:"flex",alignItems:"center",gap:10,padding:"12px 16px",borderRadius:12,cursor:"pointer",fontSize:13,fontWeight:active?700:500,transition:"all .15s",background:active?P.bgDark:P.bgSurf,color:active?"#f5e6d3":P.textSub,border:active?"1.5px solid transparent":`1.5px solid ${P.border}`,boxShadow:active?"0 4px 14px rgba(61,43,31,.3)":"none" }}>
                  <Icon style={{ width:15,height:15,flexShrink:0 }} />{m.label}
                  {active&&<Check style={{ width:12,height:12,marginLeft:"auto" }} />}
                </button>
              );})}
            </div>
          </div>
          {method==="mbway" && (
            <div>
              <p style={{ margin:"0 0 8px",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.14em",color:P.textMuted }}>Número MB Way</p>
              <input value={mbway} onChange={e=>setMbway(e.target.value)} placeholder="9XX XXX XXX"
                style={{ width:"100%",padding:"11px 14px",borderRadius:11,border:`1.5px solid ${P.border}`,fontSize:13,color:P.text,background:P.bgCard,outline:"none",boxSizing:"border-box" } as any} />
            </div>
          )}
          <div>
            <p style={{ margin:"0 0 10px",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.14em",color:P.textMuted }}>Estado do Pagamento</p>
            <div style={{ display:"flex",gap:7,flexWrap:"wrap" }}>
              {PAYMENT_STATUS_OPTS.map(s=>{const active=status===s.key;return(
                <button key={s.key} onClick={()=>setStatus(s.key)} style={{ padding:"7px 16px",borderRadius:20,fontSize:12,fontWeight:active?700:500,cursor:"pointer",transition:"all .15s",background:active?s.bg:P.bgSurf,color:active?s.color:P.textMuted,border:active?`1.5px solid ${s.color}40`:`1.5px solid ${P.border}` }}>{s.label}</button>
              );})}
            </div>
          </div>
          {method==="dinheiro" && status==="pago" && (
            <div>
              <p style={{ margin:"0 0 10px",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.14em",color:P.textMuted }}>Valor Entregue</p>
              <div style={{ display:"flex",gap:10,alignItems:"stretch",marginBottom:12 }}>
                <div style={{ flex:1,borderRadius:12,padding:"12px 16px",textAlign:"right",background:P.bgSurf,border:`1.5px solid ${P.border}` }}>
                  <span style={{ fontSize:32,fontWeight:800,color:P.text }}>{paid||"0"}</span>
                  <span style={{ fontSize:18,color:P.textMuted,marginLeft:3 }}>€</span>
                </div>
                {troco>0 && (
                  <div style={{ borderRadius:12,padding:"8px 16px",textAlign:"center",minWidth:96,background:P.greenL,border:`1.5px solid ${P.green}30` }}>
                    <p style={{ margin:0,fontSize:9,fontWeight:700,textTransform:"uppercase",color:P.green,letterSpacing:"0.1em" }}>Troco</p>
                    <p style={{ margin:"4px 0 0",fontSize:22,fontWeight:800,color:P.green }}>{fmt(troco)}€</p>
                  </div>
                )}
              </div>
              <Numpad value={paid} onChange={setPaid} />
            </div>
          )}
        </div>
        <div style={{ padding:"0 24px 22px" }}>
          <button onClick={()=>onConfirm(method,status,Number(paid)||total,mbway)} disabled={saving}
            style={{ width:"100%",padding:"16px 0",borderRadius:14,border:"none",background:saving?P.bgAccent:P.bgDark,color:saving?P.textMuted:"#f5e6d3",fontSize:16,fontWeight:800,cursor:saving?"not-allowed":"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:10,transition:"all .15s",boxShadow:saving?"none":"0 8px 24px rgba(61,43,31,.35)" }}
            onMouseEnter={e=>{if(!saving)(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
            onMouseLeave={e=>{if(!saving)(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
            {saving?<Loader2 style={{ width:18,height:18,animation:"spin 1s linear infinite" }} />:<Check style={{ width:18,height:18 }} />}
            {saving?"A processar…":`Confirmar  ${fmt(total)}€`}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── ClienteDrawer ────────────────────────────────────────────────────────────
const ClienteDrawer = ({ open, onClose, clients, onSelect, loading }: {
  open: boolean; onClose: () => void; clients: Client[]; onSelect: (c: Client) => void; loading: boolean;
}) => {
  const [search, setSearch] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (open) setTimeout(()=>inputRef.current?.focus(),120); else setSearch(""); }, [open]);
  const filtered = search.trim()
    ? clients.filter(c => { const q=search.toLowerCase(); return c.full_name?.toLowerCase().includes(q)||c.email?.toLowerCase().includes(q)||String(c.client_number??"").includes(q); })
    : clients;
  return (
    <>
      <div onClick={onClose} style={{ position:"fixed",inset:0,zIndex:50,background:"rgba(30,16,8,.4)",backdropFilter:"blur(4px)",opacity:open?1:0,pointerEvents:open?"auto":"none",transition:"opacity .25s ease" }} />
      <div style={{ position:"fixed",top:0,left:0,bottom:0,zIndex:51,width:400,background:P.bgCard,boxShadow:"8px 0 50px rgba(30,16,8,.25)",borderRight:`1.5px solid ${P.border}`,transform:open?"translateX(0)":"translateX(-100%)",transition:"transform .3s cubic-bezier(.4,0,.2,1)",display:"flex",flexDirection:"column" }}>
        <div style={{ padding:"24px 20px 16px",background:P.bgDark,flexShrink:0 }}>
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16 }}>
            <div style={{ display:"flex",alignItems:"center",gap:10 }}>
              <div style={{ width:36,height:36,borderRadius:10,background:"rgba(255,255,255,.1)",display:"flex",alignItems:"center",justifyContent:"center" }}>
                <Users style={{ width:18,height:18,color:"#f5e6d3" }} />
              </div>
              <div>
                <p style={{ margin:0,fontSize:14,fontWeight:800,color:"#f5e6d3" }}>Selecionar Cliente</p>
                <p style={{ margin:0,fontSize:11,color:"rgba(255,255,255,.4)" }}>{clients.length} clientes registados</p>
              </div>
            </div>
            <button onClick={onClose} style={{ width:32,height:32,borderRadius:9,border:"1px solid rgba(255,255,255,.15)",background:"rgba(255,255,255,.07)",color:"rgba(255,255,255,.5)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>
              <X style={{ width:14,height:14 }} />
            </button>
          </div>
          <div style={{ position:"relative" }}>
            <Search style={{ position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",width:14,height:14,color:"rgba(255,255,255,.3)",pointerEvents:"none" }} />
            <input ref={inputRef} value={search} onChange={e=>setSearch(e.target.value)} placeholder="Nome, email ou nº de cliente…"
              style={{ width:"100%",paddingLeft:36,paddingRight:12,paddingTop:11,paddingBottom:11,borderRadius:12,border:"1.5px solid rgba(255,255,255,.15)",background:"rgba(255,255,255,.08)",color:"#f5e6d3",fontSize:13,outline:"none",boxSizing:"border-box" } as any} />
            {search && <button onClick={()=>setSearch("")} style={{ position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",border:"none",background:"transparent",cursor:"pointer",color:"rgba(255,255,255,.3)",display:"flex" }}><X style={{ width:12,height:12 }} /></button>}
          </div>
        </div>
        <div style={{ flex:1,overflowY:"auto" }}>
          {loading ? (
            <div style={{ display:"flex",alignItems:"center",justifyContent:"center",padding:"60px 0",gap:10,color:P.textMuted }}>
              <Loader2 style={{ width:18,height:18,animation:"spin 1s linear infinite" }} /><span style={{ fontSize:13 }}>A carregar…</span>
            </div>
          ) : filtered.length===0 ? (
            <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"60px 20px",gap:10,color:P.textHint,textAlign:"center" }}>
              <User style={{ width:40,height:40,opacity:.2 }} /><p style={{ fontSize:13,margin:0 }}>Nenhum cliente encontrado</p>
            </div>
          ) : filtered.map(c => (
            <button key={c.id} onClick={()=>{onSelect(c);onClose();setSearch("");}}
              style={{ width:"100%",display:"flex",alignItems:"center",gap:14,padding:"14px 20px",borderBottom:`1px solid ${P.border}`,background:"transparent",border:"none",borderLeft:"3px solid transparent",cursor:"pointer",textAlign:"left",transition:"all .15s" }}
              onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.background=P.bgSurf;el.style.borderLeftColor=P.bgDark;}}
              onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.background="transparent";el.style.borderLeftColor="transparent";}}>
              <div style={{ width:44,height:44,borderRadius:"50%",background:P.bgAccent,border:`2px solid ${P.borderMed}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:800,color:P.textSub,flexShrink:0 }}>
                {(c.full_name||c.email||"?").substring(0,2).toUpperCase()}
              </div>
              <div style={{ flex:1,minWidth:0 }}>
                <p style={{ margin:0,fontSize:14,fontWeight:700,color:P.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{c.full_name||c.email}</p>
                <p style={{ margin:"2px 0 0",fontSize:11,color:P.textMuted }}>
                  Nº {c.client_number??"—"}{c.phone&&<span> · {c.phone}</span>}{c.nif&&<span style={{ color:P.textHint }}> · NIF {c.nif}</span>}
                </p>
              </div>
              <ChevronRight style={{ width:14,height:14,color:P.textHint,flexShrink:0 }} />
            </button>
          ))}
        </div>
      </div>
    </>
  );
};

// ─── PromoCard ────────────────────────────────────────────────────────────────
const PromoCard = ({ promo, subtotal, onAdd, alreadyApplied }: {
  promo: any; subtotal: number; onAdd: (p: any) => void; alreadyApplied: boolean;
}) => {
  const isPercent = promo.discount_type === "percent";
  const discountAmt = isPercent ? subtotal * promo.discount_value / 100 : Number(promo.discount_value);
  const displayDiscount = isPercent ? `${promo.discount_value}%` : `${fmt(promo.discount_value)}€`;

  return (
    <button
      onClick={() => !alreadyApplied && onAdd(promo)}
      style={{
        position:"relative", display:"flex", flexDirection:"column", gap:12,
        padding:"18px 16px 16px", borderRadius:18,
        border:`2px solid ${alreadyApplied ? P.green : P.gold}`,
        background: alreadyApplied ? P.greenL : P.goldL,
        cursor: alreadyApplied ? "default" : "pointer",
        transition:"all .2s", textAlign:"left",
        boxShadow: alreadyApplied ? `0 4px 16px ${P.green}25` : `0 4px 16px ${P.gold}25`,
        minHeight:130,
        opacity: alreadyApplied ? 0.85 : 1,
      }}
      onMouseEnter={e=>{if(!alreadyApplied){const el=e.currentTarget as HTMLElement;el.style.transform="translateY(-3px)";el.style.boxShadow=`0 10px 28px ${P.gold}40`;}}}
      onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.transform="none";el.style.boxShadow=alreadyApplied?`0 4px 16px ${P.green}25`:`0 4px 16px ${P.gold}25`;}}>

      {/* Badge desconto */}
      <div style={{
        position:"absolute", top:10, right:10,
        padding:"3px 10px", borderRadius:20,
        background: alreadyApplied ? P.green : P.gold,
        color:"#fff", fontSize:12, fontWeight:800,
        boxShadow:`0 2px 8px ${alreadyApplied?P.green:P.gold}50`,
      }}>
        {alreadyApplied ? <Check style={{ width:11,height:11 }} /> : `-${displayDiscount}`}
      </div>

      {/* Ícone */}
      <div style={{ width:48,height:48,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",background:`${alreadyApplied?P.green:P.gold}18`,border:`1.5px solid ${alreadyApplied?P.green:P.gold}30`,flexShrink:0 }}>
        <BadgePercent style={{ width:22,height:22,color:alreadyApplied?P.green:P.gold }} />
      </div>

      <div style={{ flex:1 }}>
        <p style={{ fontSize:13,fontWeight:700,color:P.text,margin:0,lineHeight:1.4,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical" as any,paddingRight:40 }}>{promo.name}</p>
        {subtotal > 0 && discountAmt > 0 && (
          <p style={{ fontSize:12,color:alreadyApplied?P.green:P.amber,margin:"5px 0 0",fontWeight:600 }}>
            Poupa {fmt(discountAmt)}€
          </p>
        )}
        <p style={{ fontSize:17,fontWeight:900,color:alreadyApplied?P.green:P.gold,margin:"5px 0 0",letterSpacing:"-0.01em" }}>
          {alreadyApplied ? "Aplicado ✓" : `Desconto de ${displayDiscount}`}
        </p>
      </div>
    </button>
  );
};

// ─── Main ─────────────────────────────────────────────────────────────────────
export const NovaOperacao = ({ onBack, onFinalized, user, settings }: {
  onBack: () => void; onFinalized: () => void; user: any; settings: any;
}) => {
  const [products,       setProducts]       = useState<any[]>([]);
  const [promotions,     setPromotions]     = useState<any[]>([]);
  const [allClients,     setAllClients]     = useState<Client[]>([]);
  const [loadingClients, setLoadingClients] = useState(true);
  const [client,         setClient]         = useState<Client | null>(null);
  const [clientEvents,   setClientEvents]   = useState<EventItem[]>([]);
  const [activeCat,      setActiveCat]      = useState("todos");
  const [activeTab,      setActiveTab]      = useState<"produtos"|"eventos"|"promocoes">("produtos");
  const [items,          setItems]          = useState<CartItem[]>([]);
  const [addedEventIds,  setAddedEventIds]  = useState<Set<string>>(new Set());
  const [selectedPromo,  setSelectedPromo]  = useState<any>(null);
  const [manualDiscount, setManualDiscount] = useState("");
  const [loyaltyInfo,    setLoyaltyInfo]    = useState<any>(null);
  const [saving,         setSaving]         = useState(false);
  const [showPayModal,   setShowPayModal]   = useState(false);
  const [showNifModal,   setShowNifModal]   = useState(false);
  const [nifAssociado,   setNifAssociado]   = useState<string | undefined>(undefined);
  const [showDrawer,     setShowDrawer]     = useState(false);
  const [loadingEvents,  setLoadingEvents]  = useState(false);
  const [customName,     setCustomName]     = useState("");
  const [customPrice,    setCustomPrice]    = useState("");
  const [productSearch,  setProductSearch]  = useState("");

  useEffect(() => {
    (async () => {
      const [{ data: p }, { data: pr }] = await Promise.all([
        supabase.from("pos_products").select("*").eq("active", true).order("category").order("name"),
        supabase.from("pos_promotions").select("*").eq("active", true),
      ]);
      setProducts(p ?? []); setPromotions(pr ?? []);
      const { data: roles } = await supabase.from("user_roles").select("user_id").eq("role","cliente");
      const ids = (roles ?? []).map((r: any) => r.user_id);
      if (ids.length) {
        const { data } = await supabase.from("profiles").select("id,full_name,email,client_number,phone,nif").in("id",ids).order("full_name");
        setAllClients((data ?? []) as Client[]);
      }
      setLoadingClients(false);
    })();
  }, []);

  useEffect(() => {
    if (!client) { setClientEvents([]); setAddedEventIds(new Set()); return; }
    setLoadingEvents(true);
    Promise.all([
      supabase.from("events").select("id,title,event_date,event_type,status,estado_pagamento,payment_value,budget,guests_count").eq("client_id",client.id).order("event_date",{ascending:false}),
      settings?.loyalty_enabled ? supabase.from("pos_loyalty").select("*").eq("client_id",client.id).maybeSingle() : Promise.resolve({data:null}),
    ]).then(([{data:evs},{data:loy}]) => {
      setClientEvents((evs??[]) as EventItem[]);
      setLoyaltyInfo(loy);
      setLoadingEvents(false);
    });
  }, [client]);

  const subtotal  = items.reduce((s,i)=>s+i.price*i.qty,0);
  const promoD    = selectedPromo ? (selectedPromo.discount_type==="percent" ? subtotal*selectedPromo.discount_value/100 : Number(selectedPromo.discount_value)) : 0;
  const loyaltyD  = settings?.loyalty_enabled && loyaltyInfo && (loyaltyInfo.total_events+1)%10===0 ? 15 : 0;
  const manualD   = parseFloat(manualDiscount)||0;
  const total     = Math.max(0,subtotal-promoD-loyaltyD-manualD);
  const itemCount = items.reduce((s,i)=>s+i.qty,0);
  const pendingEventCount = clientEvents.filter(e=>!e.estado_pagamento||e.estado_pagamento==="por_pagar"||e.estado_pagamento==="em_pagamento").length;

  const filteredProducts = products.filter(p => {
    const matchCat    = activeCat==="todos" || p.category===activeCat;
    const matchSearch = !productSearch || p.name.toLowerCase().includes(productSearch.toLowerCase());
    return matchCat && matchSearch;
  });
  const catsWithProducts = CATS.filter(c=>products.some(p=>p.category===c.key));

  const addProduct = (p: any) => {
    setItems(prev => {
      const idx = prev.findIndex(i=>i.id===p.id&&i.type==="product");
      if (idx>=0) { const n=[...prev]; n[idx]={...n[idx],qty:n[idx].qty+1}; return n; }
      return [...prev,{id:p.id,name:p.name,price:Number(p.price),qty:1,category:p.category,type:"product"}];
    });
    toast.success(`${p.name} adicionado`,{duration:600});
  };

  const addEvent = (ev: EventItem) => {
    const val = getEventValue(ev);
    if (val<=0) { toast.error("Evento sem valor definido."); return; }
    setItems(prev=>[...prev,{id:ev.id,name:`Evento: ${ev.title}`,price:val,qty:1,category:"outros",type:"event",eventId:ev.id}]);
    setAddedEventIds(prev=>new Set(prev).add(ev.id));
    toast.success(`"${ev.title}" adicionado`,{duration:800});
  };

  const applyPromo = (promo: any) => {
    if (selectedPromo?.id === promo.id) {
      setSelectedPromo(null);
      toast.info("Promoção removida");
      return;
    }
    setSelectedPromo(promo);
    toast.success(`Promoção "${promo.name}" aplicada!`, { duration: 1200 });
  };

  const addCustomItem = () => {
    const name=customName.trim(); const price=parseFloat(customPrice);
    if (!name) return toast.error("Nome obrigatório");
    if (!price||price<=0) return toast.error("Preço inválido");
    setItems(prev=>[...prev,{id:`custom-${Date.now()}`,name,price,qty:1,category:"outros",type:"product"}]);
    setCustomName(""); setCustomPrice("");
    toast.success(`${name} adicionado`,{duration:600});
  };

  const changeQty = (idx: number, delta: number) => {
    setItems(prev => {
      const n=[...prev]; const newQty=n[idx].qty+delta;
      if (newQty<=0) {
        if (n[idx].type==="event"&&n[idx].eventId) setAddedEventIds(p=>{const s=new Set(p);s.delete(n[idx].eventId!);return s;});
        return prev.filter((_,i)=>i!==idx);
      }
      n[idx]={...n[idx],qty:newQty}; return n;
    });
  };

  const removeItem = (idx: number) => {
    const item=items[idx];
    if (item.type==="event"&&item.eventId) setAddedEventIds(p=>{const s=new Set(p);s.delete(item.eventId!);return s;});
    setItems(prev=>prev.filter((_,i)=>i!==idx));
  };

  const handlePagar = () => {
    if (!client)       return toast.error("Selecione um cliente");
    if (!items.length) return toast.error("Carrinho vazio");
    setNifAssociado(undefined);
    setShowNifModal(true);
  };

  const handleNifOk       = () => { setNifAssociado(undefined); setShowNifModal(false); setShowPayModal(true); };
  const handleNifAssociar = (nif: string) => { setNifAssociado(nif); setShowNifModal(false); setShowPayModal(true); };

  const finalizar = async (method: string, status: string, paid: number, mbway: string) => {
    if (!client||!items.length) return;
    setSaving(true);
    const opNumber = await generateOpNumber();
    const troco = method==="dinheiro"&&status==="pago" ? Math.max(0,paid-total) : 0;
    const {error} = await supabase.from("pos_operations").insert({
      operation_number:opNumber,client_id:client.id,client_name:client.full_name||client.email,
      items,subtotal,discount_value:manualD,loyalty_discount:loyaltyD,promotion_id:selectedPromo?.id||null,
      total,payment_method:method,mbway_number:method==="mbway"?mbway:null,payment_status:status,
      amount_paid:paid||total,change_given:troco,status:"finalizada",created_by:user.id,
      finalized_at:new Date().toISOString(),
      ...(nifAssociado ? { client_nif: nifAssociado } : {}),
    } as any);
    if (error) { setSaving(false); return toast.error("Erro: "+error.message); }
    const eventItems = items.filter(i=>i.type==="event"&&i.eventId);
    const newEstado  = status==="pago"?"pago":status==="nao_realizado"?"nao_realizado":"em_pagamento";
    for (const ei of eventItems) await supabase.from("events").update({estado_pagamento:newEstado}).eq("id",ei.eventId!);
    if (settings?.loyalty_enabled) {
      const {data:loy} = await supabase.from("pos_loyalty").select("*").eq("client_id",client.id).maybeSingle();
      if (loy) await supabase.from("pos_loyalty").update({total_events:loy.total_events+1}).eq("client_id",client.id);
      else     await supabase.from("pos_loyalty").insert({client_id:client.id,total_events:1});
    }
    setSaving(false); setShowPayModal(false);
    toast.success(`✓ Operação ${opNumber} finalizada!${nifAssociado?` NIF ${nifAssociado} associado.`:""}`);
    onFinalized();
  };

  // ── Tab labels ──────────────────────────────────────────────────────────────
  const tabs: { key: "produtos"|"eventos"|"promocoes"; label: string; icon: any; count?: number; badge?: number; disabled?: boolean }[] = [
    { key:"produtos",   label:"Produtos",        icon:LayoutGrid,   count:products.length },
    { key:"eventos",    label:"Eventos",          icon:Calendar,     badge:pendingEventCount>0?pendingEventCount:undefined, disabled:!client },
    { key:"promocoes",  label:"Promoções",        icon:BadgePercent, count:promotions.length },
  ];

  return (
    <div style={{ display:"flex",flexDirection:"column",background:P.bg,height:"calc(100vh - 56px)",fontFamily:"inherit",overflow:"hidden" }}>
      {/* Modais */}
      {showNifModal && client && <NifModal client={client} onOk={handleNifOk} onAssociar={handleNifAssociar} />}
      {showPayModal && <PayModal total={total} saving={saving} onConfirm={finalizar} onClose={()=>setShowPayModal(false)} clientPhone={client?.phone} nifAssociado={nifAssociado} />}
      <ClienteDrawer open={showDrawer} onClose={()=>setShowDrawer(false)} clients={allClients} onSelect={setClient} loading={loadingClients} />

      {/* ── TOP BAR ──────────────────────────────────────────────────────── */}
      <div style={{ height:58,display:"flex",alignItems:"center",gap:0,background:P.bgDark,flexShrink:0,boxShadow:"0 2px 12px rgba(30,16,8,.2)" }}>
        <button onClick={onBack}
          style={{ display:"flex",alignItems:"center",gap:7,padding:"0 20px",height:"100%",background:"transparent",border:"none",borderRight:"1px solid rgba(255,255,255,.08)",color:"rgba(255,255,255,.5)",fontSize:12,fontWeight:600,cursor:"pointer",transition:"all .15s",flexShrink:0 }}
          onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.color="#f5e6d3";(e.currentTarget as HTMLElement).style.background="rgba(255,255,255,.05)";}}
          onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.color="rgba(255,255,255,.5)";(e.currentTarget as HTMLElement).style.background="transparent";}}>
          <ArrowLeft style={{ width:14,height:14 }} />Voltar
        </button>

        {/* Indicador caixa */}
        <div style={{ display:"flex",alignItems:"center",gap:8,padding:"0 20px",borderRight:"1px solid rgba(255,255,255,.08)",flexShrink:0 }}>
          <div style={{ width:8,height:8,borderRadius:"50%",background:"#4ade80",boxShadow:"0 0 8px #4ade8060" }} />
          <span style={{ fontSize:10,fontWeight:800,textTransform:"uppercase",letterSpacing:"0.18em",color:"rgba(255,255,255,.35)" }}>Caixa Aberta</span>
        </div>

        {/* Cliente */}
        <div style={{ flex:1,display:"flex",alignItems:"center",justifyContent:"center",padding:"0 20px" }}>
          {client ? (
            <div style={{ display:"flex",alignItems:"center",gap:12,padding:"8px 16px",borderRadius:30,background:"rgba(255,255,255,.08)",border:"1.5px solid rgba(255,255,255,.15)" }}>
              <div style={{ width:34,height:34,borderRadius:"50%",background:P.bgMid,border:"2px solid rgba(255,255,255,.2)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:800,color:"#f5e6d3",flexShrink:0 }}>
                {(client.full_name||client.email||"?").substring(0,2).toUpperCase()}
              </div>
              <div>
                <p style={{ margin:0,fontSize:14,fontWeight:700,color:"#f5e6d3",lineHeight:1 }}>{client.full_name||client.email}</p>
                <p style={{ margin:"3px 0 0",fontSize:10,color:"rgba(255,255,255,.4)" }}>
                  Nº {client.client_number??"—"}
                  {client.phone&&<span> · {client.phone}</span>}
                  {client.nif&&<span style={{ marginLeft:8,color:"#fbbf24" }}>NIF {client.nif}</span>}
                  {settings?.loyalty_enabled&&loyaltyD>0&&<span style={{ marginLeft:8,color:"#fbbf24" }}>⭐ €15 fidelização</span>}
                  {pendingEventCount>0&&<span style={{ marginLeft:8,color:"#fb923c" }}>⚠ {pendingEventCount} evento(s) por cobrar</span>}
                </p>
              </div>
              <button onClick={()=>setShowDrawer(true)}
                style={{ padding:"4px 10px",borderRadius:20,background:"rgba(255,255,255,.1)",border:"1px solid rgba(255,255,255,.2)",color:"rgba(255,255,255,.5)",fontSize:11,fontWeight:600,cursor:"pointer" }}>
                Trocar
              </button>
              <button onClick={()=>{setClient(null);setClientEvents([]);setLoyaltyInfo(null);setAddedEventIds(new Set());setItems(prev=>prev.filter(i=>i.type!=="event"));}}
                style={{ width:26,height:26,borderRadius:"50%",background:"rgba(255,255,255,.08)",border:"1px solid rgba(255,255,255,.15)",color:"rgba(255,255,255,.4)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center" }}>
                <X style={{ width:11,height:11 }} />
              </button>
            </div>
          ) : (
            <button onClick={()=>setShowDrawer(true)}
              style={{ display:"flex",alignItems:"center",gap:10,padding:"10px 24px",borderRadius:30,background:"rgba(255,255,255,.06)",border:"1.5px dashed rgba(255,255,255,.2)",color:"rgba(255,255,255,.5)",fontSize:13,fontWeight:600,cursor:"pointer",transition:"all .2s" }}
              onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.background="rgba(255,255,255,.12)";el.style.borderColor="rgba(255,255,255,.4)";el.style.color="#f5e6d3";}}
              onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.background="rgba(255,255,255,.06)";el.style.borderColor="rgba(255,255,255,.2)";el.style.color="rgba(255,255,255,.5)";}}>
              <User style={{ width:15,height:15 }} />
              Clique aqui para seleccionar o cliente
              <ChevronRight style={{ width:13,height:13,opacity:.5 }} />
            </button>
          )}
        </div>

        {/* Data/hora */}
        <div style={{ padding:"0 20px",borderLeft:"1px solid rgba(255,255,255,.08)",flexShrink:0 }}>
          <span style={{ fontSize:11,color:"rgba(255,255,255,.3)",fontWeight:500 }}>
            {format(new Date(),"EEE, d MMM · HH:mm",{locale:pt})}
          </span>
        </div>
      </div>

      {/* ── MAIN LAYOUT ──────────────────────────────────────────────────── */}
      <div style={{ display:"flex",flex:1,minHeight:0,overflow:"hidden" }}>

        {/* ── ESQUERDA ─────────────────────────────────────────────────── */}
        <div style={{ display:"flex",flexDirection:"column",flex:1,minWidth:0 }}>

          {/* Tabs + filtros */}
          <div style={{ display:"flex",alignItems:"stretch",borderBottom:`1.5px solid ${P.border}`,background:P.bgCard,flexShrink:0,padding:"0 16px",gap:0,minHeight:48 }}>

            {/* Tabs principais */}
            {tabs.map(tab => {
              const Icon = tab.icon;
              const active = activeTab === tab.key;
              return (
                <button key={tab.key}
                  onClick={()=>{ if(!tab.disabled) setActiveTab(tab.key); }}
                  style={{ display:"flex",alignItems:"center",gap:7,padding:"0 18px",fontSize:13,fontWeight:active?700:500,borderBottom:`2.5px solid ${active?P.bgDark:"transparent"}`,marginBottom:-1.5,cursor:tab.disabled?"not-allowed":"pointer",color:tab.disabled?P.textHint:active?P.text:P.textMuted,background:"none",border:"none",transition:"all .15s",whiteSpace:"nowrap",flexShrink:0,opacity:tab.disabled?0.5:1 }}>
                  <Icon style={{ width:14,height:14 }} />
                  {tab.label}
                  {tab.count !== undefined && (
                    <span style={{ fontSize:10,fontWeight:700,padding:"1px 7px",borderRadius:20,background:active?P.bgDark:P.bgAccent,color:active?"#fff":P.textMuted }}>
                      {tab.count}
                    </span>
                  )}
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span style={{ fontSize:10,fontWeight:800,padding:"1px 7px",borderRadius:20,background:P.amber,color:"#fff" }}>
                      {tab.badge}
                    </span>
                  )}
                  {tab.key === "promocoes" && selectedPromo && (
                    <span style={{ width:8,height:8,borderRadius:"50%",background:P.green,display:"inline-block",marginLeft:2,boxShadow:`0 0 6px ${P.green}80` }} />
                  )}
                </button>
              );
            })}

            {/* Filtros categoria — só na aba produtos */}
            {activeTab==="produtos" && (
              <>
                <div style={{ width:1,height:24,alignSelf:"center",background:P.border,margin:"0 10px",flexShrink:0 }} />
                <div style={{ position:"relative",flexShrink:0,alignSelf:"center",marginRight:8 }}>
                  <Search style={{ position:"absolute",left:9,top:"50%",transform:"translateY(-50%)",width:12,height:12,color:P.textHint,pointerEvents:"none" }} />
                  <input value={productSearch} onChange={e=>setProductSearch(e.target.value)} placeholder="Pesquisar produto…"
                    style={{ paddingLeft:26,paddingRight:8,paddingTop:6,paddingBottom:6,fontSize:12,borderRadius:20,border:`1.5px solid ${P.border}`,background:P.bgSurf,color:P.text,outline:"none",width:170 } as any} />
                </div>
                <div style={{ display:"flex",gap:5,overflowX:"auto",flex:1,paddingBottom:2,paddingTop:2,alignItems:"center" }}>
                  <button onClick={()=>setActiveCat("todos")} style={{ display:"inline-flex",alignItems:"center",gap:5,padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:activeCat==="todos"?700:500,whiteSpace:"nowrap",flexShrink:0,cursor:"pointer",transition:"all .15s",background:activeCat==="todos"?P.bgDark:P.bgSurf,border:activeCat==="todos"?`1.5px solid ${P.bgDark}`:`1.5px solid ${P.border}`,color:activeCat==="todos"?"#fff":P.textSub }}>
                    <Hash style={{ width:10,height:10 }} />Todos
                  </button>
                  {catsWithProducts.map(c => { const Icon=c.icon; const active=activeCat===c.key; return (
                    <button key={c.key} onClick={()=>setActiveCat(c.key)} style={{ display:"inline-flex",alignItems:"center",gap:5,padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:active?700:500,whiteSpace:"nowrap",flexShrink:0,cursor:"pointer",transition:"all .15s",background:active?c.bg:P.bgSurf,border:active?`1.5px solid ${c.color}40`:`1.5px solid ${P.border}`,color:active?c.color:P.textSub }}>
                      <Icon style={{ width:10,height:10 }} />{c.label}
                    </button>
                  ); })}
                </div>
              </>
            )}

            {/* Promoção ativa badge — só na aba promoções */}
            {activeTab==="promocoes" && selectedPromo && (
              <div style={{ display:"flex",alignItems:"center",gap:8,marginLeft:"auto",paddingRight:4 }}>
                <div style={{ display:"flex",alignItems:"center",gap:7,padding:"5px 12px",borderRadius:20,background:P.greenL,border:`1.5px solid ${P.green}40` }}>
                  <Check style={{ width:11,height:11,color:P.green }} />
                  <span style={{ fontSize:11,fontWeight:700,color:P.green }}>{selectedPromo.name}</span>
                  <button onClick={()=>setSelectedPromo(null)} style={{ border:"none",background:"transparent",cursor:"pointer",color:P.green,display:"flex",padding:0,marginLeft:2 }}>
                    <X style={{ width:11,height:11 }} />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ── Conteúdo da tab ──────────────────────────────────────────── */}

          {/* PRODUTOS */}
          {activeTab==="produtos" && (
            <>
              <div style={{ flex:1,overflowY:"auto",padding:"16px 16px 10px",background:P.bg }}>
                {filteredProducts.length===0 ? (
                  <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:14,color:P.textHint }}>
                    <Package style={{ width:52,height:52,opacity:.15 }} />
                    <p style={{ fontSize:14,margin:0,fontWeight:500 }}>Sem produtos nesta categoria</p>
                  </div>
                ) : (
                  <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(170px, 1fr))",gap:12 }}>
                    {filteredProducts.map(p => {
                      const cat=getCat(p.category); const Icon=cat.icon;
                      const inCart=items.find(i=>i.id===p.id&&i.type==="product");
                      return (
                        <button key={p.id} onClick={()=>addProduct(p)}
                          style={{ position:"relative",display:"flex",flexDirection:"column",gap:14,padding:"18px 16px 16px",borderRadius:18,border:`2px solid ${inCart?cat.color:P.border}`,background:inCart?cat.bg:P.bgCard,cursor:"pointer",transition:"all .2s",textAlign:"left",boxShadow:inCart?`0 6px 20px ${cat.color}25`:"0 1px 4px rgba(30,16,8,.06)",minHeight:130 }}
                          onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=cat.color;el.style.background=cat.bg;el.style.transform="translateY(-3px)";el.style.boxShadow=`0 10px 28px ${cat.color}30`;}}
                          onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=inCart?cat.color:P.border;el.style.background=inCart?cat.bg:P.bgCard;el.style.transform="none";el.style.boxShadow=inCart?`0 6px 20px ${cat.color}25`:"0 1px 4px rgba(30,16,8,.06)";}}>
                          {inCart && (
                            <div style={{ position:"absolute",top:10,right:10,minWidth:24,height:24,padding:"0 6px",borderRadius:12,fontSize:11,fontWeight:800,background:cat.color,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:`0 2px 8px ${cat.color}50` }}>
                              {inCart.qty}
                            </div>
                          )}
                          <div style={{ width:48,height:48,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",background:`${cat.color}18`,border:`1.5px solid ${cat.color}25`,flexShrink:0 }}>
                            <Icon style={{ width:22,height:22,color:cat.color }} />
                          </div>
                          <div style={{ flex:1 }}>
                            <p style={{ fontSize:13,fontWeight:600,color:P.text,margin:0,lineHeight:1.4,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical" as any }}>{p.name}</p>
                            <p style={{ fontSize:17,fontWeight:900,color:cat.color,margin:"7px 0 0",letterSpacing:"-0.01em" }}>{fmt(Number(p.price))}€</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
              {/* Item personalizado */}
              <div style={{ borderTop:`1.5px solid ${P.border}`,background:P.bgCard,padding:"10px 16px",display:"flex",alignItems:"center",gap:9,flexShrink:0 }}>
                <Zap style={{ width:14,height:14,color:P.textHint,flexShrink:0 }} />
                <input value={customName} onChange={e=>setCustomName(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addCustomItem()} placeholder="Serviço / item personalizado…"
                  style={{ flex:1,fontSize:12,padding:"8px 12px",background:P.bgSurf,border:`1.5px solid ${P.border}`,borderRadius:10,color:P.text,outline:"none",minWidth:0 } as any} />
                <div style={{ position:"relative",width:100,flexShrink:0 }}>
                  <span style={{ position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",fontSize:12,color:P.textHint,pointerEvents:"none" }}>€</span>
                  <input type="number" step="0.01" min="0" value={customPrice} onChange={e=>setCustomPrice(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addCustomItem()} placeholder="0.00"
                    style={{ width:"100%",paddingLeft:24,paddingRight:9,paddingTop:8,paddingBottom:8,fontSize:12,background:P.bgSurf,border:`1.5px solid ${P.border}`,borderRadius:10,color:P.text,outline:"none",boxSizing:"border-box" } as any} />
                </div>
                <button onClick={addCustomItem} style={{ width:34,height:34,borderRadius:10,background:P.bgDark,border:"none",color:"#f5e6d3",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
                  <Plus style={{ width:16,height:16 }} />
                </button>
              </div>
            </>
          )}

          {/* EVENTOS */}
          {activeTab==="eventos" && (
            <div style={{ flex:1,overflowY:"auto",background:P.bg,padding:16 }}>
              {!client ? (
                <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:14,color:P.textHint,textAlign:"center" }}>
                  <User style={{ width:52,height:52,opacity:.15 }} />
                  <p style={{ fontSize:14,margin:0,fontWeight:500 }}>Seleccione um cliente para ver os seus eventos</p>
                  <button onClick={()=>setShowDrawer(true)} style={{ padding:"10px 22px",borderRadius:22,background:P.bgDark,border:"none",color:"#f5e6d3",fontSize:13,fontWeight:700,cursor:"pointer" }}>Seleccionar Cliente</button>
                </div>
              ) : loadingEvents ? (
                <div style={{ display:"flex",alignItems:"center",justifyContent:"center",height:"100%",gap:10,color:P.textMuted }}>
                  <Loader2 style={{ width:20,height:20,animation:"spin 1s linear infinite" }} />
                  <span style={{ fontSize:13 }}>A carregar eventos…</span>
                </div>
              ) : clientEvents.length===0 ? (
                <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:12,color:P.textHint }}>
                  <Calendar style={{ width:48,height:48,opacity:.15 }} />
                  <p style={{ fontSize:14,margin:0 }}>Sem eventos para este cliente</p>
                </div>
              ) : (
                <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(260px, 1fr))",gap:12 }}>
                  {clientEvents.map(ev => {
                    const isPago  = ev.estado_pagamento==="pago";
                    const isAdded = addedEventIds.has(ev.id);
                    const val     = getEventValue(ev);
                    const canCobrar = !isPago && val>0;
                    const statusMap: Record<string,{label:string;color:string;bg:string}> = {
                      pago:          {label:"Pago",          color:P.green, bg:P.greenL},
                      por_pagar:     {label:"Por Pagar",     color:P.amber, bg:P.amberL},
                      em_pagamento:  {label:"Em Pagamento",  color:P.blue,  bg:P.blueL },
                      nao_realizado: {label:"Não Realizado", color:P.red,   bg:P.redL  },
                    };
                    const st = statusMap[ev.estado_pagamento??""] ?? statusMap.por_pagar;
                    return (
                      <div key={ev.id} style={{ borderRadius:16,border:`2px solid ${isAdded?P.green:canCobrar?P.amber:P.border}`,background:isAdded?P.greenL:isPago?P.bgSurf:P.bgCard,padding:"18px",display:"flex",flexDirection:"column",gap:12,opacity:isPago?0.6:1,transition:"all .2s",boxShadow:canCobrar&&!isAdded?`0 4px 16px ${P.amber}20`:"none" }}>
                        <div style={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:8 }}>
                          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                            <div style={{ width:40,height:40,borderRadius:12,background:P.bgAccent,border:`1.5px solid ${P.borderMed}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                              <Calendar style={{ width:18,height:18,color:P.textSub }} />
                            </div>
                            <div style={{ minWidth:0 }}>
                              <p style={{ margin:0,fontSize:13,fontWeight:700,color:P.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:130 }}>{ev.title}</p>
                              {ev.event_date&&<p style={{ margin:"2px 0 0",fontSize:10,color:P.textHint }}>{format(new Date(ev.event_date),"dd/MM/yyyy")}</p>}
                            </div>
                          </div>
                          <span style={{ fontSize:10,fontWeight:700,padding:"3px 9px",borderRadius:20,background:st.bg,color:st.color,border:`1px solid ${st.color}30`,flexShrink:0 }}>{st.label}</span>
                        </div>
                        {val>0&&<div style={{ display:"flex",alignItems:"baseline",gap:3 }}><span style={{ fontSize:26,fontWeight:900,color:P.text,lineHeight:1 }}>{fmt(val)}</span><span style={{ fontSize:14,color:P.textMuted }}>€</span></div>}
                        {canCobrar&&(
                          <button onClick={()=>!isAdded&&addEvent(ev)} disabled={isAdded}
                            style={{ display:"flex",alignItems:"center",justifyContent:"center",gap:8,padding:"10px 0",borderRadius:12,fontSize:13,fontWeight:700,cursor:isAdded?"default":"pointer",transition:"all .15s",background:P.bgDark,color:"#f5e6d3",border:"none",boxShadow:"0 3px 10px rgba(61,43,31,.25)",opacity:isAdded?0.7:1 }}
                            onMouseEnter={e=>{if(!isAdded)(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
                            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=P.bgDark;}}>
                            {isAdded?<><CheckCircle2 style={{ width:15,height:15 }} />Adicionado ao carrinho</>:<><ShoppingCart style={{ width:15,height:15 }} />Cobrar este evento</>}
                          </button>
                        )}
                        {!canCobrar&&!isPago&&val===0&&<span style={{ fontSize:11,color:P.textHint,fontStyle:"italic",textAlign:"center" }}>Sem valor definido</span>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* PROMOÇÕES */}
          {activeTab==="promocoes" && (
            <div style={{ flex:1,overflowY:"auto",padding:"16px",background:P.bg }}>
              {promotions.length===0 ? (
                <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:14,color:P.textHint }}>
                  <BadgePercent style={{ width:52,height:52,opacity:.15 }} />
                  <p style={{ fontSize:14,margin:0,fontWeight:500 }}>Sem promoções ativas</p>
                </div>
              ) : (
                <>
                  {/* Banner informativo */}
                  <div style={{ display:"flex",alignItems:"center",gap:12,padding:"12px 16px",borderRadius:12,background:P.goldL,border:`1.5px solid ${P.gold}50`,marginBottom:16,flexShrink:0 }}>
                    <BadgePercent style={{ width:18,height:18,color:P.gold,flexShrink:0 }} />
                    <p style={{ margin:0,fontSize:12,color:P.amber,fontWeight:600 }}>
                      {selectedPromo
                        ? `Promoção ativa: "${selectedPromo.name}" — clique novamente para remover`
                        : "Clique numa promoção para aplicar ao carrinho atual"}
                    </p>
                    {selectedPromo && (
                      <button onClick={()=>setSelectedPromo(null)} style={{ marginLeft:"auto",padding:"4px 12px",borderRadius:20,background:P.redL,border:`1px solid ${P.red}30`,color:P.red,fontSize:11,fontWeight:700,cursor:"pointer",flexShrink:0 }}>
                        Remover
                      </button>
                    )}
                  </div>

                  <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(200px, 1fr))",gap:12 }}>
                    {promotions.map(promo => (
                      <PromoCard
                        key={promo.id}
                        promo={promo}
                        subtotal={subtotal}
                        onAdd={applyPromo}
                        alreadyApplied={selectedPromo?.id === promo.id}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* ── DIREITA — Carrinho ─────────────────────────────────────────── */}
        <div style={{ width:340,display:"flex",flexDirection:"column",borderLeft:`1.5px solid ${P.border}`,background:P.bgCard,flexShrink:0 }}>

          {/* Header carrinho */}
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 16px 12px",borderBottom:`1px solid ${P.border}`,background:P.bgSurf,flexShrink:0 }}>
            <div style={{ display:"flex",alignItems:"center",gap:9 }}>
              <div style={{ width:32,height:32,borderRadius:10,background:P.bgDark,display:"flex",alignItems:"center",justifyContent:"center" }}>
                <ShoppingCart style={{ width:15,height:15,color:"#f5e6d3" }} />
              </div>
              <span style={{ fontSize:14,fontWeight:700,color:P.text }}>Carrinho</span>
              {itemCount>0&&<span style={{ minWidth:22,height:22,padding:"0 6px",borderRadius:11,fontSize:11,fontWeight:800,background:P.bgDark,color:"#f5e6d3",display:"flex",alignItems:"center",justifyContent:"center" }}>{itemCount}</span>}
            </div>
            {items.length>0&&(
              <button onClick={()=>{setItems([]);setAddedEventIds(new Set());}}
                style={{ display:"flex",alignItems:"center",gap:5,fontSize:11,color:P.textHint,background:"none",border:"none",cursor:"pointer",fontWeight:600,padding:"4px 9px",borderRadius:8,transition:"all .12s" }}
                onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.color=P.red;el.style.background=P.redL;}}
                onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.color=P.textHint;el.style.background="none";}}>
                <RotateCcw style={{ width:11,height:11 }} />Limpar
              </button>
            )}
          </div>

          {/* Itens */}
          <div style={{ flex:1,overflowY:"auto",minHeight:0 }}>
            {items.length===0 ? (
              <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:12,padding:"30px 20px",textAlign:"center" }}>
                <ShoppingCart style={{ width:40,height:40,color:P.textHint,opacity:.2 }} />
                <p style={{ fontSize:13,margin:0,color:P.textMuted,fontWeight:600 }}>Carrinho vazio</p>
                <p style={{ fontSize:11,margin:0,color:P.textHint }}>Clique nos produtos ou eventos para adicionar</p>
              </div>
            ) : items.map((item, idx) => {
              const cat   = getCat(item.category);
              const Icon  = item.type==="event" ? Calendar : cat.icon;
              const color = item.type==="event" ? P.amber : cat.color;
              const bg    = item.type==="event" ? P.amberL : cat.bg;
              return (
                <div key={item.id+idx}
                  style={{ display:"flex",alignItems:"center",gap:9,padding:"10px 14px",borderBottom:`1px solid ${P.border}`,transition:"background .12s" }}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background=P.bgSurf;}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>
                  <div style={{ width:30,height:30,borderRadius:9,background:bg,border:`1.5px solid ${color}25`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
                    <Icon style={{ width:13,height:13,color }} />
                  </div>
                  <div style={{ flex:1,minWidth:0 }}>
                    <p style={{ fontSize:11,fontWeight:600,color:P.text,margin:0,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{item.name}</p>
                    <p style={{ fontSize:10,color:P.textHint,margin:0 }}>{fmt(item.price)}€/un</p>
                  </div>
                  {item.type==="product" ? (
                    <div style={{ display:"flex",alignItems:"center",gap:2,flexShrink:0 }}>
                      <button onClick={()=>changeQty(idx,-1)} style={{ width:20,height:20,borderRadius:6,border:`1.5px solid ${P.border}`,background:P.bgSurf,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:P.textSub,transition:"all .1s" }}
                        onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor="#f4b8bb";el.style.color=P.red;el.style.background=P.redL;}}
                        onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=P.border;el.style.color=P.textSub;el.style.background=P.bgSurf;}}>
                        <Minus style={{ width:8,height:8 }} />
                      </button>
                      <span style={{ fontSize:12,fontWeight:800,width:22,textAlign:"center",color:P.text }}>{item.qty}</span>
                      <button onClick={()=>changeQty(idx,1)} style={{ width:20,height:20,borderRadius:6,border:`1.5px solid ${P.border}`,background:P.bgSurf,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:P.textSub,transition:"all .1s" }}
                        onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=P.green+"60";el.style.color=P.green;el.style.background=P.greenL;}}
                        onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=P.border;el.style.color=P.textSub;el.style.background=P.bgSurf;}}>
                        <Plus style={{ width:8,height:8 }} />
                      </button>
                    </div>
                  ) : (
                    <span style={{ fontSize:10,color:item.type==="event"?P.amber:P.gold,fontWeight:700,padding:"2px 7px",borderRadius:20,background:item.type==="event"?P.amberL:P.goldL,border:`1px solid ${item.type==="event"?P.amberB:P.goldB}50`,flexShrink:0 }}>
                      {item.type==="event"?"evento":"promo"}
                    </span>
                  )}
                  <span style={{ fontSize:12,fontWeight:800,color:P.text,width:56,textAlign:"right",flexShrink:0 }}>{fmt(item.price*item.qty)}€</span>
                  <button onClick={()=>removeItem(idx)} style={{ border:"none",background:"transparent",cursor:"pointer",color:P.border,padding:0,display:"flex",transition:"color .1s" }}
                    onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.color=P.red;}}
                    onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.color=P.border;}}>
                    <X style={{ width:12,height:12 }} />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Descontos */}
          <div style={{ borderTop:`1px solid ${P.border}`,padding:"10px 14px",display:"flex",flexDirection:"column",gap:7,flexShrink:0,background:P.bgSurf }}>
            {/* Promoção aplicada */}
            {selectedPromo && (
              <div style={{ display:"flex",alignItems:"center",gap:8,padding:"8px 12px",borderRadius:10,background:P.goldL,border:`1.5px solid ${P.gold}40` }}>
                <BadgePercent style={{ width:13,height:13,color:P.gold,flexShrink:0 }} />
                <span style={{ fontSize:11,fontWeight:700,color:P.amber,flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{selectedPromo.name}</span>
                <span style={{ fontSize:11,fontWeight:800,color:P.gold }}>
                  -{selectedPromo.discount_type==="percent"?`${selectedPromo.discount_value}%`:`${fmt(selectedPromo.discount_value)}€`}
                </span>
                <button onClick={()=>setSelectedPromo(null)} style={{ border:"none",background:"transparent",cursor:"pointer",color:P.textHint,display:"flex",padding:0 }}>
                  <X style={{ width:11,height:11 }} />
                </button>
              </div>
            )}
            {/* Desconto manual */}
            <div style={{ position:"relative" }}>
              <Tag style={{ position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",width:12,height:12,color:P.textHint,pointerEvents:"none" }} />
              <input type="number" step="0.01" min="0" value={manualDiscount} onChange={e=>setManualDiscount(e.target.value)} placeholder="Desconto manual (€)"
                style={{ width:"100%",paddingLeft:28,paddingRight:9,paddingTop:8,paddingBottom:8,fontSize:11,borderRadius:9,border:`1.5px solid ${P.border}`,background:P.bgCard,color:P.text,outline:"none",boxSizing:"border-box" } as any} />
            </div>
          </div>

          {/* Totais */}
          <div style={{ borderTop:`2px solid ${P.borderMed}`,padding:"14px 16px",display:"flex",flexDirection:"column",gap:7,flexShrink:0,background:P.bgCard }}>
            <div style={{ display:"flex",justifyContent:"space-between",fontSize:12,color:P.textMuted }}>
              <span>Subtotal</span><span style={{ fontWeight:600,color:P.textSub }}>{fmt(subtotal)}€</span>
            </div>
            {promoD>0&&(
              <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,color:P.gold }}>
                <span>{selectedPromo?.name}</span><span style={{ fontWeight:700 }}>−{fmt(promoD)}€</span>
              </div>
            )}
            {loyaltyD>0&&(
              <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,color:P.gold }}>
                <span style={{ display:"flex",alignItems:"center",gap:4 }}><Star style={{ width:10,height:10 }} />Fidelização</span>
                <span style={{ fontWeight:700 }}>−{fmt(loyaltyD)}€</span>
              </div>
            )}
            {manualD>0&&(
              <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,color:P.textSub }}>
                <span>Desconto manual</span><span style={{ fontWeight:700 }}>−{fmt(manualD)}€</span>
              </div>
            )}
            <div style={{ display:"flex",alignItems:"baseline",justifyContent:"space-between",paddingTop:12,marginTop:4,borderTop:`2px solid ${P.bgDark}` }}>
              <span style={{ fontSize:10,fontWeight:800,textTransform:"uppercase",letterSpacing:"0.14em",color:P.textMuted }}>Total</span>
              <span style={{ fontSize:42,fontWeight:900,color:P.text,lineHeight:1 }}>
                {fmt(total)}<span style={{ fontSize:18,color:P.textMuted,marginLeft:3 }}>€</span>
              </span>
            </div>
          </div>

          {/* Botão pagar */}
          <button onClick={handlePagar}
            style={{ padding:"18px 0",fontWeight:900,fontSize:16,flexShrink:0,cursor:client&&items.length>0?"pointer":"not-allowed",background:client&&items.length>0?P.bgDark:P.bgAccent,color:client&&items.length>0?"#f5e6d3":P.textHint,border:"none",display:"flex",alignItems:"center",justifyContent:"center",gap:10,transition:"all .18s",letterSpacing:"0.02em",boxShadow:client&&items.length>0?"0 -4px 18px rgba(61,43,31,.2)":"none" }}
            onMouseEnter={e=>{if(client&&items.length)(e.currentTarget as HTMLElement).style.background=P.bgDarkHov;}}
            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background=client&&items.length?P.bgDark:P.bgAccent;}}>
            <CreditCard style={{ width:18,height:18 }} />
            {!client?"Selecionar cliente primeiro":items.length===0?"Carrinho vazio":`Pagar  ${fmt(total)}€`}
          </button>
        </div>
      </div>
    </div>
  );
};

export default NovaOperacao;
