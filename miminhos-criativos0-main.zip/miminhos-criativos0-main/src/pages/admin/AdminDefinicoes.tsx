import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import {
  User, KeyRound, Shield, Bell, Palette, Save, Eye, EyeOff,
  CheckCircle2, AlertCircle, Clock, Monitor, Moon, Sun,
  ChevronRight, Settings, Lock, Mail, Phone, Hash,
} from "lucide-react";

// ─── Secção wrapper ───────────────────────────────────────────────────────────
const Section = ({ icon: Icon, title, subtitle, children }: {
  icon: React.ElementType; title: string; subtitle?: string; children: React.ReactNode;
}) => (
  <div className="bg-card border border-border rounded-lg shadow-sm overflow-hidden">
    <div className="px-5 py-3.5 bg-muted/40 border-b border-border flex items-center gap-3">
      <div className="h-7 w-7 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
        <Icon className="h-3.5 w-3.5 text-primary" />
      </div>
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-foreground">{title}</p>
        {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
      </div>
    </div>
    {children}
  </div>
);

// ─── Campo de linha ───────────────────────────────────────────────────────────
const FieldRow = ({ label, value, children, last }: {
  label: string; value?: string; children?: React.ReactNode; last?: boolean;
}) => (
  <div className={`flex items-center gap-4 px-5 py-3.5 hover:bg-muted/20 transition-colors ${!last ? "border-b border-border/40" : ""}`}>
    <span className="text-sm text-muted-foreground w-40 shrink-0">{label}</span>
    <div className="flex-1">{children ?? <span className="text-sm font-medium">{value || "—"}</span>}</div>
  </div>
);

// ─── Página principal ─────────────────────────────────────────────────────────
const AdminDefinicoes = () => {
  const { user, role } = useAuth(["admin", "colaborador"], "/colaborador/login");

  const [profile, setProfile] = useState<any>(null);
  const [loadingProfile, setLoadingProfile] = useState(true);

  // Alterar dados pessoais
  const [editingPerfil, setEditingPerfil] = useState(false);
  const [perfilForm, setPerfilForm] = useState({ full_name: "", phone: "", nif: "" });
  const [savingPerfil, setSavingPerfil] = useState(false);

  // Alterar palavra-passe
  const [pwdForm, setPwdForm] = useState({ atual: "", nova: "", confirmar: "" });
  const [showPwd, setShowPwd] = useState({ atual: false, nova: false, confirmar: false });
  const [savingPwd, setSavingPwd] = useState(false);

  // Notificações (estado local — pode ligar a tabela futuramente)
  const [notif, setNotif] = useState({
    novos_orcamentos: true,
    mensagens: true,
    eventos: true,
    relatorios: false,
  });

  // Tema (estado local)
  const [tema, setTema] = useState<"sistema" | "claro" | "escuro">("sistema");

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => {
      setProfile(data);
      setPerfilForm({
        full_name: data?.full_name || "",
        phone: data?.phone || "",
        nif: data?.nif || "",
      });
      setLoadingProfile(false);
    });
  }, [user]);

  // ─── Guardar perfil ─────────────────────────────────────────────────────────
  const guardarPerfil = async () => {
    setSavingPerfil(true);
    const { error } = await supabase.from("profiles")
      .update({ full_name: perfilForm.full_name, phone: perfilForm.phone, nif: perfilForm.nif })
      .eq("id", user!.id);
    if (error) { setSavingPerfil(false); toast.error("Erro ao guardar: " + error.message); return; }

    // Sincronizar telefone no user_phone_mappings para permitir login por telefone
    const normalizedPhone = (perfilForm.phone || "").replace(/\D/g, "");
    if (normalizedPhone) {
      await (supabase as any).from("user_phone_mappings").upsert(
        { user_id: user!.id, phone: normalizedPhone, email: user!.email || "" },
        { onConflict: "user_id" }
      );
    }

    setSavingPerfil(false);
    setProfile((p: any) => ({ ...p, ...perfilForm }));
    setEditingPerfil(false);
    toast.success("Perfil atualizado com sucesso!");
  };

  // ─── Alterar palavra-passe ──────────────────────────────────────────────────
  const alterarPassword = async () => {
    if (!pwdForm.nova.trim()) { toast.error("A nova palavra-passe não pode estar vazia."); return; }
    if (pwdForm.nova.length < 8) { toast.error("A palavra-passe deve ter pelo menos 8 caracteres."); return; }
    if (pwdForm.nova !== pwdForm.confirmar) { toast.error("As palavras-passe não coincidem."); return; }
    setSavingPwd(true);
    const { error } = await supabase.auth.updateUser({ password: pwdForm.nova });
    setSavingPwd(false);
    if (error) { toast.error("Erro: " + error.message); return; }
    setPwdForm({ atual: "", nova: "", confirmar: "" });
    toast.success("Palavra-passe alterada com sucesso!");
  };

  // ─── Reset palavra-passe (enviar email) ─────────────────────────────────────
  const enviarResetEmail = async () => {
    if (!user?.email) return;
    const { error } = await supabase.auth.resetPasswordForEmail(user.email, {
      redirectTo: `${window.location.origin}/login`,
    });
    if (error) { toast.error("Erro ao enviar email: " + error.message); return; }
    toast.success(`Email de recuperação enviado para ${user.email}`, { duration: 8000 });
  };

  const roleLabel: Record<string, string> = {
    admin: "Administrador",
    colaborador: "Colaborador",
    cliente: "Cliente",
  };

  const roleColor: Record<string, string> = {
    admin: "bg-purple-50 text-purple-700 border-purple-200",
    colaborador: "bg-blue-50 text-blue-700 border-blue-200",
    cliente: "bg-green-50 text-green-700 border-green-200",
  };

  if (loadingProfile) return (
    <div className="text-center py-16 text-muted-foreground text-sm">A carregar definições...</div>
  );

  return (
    <div className="space-y-5 animate-in fade-in duration-300 max-w-3xl">
      <PageHeader title="Definições" description="Gerencie o seu perfil e preferências do sistema." />

      {/* ── Perfil ── */}
      <Section icon={User} title="Perfil" subtitle="Informação pessoal da sua conta">
        {/* Cabeçalho do perfil */}
        <div className="px-5 py-4 flex items-center gap-4 border-b border-border/40">
          <div className="h-14 w-14 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center shrink-0">
            <User className="h-6 w-6 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-base truncate">{profile?.full_name || user?.email?.split("@")[0] || "—"}</p>
            <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
            <div className="flex items-center gap-2 mt-1.5">
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${roleColor[role ?? ""] ?? "bg-muted text-muted-foreground"}`}>
                {roleLabel[role ?? ""] ?? role}
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-emerald-600">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Conta ativa
              </span>
              {profile?.client_number && (
                <span className="text-xs text-muted-foreground font-mono">Nº {profile.client_number}</span>
              )}
            </div>
          </div>
          <Button size="sm" variant={editingPerfil ? "default" : "outline"} className={`h-8 text-xs shrink-0 ${editingPerfil ? "bg-gradient-gold" : ""}`}
            onClick={() => { if (editingPerfil) guardarPerfil(); else setEditingPerfil(true); }}
            disabled={savingPerfil}>
            {editingPerfil
              ? <><Save className="h-3.5 w-3.5 mr-1.5" />{savingPerfil ? "A guardar…" : "Guardar"}</>
              : <><User className="h-3.5 w-3.5 mr-1.5" />Editar Perfil</>}
          </Button>
          {editingPerfil && (
            <Button size="sm" variant="ghost" className="h-8 text-xs" onClick={() => { setEditingPerfil(false); setPerfilForm({ full_name: profile?.full_name || "", phone: profile?.phone || "", nif: profile?.nif || "" }); }}>
              Cancelar
            </Button>
          )}
        </div>

        {/* Campos */}
        <FieldRow label="Nome Completo">
          {editingPerfil
            ? <Input value={perfilForm.full_name} onChange={(e) => setPerfilForm({ ...perfilForm, full_name: e.target.value })} className="h-8 text-sm max-w-xs border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30" placeholder="Nome completo" />
            : <span className="text-sm font-medium">{profile?.full_name || "—"}</span>}
        </FieldRow>
        <FieldRow label="Email">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{user?.email}</span>
            <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">Não editável</span>
          </div>
        </FieldRow>
        <FieldRow label="Telefone">
          {editingPerfil
            ? <Input value={perfilForm.phone} onChange={(e) => setPerfilForm({ ...perfilForm, phone: e.target.value })} className="h-8 text-sm max-w-xs border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30" placeholder="9XX XXX XXX" />
            : <span className="text-sm font-medium">{profile?.phone || "—"}</span>}
        </FieldRow>
        <FieldRow label="NIF" last>
          {editingPerfil
            ? <Input value={perfilForm.nif} onChange={(e) => setPerfilForm({ ...perfilForm, nif: e.target.value })} className="h-8 text-sm max-w-xs border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30" placeholder="123456789" maxLength={9} />
            : <span className="text-sm font-medium">{profile?.nif || "—"}</span>}
        </FieldRow>
      </Section>

      {/* ── Segurança ── */}
      <Section icon={Shield} title="Segurança" subtitle="Gestão da palavra-passe e acesso">
        {/* Alterar palavra-passe */}
        <div className="px-5 py-4 border-b border-border/40">
          <p className="text-sm font-semibold mb-3">Alterar Palavra-passe</p>
          <div className="space-y-3 max-w-sm">
            {[
              { key: "nova", label: "Nova palavra-passe" },
              { key: "confirmar", label: "Confirmar nova palavra-passe" },
            ].map((f) => (
              <div key={f.key}>
                <label className="text-xs text-muted-foreground block mb-1">{f.label}</label>
                <div className="relative">
                  <Input
                    type={(showPwd as any)[f.key] ? "text" : "password"}
                    value={(pwdForm as any)[f.key]}
                    onChange={(e) => setPwdForm({ ...pwdForm, [f.key]: e.target.value })}
                    className="h-9 text-sm pr-9 border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/30"
                    placeholder="••••••••"
                  />
                  <button onClick={() => setShowPwd({ ...showPwd, [f.key]: !(showPwd as any)[f.key] })}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                    {(showPwd as any)[f.key] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  </button>
                </div>
              </div>
            ))}

            {/* Indicador de força */}
            {pwdForm.nova && (
              <div className="space-y-1">
                <div className="flex gap-1">
                  {[1, 2, 3, 4].map((i) => {
                    const strength = [pwdForm.nova.length >= 8, /[A-Z]/.test(pwdForm.nova), /[0-9]/.test(pwdForm.nova), /[^A-Za-z0-9]/.test(pwdForm.nova)].filter(Boolean).length;
                    return <div key={i} className={`h-1 flex-1 rounded-full transition-colors ${i <= strength ? strength <= 1 ? "bg-red-400" : strength <= 2 ? "bg-amber-400" : strength <= 3 ? "bg-blue-400" : "bg-emerald-400" : "bg-muted"}`} />;
                  })}
                </div>
                <p className="text-xs text-muted-foreground">
                  {[pwdForm.nova.length >= 8, /[A-Z]/.test(pwdForm.nova), /[0-9]/.test(pwdForm.nova), /[^A-Za-z0-9]/.test(pwdForm.nova)].filter(Boolean).length <= 1 ? "Fraca" :
                   [pwdForm.nova.length >= 8, /[A-Z]/.test(pwdForm.nova), /[0-9]/.test(pwdForm.nova), /[^A-Za-z0-9]/.test(pwdForm.nova)].filter(Boolean).length <= 2 ? "Razoável" :
                   [pwdForm.nova.length >= 8, /[A-Z]/.test(pwdForm.nova), /[0-9]/.test(pwdForm.nova), /[^A-Za-z0-9]/.test(pwdForm.nova)].filter(Boolean).length <= 3 ? "Boa" : "Forte ✓"}
                </p>
              </div>
            )}

            {pwdForm.confirmar && pwdForm.nova !== pwdForm.confirmar && (
              <p className="text-xs text-red-500 flex items-center gap-1"><AlertCircle className="h-3 w-3" /> As palavras-passe não coincidem</p>
            )}
            {pwdForm.confirmar && pwdForm.nova === pwdForm.confirmar && pwdForm.nova && (
              <p className="text-xs text-emerald-600 flex items-center gap-1"><CheckCircle2 className="h-3 w-3" /> As palavras-passe coincidem</p>
            )}

            <Button size="sm" className="bg-gradient-gold h-8 text-xs mt-1" onClick={alterarPassword} disabled={savingPwd || !pwdForm.nova || pwdForm.nova !== pwdForm.confirmar}>
              <Lock className="h-3.5 w-3.5 mr-1.5" />
              {savingPwd ? "A alterar…" : "Alterar Palavra-passe"}
            </Button>
          </div>
        </div>

        {/* Reset por email */}
        <div className="px-5 py-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-sm font-semibold">Recuperação por Email</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Envia um link de recuperação para <strong>{user?.email}</strong>. Útil se esqueceu a palavra-passe atual.
              </p>
            </div>
            <Button size="sm" variant="outline" className="h-8 text-xs shrink-0" onClick={enviarResetEmail}>
              <Mail className="h-3.5 w-3.5 mr-1.5" /> Enviar Email
            </Button>
          </div>
        </div>
      </Section>

      {/* ── Notificações ── */}
      <Section icon={Bell} title="Notificações" subtitle="Escolha o que quer ser notificado">
        {[
          { key: "novos_orcamentos", label: "Novos orçamentos", desc: "Quando um cliente submete um novo questionário" },
          { key: "mensagens", label: "Mensagens", desc: "Quando recebe uma nova mensagem de um cliente" },
          { key: "eventos", label: "Eventos", desc: "Atualizações de estado dos eventos" },
          { key: "relatorios", label: "Relatórios semanais", desc: "Resumo semanal de atividade do sistema" },
        ].map((item, i, arr) => (
          <div key={item.key} className={`flex items-center justify-between gap-4 px-5 py-3.5 hover:bg-muted/20 transition-colors ${i < arr.length - 1 ? "border-b border-border/40" : ""}`}>
            <div>
              <p className="text-sm font-medium">{item.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
            </div>
            <button
              onClick={() => setNotif({ ...notif, [item.key]: !(notif as any)[item.key] })}
              className={`relative h-5 w-9 rounded-full transition-colors shrink-0 ${(notif as any)[item.key] ? "bg-primary" : "bg-muted-foreground/30"}`}>
              <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform ${(notif as any)[item.key] ? "translate-x-4" : "translate-x-0.5"}`} />
            </button>
          </div>
        ))}
      </Section>

      {/* ── Aparência ── */}
      <Section icon={Palette} title="Aparência" subtitle="Personalize a interface">
        <div className="px-5 py-4">
          <p className="text-sm font-medium mb-3">Tema</p>
          <div className="flex gap-2">
            {[
              { key: "sistema", label: "Sistema", icon: Monitor },
              { key: "claro", label: "Claro", icon: Sun },
              { key: "escuro", label: "Escuro", icon: Moon },
            ].map(({ key, label, icon: Icon }) => (
              <button key={key} onClick={() => setTema(key as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border-2 text-sm transition-all ${tema === key ? "border-primary bg-primary/5 text-primary font-medium" : "border-border/60 hover:border-border text-muted-foreground"}`}>
                <Icon className="h-4 w-4" /> {label}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">O tema escuro requer suporte do navegador.</p>
        </div>
      </Section>

      {/* ── Info do Sistema ── */}
      <Section icon={Settings} title="Informação do Sistema" subtitle="Dados técnicos da sua sessão">
        {[
          { label: "ID de Utilizador", value: user?.id?.substring(0, 20) + "…", icon: Hash },
          { label: "Email", value: user?.email || "—", icon: Mail },
          { label: "Função", value: roleLabel[role ?? ""] ?? role ?? "—", icon: Shield },
          { label: "Último acesso", value: user?.last_sign_in_at ? format(new Date(user.last_sign_in_at), "dd/MM/yyyy 'às' HH:mm", { locale: pt }) : "—", icon: Clock },
          { label: "Conta criada", value: user?.created_at ? format(new Date(user.created_at), "dd/MM/yyyy", { locale: pt }) : "—", icon: CheckCircle2 },
        ].map((f, i, arr) => (
          <div key={f.label} className={`flex items-center gap-4 px-5 py-3 hover:bg-muted/20 transition-colors ${i < arr.length - 1 ? "border-b border-border/40" : ""}`}>
            <f.icon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <span className="text-sm text-muted-foreground w-36 shrink-0">{f.label}</span>
            <span className="text-sm font-mono font-medium text-foreground">{f.value}</span>
          </div>
        ))}
      </Section>
    </div>
  );
};

export default AdminDefinicoes;
