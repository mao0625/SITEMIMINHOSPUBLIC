import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { toast } from "sonner";
import {
  ArrowLeft, Plus, Eye, Check, Phone, Mail, Users,
  Calendar, MessageSquare, AlertCircle, RefreshCw,
  UserPlus, ChevronRight, Inbox,
} from "lucide-react";

const STATUS = ["pendente", "aprovado", "em_contacto", "convertido", "fechado"];

const STATUS_CONFIG: Record<string, { label: string; class: string; dot: string }> = {
  pendente:    { label: "Pendente",     class: "bg-amber-100 text-amber-800 border-amber-300",   dot: "bg-amber-500"   },
  aprovado:    { label: "Aprovado",     class: "bg-green-100 text-green-800 border-green-300",   dot: "bg-green-500"   },
  em_contacto: { label: "Em Contacto",  class: "bg-blue-100 text-blue-800 border-blue-300",      dot: "bg-blue-500"    },
  convertido:  { label: "Convertido",   class: "bg-primary/10 text-primary border-primary/30",   dot: "bg-primary"     },
  fechado:     { label: "Fechado",      class: "bg-muted text-muted-foreground border-border",   dot: "bg-muted-foreground" },
};

// ─── Componentes SAP-style com cores do site ──────────────────────────────────
const Shell = ({ title, subtitle, back, backLabel, actions }: {
  title: string; subtitle?: string; back?: () => void; backLabel?: string; actions?: React.ReactNode;
}) => (
  <div className="bg-card border border-border rounded-t-lg overflow-hidden">
    <div className="h-[3px] bg-gradient-to-r from-primary/40 via-primary to-primary/40" />
    <div className="flex items-center gap-3 px-4 py-2.5 bg-muted/40 border-b border-border">
      {back && (
        <>
          <button onClick={back} className="flex items-center gap-1.5 text-xs font-semibold text-primary hover:text-primary/80 hover:underline underline-offset-2 shrink-0 transition-colors">
            <ArrowLeft className="h-3.5 w-3.5" />{backLabel ?? "Voltar"}
          </button>
          <div className="h-4 w-px bg-border" />
        </>
      )}
      <div className="flex-1 min-w-0">
        <span className="font-bold text-sm text-foreground">{title}</span>
        {subtitle && <span className="text-xs text-muted-foreground ml-3">{subtitle}</span>}
      </div>
      {actions && <div className="flex items-center gap-2 ml-auto">{actions}</div>}
    </div>
  </div>
);

const Section = ({ label, icon: Icon }: { label: string; icon?: any }) => (
  <div className="flex items-center gap-2 px-4 py-2 bg-muted/30 border-b border-border/60">
    {Icon && <Icon className="h-3.5 w-3.5 text-muted-foreground" />}
    <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">{label}</span>
  </div>
);

const FieldRow = ({ label, last, children }: { label: string; last?: boolean; children: React.ReactNode }) => (
  <div className={`flex items-start ${!last ? "border-b border-border/40" : ""} hover:bg-primary/[0.02] transition-colors`}>
    <span className="text-[11px] text-muted-foreground font-medium bg-muted/20 px-4 py-2.5 w-36 shrink-0 border-r border-border/30 leading-tight">
      {label}
    </span>
    <div className="flex-1 px-4 py-2.5 text-sm text-foreground">{children}</div>
  </div>
);

const StatusBadge = ({ status }: { status: string }) => {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG["pendente"];
  return (
    <span className={`inline-flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-0.5 rounded-full border uppercase tracking-wide ${cfg.class}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
};

// ─── Formulário presencial ────────────────────────────────────────────────────
const FormPresencial = ({ onBack }: { onBack: () => void }) => {
  const [form, setForm] = useState({ name: "", email: "", phone: "", event_type: "" });
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const _pwdBuf = new Uint8Array(12);
      window.crypto.getRandomValues(_pwdBuf);
      const password = Array.from(_pwdBuf, b => "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"[b % 56]).join("") + "!A1";
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-create-user`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ email: form.email, password, full_name: form.name, phone: form.phone, role: "cliente" }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Erro ao criar utilizador");
      navigator.clipboard?.writeText(password);
      toast.success(`Conta criada! Password copiada: ${password}`, { duration: 15000 });
      await supabase.from("quote_requests").insert([{ name: form.name, email: form.email, phone: form.phone, event_type: form.event_type, status: "convertido" }]);
      window.location.href = "/admin/questionarios";
    } catch (err: any) {
      toast.error(err.message);
      setSaving(false);
    }
  };

  return (
    <div>
      <Shell title="Novo Pedido Presencial" subtitle="Criar cliente e pedido manualmente" back={onBack} backLabel="Pedidos" />
      <div className="bg-card border border-t-0 border-border rounded-b-lg">
        <Section label="Dados do Cliente" icon={UserPlus} />
        <form onSubmit={submit}>
          <div className="p-6 grid sm:grid-cols-2 gap-5">
            {[
              { id: "name",       label: "Nome Completo",  type: "text",  placeholder: "Nome completo",        required: true  },
              { id: "email",      label: "Email",          type: "email", placeholder: "email@exemplo.com",    required: true  },
              { id: "phone",      label: "Telefone",       type: "tel",   placeholder: "+351 912 345 678",     required: false },
              { id: "event_type", label: "Tipo de Evento", type: "text",  placeholder: "Casamento, Batizado…", required: false },
            ].map(f => (
              <div key={f.id} className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{f.label}</Label>
                <Input
                  required={f.required}
                  type={f.type}
                  placeholder={f.placeholder}
                  value={(form as any)[f.id]}
                  onChange={e => setForm({ ...form, [f.id]: e.target.value })}
                  className="h-9 text-sm border-border/60 focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary/20"
                />
              </div>
            ))}
          </div>

          <div className="px-6 py-4 border-t border-border bg-muted/20 flex items-center justify-between">
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <AlertCircle className="h-3.5 w-3.5 text-amber-500" />
              Será gerada uma password aleatória e copiada para a área de transferência.
            </p>
            <Button type="submit" className="bg-gradient-gold h-9 px-5 text-sm font-semibold" disabled={saving}>
              {saving ? "A criar…" : <><UserPlus className="h-4 w-4 mr-1.5" />Criar e Avançar</>}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ─── Página principal ─────────────────────────────────────────────────────────
const AdminPedidos = () => {
  const [items, setItems]                     = useState<any[]>([]);
  const [open, setOpen]                       = useState<any>(null);
  const [isCreatingPresencial, setIsCreatingPresencial] = useState(false);
  const [loading, setLoading]                 = useState(true);
  const [filterStatus, setFilterStatus]       = useState<string>("todos");

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("quote_requests").select("*").order("created_at", { ascending: false });
    setItems(data ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("quote_requests").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Estado atualizado");
    load();
  };

  const aprovar = async (p: any) => {
    if (!confirm(`Marcar pedido de ${p.name} como aprovado?`)) return;
    const { error } = await supabase.from("quote_requests").update({ status: "aprovado" }).eq("id", p.id);
    if (error) return toast.error(error.message);
    toast.success(`Pedido aprovado! Lembra-te de criar a conta para ${p.email}`);
    load();
  };

  if (isCreatingPresencial) return <FormPresencial onBack={() => setIsCreatingPresencial(false)} />;

  const filtered = filterStatus === "todos" ? items : items.filter(i => i.status === filterStatus);

  // Contadores por estado
  const counts = STATUS.reduce((acc, s) => ({ ...acc, [s]: items.filter(i => i.status === s).length }), {} as Record<string, number>);

  return (
    <>
      {/* Header */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground">Pedidos de Orçamento</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Pedidos recebidos pelo formulário público e presenciais</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-8 text-xs border-border/60" onClick={load} disabled={loading}>
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} />Atualizar
          </Button>
          <Button size="sm" className="h-8 text-xs bg-gradient-gold" onClick={() => setIsCreatingPresencial(true)}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />Novo Presencial
          </Button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-5">
        {[{ key: "todos", label: "Total", count: items.length }, ...STATUS.map(s => ({ key: s, label: STATUS_CONFIG[s]?.label ?? s, count: counts[s] ?? 0 }))].map(c => (
          <button
            key={c.key}
            onClick={() => setFilterStatus(c.key)}
            className={`text-left px-4 py-3 rounded-lg border transition-all ${
              filterStatus === c.key
                ? "border-primary bg-primary/5 shadow-sm"
                : "border-border/60 bg-card hover:border-primary/40 hover:bg-primary/[0.02]"
            }`}
          >
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground truncate">{c.label}</p>
            <p className={`text-2xl font-black tabular-nums mt-0.5 ${filterStatus === c.key ? "text-primary" : "text-foreground"}`}>{c.count}</p>
          </button>
        ))}
      </div>

      {/* Tabela */}
      <Shell
        title="Lista de Pedidos"
        subtitle={`${filtered.length} ${filterStatus === "todos" ? "pedidos" : STATUS_CONFIG[filterStatus]?.label?.toLowerCase()}`}
        actions={
          filterStatus !== "todos" && (
            <button onClick={() => setFilterStatus("todos")} className="text-xs text-primary hover:underline flex items-center gap-1">
              Ver todos
            </button>
          )
        }
      />
      <div className="bg-card border border-t-0 border-border rounded-b-lg overflow-hidden shadow-soft">
        {/* Cabeçalho da tabela */}
        <div className="grid grid-cols-[1fr_120px_90px_80px_110px_90px_100px] gap-3 px-5 py-2.5 bg-muted/30 border-b border-border text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
          <span>Cliente</span>
          <span>Tipo de Evento</span>
          <span>Data</span>
          <span>Convidados</span>
          <span>Recebido</span>
          <span>Estado</span>
          <span></span>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-16 text-muted-foreground">
            <RefreshCw className="h-5 w-5 animate-spin mr-2" /><span className="text-sm">A carregar…</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Inbox className="h-10 w-10 mb-3 opacity-20" />
            <p className="text-sm">{filterStatus === "todos" ? "Sem pedidos ainda." : "Nenhum pedido com este estado."}</p>
          </div>
        ) : filtered.map((p, i) => (
          <div
            key={p.id}
            className={`grid grid-cols-[1fr_120px_90px_80px_110px_90px_100px] gap-3 px-5 py-3.5 items-center border-b border-border/25 last:border-0 hover:bg-primary/[0.02] transition-colors ${i % 2 !== 0 ? "bg-muted/[0.03]" : ""}`}
          >
            {/* Cliente */}
            <div className="min-w-0">
              <p className="text-sm font-semibold truncate text-foreground">{p.name}</p>
              <div className="flex items-center gap-3 mt-0.5">
                <span className="text-[10px] text-muted-foreground flex items-center gap-1 truncate">
                  <Mail className="h-2.5 w-2.5 shrink-0" />{p.email}
                </span>
                {p.phone && (
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1 shrink-0">
                    <Phone className="h-2.5 w-2.5" />{p.phone}
                  </span>
                )}
              </div>
            </div>

            {/* Tipo */}
            <span className="text-xs text-muted-foreground truncate">{p.event_type || "—"}</span>

            {/* Data evento */}
            <span className="text-xs text-muted-foreground tabular-nums">
              {p.event_date ? format(new Date(p.event_date), "dd/MM/yyyy") : "—"}
            </span>

            {/* Convidados */}
            <span className="text-xs text-muted-foreground tabular-nums flex items-center gap-1">
              {p.guests_count ? <><Users className="h-3 w-3" />{p.guests_count}</> : "—"}
            </span>

            {/* Recebido */}
            <span className="text-xs text-muted-foreground tabular-nums">
              {format(new Date(p.created_at), "dd MMM yyyy", { locale: pt })}
            </span>

            {/* Estado */}
            <div className="flex flex-col gap-1">
              <select
                value={p.status}
                onChange={e => updateStatus(p.id, e.target.value)}
                className="border border-border/60 rounded h-7 px-1.5 text-[10px] font-bold bg-background text-foreground cursor-pointer focus:outline-none focus:border-primary"
              >
                {STATUS.map(s => (
                  <option key={s} value={s}>{STATUS_CONFIG[s]?.label ?? s}</option>
                ))}
              </select>
              {p.status === "aprovado" && (
                <span className="text-[9px] text-amber-600 font-semibold flex items-center gap-1 leading-tight">
                  <AlertCircle className="h-2.5 w-2.5 shrink-0" />Enviar credenciais
                </span>
              )}
            </div>

            {/* Ações */}
            <div className="flex items-center gap-1.5">
              <Button size="sm" variant="outline" className="h-7 text-[10px] px-2 border-border/60" onClick={() => setOpen(p)}>
                <Eye className="h-3 w-3 mr-1" />Ver
              </Button>
              {p.status === "pendente" && (
                <Button size="sm" className="h-7 text-[10px] px-2 bg-green-600 hover:bg-green-700 text-white border-0" onClick={() => aprovar(p)}>
                  <Check className="h-3 w-3 mr-1" />OK
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal detalhe */}
      <Dialog open={!!open} onOpenChange={o => !o && setOpen(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-8 w-8 rounded bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                <span className="text-xs font-bold text-primary">{(open?.name || "?").substring(0, 2).toUpperCase()}</span>
              </div>
              {open?.name}
            </DialogTitle>
          </DialogHeader>
          {open && (
            <div className="border border-border rounded-lg overflow-hidden">
              <FieldRow label="Email">
                <a href={`mailto:${open.email}`} className="text-primary hover:underline">{open.email}</a>
              </FieldRow>
              <FieldRow label="Telefone">
                <div className="flex items-center gap-3">
                  <span>{open.phone || "—"}</span>
                  {open.phone && (
                    <a href={`https://wa.me/351${open.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer"
                      className="text-[10px] font-bold text-green-700 bg-green-50 border border-green-200 px-2 py-0.5 rounded hover:bg-green-100 transition-colors">
                      WhatsApp →
                    </a>
                  )}
                </div>
              </FieldRow>
              <FieldRow label="Tipo de Evento">{open.event_type || "—"}</FieldRow>
              <FieldRow label="Data do Evento">
                {open.event_date ? format(new Date(open.event_date), "dd 'de' MMMM 'de' yyyy", { locale: pt }) : "—"}
              </FieldRow>
              <FieldRow label="Convidados">
                {open.guests_count ? `${open.guests_count} pessoas` : "—"}
              </FieldRow>
              <FieldRow label="Estado">
                <StatusBadge status={open.status} />
              </FieldRow>
              <FieldRow label="Mensagem" last>
                <p className="whitespace-pre-wrap text-sm text-muted-foreground leading-relaxed">{open.message || "—"}</p>
              </FieldRow>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AdminPedidos;
