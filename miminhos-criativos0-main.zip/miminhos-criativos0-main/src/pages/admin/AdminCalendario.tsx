import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, addMonths, addWeeks,
  format, isSameMonth, isSameDay,
} from "date-fns";
import { pt } from "date-fns/locale";
import {
  ChevronLeft, ChevronRight, MapPin, Users, CalendarDays,
  X, Tag, Clock, FileText, User, ExternalLink,
} from "lucide-react";

type Event = {
  id: string;
  title: string;
  event_date: string | null;
  event_type: string | null;
  location: string | null;
  guests_count: number | null;
  status: string;
  notes?: string | null;
  client_id?: string | null;
};

type View = "mes" | "semana" | "dia";

const statusColor: Record<string, string> = {
  pendente:    "bg-amber-100 text-amber-700 border-amber-200",
  planeamento: "bg-purple-100 text-purple-700 border-purple-200",
  confirmado:  "bg-green-100 text-green-700 border-green-200",
  concluido:   "bg-blue-100 text-blue-700 border-blue-200",
  cancelado:   "bg-red-100 text-red-700 border-red-200",
};

// ─── Painel de detalhe do evento ──────────────────────────────────────────────
const EventoDetalhe = ({ event, onClose }: { event: Event; onClose: () => void }) => {
  const [clientName, setClientName] = useState<string | null>(null);

  useEffect(() => {
    if (!event.client_id) return;
    supabase
      .from("profiles")
      .select("full_name, email, client_number")
      .eq("id", event.client_id)
      .single()
      .then(({ data }) => {
        if (data) setClientName(`${data.full_name || data.email} (Nº ${data.client_number ?? "—"})`);
      });
  }, [event.client_id]);

  // Fechar com Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-40 bg-black/30 backdrop-blur-sm" onClick={onClose} />

      {/* Painel lateral */}
      <div className="fixed right-0 top-0 bottom-0 z-50 w-full max-w-md bg-card border-l border-border shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">

        {/* Cabeçalho */}
        <div className="px-5 py-4 border-b border-border bg-muted/40 flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize border ${statusColor[event.status] ?? "bg-muted text-muted-foreground border-border"}`}>
                {event.status}
              </span>
              {event.event_type && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 font-medium">
                  {event.event_type}
                </span>
              )}
            </div>
            <h2 className="font-semibold text-base leading-tight">{event.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="shrink-0 p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Conteúdo */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">

          {/* Secção: Detalhes */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">
              Informação do Evento
            </p>
            <div className="space-y-0 border border-border/60 rounded-lg overflow-hidden">
              {[
                {
                  icon: CalendarDays,
                  label: "Data",
                  value: event.event_date
                    ? format(new Date(event.event_date), "EEEE, dd 'de' MMMM 'de' yyyy", { locale: pt })
                    : "Sem data definida",
                },
                {
                  icon: Tag,
                  label: "Tipo",
                  value: event.event_type || "—",
                },
                {
                  icon: MapPin,
                  label: "Local",
                  value: event.location || "—",
                },
                {
                  icon: Users,
                  label: "Convidados",
                  value: event.guests_count ? `${event.guests_count} convidados` : "—",
                },
                ...(clientName ? [{
                  icon: User,
                  label: "Cliente",
                  value: clientName,
                }] : []),
              ].map((row, i, arr) => (
                <div
                  key={row.label}
                  className={`flex items-start gap-3 px-4 py-3 hover:bg-muted/30 transition-colors ${i < arr.length - 1 ? "border-b border-border/40" : ""}`}
                >
                  <row.icon className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-muted-foreground mb-0.5">{row.label}</p>
                    <p className="text-sm font-medium capitalize">{row.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Secção: Notas */}
          {event.notes && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-1.5">
                <FileText className="h-3 w-3" /> Notas
              </p>
              <div className="bg-muted/30 border border-border/50 rounded-lg px-4 py-3">
                <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">{event.notes}</p>
              </div>
            </div>
          )}

          {/* ID interno (para debug / referência) */}
          <div className="pt-2 border-t border-border/30">
            <p className="text-[10px] text-muted-foreground/50 font-mono">ID: {event.id}</p>
          </div>
        </div>

        {/* Rodapé com ação */}
        <div className="px-5 py-4 border-t border-border bg-muted/20 flex gap-2">
          <Button
            variant="outline"
            className="flex-1 h-9 text-sm"
            onClick={onClose}
          >
            Fechar
          </Button>
          <Button
            className="flex-1 h-9 text-sm bg-gradient-gold"
            onClick={() => { window.location.href = "/admin/eventos"; }}
          >
            <ExternalLink className="h-3.5 w-3.5 mr-2" />
            Ver em Eventos
          </Button>
        </div>
      </div>
    </>
  );
};

// ─── Chip de evento clicável ──────────────────────────────────────────────────
const EventChip = ({ event, onClick }: { event: Event; onClick: () => void }) => (
  <button
    onClick={(e) => { e.stopPropagation(); onClick(); }}
    className="w-full text-left bg-primary/10 border border-primary/20 text-primary text-xs font-medium rounded px-2 py-1 truncate shadow-sm hover:bg-primary/20 hover:border-primary/40 transition-colors"
    title={event.title}
  >
    {event.title}
  </button>
);

// ─── Página principal ─────────────────────────────────────────────────────────
const AdminCalendario = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [cursor, setCursor] = useState(new Date());
  const [view, setView] = useState<View>("mes");
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  useEffect(() => {
    supabase
      .from("events")
      .select("id,title,event_date,event_type,location,guests_count,status,notes,client_id")
      .order("event_date")
      .then(({ data }) => setEvents((data ?? []) as Event[]));
  }, []);

  const eventsByDay = useMemo(() => {
    const m: Record<string, Event[]> = {};
    events.forEach((e) => { if (e.event_date) (m[e.event_date] ||= []).push(e); });
    return m;
  }, [events]);

  const shift = (n: number) => {
    if (view === "mes") setCursor(addMonths(cursor, n));
    else if (view === "semana") setCursor(addWeeks(cursor, n));
    else setCursor(addDays(cursor, n));
  };

  // ── Vista mês ──────────────────────────────────────────────────────────────
  const renderMonth = () => {
    const start = startOfWeek(startOfMonth(cursor), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(cursor), { weekStartsOn: 1 });
    const days: Date[] = [];
    for (let d = start; d <= end; d = addDays(d, 1)) days.push(d);

    return (
      <div className="bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden">
        <div className="grid grid-cols-7 bg-muted/40 text-xs font-semibold text-muted-foreground uppercase tracking-wider border-b border-border/60">
          {["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"].map((d) => (
            <div key={d} className="p-3 text-center">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {days.map((d, i) => {
            const key = format(d, "yyyy-MM-dd");
            const evs = eventsByDay[key] || [];
            const isToday = isSameDay(d, new Date());
            const isCurrentMonth = isSameMonth(d, cursor);

            return (
              <div
                key={key}
                className={`min-h-[130px] border-b border-r border-border/40 p-2 transition-colors hover:bg-muted/10 ${!isCurrentMonth ? "bg-muted/20 opacity-60" : ""} ${(i + 1) % 7 === 0 ? "border-r-0" : ""}`}
              >
                <div className={`text-sm font-medium w-7 h-7 flex items-center justify-center rounded-full mb-2 ${isToday ? "bg-primary text-primary-foreground shadow-md" : "text-foreground"}`}>
                  {format(d, "d")}
                </div>
                <div className="space-y-1.5">
                  {evs.slice(0, 3).map((e) => (
                    <EventChip key={e.id} event={e} onClick={() => setSelectedEvent(e)} />
                  ))}
                  {evs.length > 3 && (
                    <div className="text-[11px] font-medium text-muted-foreground text-center pt-1">
                      +{evs.length - 3} eventos
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // ── Vista semana / dia ─────────────────────────────────────────────────────
  const renderRange = (days: Date[]) => (
    <div className="space-y-4">
      {days.map((d) => {
        const key = format(d, "yyyy-MM-dd");
        const evs = eventsByDay[key] || [];
        const isToday = isSameDay(d, new Date());

        return (
          <div
            key={key}
            className={`bg-card border border-border/60 rounded-xl shadow-sm overflow-hidden ${isToday ? "ring-1 ring-primary" : ""}`}
          >
            <div className={`px-5 py-3 border-b border-border/60 flex items-center justify-between ${isToday ? "bg-primary/5" : "bg-muted/20"}`}>
              <h3 className="font-semibold text-lg capitalize flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-muted-foreground" />
                {format(d, "EEEE, dd 'de' MMMM", { locale: pt })}
                {isToday && (
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full ml-2 uppercase font-bold tracking-wider">
                    Hoje
                  </span>
                )}
              </h3>
              {evs.length > 0 && (
                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full border border-border/50">
                  {evs.length} evento{evs.length !== 1 ? "s" : ""}
                </span>
              )}
            </div>
            <div className="p-5">
              {evs.length === 0 ? (
                <p className="text-sm text-muted-foreground italic">Nenhum evento agendado para este dia.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {evs.map((e) => (
                    <button
                      key={e.id}
                      onClick={() => setSelectedEvent(e)}
                      className="text-left border border-border/50 bg-background p-4 rounded-lg shadow-sm hover:shadow-md hover:border-primary/40 hover:bg-primary/5 transition-all relative overflow-hidden group"
                    >
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-gold" />
                      <div className="pl-3">
                        <div className="font-semibold text-foreground text-base mb-1 group-hover:text-primary transition-colors">
                          {e.title}
                        </div>
                        <div className="flex items-center gap-2 mb-3 flex-wrap">
                          <span className="text-xs font-medium text-primary bg-primary/10 inline-block px-2 py-0.5 rounded">
                            {e.event_type || "Geral"}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded border font-medium capitalize ${statusColor[e.status] ?? "bg-muted text-muted-foreground border-border"}`}>
                            {e.status}
                          </span>
                        </div>
                        <div className="flex flex-col gap-1.5 text-sm text-muted-foreground">
                          {e.location && (
                            <span className="flex items-center gap-2">
                              <MapPin className="h-3.5 w-3.5 shrink-0" /> {e.location}
                            </span>
                          )}
                          {e.guests_count && (
                            <span className="flex items-center gap-2">
                              <Users className="h-3.5 w-3.5 shrink-0" /> {e.guests_count} convidados
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader title="Calendário Operacional" description="Visão geral do planeamento a curto e longo prazo." />

      {/* Toolbar */}
      <div className="bg-card border border-border/60 p-3 rounded-xl shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center bg-muted/30 p-1 rounded-lg border border-border/50">
          {(["mes", "semana", "dia"] as View[]).map((v) => (
            <Button
              key={v}
              size="sm"
              variant={view === v ? "default" : "ghost"}
              onClick={() => setView(v)}
              className={`capitalize px-6 ${view === v ? "shadow-sm" : ""}`}
            >
              {v.replace("mes", "mês")}
            </Button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <Button size="sm" variant="outline" onClick={() => setCursor(new Date())} className="font-medium mr-2">
            Ir para Hoje
          </Button>
          <div className="flex items-center gap-1 bg-muted/30 rounded-lg p-1 border border-border/50">
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => shift(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="font-semibold text-sm min-w-[190px] text-center capitalize text-foreground">
              {view === "mes" && format(cursor, "MMMM yyyy", { locale: pt })}
              {view === "semana" && `Semana de ${format(startOfWeek(cursor, { weekStartsOn: 1 }), "dd/MM", { locale: pt })}`}
              {view === "dia" && format(cursor, "dd/MM/yyyy", { locale: pt })}
            </span>
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => shift(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="mt-6">
        {view === "mes" && renderMonth()}
        {view === "semana" && renderRange(
          Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(cursor, { weekStartsOn: 1 }), i))
        )}
        {view === "dia" && renderRange([cursor])}
      </div>

      {/* Painel de detalhe */}
      {selectedEvent && (
        <EventoDetalhe event={selectedEvent} onClose={() => setSelectedEvent(null)} />
      )}
    </div>
  );
};

export default AdminCalendario;
