const Privacidade = () => (
  <section className="pt-32 pb-20">
    <div className="container max-w-3xl">
      <h1 className="font-display text-5xl mb-6">Política de Privacidade</h1>
      <p className="text-sm text-muted-foreground mb-8">Última atualização: {new Date().toLocaleDateString("pt-PT")}</p>

      <div className="space-y-6 text-muted-foreground leading-relaxed">
        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">1. Responsável pelo tratamento</h2>
          <p>Miminhos Criativos, sediada na Madeira, Portugal. Para qualquer questão relativa à proteção dos seus dados pessoais pode contactar-nos por: <a href="mailto:info@miminhoscriativos.pt" className="text-primary hover:underline">info@miminhoscriativos.pt</a> · <a href="mailto:site.miminhoscriativos@gmail.com" className="text-primary hover:underline">site.miminhoscriativos@gmail.com</a> · 926 992 352.</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">2. Dados recolhidos</h2>
          <ul className="list-disc pl-6 space-y-1">
            <li>Dados de identificação e contacto: nome, email, telefone.</li>
            <li>Dados sobre o evento: tipo, data, local, número de convidados, preferências.</li>
            <li>Dados de utilização do site (cookies — consultar Política de Cookies).</li>
          </ul>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">3. Finalidades e fundamento</h2>
          <ul className="list-disc pl-6 space-y-1">
            <li>Resposta a pedidos de orçamento e prestação dos serviços contratados — execução de contrato.</li>
            <li>Criação e gestão de conta de cliente — execução de contrato.</li>
            <li>Cumprimento de obrigações legais (ex.: faturação) — obrigação legal.</li>
            <li>Comunicações de marketing — apenas mediante consentimento, revogável a qualquer momento.</li>
          </ul>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">4. Conservação</h2>
          <p>Os dados são conservados pelo período necessário ao cumprimento das finalidades, e durante os prazos legais aplicáveis (nomeadamente fiscais — 10 anos).</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">5. Partilha</h2>
          <p>Os seus dados não são vendidos. Poderão ser partilhados com prestadores de serviços contratados (ex.: alojamento, ferramentas de gestão), sempre sob obrigação de confidencialidade e nos termos do RGPD.</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">6. Os seus direitos</h2>
          <p>Tem direito de acesso, retificação, apagamento, limitação, oposição e portabilidade. Pode exercê-los enviando um pedido para info@miminhoscriativos.pt. Tem ainda o direito de apresentar reclamação à <strong>CNPD — Comissão Nacional de Proteção de Dados</strong> (<a href="https://www.cnpd.pt" target="_blank" rel="noreferrer" className="text-primary hover:underline">www.cnpd.pt</a>).</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">7. Segurança</h2>
          <p>Adotamos medidas técnicas e organizativas adequadas para proteger os seus dados, incluindo encriptação, autenticação e controlo de acessos.</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">8. Enquadramento legal</h2>
          <p>Esta política cumpre o Regulamento (UE) 2016/679 (RGPD) e a Lei n.º 58/2019, de 8 de agosto.</p>
        </div>
      </div>
    </div>
  </section>
);
export default Privacidade;
