const Termos = () => (
  <section className="pt-32 pb-20">
    <div className="container max-w-3xl">
      <h1 className="font-display text-5xl mb-6">Termos e Condições</h1>
      <p className="text-sm text-muted-foreground mb-8">Última atualização: {new Date().toLocaleDateString("pt-PT")}</p>

      <div className="space-y-6 text-muted-foreground leading-relaxed">
        <p>
          Ao aceder e utilizar este website, o utilizador concorda com os presentes Termos e Condições. Caso não concorde com estes termos, solicitamos que não continue a utilizar o site.
        </p>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">1. Identificação do Responsável pelo Site</h2>
          <p>
            <strong>Nome da Empresa:</strong> Miminhos Criativos
          </p>
          <p>
            <strong>Contacto:</strong>{" "}
            <a href="mailto:site.miminhoscriativos@gmail.com" className="text-primary hover:underline">
              site.miminhoscriativos@gmail.com
            </a>
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">2. Objeto e Âmbito de Aplicação</h2>
          <p>
            Os presentes Termos e Condições aplicam-se à utilização do site e regulam a relação entre o utilizador e a Miminhos Criativos. Estes Termos e Condições podem ser alterados a qualquer momento, sem aviso prévio, pelo que o utilizador deverá consultar periodicamente esta página para verificar eventuais atualizações.
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">3. Responsabilidade e Obrigações do Utilizador</h2>
          <p>
            <strong>3.1 Utilização do Site:</strong> O utilizador compromete-se a utilizar este site de forma responsável, sem violar os direitos da Miminhos Criativos ou de terceiros, comprometendo-se a não utilizar o site para atividades ilegais, difamatórias, invasivas de privacidade ou que possam causar danos à Miminhos Criativos ou a outros utilizadores.
          </p>
          <p>
            <strong>3.2 Conteúdo do Utilizador:</strong> Todo o conteúdo submetido pelo utilizador ao site, incluindo, mas não se limitando a, comentários, opiniões ou sugestões, será considerado não confidencial e poderá ser utilizado pela Miminhos Criativos de acordo com as disposições legais aplicáveis.
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">4. Direitos de Propriedade Intelectual</h2>
          <p>
            Todos os conteúdos do site, incluindo texto, gráficos, logótipos, ícones, imagens, clipes de áudio e software, são propriedade exclusiva da Miminhos Criativos ou dos seus parceiros e estão protegidos por leis de direitos de autor, marcas registadas e outras legislações de propriedade intelectual. A utilização não autorizada desses conteúdos poderá resultar em sanções civis e criminais, de acordo com a legislação em vigor.
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">5. Limitação de Responsabilidade</h2>
          <p>
            <strong>5.1 Exatidão da Informação:</strong> A Miminhos Criativos envida todos os esforços para assegurar a exatidão e atualidade das informações contidas no site. No entanto, não garante a sua exatidão, completude ou atualidade em todos os momentos.
          </p>
          <p>
            <strong>5.2 Disponibilidade do Site:</strong> A Miminhos Criativos não garante que o site funcione de forma ininterrupta ou livre de erros, reservando-se o direito de suspender temporariamente o acesso ao site para manutenção ou atualização.
          </p>
          <p>
            <strong>5.3 Danos Resultantes do Uso do Site:</strong> A Miminhos Criativos não será responsável por quaisquer danos diretos, indiretos ou consequentes resultantes da utilização ou incapacidade de utilização do site ou de qualquer conteúdo ou material do mesmo, salvo se resultarem de dolo ou culpa grave.
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">6. Política de Privacidade</h2>
          <p>
            A recolha e tratamento de dados pessoais dos utilizadores, caso aplicável, é feita em conformidade com a legislação em vigor e a nossa{" "}
            <a href="/privacidade" className="text-primary hover:underline">Política de Privacidade</a>. Recomendamos que a consulte. A Miminhos Criativos compromete-se a proteger a privacidade e a segurança dos dados dos seus utilizadores, conforme disposto pelo Regulamento Geral sobre a Proteção de Dados (RGPD).
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">7. Links para Sites Externos</h2>
          <p>
            O nosso site pode conter links para outros websites que não são operados ou controlados pela Miminhos Criativos. A Miminhos Criativos não se responsabiliza pelo conteúdo, políticas de privacidade ou práticas de quaisquer sites de terceiros.
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">8. Alteração dos Termos e Condições</h2>
          <p>
            A Miminhos Criativos reserva-se o direito de, a qualquer momento e sem aviso prévio, alterar os presentes Termos e Condições. A versão mais atual será sempre a aplicável e estará disponível para consulta no site.
          </p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">9. Lei Aplicável e Foro Competente</h2>
          <p>
            Os presentes Termos e Condições são regidos pela lei portuguesa. Em caso de litígio, o utilizador concorda em submeter-se à jurisdição exclusiva dos tribunais do distrito da Madeira, com renúncia expressa a qualquer outro.
          </p>
        </div>
      </div>
    </div>
  </section>
);

export default Termos;
