const Cookies = () => (
  <section className="pt-32 pb-20">
    <div className="container max-w-3xl">
      <h1 className="font-display text-5xl mb-6">Política de Cookies</h1>
      <p className="text-sm text-muted-foreground mb-8">Última atualização: {new Date().toLocaleDateString("pt-PT")}</p>

      <div className="space-y-6 text-muted-foreground leading-relaxed">
        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">1. O que são cookies?</h2>
          <p>Cookies são pequenos ficheiros de texto que são guardados no seu dispositivo (computador, tablet ou telemóvel) quando visita um site. São amplamente utilizados para fazer com que os sites funcionem ou funcionem de forma mais eficiente.</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">2. Tipos de cookies utilizados</h2>
          <ul className="list-disc pl-6 space-y-2">
            <li><strong>Cookies estritamente necessários:</strong> essenciais ao funcionamento do site, permitindo a navegação e a utilização das suas funcionalidades (como a área de cliente).</li>
            <li><strong>Cookies de funcionalidade:</strong> permitem que o site recorde as suas escolhas (idioma, preferências) para lhe oferecer uma experiência personalizada.</li>
            <li><strong>Cookies analíticos:</strong> recolhem informação sobre a utilização do site (páginas visitadas, tempo de permanência) de forma anónima, para nos permitir melhorar.</li>
          </ul>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">3. Gestão de cookies</h2>
          <p>Pode aceitar ou recusar a utilização de cookies através do banner apresentado na sua primeira visita. Pode ainda, em qualquer momento, configurar o seu navegador para bloquear ou eliminar cookies. Note que a desativação de alguns cookies poderá afetar o funcionamento do site.</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">4. Enquadramento legal</h2>
          <p>Esta política cumpre o disposto na Lei n.º 41/2004 (Lei das Comunicações Eletrónicas), no Regulamento Geral de Proteção de Dados (RGPD - Regulamento UE 2016/679) e nas orientações da CNPD - Comissão Nacional de Proteção de Dados.</p>
        </div>

        <div>
          <h2 className="font-display text-2xl text-foreground mb-2">5. Contacto</h2>
          <p>Para questões sobre esta política contacte pelo WhatsApp 926 992 352 ou por email <a href="mailto:site.miminhoscriativos@gmail.com" className="text-primary hover:underline">site.miminhoscriativos@gmail.com</a>.</p>
        </div>
      </div>
    </div>
  </section>
);
export default Cookies;
