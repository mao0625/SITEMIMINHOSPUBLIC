import { Phone, Mail, MapPin, Instagram, Facebook, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

const SITE_EMAIL = "site.miminhoscriativos@gmail.com";

const Contacto = () => {
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Mensagem enviada! Entraremos em contacto em breve. 💛");
    (e.target as HTMLFormElement).reset();
  };

  return (
    <>
      {/* Hero — quiet, type-led, generous spacing */}
      <section className="pt-40 pb-20 bg-gradient-champagne text-center">
        <div className="container">
          <p className="font-script text-2xl text-primary mb-3 animate-fade-up" style={{ animationDelay: "0.05s" }}>
            Vamos conversar
          </p>
          <h1 className="font-display text-6xl md:text-8xl tracking-tight animate-fade-up" style={{ animationDelay: "0.15s" }}>
            Contacto
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto mt-5 text-base md:text-lg animate-fade-up" style={{ animationDelay: "0.25s" }}>
            Conte-nos a sua ideia. Respondemos com todo o gosto.
          </p>
        </div>
      </section>

      {/* Main content */}
      <section className="py-20 md:py-28">
        <div className="container grid lg:grid-cols-[1.1fr_1fr] gap-12 lg:gap-16 items-start">

          {/* Form */}
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-primary font-semibold mb-3">
              Mensagem
            </p>
            <h2 className="font-display text-3xl md:text-4xl mb-8">Envie-nos uma mensagem</h2>

            <form onSubmit={onSubmit} className="space-y-5 bg-card p-8 rounded-2xl shadow-soft border border-border">
              <div className="space-y-1.5">
                <Label>Nome *</Label>
                <Input required className="h-11 rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label>Telefone</Label>
                <Input className="h-11 rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label>Mensagem *</Label>
                <Textarea rows={5} required className="rounded-xl resize-none" />
              </div>
              <Button type="submit" className="bg-gradient-gold w-full h-12 rounded-xl text-base shadow-gold">
                Enviar Mensagem
              </Button>
            </form>
          </div>

          {/* Contacts + Map */}
          <div className="space-y-6 lg:pt-[52px]">

            {/* Contacts card */}
            <div className="bg-dark text-white p-8 rounded-2xl">
              <p className="text-xs uppercase tracking-[0.25em] text-primary/70 font-semibold mb-2">
                Diga olá
              </p>
              <h3 className="font-display text-2xl md:text-3xl mb-6">Contactos</h3>

              <ul className="space-y-4 text-sm">
                <li className="flex items-center gap-4">
                  <span className="flex-shrink-0 h-10 w-10 rounded-full bg-white/5 flex items-center justify-center">
                    <Phone className="h-4 w-4 text-primary" />
                  </span>
                  <span className="text-base">926 992 352</span>
                </li>
                <li className="flex items-center gap-4">
                  <span className="flex-shrink-0 h-10 w-10 rounded-full bg-white/5 flex items-center justify-center">
                    <Mail className="h-4 w-4 text-primary" />
                  </span>
                  <a href={`mailto:${SITE_EMAIL}`} className="hover:text-primary transition-smooth text-base break-all">
                    {SITE_EMAIL}
                  </a>
                </li>
                <li className="flex items-center gap-4">
                  <span className="flex-shrink-0 h-10 w-10 rounded-full bg-white/5 flex items-center justify-center">
                    <MapPin className="h-4 w-4 text-primary" />
                  </span>
                  <span className="text-base">Madeira, Portugal</span>
                </li>
              </ul>

              <div className="flex gap-3 mt-8">
                <a
                  href="https://wa.me/351926992352"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-[#25D366] hover:opacity-90 text-white px-4 py-3 rounded-xl flex items-center justify-center gap-2 transition-smooth font-medium"
                >
                  <MessageCircle className="h-4 w-4" />
                  WhatsApp
                </a>
                <a
                  href="https://instagram.com/miminhos.criativos"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-12 w-12 bg-white/5 hover:bg-primary rounded-xl flex items-center justify-center transition-smooth"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="https://facebook.com/miminhoscriativos"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="h-12 w-12 bg-white/5 hover:bg-primary rounded-xl flex items-center justify-center transition-smooth"
                >
                  <Facebook className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Map */}
            <div className="rounded-2xl overflow-hidden shadow-soft border border-border aspect-video">
              <iframe
                title="Mapa Madeira"
                src="https://maps.google.com/maps?q=Madeira%2C%20Portugal&t=&z=10&ie=UTF8&iwloc=&output=embed"
                className="w-full h-full border-0"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contacto;
