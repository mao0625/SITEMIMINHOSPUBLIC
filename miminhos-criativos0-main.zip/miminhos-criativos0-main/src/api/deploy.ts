// API Route for triggering Lovable deployment
// Usage: POST /api/deploy
// Body: { pageId: string }

export async function POST(request: Request) {
  try {
    const { pageId } = await request.json();

    if (!pageId) {
      return new Response(
        JSON.stringify({ error: 'pageId is required' }),
        { status: 400 }
      );
    }

    // Trigger Lovable deployment
    const lovableResponse = await fetch(
      `https://api.lovable.dev/deploy`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.VITE_LOVABLE_DEPLOY_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          projectId: process.env.VITE_LOVABLE_PROJECT_ID,
          message: `CMS: Page ${pageId} updated and deployed`,
        }),
      }
    );

    if (!lovableResponse.ok) {
      throw new Error(`Lovable API error: ${lovableResponse.statusText}`);
    }

    const result = await lovableResponse.json();

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Deployment triggered successfully',
        deploymentId: result.id,
      }),
      { status: 200 }
    );
  } catch (error) {
    console.error('Deployment error:', error);
    return new Response(
      JSON.stringify({
        error: 'Deployment failed',
        details: error instanceof Error ? error.message : 'Unknown error',
      }),
      { status: 500 }
    );
  }
}
