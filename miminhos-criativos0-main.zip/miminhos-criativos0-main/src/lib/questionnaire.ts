export const QUESTIONNAIRE_SECTIONS = [
  {
    id: "instrucoes",
    title: "Instrução",
    fields: [
      { id: "instrucao_texto", label: "Por favor, ao longo do questionário seja breve nas respostas. As respostas que não souber, deixe em branco.", type: "static" },
    ],
  },
  {
    id: "geral",
    title: "Secção 1 — Geral",
    fields: [
      { id: "lugar_festa", label: "Lugar da festa", type: "text" },
      { id: "hora", label: "Hora", type: "time" },
      { id: "numero_convidados", label: "Número de convidados", type: "number" },
      { id: "quantas_mesas", label: "Quantas mesas de convidados?", type: "number" },
      { id: "numero_honra", label: "Número de pessoas na mesa de honra", type: "number" },
      { id: "mesas_quadrado", label: "Mesas em quadrado?", type: "toggle", options: ["Sim", "Não"] },
      { id: "mesas_redondo", label: "Mesas em redondo?", type: "toggle", options: ["Sim", "Não"] },
      { id: "obs_geral", label: "Observações do geral", type: "textarea" },
    ],
  },
  {
    id: "entrada",
    title: "Secção 2 — Entrada da Festa",
    fields: [
      { id: "cavalete_distribuicao", label: "Cavalete com distribuição de mesas?", type: "select", options: ["Sim", "Não"] },
      { id: "obs_entrada", label: "Observações da entrada da festa", type: "textarea" },
    ],
  },
  {
    id: "mesa_bolo",
    title: "Secção 3 — Mesa do Bolo",
    fields: [
      { id: "cilindros_brancos", label: "Cilindros brancos?", type: "select", options: ["Sim", "Não"] },
      { id: "mesa_dourada_vidro", label: "Mesa dourada c/ vidro?", type: "select", options: ["Sim", "Não"] },
      { id: "mesa_dourada_retangulo", label: "Mesa dourada em retângulo?", type: "select", options: ["Sim", "Não"] },
      { id: "mesa_normal_toalha", label: "Mesa normal com toalha branca?", type: "select", options: ["Sim", "Não"] },
      { id: "toalha_bordado_madeira", label: "Toalha bordado madeira?", type: "select", options: ["Sim", "Não"] },
      { id: "estrutura_arco", label: "Estrutura de arco?", type: "select", options: ["Sim", "Não"] },
      { id: "estrutura_arco_cor", label: "Estrutura de arco — cor:", type: "radio", options: ["Dourado", "Branco"] },
      { id: "estrutura_arco_decoracao", label: "A estrutura de arco vai:", type: "checkbox", options: ["Sem nada", "Com balões", "Com tecido", "Com flores"] },
      { id: "estrutura_base_bolo", label: "Estrutura/base para o bolo?", type: "select", options: ["Sim", "Não"] },
      { id: "base_bolo_material", label: "Base do bolo — material:", type: "radio", options: ["Branco", "Dourado", "Transparente", "Madeira"] },
      { id: "ramo_mesa_bolo", label: "Ramo para a mesa do bolo?", type: "select", options: ["Sim", "Não"] },
      { id: "ramo_mesa_bolo_direcao", label: "Ramo na vertical ou horizontal?", type: "radio", options: ["Vertical", "Horizontal"] },
      { id: "baloes", label: "Balões?", type: "select", options: ["Sim", "Não"] },
      { id: "cor_baloes", label: "Cor dos balões", type: "text" },
      { id: "tule_mesa_bolo", label: "Tule para a mesa do bolo?", type: "select", options: ["Sim", "Não"] },
      { id: "cor_tule_mesa_bolo", label: "Cor do tule", type: "text" },
      { id: "aluguer_material_mesa_bolo", label: "Aluguer de material que pretende", type: "textarea" },
      { id: "obs_mesa_bolo", label: "Observações mesa do bolo", type: "textarea" },
    ],
  },
  {
    id: "mesa_convidados",
    title: "Secção 4 — Mesa dos Convidados",
    fields: [
      { id: "ramo_mesa_convidados", label: "Ramo para a mesa dos convidados?", type: "select", options: ["Sim", "Não"] },
      { id: "tamanho_ramo_convidados", label: "Tamanho do ramo", type: "radio", options: ["Pequeno", "Médio", "Grande"] },
      { id: "numero_flores_convidados", label: "Número de flores para esse ramo", type: "number" },
      { id: "tule_convidados", label: "Tule?", type: "select", options: ["Sim", "Não"] },
      { id: "cor_tule_convidados", label: "Cor do tule", type: "text" },
      { id: "marcador_mesa_convidados", label: "Marcador de mesa?", type: "select", options: ["Sim", "Não"] },
      { id: "aluguer_material_convidados", label: "Aluguer de material", type: "textarea" },
      { id: "obs_mesa_convidados", label: "Observações mesa dos convidados", type: "textarea" },
    ],
  },
  {
    id: "mesa_honra",
    title: "Secção 5 — Mesa de Honra",
    fields: [
      { id: "ramo_mesa_honra", label: "Ramo para a mesa de honra?", type: "select", options: ["Sim", "Não"] },
      { id: "tamanho_ramo_honra", label: "Tamanho do ramo", type: "radio", options: ["Pequeno", "Médio", "Grande"] },
      { id: "ramo_mesa_honra_direcao", label: "Ramo na vertical ou horizontal?", type: "radio", options: ["Vertical", "Horizontal"] },
      { id: "numero_flores_honra", label: "Número de flores para esse ramo", type: "number" },
      { id: "tule_honra", label: "Tule?", type: "select", options: ["Sim", "Não"] },
      { id: "cor_tule_honra", label: "Cor do tule", type: "text" },
      { id: "marcador_mesa_honra", label: "Marcador de mesa?", type: "select", options: ["Sim", "Não"] },
      { id: "aluguer_material_honra", label: "Aluguer de material", type: "textarea" },
    ],
  },
  {
    id: "flores",
    title: "Secção 6 — Flores",
    fields: [
      { id: "rosas", label: "Rosas?", type: "select", options: ["Sim", "Não"] },
      { id: "gerberas", label: "Gérberas?", type: "select", options: ["Sim", "Não"] },
      { id: "margaridas", label: "Margaridas?", type: "select", options: ["Sim", "Não"] },
      { id: "cor_flores", label: "Cor das flores", type: "text" },
      { id: "vivais", label: "Vivais?", type: "select", options: ["Sim", "Não"] },
      { id: "eucaliptos", label: "Eucaliptos?", type: "select", options: ["Sim", "Não"] },
      { id: "eiras", label: "Eiras?", type: "select", options: ["Sim", "Não"] },
      { id: "outro_tipo_flores", label: "Outro tipo de flores?", type: "text" },
      { id: "obs_flores", label: "Observações sobre flores", type: "textarea" },
    ],
  },
  {
    id: "contacto",
    title: "Secção 7 — Dados de Contacto",
    fields: [
      { id: "nome_completo", label: "Nome completo", type: "text", required: true },
      { id: "email", label: "E-mail", type: "email", required: true },
      { id: "telefone", label: "Telefone", type: "tel", required: true },
      { id: "data_evento", label: "Data do evento", type: "date", required: true },
      { id: "obs_decoracao_geral", label: "Observações gerais de toda a decoração", type: "textarea" },
    ],
  },
] as const;

export type QField = { 
  id: string; 
  label: string; 
  type: string; 
  options?: readonly string[];
  required?: boolean;
};
