import { Page, PageBlock } from '@/types/pageBuilder';

class PageBuilderService {
  private baseUrl = '/api/page-builder';

  async getPageBySlug(slug: string): Promise<Page> {
    const response = await fetch(`${this.baseUrl}/pages/${slug}`);
    if (!response.ok) throw new Error('Failed to fetch page');
    return response.json();
  }

  async updatePage(pageId: string, data: Partial<Page>): Promise<Page> {
    const response = await fetch(`${this.baseUrl}/pages/${pageId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update page');
    return response.json();
  }

  async createBlock(data: Partial<PageBlock>): Promise<PageBlock> {
    const response = await fetch(`${this.baseUrl}/blocks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to create block');
    return response.json();
  }

  async updateBlock(blockId: string, data: Partial<PageBlock>): Promise<PageBlock> {
    const response = await fetch(`${this.baseUrl}/blocks/${blockId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('Failed to update block');
    return response.json();
  }

  async deleteBlock(blockId: string): Promise<void> {
    const response = await fetch(`${this.baseUrl}/blocks/${blockId}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete block');
  }

  async reorderBlocks(pageId: string, blocks: PageBlock[]): Promise<void> {
    const response = await fetch(`${this.baseUrl}/pages/${pageId}/reorder`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ blocks }),
    });
    if (!response.ok) throw new Error('Failed to reorder blocks');
  }

  async publishPage(pageId: string): Promise<void> {
    const response = await fetch(`${this.baseUrl}/pages/${pageId}/publish`, {
      method: 'POST',
    });
    if (!response.ok) throw new Error('Failed to publish page');
  }

  async triggerDeploy(pageId: string): Promise<void> {
    const response = await fetch(`${this.baseUrl}/pages/${pageId}/deploy`, {
      method: 'POST',
    });
    if (!response.ok) throw new Error('Failed to trigger deploy');
  }
}

export const pageBuilderService = new PageBuilderService();
