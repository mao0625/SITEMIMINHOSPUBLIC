/**
 * Sistema completo de sincronização de pagamentos POS
 * Atualiza estado_pagamento em events e questionnaires em tempo real
 * com listeners Realtime do Supabase
 */

import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

// Mapeamento de estados POS para eventos/questionários
export const PAYMENT_STATUS_MAP = {
  pago: "pago",
  por_pagar: "por_pagar",
  em_pagamento: "em_pagamento",
  nao_realizado: "nao_atribuido",
  nao_atribuido: "nao_atribuido",
  cancelado: "cancelado",
} as const;

type POSPaymentStatus = keyof typeof PAYMENT_STATUS_MAP;

/**
 * Mapeia um status POS para o formato de evento/questionário
 */
export const mapPosStatusToEventStatus = (
  posStatus: string
): string => {
  return (
    PAYMENT_STATUS_MAP[posStatus as POSPaymentStatus] || "por_pagar"
  );
};

/**
 * Sincroniza o estado de pagamento de uma operação POS
 * para seus eventos e questionários associados
 */
export const syncPaymentStatusFromPOS = async (operation: {
  id: string;
  event_id?: string | null;
  questionnaire_id?: string | null;
  payment_status: string;
  client_id: string;
  created_at: string;
}): Promise<{ success: boolean; updated: number; error?: string }> => {
  const mappedStatus = mapPosStatusToEventStatus(
    operation.payment_status
  );
  const timestamp = new Date().toISOString();
  let updatedCount = 0;

  try {
    // Atualizar evento se existir
    if (operation.event_id) {
      const { error: eventError } = await supabase
        .from("events")
        .update({
          estado_pagamento: mappedStatus,
          updated_at: timestamp,
        })
        .eq("id", operation.event_id);

      if (eventError) throw eventError;
      updatedCount++;
    }

    // Atualizar questionário se existir
    if (operation.questionnaire_id) {
      const { error: questError } = await supabase
        .from("questionnaires")
        .update({
          estado_pagamento: mappedStatus,
          updated_at: timestamp,
        })
        .eq("id", operation.questionnaire_id);

      if (questError) throw questError;
      updatedCount++;
    }

    return { success: true, updated: updatedCount };
  } catch (error) {
    const errorMsg =
      error instanceof Error ? error.message : "Erro desconhecido";
    console.error("❌ Erro ao sincronizar pagamento:", errorMsg);
    return {
      success: false,
      updated: 0,
      error: errorMsg,
    };
  }
};

/**
 * Sincroniza múltiplas operações POS em lote
 */
export const syncMultiplePaymentStatuses = async (
  operationIds: string[]
): Promise<{ total: number; success: number; failed: number }> => {
  const results = await Promise.allSettled(
    operationIds.map(async (id) => {
      const { data: operation } = await supabase
        .from("pos_operations")
        .select("*")
        .eq("id", id)
        .single();

      if (operation) {
        return syncPaymentStatusFromPOS(operation);
      }
      throw new Error(`Operação ${id} não encontrada`);
    })
  );

  const succeeded = results.filter((r) => r.status === "fulfilled").length;
  const failed = results.filter((r) => r.status === "rejected").length;

  return {
    total: operationIds.length,
    success: succeeded,
    failed,
  };
};

/**
 * Busca evento ou questionário mais recente não pago para um cliente
 * Usado quando uma operação POS não tem referência explícita
 */
export const findRelatedEventOrQuestionnaire = async (
  clientId: string,
  posCreatedAt: string
): Promise<{
  type: "event" | "questionnaire";
  id: string;
} | null> => {
  const operationDate = new Date(posCreatedAt);
  const dayBefore = new Date(
    operationDate.getTime() - 24 * 60 * 60 * 1000
  ).toISOString();
  const dayAfter = new Date(
    operationDate.getTime() + 24 * 60 * 60 * 1000
  ).toISOString();

  // Procurar evento confirmado não pago próximo
  const { data: events } = await supabase
    .from("events")
    .select("id")
    .eq("client_id", clientId)
    .eq("status", "confirmado")
    .in("estado_pagamento", ["null", "por_pagar"])
    .gte("event_date", dayBefore)
    .lte("event_date", dayAfter)
    .order("event_date", { ascending: false })
    .limit(1);

  if (events && events.length > 0) {
    return { type: "event", id: events[0].id };
  }

  // Procurar questionário aprovado não pago
  const { data: questionnaires } = await supabase
    .from("questionnaires")
    .select("id")
    .eq("client_id", clientId)
    .eq("status", "aprovado")
    .in("estado_pagamento", ["null", "por_pagar"])
    .gte("created_at", dayBefore)
    .lte("created_at", dayAfter)
    .order("created_at", { ascending: false })
    .limit(1);

  if (questionnaires && questionnaires.length > 0) {
    return { type: "questionnaire", id: questionnaires[0].id };
  }

  return null;
};

/**
 * Listener em tempo real para atualizações de pagamento POS
 * Sincroniza automaticamente quando um pagamento é alterado
 */
export const setupPaymentSyncListener = (
  onSync?: (
    operationId: string,
    result: Awaited<
      ReturnType<typeof syncPaymentStatusFromPOS>
    >
  ) => void
) => {
  const subscription = supabase
    .channel("pos-payments-sync")
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "pos_operations",
      },
      async (payload) => {
        const operation = payload.new;

        // Sincronizar pagamento
        const result = await syncPaymentStatusFromPOS(operation as any);

        // Callback opcional
        if (onSync) {
          onSync(operation.id, result);
        }

        // Log
        if (result.success) {
          console.log(
            `✅ Pagamento sincronizado: ${operation.operation_number}`
          );
        } else {
          console.error(
            `❌ Erro na sincronização: ${result.error}`
          );
        }
      }
    )
    .subscribe((status) => {
      if (status === "SUBSCRIBED") {
        console.log("🔄 Listener de pagamentos ativo");
      } else if (status === "CLOSED") {
        console.log("⛔ Listener de pagamentos desconectado");
      }
    });

  return () => {
    subscription.unsubscribe();
  };
};

/**
 * Listener em tempo real para alterações de eventos/questionários
 * Notifica quando um pagamento foi sincronizado
 */
export const setupPaymentNotificationListener = (
  clientId: string,
  onEventUpdate?: (event: any) => void,
  onQuestionnaireUpdate?: (questionnaire: any) => void
) => {
  const eventSub = supabase
    .channel(`client-payments:${clientId}:events`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "events",
        filter: `client_id=eq.${clientId}`,
      },
      (payload) => {
        if (onEventUpdate) {
          onEventUpdate(payload.new);
        }
      }
    )
    .subscribe();

  const questSub = supabase
    .channel(`client-payments:${clientId}:questionnaires`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "questionnaires",
        filter: `client_id=eq.${clientId}`,
      },
      (payload) => {
        if (onQuestionnaireUpdate) {
          onQuestionnaireUpdate(payload.new);
        }
      }
    )
    .subscribe();

  return () => {
    eventSub.unsubscribe();
    questSub.unsubscribe();
  };
};

/**
 * Sincroniza todos os pagamentos pendentes (útil para recuperação)
 */
export const syncAllPaymentStatuses = async (): Promise<{
  total: number;
  succeeded: number;
  failed: number;
}> => {
  try {
    const { data: operations, error } = await supabase
      .from("pos_operations")
      .select("*")
      .neq("payment_status", "nao_atribuido")
      .order("created_at", { ascending: false });

    if (error) throw error;
    if (!operations || operations.length === 0) {
      return { total: 0, succeeded: 0, failed: 0 };
    }

    const results = await Promise.allSettled(
      operations.map((op) => syncPaymentStatusFromPOS(op))
    );

    const succeeded = results.filter(
      (r) => r.status === "fulfilled" && r.value?.success
    ).length;
    const failed = results.length - succeeded;

    console.log(
      `📊 Sincronização em lote: ${succeeded}/${operations.length} bem-sucedidas`
    );

    return {
      total: operations.length,
      succeeded,
      failed,
    };
  } catch (error) {
    console.error("❌ Erro ao sincronizar pagamentos:", error);
    return { total: 0, succeeded: 0, failed: 0 };
  }
};

/**
 * Valida e sincroniza um pagamento específico
 * Usado quando alterando manualmente o estado
 */
export const validateAndSyncPayment = async (
  operationId: string
): Promise<{ valid: boolean; message: string }> => {
  try {
    const { data: operation, error } = await supabase
      .from("pos_operations")
      .select("*")
      .eq("id", operationId)
      .single();

    if (error || !operation) {
      return { valid: false, message: "Operação não encontrada" };
    }

    // Validações
    if (!operation.payment_status) {
      return { valid: false, message: "Estado de pagamento inválido" };
    }

    // Sincronizar
    const result = await syncPaymentStatusFromPOS(operation);

    if (!result.success) {
      return {
        valid: false,
        message: result.error || "Erro ao sincronizar",
      };
    }

    return {
      valid: true,
      message: `Pagamento sincronizado com sucesso (${result.updated} registos atualizados)`,
    };
  } catch (error) {
    const msg =
      error instanceof Error ? error.message : "Erro desconhecido";
    return { valid: false, message: msg };
  }
};
