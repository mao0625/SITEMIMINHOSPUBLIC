/**
 * Sistema de sincronização de itens pendentes no POS
 * Carrega eventos e orçamentos por pagar quando cliente é selecionado
 */

import { supabase } from "@/integrations/supabase/client";

export interface PendingItem {
  id: string;
  type: "event" | "questionnaire";
  title: string;
  reference: string;
  total: number;
  payment_status: string;
  event_date?: string;
}

/**
 * Carrega itens pendentes (por pagar ou em pagamento) de um cliente
 */
export const loadPendingItems = async (
  clientId: string
): Promise<PendingItem[]> => {
  try {
    const [{ data: events }, { data: questionnaires }] = await Promise.all([
      supabase
        .from("events")
        .select("id, title, event_date, estado_pagamento, budget")
        .eq("client_id", clientId)
        .in("estado_pagamento", ["por_pagar", "em_pagamento"])
        .order("event_date", { ascending: false }),
      supabase
        .from("questionnaires")
        .select("id, reference_number, estado_pagamento, budget_value, orcamento")
        .eq("client_id", clientId)
        .in("estado_pagamento", ["por_pagar", "em_pagamento"])
        .order("created_at", { ascending: false }),
    ]);

    const pendingItems: PendingItem[] = [];

    // Adicionar eventos pendentes
    if (events) {
      pendingItems.push(
        ...events.map((e: any) => ({
          id: e.id,
          type: "event" as const,
          title: e.title,
          reference: `Evento ${e.event_date ? new Date(e.event_date).toLocaleDateString("pt-PT") : ""}`,
          total: Number(e.budget) || 0,
          payment_status: e.estado_pagamento,
          event_date: e.event_date,
        }))
      );
    }

    // Adicionar questionários pendentes
    if (questionnaires) {
      pendingItems.push(
        ...questionnaires.map((q: any) => {
          const orc = typeof q.orcamento === "string" ? JSON.parse(q.orcamento) : q.orcamento;
          return {
            id: q.id,
            type: "questionnaire" as const,
            title: q.reference_number,
            reference: q.reference_number,
            total: orc?.total || Number(q.budget_value) || 0,
            payment_status: q.estado_pagamento,
          };
        })
      );
    }

    return pendingItems;
  } catch (error) {
    console.error("Erro ao carregar itens pendentes:", error);
    return [];
  }
};

/**
 * Cria listeners Realtime para atualizar automaticamente quando o pagamento muda
 */
export const subscribeToClientPayments = (
  clientId: string,
  onUpdate: (items: PendingItem[]) => void
) => {
  const channel = supabase
    .channel(`client_payments_${clientId}`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "events",
        filter: `client_id=eq.${clientId}`,
      },
      async () => {
        const items = await loadPendingItems(clientId);
        onUpdate(items);
      }
    )
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "questionnaires",
        filter: `client_id=eq.${clientId}`,
      },
      async () => {
        const items = await loadPendingItems(clientId);
        onUpdate(items);
      }
    )
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "pos_operations",
        filter: `client_id=eq.${clientId}`,
      },
      async () => {
        const items = await loadPendingItems(clientId);
        onUpdate(items);
      }
    )
    .subscribe();

  return channel;
};
