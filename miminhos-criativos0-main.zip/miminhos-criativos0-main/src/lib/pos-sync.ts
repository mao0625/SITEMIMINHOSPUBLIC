/**
 * Sincronização entre POS Operations e Eventos/Questionários
 * Mapeia mudanças de pagamento do POS para os registos de eventos e orçamentos
 */
import { supabase } from "@/integrations/supabase/client";

/**
 * Mapeia estados de pagamento do POS para estados de eventos/questionários
 * POS: pago, por_pagar, em_pagamento, nao_realizado, nao_atribuido
 * Events/Questionnaires: pago, por_pagar, em_pagamento, cancelado, nao_atribuido
 */
export const mapPosStatusToEventStatus = (posStatus: string): string => {
  const mapping: Record<string, string> = {
    "pago": "pago",
    "por_pagar": "por_pagar",
    "em_pagamento": "em_pagamento",
    "nao_realizado": "nao_atribuido",
    "nao_atribuido": "nao_atribuido",
  };
  return mapping[posStatus] ?? "por_pagar";
};

/**
 * Sincroniza o estado de pagamento de uma operação POS com o evento/questionnaire associado
 */
export const syncPosPaymentStatus = async (operation: any): Promise<void> => {
  if (!operation) return;

  const mappedStatus = mapPosStatusToEventStatus(operation.payment_status);
  const timestamp = new Date().toISOString();

  try {
    // Se tem evento associado, atualiza o estado de pagamento
    if (operation.event_id) {
      await supabase
        .from("events")
        .update({
          estado_pagamento: mappedStatus,
          updated_at: timestamp,
        })
        .eq("id", operation.event_id);
    }

    // Se tem questionário associado, atualiza o estado de pagamento
    if (operation.questionnaire_id) {
      await supabase
        .from("questionnaires")
        .update({
          estado_pagamento: mappedStatus,
          updated_at: timestamp,
        })
        .eq("id", operation.questionnaire_id);
    }
  } catch (error) {
    console.error("Erro ao sincronizar estado de pagamento:", error);
    throw error;
  }
};

/**
 * Busca a operação POS associada a um evento
 */
export const findPosOperationByEvent = async (eventId: string): Promise<any> => {
  const { data } = await supabase
    .from("pos_operations")
    .select("*")
    .eq("event_id", eventId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return data;
};

/**
 * Busca a operação POS associada a um questionário
 */
export const findPosOperationByQuestionnaire = async (questionnaireId: string): Promise<any> => {
  const { data } = await supabase
    .from("pos_operations")
    .select("*")
    .eq("questionnaire_id", questionnaireId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return data;
};

/**
 * Retorna o estado de pagamento mais recente baseado em operações POS
 * Útil para sincronizar estado quando um evento/questionnaire tem múltiplas operações
 */
export const getLatestPaymentStatusFromPos = async (
  eventId?: string,
  questionnaireId?: string
): Promise<string | null> => {
  let query = supabase.from("pos_operations").select("payment_status");

  if (eventId) {
    query = query.eq("event_id", eventId);
  } else if (questionnaireId) {
    query = query.eq("questionnaire_id", questionnaireId);
  } else {
    return null;
  }

  const { data } = await query.order("created_at", { ascending: false }).limit(1);
  
  if (data && data.length > 0) {
    return mapPosStatusToEventStatus(data[0].payment_status);
  }
  
  return null;
};

/**
 * Sincroniza todos os eventos/questionários com base em operações POS pendentes
 * Executa uma sincronização em lote de todos os pagamentos
 */
export const syncAllPendingPayments = async (): Promise<number> => {
  const { data: operations } = await supabase
    .from("pos_operations")
    .select("*")
    .neq("payment_status", "nao_atribuido");

  if (!operations || operations.length === 0) return 0;

  let syncedCount = 0;

  for (const op of operations) {
    try {
      await syncPosPaymentStatus(op);
      syncedCount++;
    } catch (error) {
      console.error(`Erro ao sincronizar operação ${op.id}:`, error);
    }
  }

  return syncedCount;
};
