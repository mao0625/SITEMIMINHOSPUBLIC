import jsPDF from "jspdf";
import { QUESTIONNAIRE_SECTIONS } from "./questionnaire";

// ─── Logo Miminhos Criativos (embedded) ───────────────────────────────────────
const LOGO_B64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAC0ASwDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDyqTUF8gHepkDLlB/CAfai6KyBfKJ87bwNmDj196wvkyWLEEDnYaX7ayFB53yopA9R/jXBynQbvh3Tr/Xb77DbxZlQZZmcfKM4OP8ACr114RuLO4u1ucXEUFu7wPHjhwN2HB6fKCcd8cGsnwrqp07VBPCxEjNgkTBAfqCMH8a9ZTxFpt5cW9vKYYr64YROoBlYLg7dzKNpxnOc4GTUSck9Ckkzyi88LpcLJdQpLGreUUjQZILH5iAeqgc5Paufv9Gv7Lzmlt5DBHKY/NxhWOeCvqDxyPWvoS40DTr7SpdPdhEtyDskA2E5wQMjqOo5xkGuU8UeF5obttW8ltsSRxIdmzyYkUK5X0OOV9DSjVBxPGpI5IWCzRPGSu4Bhg49a3fA15Haam7ee6M4yEAGJNuTtLHpnpx61sjwo9w1ssrSTxpcptOQGlids8DOQBxyffFYeo2b22tSG0kKlnYRMIwBgdz6DjHA7da1upaEWsdb4kuL2WBTIm3Mgk9NpKj5RjsPU981g3SifcttI5ZBko/OR7HFT6Zff2jpTpertdMoxAwDg5B9sVn6kr2d8kiTMrAAHHT6VKXQd7mfcGZcttLL7jlapSud2CvHqK02jZ0Z5GBG7I59ayskyNn6cGrQmNlctjPOM/hmnl90adCR1JpuxnOB2GTzT7O2nupTHbRmR1XcQPSqEXtD0uXU9Tt7aQSLCxUGRV52kkKfxPGafqvhvVNNu54ZolkEKbneNsqBjPevQ/hzFdRaOILyzaMx5KyjbkIWJK8HOPr0J4qLxpEkyO7zNEkoMUiscEYIwOB1wQeKy53zWL5dDy1CBEQ2cbvy461d0qxnuJFkXyxFC253ZwAADVnWbURabCyNAI0YggOCxyfzPv6ZqtpESyvtaQxo4KFgehPSr6Eo7DRZY2cW00kszSsZJZkOP58Y96j17fdWqeVv2xHDI4yZHY/eJ+mKzb5G0rEkDNIrsI5yV5B6gY9CO9VftzT3U2WXZId0gPqTUJdRk39o3U8YkmSNXt08sJs/g9CP8/pVLVryG9WOVQiTKu1xzycdRUXnvb3OSwIQbD7qOOfwNVpvKJOH6nHv+NUlqBNYnEqhSS5Vtwx0+tdB4XX+z9SWKSBluJZDGwZh/CQ2eOBjOPrVDwparJdG4fngq2DyB/8AqruNNmWXWfstvbt5hCqZCmcgjOQMYyTgk8VMmNEOtXL2FpDK0MM0THfLGJioBzkbc9iP51DJGRZRX13dTXFt525IHUAoG6fN6jaeOnT1qe9s5NRulsxfwtJb5a4KjIPXufTJ47EccVm+Jt1tosFhJFI7KPMLxsSoXJ4PvyM1CGYutXFg1yJNLlmXeoLWzggBuckg8fhUdgz+SHDIskWSS8fCAdaivL2Ke2iVmSV0j+8VIKnPQEdfqarPd7XCnOVxvXPBz/8AWrRLQkvXklm8DwyyAujbkZWAIO0cY9Of0rBkBecRKm0ehbcfzptxMxZsxRHnG4pyafaOLYl5FVwVGE9KpKwjX0OwdgpZ0jXfy2cE+mPT611NrcrY7i1yYjDwdo3Ak89D1/z9K5Wy1EyW7RxL5chbkhucHOc/4VfS0gvfIk3zxmID5iuec8cHrUPzGjevoI7++WO8MsVj5e4ncdrsT1PXovOBWqNMeGGCB7RLqNjkou0Rxr13A/xYHXjp9aXQ/s0QQyXLFY28xDyqkY5zg5bjPb8elQ6rdWcunz/2bp8sSwyhDDFhH8sLu+b6nBxnvWd3sX5jrrVGstfsbSeFra0j3uJs4WQHoxyMbR/hWHfXaahqkw0m7urgGYeUrMShY9COnHsRirJ1NNVa0s4kkvN8Zd8fLsAHGSOvNdJ4R8NQWkEDzMsTsxZgORn6/SnpEW5k6N4Q1S+vN13dRiFEDSyFdyk/3QOMn8h1rrV0TSbNRBcmWeUAEyBtuePQDFWpbwQmS43RpAk20MnGWHQHnGOvJpzTrJiSLTY7hWGQ8hUk1m5NlJJHgNrHNO7JFb/NtONi/L+PamSWN0ZGR7d1ZZFjZiCACfWu8ukOmWo+yWDtb7tuSuVA69epHvWXcPLeo8vlN5jbd6DIBxjGT6/0roUjNo5T7Hdm9NkI2edCQY+4xXT+GtdudFB2Wj2ryI0WSfkPHJwec4OeuPaopI57rUHuysazwyKHdRg5zgse3H65p2oMlzZzB5ThSgPO0k9CMem0D8cUN3BaHovhbVdPmspFutXd7m4n3IfNcsq7QPkB57LkHit86/ZTQXEkV0ZxEQJldCjDAyCpPB64rwGyu7vTnm8pxCOVUsuWK57Z7YrobHxlLFAd10kZmZmcIjBgOcAEccn9KzlSKUj0iFbf7fPcvb2sc0kfktIow2B0JHb+EAdsdTXn+uaVBPPe3e1xd3RxwPlRehCntnkZOORwMVcXxHbJF5qXc2cbN/BIwAWyQOcZxjnuaiu723M07zPF5jReVL5YPQng4ByD1oimgbTOUv8Az7C8SeDPlqmSp6MGJJB7cDH412PhLwVNq7RT6hG0VuybmjDcjPY/hzwea5fUoVuJionAhQKkQD5HT3r1v4Vy2Npo0Nml7l5UAVHuNyHrnAPQ8c05yaWgoq7MC38AW9tFKLuaSZQABEuMgZ5575PGPpXJeLfC9ymqSS6Zas0QgV3UAcsBhsfjXuN9ZKodoGyj8Lk8jHYE+nbNYN/C1rbSorhGZiQ0mW6/5PFRGo7lOKPBrm2NpcSwSnEkTYyP60toTbahEWcW8qkcldwOfUe4Ndnd6RZ2Ni8kjR3VxJMZSGAJJzwM9vf14ri9YjLX0kskqkuxzzzn0xW6lczasdvaeJG8uKBWeRmkAKgAbQOrBRxk+/TrS+KbsPprRi5jEj3DLMMcGRVB49ODj8K43SLxLCJirqJZDlmJ7DoPYZ/OrGq7Yp4YpZidg3yMOdzsMk/yH4VPLZjuVZo4mVkIVcANgN1PHT35qDTpUgmJMSl1ORvORx7VNfQEFbiN98brlcdRj+E/Sswu3m5P61puhHSm5ebTpYQxBJ3LjI6c/hzWKpaFXYqeR1z1pkFxIsitu6cY7U24lZmbIHI59KSVgBpCTv8AXrTSSxC459QOabCplfYozgZ/Ctiws4Bb/aZFbdnAU+nrTbsA/Ql1KMRvbBBF5i5J4zk9/wDPFdZdXd/CpeOZ7dmIieTHyA56q3XnjmsSKCS60xoQsqgFnj6ZbB6cdevtWzp0ttrUElhHKIJjGfK8w4GewPvn09BWcmNBY27Ppc1ypKq+/wA0hMltp7Y6k8/XrUU9tqmpTLqOPs8QO0eZIWPIAAC/lx61s6Ky2CQ2KQ3T28XE0jLgJng5GeRwfWpkn+z3EltGDd+dG06KCDk5+VV/A5x14qLlWOF8VPPCLeGWNUYoZGHl7eQSB/n1rAeVpG8/gknDD0P/AOquk8daiLjUnm8pZEdQqyMuGzgZJB5Bz26VybMpkYxjYOwzW0NiGK7DPGfYHoKfbo8oIOSCfXFRrGS2XOKvQTeUAiBRnkrTA09PjW03qx8xSw2/LgHH1pXvJUvkXeZAzb23DjA//UfyrNuJgsa/xM33hnA2+gqrJNI7ttyQRjnnilYDooL6a4lZ/Olje4HmQ7pPlV1OOPyx+NaJGoapdW+qW8piZlWG6V24JXjJHQjHH1Fc1CX+zgEh5UJkQEcjjn+X6V1ngnU1uEJuyklyXCAEYG0/xH375qZK2o0dJ4dgTT7F768VBdeUNzEALt9h1HB6cc1rW2tC7uJZrK3aWNVwpcY57EAjJH0PeuV1PU4k1pZCqNZxcSIyhvmxkEDr14pbXUQ4uWspmhDqC3lxlwnsR264B7Vly31KuWyLu+vGN8ZbiGFHLRR4wjE55Awe/fmrsFnYfYrX7SZWfyQAIjJtUcgD5eOKh8PxXdtMkC2UUkTO32lcjIOOBnuScdsdcV01rKLaIW9ppWI04OJhGd3Vsgd8k0mxpHnmn649zYfbY4kSPLI8bNuRV7jA5A5zVIK9xrDW0LNJGBvVg2Nvcn3rj9NvJrWUENIYs5aNZCoY/hXTafJGJY725lZIZyJCrDg4PAb2rZxsRe5LdeYsAhECRkuSpJJI5x1HXJ/+vWnonh66vLuaC8tZ4UQD94VOdx6kE/Ssayv55NbikW7V3WYStsPUg5z7CvULOaTUII9QMbWsjLkx5DA+nIPP/wBeok2ikrnB3Pg+cXN5BPIrN5Qa3lU538/y4IrJ1zw7LZ6DDOQgmG4yc8ncfl47cZNeo3AtrjTVXyD5KNvTZlVDZycH8c8elc3rsf23dNPujjAKMvADA+460ozYOJwem6feW7xNNAuwZYkyDABHU/kKihv2LuGbDNj5iCSSDXS6zb+ZaDGBvOwbs8L3PFc9eKLYDyipYDaPlwT781onckrzgrISqAg5JBHStnwlrEOnGcx6YlzdsN0LucrGw6Hb3+tYdra3l7fLZ2sZlmfgLnGccmur8B2cryS2d3ZS25VvMWVl4Yn+HB55GeR6CnK1gR6LoviFtR063e4mUSBctsGV3EcEZ9uce9UrjVU+0NGkw3qu4MBlWIHIx9a46x+1WVzqVpJJ5cMaMqIBgg8bZCe47cetLHcsIxcg4kX5evGcZP8ALr2rHkRXMO16R9ScXMVwkh2BSI02MB7e3PWuP1CO3CEBFG30GR+ddFpNvPqd+lnp4WSY/NuztyO5APXr0rQb4baofN8y4VZEByoT5d2ARz369u9aJqO4rXPNnPzAkYGc8VavLo3DiRxgkZIFdtbeEEiuJo542c25D4J3LKcH5c+1YGu6dbwQwJFAgupW/ebX3AHnAH16+1UpJsmzMUSsNzIxU9vWq7sSfpW3d2sNva+Sygztj6gen/16yJ0BkYoML7dKpMTIg1SbieAM5qJBlgKuCJcj29O9NgixpKK07fKV4/GteN1Jt4kKNhSMsCMH+p5rMtI8QO5BOc9OntVqKYrthI2tkbQvPPqah6lG7pc0u9ZLaVDGX+46856MPTOMe9ac0MEjwLeRGRmdnjEgIEZJGAG5I57Vl+CtEuZ7wjUUeOGKQMsTfxsORj8BXoGn+RbyLZxbYwiFWdv4CxJxn1/xrOTsUkYa3sLPNBOsZhibJEzAq3POB6Z5yfWsuwv7K4uLyW5Eca+ZGcMOQq8Bdw6Eevpj3q14ghl1i9WCP91awr5Ss4GAT1AOfm5xyeOa4vUBd6JeFpEKeau2Ty2BG7HI49Qc/jRFXE2QeK57S51G4e2ld38zaQqAIwA+9kHqT/jWPFFI7qqqcscDir115zMRbF5Ix3C5Iq9oESbZkcEXATcgK549K12RJmixuA7Iq+Y6n7q8npmmiKRbgxOQrdznNek+GdDbYb2/s4hJ5m2JY/ukYwSc8+1Uj4Vtl1kSXc0cokuM7YSVXbz8ufXI5/pU84+U5jTrS2uJgk77VVDgYyWPpXQ+HtNiiuZT5hW3mG0qUAwc4wQefX2q+/hX/SHi0+byioUOrOW3ZyeD6D1+lasXhRrDT57i6uZZrt1BWMDarNjlTz1z3qXNDsyGy06xkVYYlUNa5+dIiSBjkEe4yOPWrerWOkRaRHbQwmJzzb+UnIwB6c45zk1Hp8+o2lnHFLE5uEZoz5aEFRxldx78Gq09rFLeLLLeMCMhgqAMmR6nqM5/IVHUo4/XYDpd0sUky3JZOGUkcg9/X6UaTNM9s8Zn8gNjLZyWHPXPUdKf4kh06G4S3tjfPMqqGklcbCB1OMZ59Og96pM7CF4wpdcZ5PKsOnWtehB3YuLN1s0vpIwVXy1liOJGOMcnpjJqxDfw2vmQT6kRtkYIzqdzLngnj61wa3jXM0K+UVUgB9hyXY8En1roYBqqRBIGKooxhYN3PufWocRpnB21s87MEZIwq5ZnYKqj3NWZdNufNa1juYHCJvIE424wDn9c1VdBIhZI/mH908fWoS7uTl2ywweeo/yB+VbbkmtFpmrW8ckC2g2ZBd1wRjHHIPvkD2rd0jWb7RoIoJfOltk+/IrHnnnHbHOPU/hXLWt9dwW5hhkaMH5QynlATyQPU8c9ccVpHXWkn3SgYAIU7RhMdGwepPpUtNgj1JNci8i2WaVikxbbuJIxjufSq2tP5cSiOPy2SISxfLlWU9VP864fQLy51GCe4fKlAEAAyq/7XoBVrVddNwQxmBdo9jx5JX+6CO3T+dZclmXfQt3jPbM25Y/s0xBCsOhx6f56Vi34ileNpo8xqw34J9hkd+h/Clmmury5Ejsd20CRiQowMdPSls2jF5EZoDdFTuSJGwN2eMnv2q9iTrtH8P6ZbW091bIsLWsu6OWUkOpHUNjqCDjHrS3dxZ3K/JJLFMCPJm83cpYc4/MkCus8PaF4o1qOO9sdB1WeOROcWzFSeo5+73xnPOK01+EvjOOaTUoPDtzBKRlYwY8ZBH8O443D+VQoyfQq6PNdRsoZneUwSQyyYjdH5BQEMMZ6YxxWZeabqH9miSBAXkOcEgLtwM8/h+VeleJ/DutaZA8+q6He2iSAhkltmGQO2/pjvz71xeqXnnyCCCWSJgCuPLUBsdQp6fhQrg7HMPFZ6dGsseqIbxGQMoQgqc84zjP1ru7fxda20FkkE+UU7JGXjaTj+Zz+dcJrOm6dLN5z3My3DkZ87jn6Y/lSfYYfsexH3nB3FSRj/HpVNJ7ivY39W8XQz3AdYwE3ESRY+UkHqp7E1jLrMKOXRbcREZBCYKE9jWNcW/kRtFI7LubJJAx07frVMlYh8soHbKnOce1UooVzT1FPMuGkU5L8qR1asW63DKlV9ytTrcCYFN2CMMOMYPqKqSsGJOfmHU1SVhES5VgR2p4WRicg4PJPpSIV3YJGM960LZCCWYDHQZ70wHaf50OE6q5w2elb+hWLrdJPEnmYbaC3cnuPp/Wqmn28kjKQo8thySOR9K6PS54rfy08uQ7R1UfxEYyR2ArOTGjdjTzYdsB8qZSSp6bfYHPc9D7VPPaw3dpE0jCSZU2l3AycdmHrknJrO0mdre/FvIc+YrKAwwA2fXsPb8qbfmG3HlvcMkSyku3mbVLN149M7ec8VnYu5xHihpbfUXUxukikHYWzknuMdjWS0dxIFkntnYSnCHYcfnXaQ6FNegXwnUXJbKBxxxyPx7E9q3r90sILJL218gx3Qm2gcHgh+fQ5Nac9tCLHnug208V5PHcfaIIo1wxKbRnGdpJ6HH41pmwijvftsU7M0sJyTwU4x19wa9DOh2dyJp4rhPJuLhbsqTuKupyCM9VJ7VnT+F7G4uXkF7LPbyYI2H5lI6r7DPt7Cp9pcfKyvpmpwWenxwNO0yoNo3jcQpxwD1496q67qE1zaC3to2fyCCQmctnocjjHWsQqbK/n02Q+a0MmwFehxzkVs6daXNzDJLEZCFbGMgDgd6LJah5HU6N5X2iCF/m+1Rpv3EttYLzgjp3/AJ1eRpxrFsVSR7aJSsrOOQPXI6dvy71g+G47iO9aSb/URxjy2VgwU56e/v8AWuk1Cee2RZI4yZGDbWzjAPOMfxYH48Vk9y0W1MBZo5FyN56DbnI4wR0bPX14rx/xNrctrrt5arp7W7JK5C7ypGfT+lb/AIo8SyQvHavcS2zPHuWWJSPOXs2O3pXC3NxDdajNLcNNdGRsmV2w+T/OtKcbbkyZW+z3EqyS7nlYLuzksTj+laum+Hpb2NlW5EUpAKmRiFI6n9KbEbeMCJd2WX+Lqv5e1dBoBmik3ZUwK3G4hQCR09sjv/KtG2SivYeEriSNXS9mVhlXjAVZPoM9DmtO08PapFbR/atVuTKw3EKmdvsSWGTSX3ii1iUxiKKe4bKlFKlV5ycsPf8AH3rMu/E+rz3DSG4jtcniOOYrx6n3qPeY9Dho7ho0KBRj1zzQ0qSKGfh++KgI4/xpPxrci5ZLoq4DA0uUK7W/UVV3d6duoA6nwzfvHZyWyohK4HB6JznOTjqev/1qNXsof3c8I3xBdrbR82cn8u1c3b3Etu5eFyrFSp+hrorJm12S206xt3luGdIYLdFwzMzBVGR1yx/xqGtRpm78OfBuv+PNci0TQ7ffuG65d8iO2XON8jY6eg5JxgV9Z+CfhH8Ovhboba/rz2t5dWkfmXGqaiAI4sd0Q/KnPTqx9a6z4Q+BdM+Hngu30q2ji+1Molv7kdZpccnJ/hHQDsB7mvlz4reL9X+OnxVtvBfh2+httIhu3g0/zXYQ3DqjM08mASfuHbxwCO5NbqKgrvczb5md/wCKv2kpdXuLnTvh/aWlrFCcHU9YIiiI/vKpICj03HJ/u1lf8JNcakkI8V/G67t7mU5ePRLScwjg4+YBAAB3Arw/xt4Y1nwD4obTPEemKky/PBgZjdccyIcYYcn3HAOMYpltqqmOe9leWMMSiAsDlO/OeD0Gew6VlKcupaij6Y8GRaVrlxs8NfH3VJ5WXyxZ3eRngDGyQgk9889a5X4ofB7xta2dxqSaZpusSo2559KjMMrr/eaEDG73QfXNeefD7wbrnjdRYeHYEF2Ckpd2Kw2kZPylzjg9TgZJzXpngv4q638OfHU3hDxRfPqmkw3Jtp3JLGzZTgyRsfmZOmUPT+HHQtNS3QttjwDzriKN4biQzWynG90JKn0I6hh6VNZ3TKhu3cZQMUDHuwwMY56k4r6v/aA+EmneKtMn8Y+GIY11YQeZOkGNmoRYznjgyAcq3foe2Pj+1djb4aIusTDapJygyeamcOVjUrliV4blmNxFEsiAFEZiyyDPIB7f1r0v9ljwb4Z8WePNTTxPpVvc2en6X9oEEjHyy7SBd7Y6gLnivL90s0MloqYliZpYWxjIHJH5Z6V7r+yKwfxl4sKxukbaF8oYY48z6U6fxBLY8m/aI8GWfgP4lXen6UGXSL2JL7TCH3L5L9VDHqFYMB7Yr2v4FfBXwhqPwYbVfF2lx3Wt63aTXls0jsJbaADEbRgHg8q5PfcAeKwtK8Mz/HT4J+Bxbv5ms+G9TTR9Skz832FtuZD64Tyz9Q1el+D/ABNBrnx98baNphC6T4b8MrpdpGv3VZH/AHmP+BYX/gArZJXuZt6HgEvhLw6v7INn4zXTIhr8mueS19k7ynmsm3rjbgDjHXmvVP2hPg94Q0P4TjVvCelxwapocME95skJkuLZsqzuCTk5BbP+ywrjGiz+wnp6ODx4hBOO3+kNXsvjfXbWw/aG8P8AhzVNraT4n8LnS7qNjwzNJJ5f5ncv/A6dlYep8/fs0eH4/GnxEWy1S0H9iWNq95f5YqNi4CqT6Mx59ga9v1j4feDoP2idC0WHRYTpV/pT3clrk+UZFDgHGenCnHTIrkpdCf4I/BTxBZX0hj1zxLqr6bbyA5c2kZZQ4+qb2/7aCvSfEcxX9rDwRbgkBvD1w3seJalRVrDbZzfwm8E+DdTvfHp1+zie207Vns7aWWRk+yxZYDa2eGHHzH0FeM/EXwrdeDfiDd6Fqjvcq0iyQvIg2z25PysCMehB9CCK9k0YpJ4A+NpjfOdRugfb7wxWZ4dmT4x/DcaNctG/jbwyge1kdsG7gyBgt3PAUnswU9zUOKat1Gm73Oo1DwV4Usvjr4c8OQaFANLvNIe4lgBOwyJvAY85OQB7HbzXk3i5/sOvazaadIIksr64jVZF3BY1dsA/XA56mvcfEbY/ap8GRMr5Ph+4IPGAR5mf515142+K/g/Tde1uCX4VaFe3UGoSRyPJIga4ZXZTIf3Z/u5PWlUgn5ahGTLPxX8PaVpN54PtPD+l+TfaxZohWLJM0hMYA5OATuOTxx9Kl8W6h8N/hRbw6T4g0+bxb4kMavdRwny4YiRlQecAYIwMMcYPHFdV8RNc0yx+J/wx1e9SK1tnt3bDH5IVkVVHbopZeeMCvGvj/wCEtR074u6peX9qTb6pcme3uSuUkjIHAP8AeXG3B9B2NDjGN3YE27I6XwsPhB8Ur/8As608O3HgnxDPlrS4hmDxSyf3SMhS3sQCexzUHw5+HFzc/FqTwrr0rQR2EUsl4kTY+0oNoAB7Bt6tnrj3rE+FHh251fxdpdnpEZlaC8ineZQCLdEYMWYjp049Sa6f4ueKtcj+PV5e+AYp7/UrC3SF0tYTLnYP3pZRnKjcFPuKSakrtD20uXtU8VfB64Gp6JN4buPD0lujixvYYmkaSRcgBlGcEkDhs555BriNPuRcQWJuWAEpztLBcNjO38cYr0rwvqHhr4y6heaRrHhqDTfEUFm9zHqtj8ozkKQ469WHDZB5wQRXgkeqRRQSxTvv+ZlaVTkEqSMEdunb61FWN0mioOx0PiWws9SvcllFwiFVQLg45PI56e3XvWAvhbTUiSa485w2VURISFOTgnHKt06jFLJ4iiuC0yR+Wmwb5SMYHp15OcgH3q3ZaqYo0lSZZ725lAiLAqoHHVf4se5rJXSK0ZVbwuqzhHWSDeoAJPmc44ORj/61a2ieGGhV5ZrkXkTDY8Sja7c9cHqQOhNFmxiF7qEjTyJ5J2o0gLSlc7toI+XP+cVmnxdp13YXqJcmAkqIjKxXzsDOwkcouBj69+aPeY9DdbwPo0cSLJCxWRWRpDJ84OeORnDdv0qlqvw/srq8M1hdwWUBAxHjqe7DnvXK6p8Qb+4vo5LaExxLAYjAWIVT03KR7Y+lc9qeq3mpXC3F6WeYIqFhxwOnFUoz7iujBOfSmEe9PGRkEim9TgZrczG4pKcc0mKBCqa9h/Y90WPWfjnpssyb49Mtp77HbcoCJ+Rkz+FeR2trNcN8inA+8fSvdP2J500/41vbTMN17pNxFF7lWjf+Sn8qcfiQPY+lf2nfEU/hj4IeIb60k8u6mhSzhI6gzOsZx77WavkL9mG4if48+EkSJo8XMoC8YAFvJ/nNfU37Y+nS6h8BNZaIZNpNbXLD/ZWZcn8Ac/hXyn+y4jD4++FMg8XMuT/27y1rP4kStj7g+I/hTwj4704eFvEiQSzyRtPbASBbmHGFMsR6jBIB6jkA5Br5q079l/xYPiM9ndapbL4biYSjUVUF5U6CMRHpJxyT8o689K0f269T1LRfF/gTV9HvZ7G/tYbuSCeFtro26Lof5g8EcGsS7/at8T3Pw7TTrXSIYPFR/dTakADAExxKkf8Az0P90/KDzz90EuVvUSv0PqzwTo3hjwzYyeGvDcdrB9iCvcQo4aUM4JDynqWbBOT2HHGK+FPjdqUc3xq8RwcRmHWZkZz2AkznP417f+wXc3l9ZeN77Ubqe7u7i/t5Jp5nLySMY3yWJ5Jr58+PduI/jH4wl+YF9YnIz/vUp2cUOO59a/se+KpPEHw0uNMnffJot89rGc5/csA8Yz7ZK/QCvmb9onSbXwr8Yda0yxBSNphdRxjoEmAk2/QEsB9PavdP2C9Mnt/AWv6tIpEV7qYjiz/EIowCfzYj8K8O/a41KDUP2gNcFu4ZbSK3tWI/vrGCw/Atj8KUleCBPU4qyucOSxkAOcZGSoPXmu8+F/xBu/At7qF3YQ2t29/ZtayLcB1CgnIYY7+3evLI52XlXORXsn7PPglvHXiwWWrB4NLtIRd3Lo/+tjBGFB/2iRyOgB71jZ30NHa2pX+CvjPXPh9Pqo8MQLqS38KpJC0cjiJ1zskwgPIyRg9RUPwu8T6j4A17XNQgayu73VbR7a5F6zoyszbt+MZzuJyD1zXaeOPj/qehTvpfw503S9E0W2bZbf6KrNOoON57DPXGM+pzXFfEP43T+OPBB0/xF4R0qbWY3DQ6xD+7dEH3hs5PPT72O+MgVfoyfkWf7U1k/BuD4fRWUD6XHe/blvVWTefmLbem3G4nn0496b8UvGGo+NfEWj+I7htOsbrTLeOC3NtKThkcuHOeh3Hp2xivYfjz8UPGfw8/4Q/T/CFrDJbXWkLI8BsjMCy7FVRjkcHGBXL/AB5s9ItviJ8MNbk0WDS9a157abVbGMBdkglh5ZfXLspJ67eelNxfcV0cD8avHGufEPVrGfWIrWw/s6AxR28TnAZiC7kNzlsLx2AFamofGTxLefEvRvH50TTTNo9k1isKyN5UgcNuLN1VjuJA9h1qp+2DcW8Px41UPbq5+yWpJycn93XuPgvwj4asPhbp/wAGtZEcHiDxNpFxqkkZH3JgUIJPXchKAf8AXJqaUrvUG1Y8H0Lx54oXQfG2lWmkW1yniu5a4u5Iw7G2ZydwUDIwQcDP15qt4Q1XX/COvWuvabbz2s1q29mlhYRkFfmVuB8h5Bz7Gm/DX4o+MvhvqcvhLTBa2ayaqsd7BNbiRll3rE+CeR0r1v8Aas+Lni3wp42uPB+lT2iaZd6UhlV7ZXc+YZFbDH2HpU8t1dsd+hydx8XtW1D4pab8RrnTLaNtPtGsba1Vn8qRXVt3z92y+fbArzvxBcDU/EWqalfqfNv5XuZbcKY/JkdyxUA8gYPFevx3Udp+yP4K1CAQwyQ60ZIi+NodZZ8E569Kt/tCWVrrcPh34iWELC01yyWK724wkyKSu4464LL/AMAqZJ23BM8y8f8AxD1fxeNImubO0todFtBZgwszBwccuTwCdo4+tb3gz46+KdL0OPQtQtNO8XQKQsVveoXkVewBUEsB05Bx6112peG30H9nrRvBGkxRx63481GJpTKnKxs6EFh1ACiMe2WpnjDxdpnwVvo/h/8ADfR7FtXt4Y31XWLuEPLI7KDtHuQQeTtGQAOtUlbVsL9LHI+MPj14ri0uTRNC8PaX4JhuAQ5s7Z452/3WZVAOO4XPuK848BePte8E+KU8SaNqMZutpSZJ0LRzRnGVccHHAOQQQRmvatD+Mt3ruow+H/ilouma74b1GZLdrg2myS1dztD8cYyeoww6g8Yqr4J+Gnhvwf8AtXQ+F9aMd1pwge80hLoAiViMxq2eGZcSY9SgNP4rNMW3QzPFX7QfiZ9BuYdI8JaX4Xm1RSLjUoLVw82RyULKozyeTuIzxzzXjC30DW5iJOCMnA9+g9BivffiX8XPiR4f1LxH4d+JvgKzv9BvxNBYQPAY4UGSI3SYBhIMYPZgeRtxivmqGdwoBIPHpRNDizc/tBWVY2k/dA52hfbirUOsGPeY5CGK7VbbnZ64+uK58Tygbug9cU4XUgGd36Vm4lXNi6vvtMMUTTTbY12rVaOOHOQZOf8AYqoL2XGC2fwpVvZB3NFh3NWOKJRkK3/fIp5Kg9/+/YrLXUZB1NSrqjY/1YpWYGQFJ6DIFOWNtjOFOB1I7VJbIzSBUwCfXvWk9kwkaP7hdcgc4NVcVjHZGB5FPtLZ7m4jgjIDOcZPQVdubeRCHdW2kfKSMZ7VVQbHDKSpHRvQ0COzuLG4S3jiEKcIIzIF64HJ9ql8HahqPhHxxpPiizjeV9OuFmdAMGROjp+Klh+NcbFd3cKtsuZV3Dbw3+cVYe7v71hFG+Mpt2KcZHfr3qUmmM/SWQaJ478DukciXuj61Yldy874pFx+BGfwIr4c8I2g+Df7QthH4yeWG30e5kZ50jZ/NiaKRY5VA6hsjp0OR2NdR+zn8YL74fXJ8PeII7i58NSSE71Tc9i5x8ygfeQ/xKPqO4P0R8Vvh34Q+NPhG2u7e+tzdIhbTdWtSJNmeqNj7yE9VOCD0wa6bqaujL4T53/aj8Z+HPifqPhy58L3VxPDYwXAnMts0R+do9uN3X7prya3sLeC1LucOoAyBn5u/TqM16Z4i+G2t+Cb5LXxVp94LQYSLVLFBJDx3546D7rFT9aitvCvh/Wz5OkfE3wxbSs2dmopNaOrd+CpU8ejGsJc0maKyR0H7MHxI8I/DSw8QQ+KL24t5NQuYZIVhtXl4VCDnaDjk1wmo6Nqfxb+NGtw+EInuoNS1GS4S4mjZUt4GbPmPn7oHoeSeBzXa6b8Ivhxbk3XjT4w+G/IU/NFpc8Ydl/u72JI/Ba6+X43/Cr4ZeFZtL+FPh6bVtpAe5SN47dpMYDSzuN8jewB9sCtEm0lIlvXQ9Q8Rax4Y+AnwbtraNlkFjB9nsLdiBJe3JyTn6sSzHsM+1fn/f3t7rGr3mq38rTXd5O9xcSnqzuxZj+ZrZ8eeNfEnxC8SNrXijUWuJeVgiUbYbdP7ka/wj35J7k1jELGCBgZFEpXCKGy7FYYr2T9mD4m6f4S8Zw6f4hMcOlX1s9lLdNwIcsGQsey5yCewbPavG4oWmY4PHck0nlMjZQF17nFQtHcp7HuPxR+CvjbStcnbQfD8viDQ7g77G6sMSny25G9QchgD1AIPUHtXG+MfhB428J+A5/GHiC2tNMsvNWFbS4uALp93AIQZH4ZzjJxgVS8LeKviXoMNnpnhbXtdsYLwF7W2hmOyQAsCUVsqBlW6Y6GsvxVc+OPEjrf+Jb7VtVxbi4WS8n3hIWbaGAJwqknHAGar3ehN2fVvxg+MGr/AAy8V/D+3QRTeH7vTFl1ODyQZSvyruRuoKg5x3xjvXmXx68Oapa/tB+FfF/9qT6xoPiHUbKfTLpn3rEvmofIU9AoDbl9Qx6kE1414lfxbql5ZxeI59SvZrU/2Za/aXMnllCP3KHpkb14B7jNTXNx40uLe38Py32pzW+gXAFtaibKWcrPtXZg8EtwMdD0xVOVxWPonxn4MHjX9tk2tzDv03TrO01G+JHylI0BVT/vPtH0zTfE/jv4IX/xjt/iJcePvEyarpsiJDFb2LG2CRhlKD92SUbL5553HHavD4tW8fya1f60db15dR1C3Nrd3QmIe4Tyg4iZv+uYDAdhyK5G50PUoIreZ7KRIrlgsBGPmJJAA+uDj1wcdDRzj5T279p/w3Z2nxb8OeONFKyaN4ra1u45UGFaYPHuP/AkKN9S1Q/tu4/4XdHxn/iUW/T/AH5a821m28cS6dpei6gNaks9NnkttOtZSWWCUDe6oAeGAGfYDimayvi3xLMdf1u6vdXna1SU3M8okbyQ2xTnPA3ZGOuc980nIEj1zxxsT9iTwdsHyjWyR/33c11n7Nsmm+P/AIc6n8OtRnKi0ni1CyDHLxxbxvH5gj/trXz7qM3jE6ZN4WuTqI0/SC11LYSP+7ti3WTbnAzv/wDHuOtXfCdv4w0fXok0Eajpetyq6QSRs0EvlrkSBs/wgqc/T2qebUdtD2r4r+Od/wAZLbUrGNp7LQbyK3tUixtxC/7zrxgtvXj+6KufFz4eXvjDxIvxM8Bwx67p2pwq1xboV86CZUC7tjHngKCvUHPbFeTW6anpcWmRXOk3dwLwLgtJkyM7hFYNzuDPx9a3PD9n4s0DZqGh3msafdXL+VH9nnMSTENtIZOVO3pz3FZ8+9+pVux2Hgb4U+J9Q8QRXXiDTP7E8P2wWS7mvSI2KqcsqgnvjqcADPtXMfEaK5+OX7QM9v4U1OztVgtPL06e4kaPzVgyxZcAnJZmK+wz2p2oa1471u1v/wC1r3U9ct4SRPA0rFYiM4O1Ttxwexzjg1Th0DVjBHc2+k3NlcYRTJbOFljl3YQpgghshh+eehoU0tEg5b7nq/wbtfiXcw+I/DPxksJbnwjBYOJZ9VCttZSP9XL1ddoY7ucEAgg18hpZlZmlSNnt1c4JPzbcnBI9cYNej+L9b+JWo276TrniDXtQ0wFt0FxPlTsDHD4xu+43XIO04zisGx0y7S1OpNDDJaxgNsLYJHfjv1/nVymrCUTmoLcf8tELIsbFf9ogZrZt/Dol0SC5dJDPdOsdsqHG4nueOg5z9Ki068t5bktLsijkY4D5IT6elehaabdNGtJYIWn8iQSRKDhkGCpAz1Bzn8sVlKTRSVzy660W4jvWtbVvtbKcMY0OMjrj1AOfyqK7024txuOGTPDqDtNetweHji4RZnT7VL5mGGDtHOxh+XQ1Wg8PvqMZS4njjhRjG8dsmwI/THPXjml7UfKeUxx4kMbAZYcCr+mRD7L88SZ3H7zAGuuv/A01v50yXO4QMcBlDB1AzwR3x/niubnsNRWQ7LDeh5Vtmciq50xWsVNLtY0lFwXjKyExqC3T1P0rpU0d5EQtIrfIQo27t4I+n45/GuS+zyQsxaYhCBjFaVj4nvrZFhd0ZB8oIUZA7USTewE+r2lxAu2VH2qPL+dAVAHcMO/esSfYoZVQlsAAjt71d1jXGvZijkPABlFXI2n1+vWsWSaSRiFyM9KpJiZNKfnVcbTjPJ61Y0qaO2vYmMgXPAbjKn6+lU1TbJmXJBHbr9KjZRn0piOtutRivUKQMjyj5sKccYHPP4/TPtWj4N8U+MPCU/2/whrt3ZfvN1xDjMMnGfmjbKtxnng+9croulX0zi4t38p0+Ybjgle5rqrv7Ta29rZzwhfPYJM4Bw/OQSB3Ht1qL8r0Hvuey6H+1RqsMDW/iHwvYaphSGktZjBvXuSjBh07ZxWLrnxi+EGru15efBaOW56l0mihz7lkx/KvE7oJBeSSgpcMDtwcEZ6H2xxTHQSWwLQMFxjapIGfp3/lWvtH1Fyo7LWPiH4XSWQeF/hB4V0tznZNfF791PqFchM/UGuA1zVtW1y7Fzq19JOyDEaYVI4x6IigKg9lAqzt82Bfk2kfdxxng8VnyKCwwQT3Ipc1wtYreWFNSOruucE0+WFlXPGO/tSjHkrlipU4OKAFtHVUMRTdk5qR53QHdgZGAoqAyE5yBj9agJY9aANBdT1GRrbN/c4tUKQfvD+6UjBC/wB0EccVJLqmqLB9n+3TmL7N9lC548nr5f8Au57U/wAM20V5cPbOu07dxfGQBnrSa5YPY3TJncoAIb1B5H5jmlfWwWK0urapJsD6hcuI5vtCBpCQsuSd4HZsknNaOn3d5I1xeSajcCS5bddOjAOxDBgT3IyAePSsNlJPHNdL4esEnjSIToLhsgIy8dc5Hrx6UN2BI6W2uLi/0xJLrUJ3jWXzJRvILMQRn0zjjjtxWNezXgsfs93eTpJbzoIo2OShzlWA9s9e2frW/ottcwTPpt3GjrKv7uRWygk5woP8PvnrUPie0W21QTC2CzKiNKrDkttxn6DbWSlqXY5e41bVLV5fsWo30eyeSVf9IKmN2PzNnruPOSO3eqw13VpIBG2ozqhhEDLxgxg7gn0B5FberaNBZ2NmWH76XDzAsSWJ524x1Ax+dc3qMZjuCQuBjI4x+XtWilclovxa1qn2i6lfUJ3lvEC3DyPuMy8cMT16D8hWjbeI9WTxHa6hcajdy3FqG8qSVyzKCDkAnPHJ46cmuZgwWBPPUdOlaUEazxDd8zbgEJ4OKGCOo1nxJ4hW4txHqQhtlZUiPaFPvZDdu5GO9b9hq+qrb6fNNfXzeXO0xcMSFYkZIB4+Yc/X615vqCXEVkY/OZkU7SCK3PBfi06db/YdSU3NmzDIYksvIOV/LpUNO2g1a56gIbm4cz2uonbcRkSvA5QyIwIBK9+pGDxzVS2v/EGmXkwmvru6hkACyNjYSjZUH0w2Sfeua8UeL9MtLczaFcs18Qp2nOEzzyOhPr2ri7XxPqc+rG9vdQnzncAv3Qew29AKiMZNFNo9In+33Fxd319ds0KlpSBJ5nJzu69eGbj3OOvMNrqsL2TQWMERkmRyiSp5bHGBkoe2MHvkCud0XUTftmS8/wBMZAFeWIcg88Y4PToe9b8VyXiE5l3OpC8/eIBwDkfwnnPpmh36gjgbnSLuRUu0tV2zlzEIc7ioOS2P8at6ampTxxGG83tbHCJg+YnsPb6Gusu77RNPaP7WzwiSV5AOWw57DHQfhV3w9JopnZoY1t2lB2TiQDr/AA46e44qnJ22Eka2g3D380UtxGkVzGwJxJkNxg/T8a0IY50u3ikt2KxxqWkKFEOTxjB68f56Vm232S61GGOO3aa4ZikzeWQroByR6HI/GtnTpLPTbJYUN0LZQShMZwnzdPm7cj8qxZYxHuTcs2IEgVtsrY+UgqcA5GQc454qWUwkr+8uMgYJRsAnPNSxXX2CNvP86WJWLiaN/MIH+1/skdu1PXVNLkG8avGQ3Zkjyvsc81Iz5tvZiDtDAnGBg5xVdRIc5Xp60x8BuOvsaleUlSSckntXaYklpZTTgsinaDgnHFWGgW3iIIV2zkMOlXNDnie2MczojLnYSQDz1GPeo5VeRA/mDEg+XHFK+oIypPMdycEZ9q6DTdGNskV1PKhV1IeFlzvHXAYZHbrWXZ20899DbYfZI4VsV1utNcRxLbxKfKMe3dt43AdvQ/lSk+gIto0NvDFLtZrcuBG/mhkUDOcHuOe+awNRuIWPmSPIA7FwhOFAPQ/jUSK73CLPuZsKwjzxt7UTxxTXS2pl8mYthTI4AJJ6cdP1qUhj9H0q4vpVkaN1tiwDN6A57fh+opdn2PzoUJba5VDkHkcda6yB/wCztISOadsXAbZ5S5+7gEBTwAfr6965m/nCzrG0YLSAk7V5Y5759h1oTuBjTOGYK7DaCdq8nqe9QXEbs+1Nrew6ip5bpZXYCKNCDgKqgg/Q9RS2FncalfxWiFY5XYBT0xmrQiuEYSAMONuGx61CsTEkJ9xsmu+tPDkcOn3DXTY2LsEjdd3936884rE1O0ijBWBFVY8K2wH5j3P/ANalz3HY5d4yFyOlQgEk4FaV1jJEa7QenvVYQsgZhyv94dOaoQ2znks7hZ4mIdT0HcelW9b1M6pcGYQiM8ZOf5elV4baS4B8tSzA9B3Fa9joJuoGlhbbhDvUjO0jk/gQOPxpOyAw7hVSTap6gE/jXS+GdbtbKONrkhHUkDYnOOOfr2zWZp0Rlhus52mDg+4I/I4qtaubUpM0KSeWdwV1yCfQ0PXQD06ykjmkt5hcNLn5DsZVZiTxlSBjqOcVty2MV3O6XTNCxG2KRkIER7bueQ35ZNclY6jBcaUbm7jXzoANkq8BmIywI/lnrXZaXcwG1QpNCdgVWjuH2+XnsfUnjg/pjFYS0NEctqmmSLZNqDSJGqkRbZGwWIxk56Yzn3OK4fxDJPNMzz3n2lUG2NiOAP7vtXqPi+0vruztSYgINvmO0a7hExY7gR198e59K808RadcQXGydVwzgrIhyjL6irpsmSMSCUoCCeDjPvVmO5jWcMAwHGVHQ0yW0C7ihJxVWJXMgyMYrXcjY3lureR9kkRUE856Y960tft4fLjurK3iuXb5ZNp4RumcYHBFYUAuM71UMegGaJdSuUhESybVPUEAnHpmpsM3E02FryG6CRGIWy4VAcPgYJxjPHQ+9YWuWUlpd58tUUkjaJNxyOvYVd0rVbiBhskZUzkKeR+XpjitllTVrrT1vZrYQmYIyYwcYI5brtPv0papjOUsb+a1YPCcOpB57elXZdd1UpzdNGM7sxDbk+tGv6Rdw6lfNBYtHaQ3ZgXaMAHqAAeTxzWVMJV3IxJUHkDsarRiJ3l80EFmlc8gk/Nn61s6LfPuSF7gQyYwivwD0xhvWuaQFmCr1zxXSaVp17cwRNtgnQcspG2ReejZ4Pt1+oolawI77wzaTSStN5jOI/7hK/MeoODknof1rs7FhLm3vTBO0gO5FODg/wBcfTNeLpcahZuGs5zBhhIY03buO5U8n8MitpfFtxcacH8z7PfREKjQD5JOmC3oRyMdDWEoNlpnq9pFbadbLZ2ZUT8kIMEt0yCpJxn1GK0Y7aF41eaGJWI/ijycduvNeKat441m68OLZTqUu12k3kUgDPtOQW468dutLpnxI8VWFotqGFyqHh5og7YPOM+lT7KQ+ZHne3nB5oK7SaUtjGPzowzkkcnGa6zIu6TbrLdgMrNxkEDj8a1fsjNbGLIjw2WJ5wvrT7GwisbZbwTJvJyrddykDgimTXykOEQNuOWPQfTFQ3dlFO+uSkkQh3Hyv4lJHNINbvllid5y4jOdp+6e2DRctIUC7QqjIUD1qgdq78E7unPbnmmkI09Jubhr98yQr9pfDhhkN3xV7W4rptkax7mRAS23nI6AfT1rmGJyMH8aswandRSF95kJQp85yAKGtQuba63q9lp8Fm8ieVG48uRlGVBG7APpg1Dqd1O9n5jsDluoP3WJJPHv6Vj317JdqgkVQEGBj09KrI7qCATgnJGeKFELl5nUwKwX96D16dutdZ8KLaGfVZrmeWUSImwcjDKwIzyOoIHT1riNrFQ2DtJxXpfwjlefS7mxuIC1vDOJIpB/C7Dv6AYBqZ6RHHc2tejkjtks0gEe9R8hUod24g/Q9DXKa+yrhHyoCbfnX7xHFdfqpj1C+uZvNWMxKXG5uRuPy5yeBnp7VxesxQW13HAb2GbzmJWSN9ygHHX0PP6VnApnNu3+lJGmx93Yng+1XdWjijIhEZUrGPunIfnj8R0pbaLy/FS2ksI3LMysMc5xwR+QP41P4hupre8IER8worSSHjg8jH4Y5HXFakmTYx3MFykz27OJQGUrJtABOM5rt7B3eeVzEuwALNbMcunqc9+OjDtTtGsmv7e2dTYuCAoTzcbg3qD0+n41ORKmpwB7W7Sa3OwAASHAxx8vYjn0qHK40jkCi29s6QhsMxTewODngH06fyrM1N8TFFOFUnIJzzXfWlpF/Z80TRlrYzb41Y8KhBPX2POPpXJCAo/2giPJyAOpAA/UmqixWMNLqdYxAshMXmByh6Fh611vh/xFdCGcsN1xLcedM7Dg8AAD0HABHeuWnCeaW2bB0IHHNaekKqrx1xnHXJqpJWEjpda8Vu1tbwbWCksJ1DleNxYFT25J/LFc1LPJd2qESHy4ZDy3cnv6Zxxn2ovoWLbFiZmc5AIyealv7OazjSASAx7iUGOlSklsMdBDHLH84Urnp096r6jok8cTXIdQSARGeGYeq+orZslijhttwYFW+dlHK+/vXX2W68gyEDEOUYKMggdvyx+dJysCVzye2lubGUK/mx85ZGGO3oafILaYvJ54R8ltnr7A12nxC0y1ghGrRORLIdrJMSWOMYIyOvPNcBPGNxKgEH1NXF3VxNWLNncQod7RsCCDncDj866bQr22vb6KFSoyWMsRAVZRycHAye3BrjVJXkYNaOnXkqSRRw2sckgOIzkhx9CpBokrgmel6dHJeQRm5kuI2jmbeElx5TBcFlOMkY+X2IJFcp4i8NrZxSy2sr3MzOTGx4Z16lyc47/yrZ0rWf3Qlm8+zkLgq2zfG7c7lK/ewe+PrWnrWvHTobeJrS1u4VhAPzbcDPGOCBn1HpWSbT0L0aPM7FY3xJLiPnD46/h6GtDTry8t3IUFSvPmb8kduDS67BHBqQliLhLkCbynI3Rg9m9/erWk+QWWPcjEHG054+hrRskj1SaXUYoliskjljO5pskFj2+nPf3qus95tJubcM5YjzQvzk+56EfrXRDTXuGVIRmRid0eMFe44PB/zxU9/pcq2oaKGYtt55A2k/wnufr0qeZAYFsPtU8XyZOeSAcjjnI6EVd8qZuIb8RovABjxn3wDUF9ZX1rKXjhRiFCsA2ACfb8KqO+rwyNDIYwyEAhgFI4Bxj8aNwOcER2Zfj0x3qxamJCNxIBJByP61AW5wAcZ6UjEsMAEgcnvitSTQu7qEHYjfKvygAdqIPlt0uWG9WZuO4xiq1lDDNKkUu9cnJYVqxRP9nMIwrbSACcHqKl6DIpgWjWR+GYcKRjGelZ77eeM/XrV+4SaN2JBfsCecc9fc1mSuc4wPrTQMY5Hp+VNxnHFP5GHKHA9RwaZI2W3HgUxD/KYpuA4xULDBx3pyMCTkmlILdMkCgC5ZGXZ5b7Aq8gEfe/Grml63f6Pl7G4KB85QrleRjJB71mGVyoJOSAM8VC75OPypNXGdt4W1canqlwLqNUvLkFnuADtfjneBwAO3GKrXdpFHqFyDdwCTnYshwOvPNZXhLVLXTrx3uo/lZeHAywxzj8cVvT3dlfXdzIJIpTGRIvyHYARwOh+lQ1ZjWxg3v2y3vEupZM3Hl7g/QgjgDPcgY6Uup6pc3yebcRxL5mMlU649M/yp7wGe8FqgkaGAlRJwSQTnn29Kgv4o+fIVljXj5+tUhHb+D7GAwpqFpaRyxTRsrRlVibg/e5b1yBt966xYpHTzLe0mQwgKYZR8yjHJRuh6n8/aua8FXKS6ZCsEisoQoYjHtQPjLHd14HpXZ2MzJbFtOtUs3CjKMTyMcfLnbkjueTWE3qaIydJ0uGCHUbGJ0kjmiE0Mb/APLM7vmHtxgVweuWmrNcypcR7UibAGwqVPoT3+tegane6q13JbxweTPcJg3ESYZgD029yD3Fczc3uoLbyQfbJXRNwdTyoHQnOM5x6043Ezhri0dLiNVaHbJ91sZwfet+w052IKxbARxkYyfxrB1O52SPBbOfLZMMCP5+4rY8J+IpkuYNOvlWeFiVjdhkoSMAY7jj61q72JNcae0sbNDt8zyy2T93jrg/nVW0tbVjGJHiRy2C2wkAnoAB6dc1s3GrWVrutLi8aICIuGVcgHIBH6nj0Fcnd67bxNEum2refE5xPJjDjBHTqPzqEmxs6vT4IIGJ83dHIxjZdvGfQ+9aX9niIxvbSeVGqkhQxAbqPw69a4rSvE8j3JingjXzD8u1iAGxyTXT2utJtMN3LAGAziIFgp6ct249eOnNJpjTRV1q0urjSpRIY/KZt8xklJO7HLAN0PH5ZrjvKYSm4iWKVJcFF25y3HGPrXW6v4vtkkutLm0v7SEby3O8bWG0jnA46j9a5fQ7qWNkKyRp5GAoc43AnkA/0qo3SEzFlQh2ypByc5GMGmD5eRjj3rqPsijTZXuoOQzvcuBuZOgAz7kisBYQ4EHlP5jMNpwc/TH5VaZNi9o2qtAwRpWXy0LIyqCd2Rgew613+mXKTwMLjZdQtH5QJAMjhj13cbQME4AxxXnVrAIzJay2a+eDtJYn/wDVXX+GJS14NNltY7Zl2iDDEhm6lc9sj+tROw0M1HSbhL2G5t9siTQqgmkVcLgAEcE84/SqTWE2k6lLM8kLEKA7FfkOe23GOPwrv7PS7cLHI6wkRyM6oGB2uQcn3/HFLd6Klxbssh8zL4XzsAZ7kYI7Y6mo5yuUxNHvtLmkQI0sE82EDCP5Aw64H16E+tdfbRTuSFSORQAY1kA5weR04HH1rya8tdQ0i5WeSNls3kO5QTlGB6j2967HwrrNrNClvLcSrLuBS4SQbwo4wR3GSOfrntSlHqgTOl1LR1uYMfZS0JLFouFOTn5g2Pw55471WtfCJvLaOT7VHCyLscSSBSxHf8sflWy7yMyh/MhkY7W8s5jf1BA6cdMYNPaVoMCO4SNHG9cN1B747fSs+Zoo+bowDFISASMYP41o+GESTVEhdcrKCjeuDRRXY9jJbnS3lpB/aNxlAfL6E9eg4/WquvqLOyikiAMkqgs7Dn/PFFFZobOauJ5ZyxkcnHI/GqqsWYbuee9FFaCJpHYI0YPyDBC9hxVRiS3NFFMQ5AMH6VPEoUFh1B4oooAicnyh7nmmY+aiigBzKODjrXTeCYFdryUswKxHAB46daKKmWw0bc1pb2enKYYlDLHvDHryBx9Oa5XUIkjidwMtuK8nsMUUVMRkWkajf27/ALm7lRYyXVQeA2OtepvfzyWgQbY/MdtzL94gAcZPtx9KKKmpuOI7xbM1vZ/bIlUTRxbFbHRQRgew5PSuY8ch9MexvrKWSGcnO5T+Y+nHSiiph0HI57xrM1xrondVDSW8bPtGASQc1kQSva3CXMWA8TB1yMjINFFbR2IZYW6mvLm5Nw28eWxVey+w9qhtvmVi3O0cD86KKaA2FijMEdxtAkXbjHHbP/1qsafcBtWD/ZrYYaWQDy8jIXI4OaKKhjH+PII4W06eEeWZYA7KvTJOSfX8zVfSsSzJG6rtEY4x160UUL4QNLUooRo7SRRLDvaJXWPIVhz1H4A1m3FvCmp2qBTtePcw3Hk80UUkBvmzhNo8EgaVVCgFjyFKsduRjgbRj0rn9FvLj7VAySvGu7bsRiBjOfrRRS7jPSTfTRzWUkSwxyTQGR3WJdxPTH0qGO6mXTUlL7zLaF2DcjcMc/qfzoorJFdS14ssYX0W1Z2lPmthgW46D/GvLLGMR380YZtqMFXn2PP14FFFaQ2YpHsPgS/m1rTpINQSGQwozLIIwH4PQ44x+Fbmo2EEN28cZlVR0G80UVjLcpbH/9k=";

// ─── Footer text ─────────────────────────────────────────────────────────────
const FOOTER_LINES = [
  "Site :   https://miminhos-criativos0.lovable.app/",
  "Contactos : 926 992 352",
  "Email ( apenas para assuntos sobre o site e Portal do Cliente ) - site.miminhoscriativos@gmail.com",
];

// ─── Helpers internos ─────────────────────────────────────────────────────────
const drawPageHeader = (doc: jsPDF, title: string, subtitleLines: string[] = []) => {
  doc.addImage(LOGO_B64, "JPEG", 15, 10, 52, 31);
  if (title) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(30, 30, 30);
    doc.text(title, 73, 20);
  }
  subtitleLines.forEach((line, i) => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(60, 60, 60);
    doc.text(line, 73, 28 + i * 6);
  });
  doc.setDrawColor(180, 180, 180);
  doc.line(15, 46, 195, 46);
};

const addFooterToAllPages = (doc: jsPDF) => {
  const total = doc.getNumberOfPages();
  for (let i = 1; i <= total; i++) {
    doc.setPage(i);
    doc.setDrawColor(180, 180, 180);
    doc.line(15, 272, 195, 272);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(100, 100, 100);
    doc.text(FOOTER_LINES[0], 105, 277, { align: "center" });
    doc.text(FOOTER_LINES[1], 105, 282, { align: "center" });
    doc.text(FOOTER_LINES[2], 105, 287, { align: "center" });
  }
};

const safeName = (s: string) => s.replace(/\s+/g, "_").replace(/[^a-zA-Z0-9_]/g, "");

// ─── Tipos públicos ───────────────────────────────────────────────────────────
export interface ContentBlock {
  type: "paragraph" | "heading" | "spacer";
  text?: string;
  bold?: boolean;
  italic?: boolean;
  fontSize?: number;
  align?: "left" | "center" | "right";
}

export type DocType = "comass" | "semass" | "orcamento_interno" | "orcamento_externo";

export interface DocumentPDFOpts {
  docTitle: string;
  contentBlocks: ContentBlock[];
  docType: DocType;
  clientName?: string;
  clientNif?: string;
  clientReference?: string;
  clientNameForFile?: string;
}

interface QuestionnairePDFOpts {
  clientName: string;
  clientEmail?: string;
  clientNif?: string;
  referenceNumber?: string;
  answers: Record<string, any>;
  submittedAt?: string;
  mode?: "interno" | "externo";
}

// ─── Exportar PDF de Questionário (existente, header/footer atualizados) ──────
export const exportQuestionnairePDF = async (opts: QuestionnairePDFOpts) => {
  const mode = opts.mode ?? "externo";
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  const subtitleLines =
    mode === "interno"
      ? [
          opts.clientNif ? `Nif - ${opts.clientNif}` : "",
          `Nome - ${opts.clientName}`,
          opts.referenceNumber ? `Referência - ${opts.referenceNumber}` : "",
        ].filter(Boolean)
      : [`Nome - ${opts.clientName}`];

  drawPageHeader(doc, "Pedido de Orçamento", subtitleLines);

  let y = 50 + subtitleLines.length * 2;

  for (const section of QUESTIONNAIRE_SECTIONS) {
    if (y > 255) { doc.addPage(); drawPageHeader(doc, "Pedido de Orçamento"); y = 52; }
    doc.setFillColor(247, 240, 230);
    doc.rect(15, y - 4, 180, 8, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(80, 60, 20);
    doc.text(section.title, 18, y + 1);
    y += 9;
    doc.setFontSize(9.5);
    doc.setTextColor(40, 40, 40);
    for (const f of section.fields) {
      if (f.type === "static") continue;
      const raw = opts.answers?.[f.id];
      const val = Array.isArray(raw) ? raw.join(", ") : String(raw ?? "—");
      const lines = doc.splitTextToSize(val, 108);
      if (y + 5 > 265) { doc.addPage(); drawPageHeader(doc, "Pedido de Orçamento"); y = 52; }
      doc.setFont("helvetica", "bold");
      doc.text(f.label + ":", 18, y);
      doc.setFont("helvetica", "normal");
      doc.text(lines, 82, y);
      y += 5 + (lines.length - 1) * 5;
    }
    y += 4;
  }

  addFooterToAllPages(doc);

  const n = safeName(opts.clientName ?? "cliente");
  const filename = mode === "interno"
    ? `DOC_PedidodeOrcamento_${n}_INTERNO.pdf`
    : `DOC_PedidodeOrcamento_${n}.pdf`;
  doc.save(filename);
};

// ─── Exportar PDF de Documento Geral ─────────────────────────────────────────
export const exportDocumentPDF = (opts: DocumentPDFOpts) => {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  const subtitleLines: string[] = [];
  if (opts.docType === "orcamento_interno" || opts.docType === "orcamento_externo") {
    if (opts.clientNif)       subtitleLines.push(`Nif - ${opts.clientNif}`);
    if (opts.clientName)      subtitleLines.push(`Nome - ${opts.clientName}`);
    if (opts.clientReference) subtitleLines.push(`Referência - ${opts.clientReference}`);
  }

  drawPageHeader(doc, opts.docTitle, subtitleLines);
  let y = 52 + subtitleLines.length * 2;

  for (const block of opts.contentBlocks) {
    if (block.type === "spacer") { y += block.fontSize ?? 6; continue; }
    if (y > 262) { doc.addPage(); drawPageHeader(doc, opts.docTitle, subtitleLines); y = 52; }

    const fs = block.fontSize ?? (block.type === "heading" ? 13 : 10.5);
    const style =
      block.bold && block.italic ? "bolditalic"
      : block.bold ? "bold"
      : block.italic ? "italic"
      : "normal";

    doc.setFont("helvetica", style);
    doc.setFontSize(fs);
    doc.setTextColor(30, 30, 30);

    const align = block.align ?? "left";
    const xPos = align === "center" ? 105 : align === "right" ? 195 : 20;
    const lines = doc.splitTextToSize(block.text ?? "", 170);
    lines.forEach((line: string, i: number) => {
      doc.text(line, xPos, y + i * (fs * 0.45), { align });
    });
    y += lines.length * (fs * 0.45) + 2;
  }

  // Assinaturas para doc com assinatura
  if (opts.docType === "comass") {
    y = Math.max(y + 20, 215);
    if (y > 248) { doc.addPage(); drawPageHeader(doc, opts.docTitle); y = 180; }
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(30, 30, 30);
    doc.text("Assinatura do (nome da pessoa ou cliente)", 20, y);
    doc.text("Assinatura do Colaborador", 125, y);
    doc.setDrawColor(100, 100, 100);
    doc.line(20, y + 14, 92, y + 14);
    doc.line(125, y + 14, 195, y + 14);
  }

  addFooterToAllPages(doc);

  const safeTitle = opts.docTitle.replace(/\s+/g, "").replace(/[^a-zA-Z0-9]/g, "");
  const n = safeName(opts.clientNameForFile ?? "");

  let filename = "";
  switch (opts.docType) {
    case "comass":             filename = `DOC_COMASS_${safeTitle}.pdf`; break;
    case "semass":             filename = `DOC_SEMASS_${safeTitle}.pdf`; break;
    case "orcamento_interno":  filename = `DOC_PedidodeOrcamento_${n}_INTERNO.pdf`; break;
    case "orcamento_externo":  filename = `DOC_PedidodeOrcamento_${n}.pdf`; break;
  }
  doc.save(filename);
};
