import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";

export type Role = "admin" | "colaborador" | "cliente" | null;

export const useAuth = (requireRoles?: Role[], redirectIfNoUser = "/cliente/login") => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<Role>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRole = async (uid: string) => {
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid);
      const roles = (data ?? []).map((r) => r.role);
      if (roles.includes("admin")) return "admin" as Role;
      if (roles.includes("colaborador")) return "colaborador" as Role;
      if (roles.includes("cliente")) return "cliente" as Role;
      return "cliente" as Role;
    };

    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user ?? null);
      if (!session) {
        setRole(null);
        if (requireRoles) navigate(redirectIfNoUser);
      } else {
        setTimeout(async () => {
          const r = await fetchRole(session.user.id);
          setRole(r);
          if (requireRoles && !requireRoles.includes(r)) navigate("/");
        }, 0);
      }
    });

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!session) {
        if (requireRoles) navigate(redirectIfNoUser);
        setLoading(false);
        return;
      }
      setUser(session.user);
      const r = await fetchRole(session.user.id);
      setRole(r);
      if (requireRoles && !requireRoles.includes(r)) navigate("/");
      setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  return { user, role, loading, signOut };
};
