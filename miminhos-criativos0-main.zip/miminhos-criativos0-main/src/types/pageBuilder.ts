export type BlockType = 'hero' | 'section' | 'card' | 'gallery' | 'form' | 'testimonial' | 'cta' | 'text';

export interface Page {
  id: string;
  title: string;
  slug: string;
  is_published: boolean;
  blocks?: PageBlock[];
  created_at: string;
  updated_at: string;
}

export interface PageBlock {
  id: string;
  page_id: string;
  type: BlockType;
  order: number;
  properties: Record<string, any>;
  styles: Record<string, any>;
  created_at: string;
  updated_at: string;
}
