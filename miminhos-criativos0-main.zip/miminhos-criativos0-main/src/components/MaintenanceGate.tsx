import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "./Logo";
import ComingSoon from "@/pages/ComingSoon";

export const MaintenanceGate = ({ children }: { children: React.ReactNode }) => {
  const { pathname } = useLocation();
  const [s, setS] = useState<{ maint: boolean; coming: boolean; msg: string } | null>(null);

  useEffect(() => {
    supabase.from("site_settings").select("maintenance_mode, maintenance_message, coming_soon_mode").eq("id", 1).maybeSingle()
      .then(({ data }) => setS({
        maint: !!data?.maintenance_mode,
        coming: !!data?.coming_soon_mode,
        msg: data?.maintenance_message || "Site em manutenção",
      }));
  }, []);

  const bypass =
    pathname.startsWith("/admin") ||
    pathname.startsWith("/colaborador") ||
    pathname.startsWith("/cliente") ||
    pathname.startsWith("/dashboard");

  if (!s) return null;
  if (bypass) return <>{children}</>;
  if (s.coming) return <ComingSoon />;
  if (!s.maint) return <>{children}</>;

  return (
    <div className="min-h-screen bg-gradient-champagne flex items-center justify-center p-6 text-center">
      <div className="max-w-lg">
        <Logo className="h-24 mx-auto mb-6" variant="dark" />
        <h1 className="font-display text-4xl mb-3">Em manutenção</h1>
        <p className="font-script text-2xl text-primary mb-4">Estamos a preparar algo especial</p>
        <p className="text-muted-foreground mb-8">{s.msg}</p>
        <p className="text-sm text-muted-foreground">
          Contacto urgente: <a className="text-primary" href="https://wa.me/351926992352">926 992 352</a> · <a className="text-primary" href="mailto:site.miminhoscriativos@gmail.com">site.miminhoscriativos@gmail.com</a>
        </p>
      </div>
    </div>
  );
};
