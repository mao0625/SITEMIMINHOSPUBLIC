import { Link } from "react-router-dom";
import { Instagram, Facebook, Phone, MapPin, Mail } from "lucide-react";
import { Logo } from "./Logo";

const SITE_EMAIL = "site.miminhoscriativos@gmail.com";
 
export const Footer = () => (
  <footer className="bg-dark text-white/80 pt-16 pb-8 mt-24">
    <div className="container grid gap-10 md:grid-cols-4">
      <div className="md:col-span-2">
        <Logo className="h-20 mb-4" />
        <p className="font-script text-2xl text-primary mb-3">A festa é sua! O prazer em criar é nosso!</p>
        <p className="text-sm leading-relaxed max-w-md">
          Especialistas em decoração e organização de eventos na Madeira. Criamos momentos inesquecíveis com elegância, dedicação e muito carinho.
        </p>
      </div>
      <div>
        <h4 className="font-display text-primary text-lg mb-4">Contactos</h4>
        <ul className="space-y-3 text-sm">
          <li className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary" /> 926 992 352</li>
          <li className="flex items-center gap-2"><Mail className="h-4 w-4 text-primary" /> <a href={`mailto:${SITE_EMAIL}`} className="hover:text-primary transition-smooth">{SITE_EMAIL}</a></li>
          <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> Madeira, Portugal</li>
        </ul>
        <div className="flex gap-3 mt-5">
          <a href="https://instagram.com/miminhos.criativos" target="_blank" rel="noopener noreferrer" className="h-10 w-10 rounded-full bg-white/10 hover:bg-primary flex items-center justify-center transition-smooth"><Instagram className="h-5 w-5" /></a>
          <a href="https://facebook.com/miminhoscriativos" target="_blank" rel="noopener noreferrer" className="h-10 w-10 rounded-full bg-white/10 hover:bg-primary flex items-center justify-center transition-smooth"><Facebook className="h-5 w-5" /></a>
        </div>
      </div>
      <div>
        <h4 className="font-display text-primary text-lg mb-4">Navegação</h4>
        <ul className="space-y-2 text-sm">
          <li><Link to="/sobre-nos" className="hover:text-primary transition-smooth">Sobre Nós</Link></li>
          <li><Link to="/servicos" className="hover:text-primary transition-smooth">Serviços</Link></li>
          <li><Link to="/galeria" className="hover:text-primary transition-smooth">Galeria</Link></li>
          <li><Link to="/faq" className="hover:text-primary transition-smooth">FAQ</Link></li>
          <li><Link to="/orcamento" className="hover:text-primary transition-smooth">Pedir Orçamento</Link></li>
          <li><Link to="/privacidade" className="hover:text-primary transition-smooth">Política de Privacidade</Link></li>
          <li><Link to="/cookies" className="hover:text-primary transition-smooth">Política de Cookies</Link></li>
          <li><Link to="/termos" className="hover:text-primary transition-smooth">Termos e Condições</Link></li>
        </ul>
      </div>
    </div>
    <div className="container mt-12 pt-6 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-3 text-xs text-white/50">
      <p>© {new Date().getFullYear()} Miminhos Criativos. Todos os direitos reservados. Desenvolvido por Mateus Oliveira .</p>
      <div className="flex gap-4">
        <Link to="/privacidade" className="hover:text-primary transition-smooth">Privacidade</Link>
        <Link to="/cookies" className="hover:text-primary transition-smooth">Cookies</Link>
        <Link to="/termos" className="hover:text-primary transition-smooth">Termos</Link>
      </div>
    </div>
  </footer>
);
 
