import { useState, useEffect } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, LogOut } from "lucide-react";
import { Logo } from "./Logo";
import { Button } from "./ui/button";
import { supabase } from "@/integrations/supabase/client";

const links = [
  { to: "/", label: "Início" },
  { to: "/sobre-nos", label: "Sobre Nós" },
  { to: "/servicos", label: "Serviços" },
  { to: "/galeria", label: "Galeria" },
  { to: "/produtos", label: "Produtos" },
  { to: "/blog", label: "Blog" },
  { to: "/faq", label: "FAQ" },
  { to: "/contacto", label: "Contacto" },
];

interface UserInfo {
  name: string;
  role: "admin" | "colaborador" | "cliente";
}

export const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const onHome = pathname === "/";

  useEffect(() => {
    const loadUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setUserInfo(null); return; }

      const name = user.user_metadata?.full_name
        || user.user_metadata?.name
        || user.email?.split("@")[0]
        || "utilizador";

      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      setUserInfo({ name, role: roleData?.role ?? "cliente" });
    };

    loadUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      loadUser();
    });

    return () => subscription.unsubscribe();
  }, []);

  // Subtle shrink/blur on scroll — quiet, Apple-style chrome
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const portalPath = userInfo?.role === "admin" || userInfo?.role === "colaborador"
    ? "/admin"
    : "/portal";

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUserInfo(null);
    navigate("/");
  };

  const textColor = onHome ? "text-white/90" : "text-foreground";
  const showChrome = !onHome || scrolled;

  return (
    <header
      className={`fixed top-0 inset-x-0 z-40 transition-all duration-500 ease-out ${
        showChrome ? "bg-background/80 backdrop-blur-xl shadow-soft" : "bg-transparent"
      }`}
    >
      <div className={`container flex items-center justify-between transition-all duration-500 ease-out ${scrolled ? "h-16" : "h-20"}`}>
        <Link to="/" className="flex items-center gap-3">
          <Logo className={`transition-all duration-500 ${scrolled ? "h-11" : "h-14"}`} variant={onHome && !scrolled ? "light" : "dark"} />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) =>
                `text-sm font-medium tracking-wide transition-colors duration-300 hover:text-primary ${
                  isActive ? "text-primary" : onHome && !scrolled ? "text-white/90" : "text-foreground"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}

          {userInfo ? (
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate(portalPath)}
                className="flex items-center gap-2 bg-primary/10 hover:bg-primary/20 border border-primary/20 rounded-full px-4 py-1.5 transition-all duration-300"
              >
                <span className="text-xs font-medium text-primary">
                  Olá, <span className="font-bold">{userInfo.name}</span>
                </span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                  userInfo.role === "admin"
                    ? "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300"
                    : userInfo.role === "colaborador"
                    ? "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300"
                    : "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300"
                }`}>
                  {userInfo.role === "admin" ? "Admin" : userInfo.role === "colaborador" ? "Colaborador" : "Cliente"}
                </span>
              </button>
              <button
                onClick={handleLogout}
                title="Terminar sessão"
                className={`transition-colors duration-300 hover:text-primary ${onHome && !scrolled ? "text-white/90" : "text-foreground"}`}
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Button
                asChild
                variant="ghost"
                className={`font-semibold tracking-wide transition-colors duration-300 ${
                  onHome && !scrolled ? "text-white hover:text-white hover:bg-white/10" : ""
                }`}
              >
                <Link to="/login">Entrar</Link>
              </Button>
              <Button asChild variant="default" className="bg-gradient-gold hover:opacity-90 shadow-gold border-0 text-primary-foreground font-semibold tracking-wide rounded-full px-5">
                <Link to="/orcamento">Pedir Orçamento</Link>
              </Button>
            </div>
          )}
        </nav>

        {/* Mobile hamburger */}
        <button
          className={`lg:hidden transition-colors duration-300 ${onHome && !scrolled ? "text-white" : "text-foreground"}`}
          onClick={() => setOpen(true)}
          aria-label="Abrir menu"
        >
          <Menu className="h-7 w-7" />
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div
          className="fixed inset-0 z-[999] bg-[#0a0a0a] flex flex-col animate-fade-up"
          style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, minHeight: "100dvh", animationDuration: "0.25s" }}
        >
          <div className="container flex items-center justify-between h-20">
            <Logo className="h-14" />
            <button onClick={() => setOpen(false)} className="text-white transition-transform duration-300 hover:rotate-90" aria-label="Fechar menu">
              <X className="h-7 w-7" />
            </button>
          </div>
          <nav className="flex-1 flex flex-col items-center justify-center gap-6">
            {links.map((l, i) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `font-display text-3xl transition-colors duration-300 animate-fade-up ${isActive ? "text-primary" : "text-white"}`
                }
                style={{ animationDelay: `${0.04 * i}s` }}
              >
                {l.label}
              </NavLink>
            ))}

            {userInfo ? (
              <>
                <button
                  onClick={() => { setOpen(false); navigate(portalPath); }}
                  className="flex flex-col items-center gap-1 mt-2"
                >
                  <span className="text-white font-display text-xl">
                    Olá, {userInfo.name}
                  </span>
                  <span className="text-primary text-sm font-semibold">
                    {userInfo.role === "admin" || userInfo.role === "colaborador"
                      ? "→ Portal do Colaborador"
                      : "→ Portal do Cliente"}
                  </span>
                </button>
                <button
                  onClick={() => { setOpen(false); handleLogout(); }}
                  className="flex items-center gap-2 text-white/60 hover:text-white text-sm mt-2 transition-colors duration-300"
                >
                  <LogOut className="h-4 w-4" />
                  Terminar sessão
                </button>
              </>
            ) : (
              <>
                <Button asChild variant="ghost" className="text-white font-display text-2xl mt-2" onClick={() => setOpen(false)}>
                  <Link to="/login">Entrar</Link>
                </Button>
                <Button asChild className="bg-gradient-gold px-8 py-6 text-lg rounded-full shadow-gold" onClick={() => setOpen(false)}>
                  <Link to="/orcamento">Pedir Orçamento</Link>
                </Button>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};
