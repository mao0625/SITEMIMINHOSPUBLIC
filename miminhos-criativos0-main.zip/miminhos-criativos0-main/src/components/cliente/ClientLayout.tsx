import { NavLink, Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";
import { supabase } from "@/integrations/supabase/client";
import {
  LayoutDashboard, FileText, Calendar,
  Star, LogOut, Menu, X, CheckCircle2,
} from "lucide-react";

const items = [
  { to: "/cliente",             label: "Painel",              icon: LayoutDashboard, end: true },
  { to: "/cliente/eventos",     label: "Os meus eventos",     icon: Calendar },
  { to: "/cliente/confirmados", label: "Eventos Confirmados", icon: CheckCircle2 },
  { to: "/cliente/questionario",label: "Questionário",        icon: FileText },
  { to: "/cliente/avaliacao",   label: "Avaliar serviço",     icon: Star },
];

export const ClientLayout = () => {
  const { user, loading, signOut } = useAuth(["cliente", "admin", "colaborador"], "/cliente/login");
  const navigate  = useNavigate();
  const location  = useLocation();
  const [open, setOpen]           = useState(false);
  const [mustChange, setMustChange] = useState(false);
  const [checked, setChecked]     = useState(false); // evita flash

  const onPasswordPage = location.pathname === "/cliente/password";

  useEffect(() => {
    setChecked(true);
  }, [user]);


  if (loading || !checked) return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-champagne">
      A carregar…
    </div>
  );

  const name = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "Cliente";

  return (
    <div className="min-h-screen bg-gradient-champagne">
      <header className="bg-card border-b shadow-soft sticky top-0 z-30">
        <div className="container flex items-center justify-between h-20">
          <Link to="/cliente"><Logo className="h-12" variant="dark" /></Link>
          <div className="flex items-center gap-3">
            <span className="text-sm hidden sm:inline">
              Olá, <strong>{name}</strong>
            </span>
            <Button variant="outline" size="sm" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-1" />Sair
            </Button>
            <button className="md:hidden" onClick={() => setOpen(!open)}>
              {open ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </header>

      <div className="container py-8 grid md:grid-cols-[220px_1fr] gap-8">
        {/* Sidebar — esconde quando está a forçar mudança de password */}
        <aside className={`${open ? "block" : "hidden"} md:block`}>
          {(
            <nav className="bg-card rounded-lg shadow-soft border overflow-hidden">
              {items.map(i => (
                <NavLink
                  key={i.to} to={i.to} end={i.end}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-4 py-3 text-sm border-l-4 transition-smooth ${
                      isActive
                        ? "border-primary bg-primary/5 text-primary"
                        : "border-transparent hover:bg-muted/50"
                    }`
                  }
                >
                  <i.icon className="h-4 w-4" />{i.label}
                </NavLink>
              ))}
            </nav>
          )}

        </aside>

        {/* Main content — sempre renderiza o Outlet */}
        <main>
          <Outlet />
        </main>
      </div>

      <WhatsAppFloat />
    </div>
  );
};
