import { NavLink, Outlet, useLocation, useNavigate, Link } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/hooks/useAuth";
import { useIsMobile } from "@/hooks/useIsMobile";
import { useState, useEffect, useRef } from "react";
import {
  LayoutDashboard, Inbox, Calendar, FileText, MessageSquare,
  Image as ImageIcon, Users, Settings, LogOut, Newspaper, ExternalLink,
  CalendarDays, Package, MapPin, Wallet, FileBarChart, Palette,
  StickyNote, HelpCircle, ChevronLeft, ChevronRight, FolderOpen,
  Bell, Bug, RefreshCw, ShoppingCart, Mail, Search, X,
} from "lucide-react";
import { AdminLayoutMobile } from "./AdminLayoutMobile";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

const GMAIL_URL = "https://mail.google.com/mail/u/0/#inbox";
const BUSINESS_EMAIL = "site.miminhoscriativos@gmail.com";

const navGroups = [
  {
    label: "Principal",
    items: [
      { to: "/admin", label: "Dashboard", icon: LayoutDashboard, end: true },
      { to: "/admin/pedidos", label: "Pedidos", icon: Inbox },
      { to: "/admin/eventos", label: "Eventos", icon: Calendar },
      { to: "/admin/calendario", label: "Calendário", icon: CalendarDays },
    ],
  },
  {
    label: "Operações",
    items: [
      { to: "/admin/notas-eventos", label: "Notas dos Eventos", icon: StickyNote },
      { to: "/admin/entregas", label: "Mapa de Entregas", icon: MapPin },
      { to: "/admin/materiais", label: "Stock Materiais", icon: Package },
      { to: "/admin/financeiro", label: "Despesas / Lucro", icon: Wallet },
      { to: "/admin/relatorio", label: "Relatório Mensal", icon: FileBarChart },
      { to: "/admin/questionarios", label: "Orçamentos", icon: FileText },
      { to: "/admin/documentos", label: "Documentos", icon: FolderOpen },
      { to: "/admin/mensagens", label: "Mensagens", icon: MessageSquare },
      { to: "/admin/pos", label: "Ponto de Venda", icon: ShoppingCart },
    ],
  },
  {
    label: "Conteúdo",
    items: [
      { to: "/admin/galeria", label: "Galeria", icon: ImageIcon },
      { to: "/admin/blog", label: "Blog", icon: Newspaper },
      { to: "/admin/faq", label: "FAQ", icon: HelpCircle },
      { to: "/admin/page-builder", label: "Brevemente", icon: Palette },
    ],
  },
  {
    label: "Sistema",
    adminOnly: true,
    items: [
      { to: "/admin/utilizadores", label: "Utilizadores", icon: Users },
      { to: "/admin/definicoes", label: "Definições", icon: Settings, adminOnly: true },
    ],
  },
];

const routeLabels: Record<string, string> = {
  admin: "Painel",
  pedidos: "Pedidos",
  eventos: "Eventos",
  calendario: "Calendário",
  "notas-eventos": "Notas dos Eventos",
  entregas: "Mapa de Entregas",
  materiais: "Stock",
  financeiro: "Financeiro",
  relatorio: "Relatório",
  questionarios: "Orçamentos",
  documentos: "Documentos",
  mensagens: "Mensagens",
  galeria: "Galeria",
  blog: "Blog",
  faq: "FAQ",
  "page-builder": "Page Builder",
  utilizadores: "Utilizadores",
  definicoes: "Definições",
  problemas: "Problemas e Suporte",
  pos: "Ponto de Venda",
};

// All searchable items flattened (for the command palette)
const allNavItems = navGroups.flatMap(g => g.items.map((i: any) => ({ ...i, group: g.label, adminOnly: g.adminOnly || i.adminOnly })));

// ─── Tooltip ──────────────────────────────────────────────────────────────────
const Tooltip = ({ label, children }: { label: string; children: React.ReactNode }) => {
  const [show, setShow] = useState(false);
  return (
    <div className="relative" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      {show && (
        <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 z-[999] pointer-events-none">
          <div className="tooltip-pop px-3 py-2 rounded-lg bg-[#222] border border-white/10 text-white text-sm font-medium whitespace-nowrap shadow-2xl">
            {label}
            <div className="absolute right-full top-1/2 -translate-y-1/2 border-[5px] border-transparent border-r-[#222]" />
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Page transition ──────────────────────────────────────────────────────────
const PageTransition = ({ children, pathname }: { children: React.ReactNode; pathname: string }) => {
  const [visible, setVisible] = useState(true);
  const prev = useRef(pathname);
  useEffect(() => {
    if (prev.current === pathname) return;
    prev.current = pathname;
    setVisible(false);
    const t = setTimeout(() => setVisible(true), 110);
    return () => clearTimeout(t);
  }, [pathname]);
  return (
    <div style={{
      opacity: visible ? 1 : 0,
      transform: visible ? "translateY(0) scale(1)" : "translateY(8px) scale(0.99)",
      transition: "opacity 0.28s cubic-bezier(0.22,1,0.36,1), transform 0.28s cubic-bezier(0.22,1,0.36,1)",
    }}>
      {children}
    </div>
  );
};

// ─── Gmail button ─────────────────────────────────────────────────────────────
const GmailButton = () => {
  const [hovered, setHovered] = useState(false);
  return (
    <a
      href={GMAIL_URL}
      target="_blank"
      rel="noreferrer"
      title={`Abrir Gmail — ${BUSINESS_EMAIL}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex items-center gap-2 text-[12.5px] font-medium px-3 py-1.5 rounded-lg border transition-all duration-200"
      style={{
        border: hovered ? "1px solid rgba(234,67,53,0.45)" : "1px solid rgba(255,255,255,0.08)",
        background: hovered ? "rgba(234,67,53,0.12)" : "rgba(255,255,255,0.03)",
        color: hovered ? "#ea4335" : "rgba(255,255,255,0.38)",
        textDecoration: "none",
        transform: hovered ? "translateY(-1px)" : "translateY(0)",
      }}
    >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 18V8.4L12 13L18 8.4V18H6Z" fill={hovered ? "#ea4335" : "rgba(255,255,255,0.38)"} />
        <path d="M18 6H6L12 10.8L18 6Z" fill={hovered ? "#fbbc05" : "rgba(255,255,255,0.55)"} />
        <rect x="2" y="4" width="20" height="16" rx="2" stroke={hovered ? "#ea4335" : "rgba(255,255,255,0.15)"} strokeWidth="1.5" fill="none"/>
      </svg>
      <span className="hidden sm:inline">Gmail</span>
    </a>
  );
};

// ─── Command Palette (⌘K) ──────────────────────────────────────────────────────
const CommandPalette = ({ open, onClose, onNavigate, role }: {
  open: boolean; onClose: () => void; onNavigate: (to: string) => void; role: string | null;
}) => {
  const [query, setQuery] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const results = allNavItems
    .filter(i => !i.adminOnly || role === "admin")
    .filter(i => i.label.toLowerCase().includes(query.toLowerCase()));

  useEffect(() => {
    if (open) { setQuery(""); setActiveIdx(0); setTimeout(() => inputRef.current?.focus(), 50); }
  }, [open]);

  useEffect(() => { setActiveIdx(0); }, [query]);

  if (!open) return null;

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") onClose();
    if (e.key === "ArrowDown") { e.preventDefault(); setActiveIdx(i => Math.min(i + 1, results.length - 1)); }
    if (e.key === "ArrowUp") { e.preventDefault(); setActiveIdx(i => Math.max(i - 1, 0)); }
    if (e.key === "Enter" && results[activeIdx]) { onNavigate(results[activeIdx].to); onClose(); }
  };

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-start justify-center pt-[12vh]"
      style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(6px)", animation: "fadeIn 0.15s ease-out" }}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        onKeyDown={handleKey}
        className="w-full max-w-lg mx-4 rounded-2xl overflow-hidden border border-white/10 bg-[#181818] shadow-2xl"
        style={{ animation: "paletteIn 0.18s cubic-bezier(0.22,1,0.36,1)" }}
      >
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-white/[0.06]">
          <Search className="h-4 w-4 text-white/30 shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Pesquisar páginas..."
            className="flex-1 bg-transparent text-white text-sm placeholder:text-white/25 outline-none"
          />
          <kbd className="text-[10px] text-white/25 border border-white/10 rounded px-1.5 py-0.5">ESC</kbd>
        </div>
        <div className="max-h-72 overflow-y-auto slim-scroll py-1.5">
          {results.length === 0 && (
            <p className="px-4 py-6 text-center text-sm text-white/25">Nenhum resultado para "{query}"</p>
          )}
          {results.map((item, idx) => (
            <button
              key={item.to}
              onClick={() => { onNavigate(item.to); onClose(); }}
              onMouseEnter={() => setActiveIdx(idx)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors duration-100 ${
                idx === activeIdx ? "bg-primary/12 text-primary" : "text-white/60"
              }`}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              <span className="text-[13px] font-medium">{item.label}</span>
              <span className="ml-auto text-[10px] text-white/20 uppercase tracking-wider">{item.group}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── Main ─────────────────────────────────────────────────────────────────────
export const AdminLayout = () => {
  const { user, role, loading, signOut } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const isMobile = useIsMobile();

  // ⌘K / Ctrl+K shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen(v => !v);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#111]">
      <div className="flex flex-col items-center gap-5">
        <div className="relative h-12 w-12">
          <div className="absolute inset-0 rounded-full border-2 border-primary/15" />
          <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary animate-spin" />
        </div>
        <p className="text-sm text-white/30 tracking-[0.2em] uppercase">A carregar</p>
      </div>
    </div>
  );

  if (isMobile) return <AdminLayoutMobile />;

  const name = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "Utilizador";
  const initials = name.split(" ").map((n: string) => n[0]).slice(0, 2).join("").toUpperCase();
  const crumbs = pathname.split("/").filter(Boolean);
  const currentLabel = routeLabels[crumbs[crumbs.length - 1]] ?? crumbs[crumbs.length - 1] ?? "Painel";

  const handleRefresh = () => {
    setRefreshing(true);
    if (pathname === "/admin" || pathname === "/admin/") window.open("/", "_blank");
    setTimeout(() => window.location.reload(), 500);
  };

  return (
    <>
      <style>{`
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-14px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideInDown {
          from { opacity: 0; transform: translateY(-8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes navItem {
          from { opacity: 0; transform: translateX(-6px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes tooltipPop {
          from { opacity: 0; transform: translateX(-4px); }
          to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes paletteIn {
          from { opacity: 0; transform: translateY(-8px) scale(0.98); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes pulseRing {
          0%   { box-shadow: 0 0 0 0 rgba(var(--primary-rgb, 217,164,76), 0.35); }
          70%  { box-shadow: 0 0 0 6px rgba(var(--primary-rgb, 217,164,76), 0); }
          100% { box-shadow: 0 0 0 0 rgba(var(--primary-rgb, 217,164,76), 0); }
        }
        .sidebar-anim { animation: slideInLeft 0.28s cubic-bezier(0.22,1,0.36,1) both; }
        .topbar-anim  { animation: slideInDown 0.22s cubic-bezier(0.22,1,0.36,1) both; }
        .nav-item     { animation: navItem 0.2s ease-out both; }
        .tooltip-pop  { animation: tooltipPop 0.12s ease-out both; }
        .slim-scroll::-webkit-scrollbar       { width: 2px; }
        .slim-scroll::-webkit-scrollbar-track { background: transparent; }
        .slim-scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.06); border-radius: 99px; }
        .slim-scroll::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.14); }

        /* Apple-style spring hover for nav items */
        .nav-item-link {
          transition: background-color 0.18s ease, color 0.18s ease, transform 0.18s cubic-bezier(0.34,1.56,0.64,1);
        }
        .nav-item-link:hover { transform: translateX(2px); }
        .nav-item-link:active { transform: translateX(2px) scale(0.985); }

        /* Smooth icon scale */
        .icon-spring { transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1); }

        /* Glass topbar buttons */
        .glass-btn {
          transition: background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease, transform 0.2s cubic-bezier(0.34,1.56,0.64,1);
        }
        .glass-btn:hover { transform: translateY(-1px); }
        .glass-btn:active { transform: translateY(0px) scale(0.97); }

        /* Active dot pulse */
        .live-dot {
          animation: pulseRing 2.4s cubic-bezier(0.4,0,0.6,1) infinite;
        }
      `}</style>
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onNavigate={navigate} role={role} />

      <div className="flex min-h-screen bg-[#ede9e0] dark:bg-[#111]">
        {/* ═══════════════════ SIDEBAR ═══════════════════ */}
        <aside className={`
          sidebar-anim
          ${collapsed ? "w-[64px]" : "w-[248px]"}
          bg-[#111] text-white flex flex-col sticky top-0 h-screen shrink-0
          shadow-[6px_0_40px_rgba(0,0,0,0.4)]
          border-r border-white/[0.05]
          transition-[width] duration-[280ms] cubic-bezier(0.22,1,0.36,1)
        `}>
          {/* Logo */}
          <div className={`
            relative flex items-center border-b border-white/[0.06] bg-black/25 min-h-[70px]
            ${collapsed ? "justify-center px-2 py-4" : "px-5 py-4"}
          `}>
            {!collapsed && (
              <Link
                to="/admin"
                className="flex-1 flex justify-center transition-transform duration-200 hover:scale-[1.03]"
                style={{ animation: "slideInLeft 0.22s ease-out 0.06s both" }}
              >
                <Logo className="h-11" />
              </Link>
            )}
            <button
              onClick={() => setCollapsed(v => !v)}
              title={collapsed ? "Expandir menu" : "Recolher menu"}
              className={`
                glass-btn
                h-6 w-6 rounded-md border border-white/[0.09] bg-white/[0.03]
                hover:bg-primary/15 hover:border-primary/25 hover:text-primary
                flex items-center justify-center text-white/20
                shrink-0
                ${collapsed ? "" : "absolute right-3 top-1/2 -translate-y-1/2"}
              `}
            >
              {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
            </button>
          </div>

          {/* User */}
          <div className={`border-b border-white/[0.06] ${collapsed ? "py-3 flex justify-center" : "px-5 py-4"}`}>
            {collapsed ? (
              <Tooltip label={`${name} · ${role === "admin" ? "Administrador" : "Colaborador"}`}>
                <div className="h-9 w-9 rounded-xl bg-primary/15 border border-primary/20 flex items-center justify-center cursor-default hover:ring-2 hover:ring-primary/20 hover:scale-105 transition-all duration-200">
                  <span className="text-sm font-bold text-primary">{initials}</span>
                </div>
              </Tooltip>
            ) : (
              <div className="flex items-center gap-3" style={{ animation: "slideInLeft 0.2s ease-out 0.1s both" }}>
                <div className="relative h-10 w-10 rounded-xl bg-primary/15 border border-primary/20 flex items-center justify-center shrink-0">
                  <span className="text-[13px] font-bold text-primary">{initials}</span>
                  <span className="live-dot absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 border-2 border-[#111]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[13px] font-semibold text-white/90 truncate leading-snug">{name}</p>
                  <span className="text-xs text-primary/55 uppercase tracking-[0.15em]">
                    {role === "admin" ? "Administrador" : "Colaborador"}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Quick search trigger */}
          <div className={`px-3 py-2.5 border-b border-white/[0.06] ${collapsed ? "flex justify-center" : ""}`}>
            {collapsed ? (
              <Tooltip label="Pesquisar (⌘K)">
                <button
                  onClick={() => setPaletteOpen(true)}
                  className="glass-btn h-9 w-9 rounded-xl border border-white/[0.06] bg-white/[0.02] flex items-center justify-center text-white/30 hover:text-primary hover:border-primary/25 hover:bg-primary/10"
                >
                  <Search className="h-4 w-4" />
                </button>
              </Tooltip>
            ) : (
              <button
                onClick={() => setPaletteOpen(true)}
                className="glass-btn w-full flex items-center gap-2.5 px-3 py-2 rounded-xl border border-white/[0.06] bg-white/[0.02] text-white/30 hover:text-white/60 hover:border-white/[0.1] hover:bg-white/[0.04]"
              >
                <Search className="h-3.5 w-3.5" />
                <span className="text-[12.5px]">Pesquisar...</span>
                <kbd className="ml-auto text-[10px] border border-white/10 rounded px-1.5 py-0.5">⌘K</kbd>
              </button>
            )}
          </div>

          {/* Nav */}
          <nav className="flex-1 py-2 overflow-y-auto overflow-x-hidden slim-scroll">
            {navGroups.map((group, gi) => {
              if (group.adminOnly && role !== "admin") return null;
              const items = group.items.filter((i: any) => !i.adminOnly || role === "admin");
              if (!items.length) return null;
              return (
                <div key={group.label} className="mb-1">
                  {collapsed
                    ? <div className="mx-3.5 my-3 h-px bg-white/[0.05]" />
                    : (
                      <p
                        className="px-5 pt-4 pb-1.5 text-[11px] uppercase tracking-[0.2em] text-white/18 font-bold select-none"
                        style={{ animation: `navItem 0.18s ease-out ${gi * 0.05}s both` }}
                      >
                        {group.label}
                      </p>
                    )
                  }
                  {items.map((item: any, ii: number) => {
                    const link = (
                      <NavLink
                        key={item.to}
                        to={item.to}
                        end={item.end}
                        style={{ animationDelay: `${(gi * 4 + ii) * 0.03}s` }}
                        className={({ isActive }) => `
                          nav-item nav-item-link relative flex items-center gap-3
                          mx-2 rounded-xl
                          ${collapsed ? "justify-center px-0 py-3 my-0.5" : "px-4 py-2.5 my-0.5"}
                          ${isActive
                            ? "bg-primary/10 text-primary"
                            : "text-white/45 hover:bg-white/[0.04] hover:text-white/80"
                          }
                        `}
                      >
                        {({ isActive }) => (
                          <>
                            {isActive && (
                              <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-[55%] bg-primary rounded-r-full" />
                            )}
                            <item.icon className={`icon-spring h-[18px] w-[18px] shrink-0 ${isActive ? "scale-110" : ""}`} />
                            {!collapsed && (
                              <span className={`text-[12.5px] truncate leading-none ${isActive ? "font-semibold" : "font-medium"}`}>
                                {item.label}
                              </span>
                            )}
                          </>
                        )}
                      </NavLink>
                    );
                    return collapsed
                      ? <Tooltip key={item.to} label={item.label}>{link}</Tooltip>
                      : <span key={item.to}>{link}</span>;
                  })}
                </div>
              );
            })}
          </nav>

          {/* Sidebar footer */}
          <div className="p-3 border-t border-white/[0.06] space-y-0.5">
            {collapsed ? (
              <>
                <Tooltip label="Gmail — Abrir caixa de entrada">
                  <a
                    href={GMAIL_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="glass-btn flex items-center justify-center h-9 w-9 mx-auto rounded-xl"
                    style={{ color: "rgba(255,255,255,0.22)" }}
                    onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.color = "#ea4335"; el.style.background = "rgba(234,67,53,0.1)"; }}
                    onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.color = "rgba(255,255,255,0.22)"; el.style.background = "transparent"; }}
                  >
                    <Mail className="h-4 w-4" />
                  </a>
                </Tooltip>
                <Tooltip label="Ver site público">
                  <a href="/" target="_blank" rel="noreferrer"
                    className="glass-btn flex items-center justify-center h-9 w-9 mx-auto rounded-xl text-white/22 hover:text-primary hover:bg-white/[0.04]">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Tooltip>
                <Tooltip label="Terminar sessão">
                  <button onClick={signOut}
                    className="glass-btn flex items-center justify-center h-9 w-9 mx-auto rounded-xl text-white/22 hover:text-red-400 hover:bg-red-500/10 w-full">
                    <LogOut className="h-4 w-4" />
                  </button>
                </Tooltip>
              </>
            ) : (
              <>
                {/* Gmail link destacado */}
                <a
                  href={GMAIL_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="glass-btn flex items-center gap-3 text-[13px] rounded-xl px-3.5 py-2.5 group"
                  style={{ color: "rgba(255,255,255,0.28)" }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.color = "#ea4335"; el.style.background = "rgba(234,67,53,0.08)"; }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.color = "rgba(255,255,255,0.28)"; el.style.background = "transparent"; }}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="shrink-0 icon-spring group-hover:scale-110">
                    <rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" strokeWidth="1.5" fill="none"/>
                    <path d="M2 7L12 14L22 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                  <span>Gmail</span>
                  <span className="ml-auto text-[10px] opacity-40 truncate max-w-[100px]">{BUSINESS_EMAIL}</span>
                </a>
                <a href="/" target="_blank" rel="noreferrer"
                  className="nav-item-link flex items-center gap-3 text-[13px] text-white/28 hover:text-primary/80 rounded-xl px-3.5 py-2.5 hover:bg-white/[0.04]">
                  <ExternalLink className="h-4 w-4 shrink-0 icon-spring" />
                  Ver site público
                </a>
                <button onClick={signOut}
                  className="nav-item-link w-full flex items-center gap-3 text-[13px] text-white/28 hover:text-red-400 rounded-xl px-3.5 py-2.5 hover:bg-red-500/[0.08]">
                  <LogOut className="h-4 w-4 shrink-0 icon-spring" />
                  Terminar sessão
                </button>
              </>
            )}
          </div>
        </aside>

        {/* ═══════════════════ MAIN ═══════════════════ */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Topbar */}
          <header className="topbar-anim bg-[#111] text-white shrink-0 border-b border-white/[0.06] sticky top-0 z-20">
            <div className="h-[2px] bg-gradient-to-r from-transparent via-primary/55 to-transparent" />
            <div className="flex items-center justify-between px-6 h-[52px] gap-4">
              {/* Breadcrumb */}
              <nav className="flex items-center gap-2 text-[12.5px] text-white/35 min-w-0">
                <button onClick={() => navigate("/admin")} className="hover:text-primary/80 transition-colors duration-150 shrink-0">
                  Painel
                </button>
                {crumbs.slice(1).map((c, i) => (
                  <span key={i} className="flex items-center gap-2 min-w-0">
                    <ChevronRight className="h-3.5 w-3.5 text-white/15 shrink-0" />
                    <button
                      onClick={() => navigate("/" + crumbs.slice(0, i + 2).join("/"))}
                      className={`hover:text-white/80 transition-colors truncate duration-150 ${
                        i === crumbs.slice(1).length - 1 ? "text-white/70 font-semibold" : ""
                      }`}
                    >
                      {routeLabels[c] ?? c}
                    </button>
                  </span>
                ))}
              </nav>

              {/* Right actions */}
              <div className="flex items-center gap-2 shrink-0">
                {/* Search trigger (icon only on topbar for quick access) */}
                <Tooltip label="Pesquisar (⌘K)">
                  <button
                    onClick={() => setPaletteOpen(true)}
                    className="glass-btn h-8 w-8 rounded-lg border border-white/10 bg-white/[0.03] text-white/35 hover:text-primary hover:border-primary/25 hover:bg-primary/10 flex items-center justify-center"
                  >
                    <Search className="h-3.5 w-3.5" />
                  </button>
                </Tooltip>

                <span className="text-[12.5px] text-white/20 hidden lg:block capitalize tabular-nums">
                  {format(new Date(), "EEE, dd MMM yyyy", { locale: pt })}
                </span>
                <div className="h-4 w-px bg-white/[0.08]" />
                <GmailButton />
                <div className="h-4 w-px bg-white/[0.08]" />
                <button
                  onClick={handleRefresh}
                  title="Atualizar página"
                  className="glass-btn flex items-center gap-2 text-[12.5px] font-medium px-3 py-1.5 rounded-lg border border-white/10 bg-white/[0.03] text-white/38 hover:bg-primary/10 hover:border-primary/22 hover:text-primary"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
                  <span className="hidden sm:inline">Atualizar</span>
                </button>
                <button
                  onClick={() => navigate("/admin/problemas")}
                  title="Reportar problema"
                  className="glass-btn flex items-center gap-2 text-[12.5px] font-medium px-3 py-1.5 rounded-lg border border-red-500/18 bg-red-500/[0.05] text-red-400/55 hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-300"
                >
                  <Bug className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Reportar</span>
                </button>
                <div className="h-4 w-px bg-white/[0.08]" />
                <button
                  onClick={() => navigate("/admin/notificacoes")}
                  title="Notificações"
                  className="glass-btn text-white/28 hover:text-primary p-1.5 rounded-lg hover:bg-white/[0.04]"
                >
                  <Bell className="h-4 w-4" />
                </button>
                <div className="h-4 w-px bg-white/[0.08]" />
                <div className="flex items-center gap-2.5">
                  <div className="h-7 w-7 rounded-lg bg-primary/15 border border-primary/18 flex items-center justify-center transition-transform duration-200 hover:scale-110">
                    <span className="text-xs font-bold text-primary">{initials}</span>
                  </div>
                  <span className="text-[13px] text-white/52 hidden sm:block font-medium">{name}</span>
                  <span className={`text-[11px] px-2 py-0.5 rounded-lg border font-bold uppercase tracking-wider ${
                    role === "admin"
                      ? "bg-purple-500/10 text-purple-300/70 border-purple-500/18"
                      : "bg-blue-500/10 text-blue-300/70 border-blue-500/18"
                  }`}>
                    {role === "admin" ? "Admin" : "Staff"}
                  </span>
                </div>
              </div>
            </div>
            {/* Page strip */}
            <div className="flex items-center gap-3 px-6 py-2 bg-white/[0.018] border-t border-white/[0.04]">
              <span className="text-[11.5px] font-bold text-primary/75 uppercase tracking-[0.22em]">{currentLabel}</span>
              <div className="flex-1 h-px bg-white/[0.04]" />
              <span className="text-[11.5px] text-white/14 hidden md:block">Miminhos Criativos · Portal de Gestão</span>
            </div>
          </header>

          {/* Content */}
          <main className="flex-1 p-6 lg:p-8 overflow-auto">
            <PageTransition pathname={pathname}>
              <Outlet />
            </PageTransition>
          </main>

          {/* Footer */}
          <footer className="h-7 bg-[#111] border-t border-white/[0.04] px-6 flex items-center justify-between shrink-0">
            <span className="text-xs text-white/14 uppercase tracking-widest">Miminhos Criativos · Sistema de Gestão</span>
            <span className="text-xs text-white/14">© {new Date().getFullYear()}</span>
          </footer>
        </div>
      </div>
    </>
  );
};
