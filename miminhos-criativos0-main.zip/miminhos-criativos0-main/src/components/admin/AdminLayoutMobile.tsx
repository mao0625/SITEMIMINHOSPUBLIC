import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import {
  Users, LogOut, Menu, X, Calendar, FileText, LayoutDashboard, StickyNote,
  Inbox, CalendarDays, MapPin, Package, Wallet, FileBarChart, FolderOpen,
  MessageSquare, ShoppingCart, Image as ImageIcon, Newspaper, HelpCircle,
  Palette, Settings, Bell, Bug, ExternalLink, Search, ChevronRight,
} from "lucide-react";

type Item = { to: string; label: string; icon: any; end?: boolean; adminOnly?: boolean };

const groups: { label: string; items: Item[]; adminOnly?: boolean }[] = [
  {
    label: "Principal",
    items: [
      { to: "/admin", label: "Dashboard", icon: LayoutDashboard, end: true },
      { to: "/admin/pedidos", label: "Pedidos", icon: Inbox },
      { to: "/admin/eventos", label: "Eventos", icon: Calendar },
      { to: "/admin/calendario", label: "Calendário", icon: CalendarDays },
    ],
  },
  {
    label: "Operações",
    items: [
      { to: "/admin/notas-eventos", label: "Notas dos Eventos", icon: StickyNote },
      { to: "/admin/entregas", label: "Mapa de Entregas", icon: MapPin },
      { to: "/admin/materiais", label: "Stock Materiais", icon: Package },
      { to: "/admin/financeiro", label: "Despesas / Lucro", icon: Wallet },
      { to: "/admin/relatorio", label: "Relatório Mensal", icon: FileBarChart },
      { to: "/admin/questionarios", label: "Orçamentos", icon: FileText },
      { to: "/admin/documentos", label: "Documentos", icon: FolderOpen },
      { to: "/admin/mensagens", label: "Mensagens", icon: MessageSquare },
      { to: "/admin/pos", label: "Ponto de Venda", icon: ShoppingCart },
    ],
  },
  {
    label: "Conteúdo",
    items: [
      { to: "/admin/galeria", label: "Galeria", icon: ImageIcon },
      { to: "/admin/blog", label: "Blog", icon: Newspaper },
      { to: "/admin/faq", label: "FAQ", icon: HelpCircle },
      { to: "/admin/page-builder", label: "Brevemente", icon: Palette },
    ],
  },
  {
    label: "Sistema",
    adminOnly: true,
    items: [
      { to: "/admin/utilizadores", label: "Utilizadores", icon: Users },
      { to: "/admin/definicoes", label: "Definições", icon: Settings, adminOnly: true },
    ],
  },
];

// Quick access in bottom bar (4 most used)
const quickNav: Item[] = [
  { to: "/admin", label: "Início", icon: LayoutDashboard, end: true },
  { to: "/admin/pedidos", label: "Pedidos", icon: Inbox },
  { to: "/admin/eventos", label: "Eventos", icon: Calendar },
  { to: "/admin/calendario", label: "Agenda", icon: CalendarDays },
];

const routeLabels: Record<string, string> = {
  admin: "Painel",
  pedidos: "Pedidos",
  eventos: "Eventos",
  calendario: "Calendário",
  "notas-eventos": "Notas",
  entregas: "Entregas",
  materiais: "Stock",
  financeiro: "Financeiro",
  relatorio: "Relatório",
  questionarios: "Orçamentos",
  documentos: "Documentos",
  mensagens: "Mensagens",
  galeria: "Galeria",
  blog: "Blog",
  faq: "FAQ",
  "page-builder": "Page Builder",
  utilizadores: "Utilizadores",
  definicoes: "Definições",
  problemas: "Problemas",
  pos: "POS",
  notificacoes: "Notificações",
};

export const AdminLayoutMobile = () => {
  const { user, role, loading, signOut } = useAuth(["admin", "colaborador"], "/colaborador/login");
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => { setMenuOpen(false); }, [pathname]);
  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [menuOpen]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="h-8 w-8 rounded-full border-2 border-primary/20 border-t-primary animate-spin" />
      </div>
    );
  }

  const name = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "Utilizador";
  const initials = name.split(" ").map((n: string) => n[0]).slice(0, 2).join("").toUpperCase();
  const crumbs = pathname.split("/").filter(Boolean);
  const currentLabel = routeLabels[crumbs[crumbs.length - 1]] ?? "Painel";

  const q = query.trim().toLowerCase();
  const filteredGroups = groups
    .filter(g => !g.adminOnly || role === "admin")
    .map(g => ({
      ...g,
      items: g.items
        .filter(i => !i.adminOnly || role === "admin")
        .filter(i => !q || i.label.toLowerCase().includes(q)),
    }))
    .filter(g => g.items.length > 0);


  return (
    <div className="min-h-screen bg-[#fafaf7] dark:bg-[#0f0f0f] text-foreground flex flex-col">
      {/* ─── Top bar ─────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#161616]/95 backdrop-blur border-b border-black/5 dark:border-white/5">
        <div className="flex items-center justify-between px-4 h-14">
          <button
            onClick={() => setMenuOpen(true)}
            aria-label="Abrir menu"
            className="h-10 w-10 -ml-2 rounded-full flex items-center justify-center active:bg-black/5 dark:active:bg-white/10 transition"
          >
            <Menu className="h-5 w-5" />
          </button>

          <div className="flex flex-col items-center leading-tight">
            <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              {role === "admin" ? "Admin" : "Colaborador"}
            </span>
            <span className="text-[15px] font-semibold">{currentLabel}</span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => navigate("/admin/notificacoes")}
              aria-label="Notificações"
              className="h-10 w-10 rounded-full flex items-center justify-center active:bg-black/5 dark:active:bg-white/10 transition"
            >
              <Bell className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* ─── Main content ────────────────────────────────────── */}
      <main className="flex-1 px-4 pt-4 pb-28 overflow-y-auto">
        <Outlet />
      </main>

      {/* ─── Bottom tab bar (quick access) ───────────────────── */}
      <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/95 dark:bg-[#161616]/95 backdrop-blur border-t border-black/5 dark:border-white/5 pb-[env(safe-area-inset-bottom)]">
        <div className="grid grid-cols-4">
          {quickNav.map(item => {
            const Icon = item.icon;
            const active = item.end ? pathname === item.to : pathname.startsWith(item.to);
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className="flex flex-col items-center justify-center gap-1 py-2.5 active:bg-black/5 dark:active:bg-white/10 transition"
              >
                <Icon className={`h-5 w-5 ${active ? "text-primary" : "text-muted-foreground"}`} />
                <span className={`text-[10.5px] ${active ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                  {item.label}
                </span>
              </NavLink>
            );
          })}
        </div>
      </nav>

      {/* ─── Slide-in menu ───────────────────────────────────── */}
      {menuOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
          onClick={() => setMenuOpen(false)}
        >
          <aside
            className="absolute inset-y-0 left-0 w-[88%] max-w-sm bg-white dark:bg-[#161616] flex flex-col shadow-2xl animate-in slide-in-from-left duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* user header */}
            <div className="px-5 pt-5 pb-4 border-b border-black/5 dark:border-white/5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="h-11 w-11 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{initials}</span>
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold truncate">{name}</p>
                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                      {role === "admin" ? "Administrador" : "Colaborador"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setMenuOpen(false)}
                  aria-label="Fechar"
                  className="h-9 w-9 rounded-full flex items-center justify-center active:bg-black/5 dark:active:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Procurar página…"
                  className="w-full h-10 pl-9 pr-3 rounded-xl bg-black/[0.04] dark:bg-white/[0.05] text-sm border-0 focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
            </div>

            {/* nav list */}
            <div className="flex-1 overflow-y-auto py-2">
              {filteredGroups.length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-8">Nada encontrado</p>
              )}
              {filteredGroups.map((g) => (
                <div key={g.label} className="mb-2">
                  <p className="px-5 pt-3 pb-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-muted-foreground/70">
                    {g.label}
                  </p>
                  {g.items.map((item) => {
                    const Icon = item.icon;
                    return (
                      <NavLink
                        key={item.to}
                        to={item.to}
                        end={item.end}
                        className={({ isActive }) =>
                          `flex items-center gap-3 px-5 py-3 text-[14px] transition active:bg-black/5 dark:active:bg-white/10 ${
                            isActive
                              ? "bg-primary/8 text-primary font-semibold border-l-[3px] border-primary"
                              : "text-foreground/80 border-l-[3px] border-transparent"
                          }`
                        }
                      >
                        <Icon className="h-[18px] w-[18px] shrink-0" />
                        <span className="flex-1">{item.label}</span>
                        <ChevronRight className="h-4 w-4 text-muted-foreground/40" />
                      </NavLink>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* footer actions */}
            <div className="border-t border-black/5 dark:border-white/5 p-2">
              <button
                onClick={() => { setMenuOpen(false); navigate("/admin/problemas"); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[13.5px] text-foreground/80 hover:bg-black/5 dark:hover:bg-white/5 transition"
              >
                <Bug className="h-4 w-4" /> Reportar problema
              </button>
              <a
                href="/"
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[13.5px] text-foreground/80 hover:bg-black/5 dark:hover:bg-white/5 transition"
              >
                <ExternalLink className="h-4 w-4" /> Ver site público
              </a>
              <button
                onClick={signOut}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[13.5px] text-red-600 dark:text-red-400 hover:bg-red-500/5 transition"
              >
                <LogOut className="h-4 w-4" /> Terminar sessão
              </button>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
};
