import { ReactNode } from "react";

export const PageHeader = ({ title, action, description }: { title: string; description?: string; action?: ReactNode }) => (
  <div className="flex items-start justify-between mb-6 gap-4">
    <div>
      <h1 className="font-display text-3xl">{title}</h1>
      {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
    </div>
    {action}
  </div>
);
