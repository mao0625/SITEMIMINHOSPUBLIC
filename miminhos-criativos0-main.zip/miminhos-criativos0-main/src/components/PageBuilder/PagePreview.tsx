import React from 'react';
import { Page, PageBlock } from '@/types/pageBuilder';

interface PagePreviewProps {
  page: Page;
  blocks: PageBlock[];
}

export const PagePreview: React.FC<PagePreviewProps> = ({ page, blocks }) => {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="bg-gray-100 p-4 border-b">
        <h3 className="font-semibold text-sm">Preview</h3>
      </div>
      <div className="p-4 overflow-y-auto max-h-[500px]">
        <div className="space-y-4">
          {blocks.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No blocks to preview</p>
          ) : (
            blocks.map((block) => (
              <div
                key={block.id}
                className="p-4 rounded border"
                style={{ backgroundColor: block.styles?.backgroundColor || '#f3f4f6' }}
              >
                <h4 className="font-semibold text-sm capitalize">{block.type}</h4>
                <p className="text-xs text-gray-600 mt-1">{block.properties?.title || 'Block'}</p>
                {block.properties?.content && (
                  <p className="text-xs mt-2 line-clamp-2">{block.properties.content}</p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
