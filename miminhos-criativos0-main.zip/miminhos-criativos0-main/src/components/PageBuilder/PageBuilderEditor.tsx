import React, { useState, useEffect } from 'react';
import { Page, PageBlock, BlockType } from '@/types/pageBuilder';
import { pageBuilderService } from '@/lib/pageBuilderService';
import { DraggableBlock } from './DraggableBlock';
import { BlockEditor } from './BlockEditor';
import { PagePreview } from './PagePreview';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Save, Plus, Loader } from 'lucide-react';

interface PageBuilderEditorProps {
  pageSlug: string;
}

export const PageBuilderEditor: React.FC<PageBuilderEditorProps> = ({ pageSlug }) => {
  const [page, setPage] = useState<Page | null>(null);
  const [blocks, setBlocks] = useState<PageBlock[]>([]);
  const [selectedBlock, setSelectedBlock] = useState<PageBlock | null>(null);
  const [isBlockEditorOpen, setIsBlockEditorOpen] = useState(false);
  const [selectedBlockType, setSelectedBlockType] = useState<BlockType>('section');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const blockTypes: BlockType[] = ['hero', 'section', 'card', 'gallery', 'form', 'testimonial', 'cta', 'text'];

  useEffect(() => {
    loadPage();
  }, [pageSlug]);

  const loadPage = async () => {
    try {
      setIsLoading(true);
      const pageData = await pageBuilderService.getPageBySlug(pageSlug);
      setPage(pageData);
      setBlocks(pageData.blocks || []);
    } catch (error) {
      toast.error('Failed to load page');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const addBlock = async () => {
    if (!page) return;

    try {
      const newBlock = await pageBuilderService.createBlock({
        page_id: page.id,
        type: selectedBlockType,
        order: blocks.length,
        properties: {
          title: `New ${selectedBlockType}`,
        },
        styles: {
          backgroundColor: '#ffffff',
          textColor: '#000000',
          padding: '16px',
        },
      } as any);

      setBlocks([...blocks, newBlock]);
      toast.success('Block added');
    } catch (error) {
      toast.error('Failed to add block');
      console.error(error);
    }
  };

  const updateBlock = async (updatedBlock: PageBlock) => {
    try {
      await pageBuilderService.updateBlock(updatedBlock.id, updatedBlock);
      setBlocks(blocks.map((b) => (b.id === updatedBlock.id ? updatedBlock : b)));
      toast.success('Block updated');
    } catch (error) {
      toast.error('Failed to update block');
      console.error(error);
    }
  };

  const deleteBlock = async (blockId: string) => {
    try {
      await pageBuilderService.deleteBlock(blockId);
      setBlocks(blocks.filter((b) => b.id !== blockId));
      toast.success('Block deleted');
    } catch (error) {
      toast.error('Failed to delete block');
      console.error(error);
    }
  };

  const handleDragEnd = (draggedBlock: PageBlock, targetIndex: number) => {
    const sourceIndex = blocks.findIndex((b) => b.id === draggedBlock.id);
    if (sourceIndex === -1 || sourceIndex === targetIndex) return;

    const newBlocks = [...blocks];
    newBlocks.splice(sourceIndex, 1);
    newBlocks.splice(targetIndex, 0, draggedBlock);
    setBlocks(newBlocks);
  };

  const savePage = async () => {
    if (!page) return;

    try {
      setIsSaving(true);
      await pageBuilderService.updatePage(page.id, {
        ...page,
        updated_at: new Date().toISOString(),
      });
      await pageBuilderService.reorderBlocks(
        page.id,
        blocks
      );
      toast.success('Page saved');
    } catch (error) {
      toast.error('Failed to save page');
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  };

  const publishAndDeploy = async () => {
    if (!page) return;

    try {
      setIsPublishing(true);
      await pageBuilderService.publishPage(page.id);
      await pageBuilderService.triggerDeploy(page.id);
      toast.success('✅ Page published and deployed to Lovable!');
      setPage({ ...page, is_published: true });
    } catch (error) {
      toast.error('Failed to publish and deploy');
      console.error(error);
    } finally {
      setIsPublishing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!page) {
    return <div className="p-6 text-center text-gray-500">Page not found</div>;
  }

  return (
    <div className="grid grid-cols-3 gap-6 p-6 min-h-screen bg-gray-50">
      {/* Left Panel - Blocks */}
      <div className="col-span-2 space-y-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h1 className="text-2xl font-bold">{page.title}</h1>
              <p className="text-sm text-gray-500 mt-1">/{page.slug}</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={savePage}
                disabled={isSaving}
                className="gap-2"
              >
                <Save className="w-4 h-4" />
                {isSaving ? 'Saving...' : 'Save'}
              </Button>
              <Button
                onClick={publishAndDeploy}
                disabled={isPublishing}
                className="gap-2 bg-green-600 hover:bg-green-700"
              >
                {isPublishing ? 'Publishing...' : '🚀 Publish & Deploy'}
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <Label>Add Block</Label>
                <Select value={selectedBlockType} onValueChange={(value) => setSelectedBlockType(value as BlockType)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {blockTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button onClick={addBlock} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add Block
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Blocks ({blocks.length})</h2>
          <div className="space-y-2">
            {blocks.length === 0 ? (
              <p className="text-gray-500 text-sm">No blocks yet. Add one to get started!</p>
            ) : (
              blocks.map((block) => (
                <DraggableBlock
                  key={block.id}
                  block={block}
                  onEdit={(block) => {
                    setSelectedBlock(block);
                    setIsBlockEditorOpen(true);
                  }}
                  onDelete={deleteBlock}
                />
              ))
            )}
          </div>
        </div>
      </div>

      {/* Right Panel - Preview */}
      <div className="space-y-6">
        <div className="sticky top-6">
          <PagePreview page={page} blocks={blocks} />
        </div>
      </div>

      {/* Block Editor Modal */}
      <BlockEditor
        block={selectedBlock}
        isOpen={isBlockEditorOpen}
        onClose={() => {
          setIsBlockEditorOpen(false);
          setSelectedBlock(null);
        }}
        onSave={updateBlock}
      />
    </div>
  );
};
