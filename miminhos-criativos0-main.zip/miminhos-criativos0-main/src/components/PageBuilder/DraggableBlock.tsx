import React from 'react';
import { PageBlock } from '@/types/pageBuilder';
import { Button } from '@/components/ui/button';
import { Trash2, Edit } from 'lucide-react';

interface DraggableBlockProps {
  block: PageBlock;
  onEdit: (block: PageBlock) => void;
  onDelete: (blockId: string) => void;
}

export const DraggableBlock: React.FC<DraggableBlockProps> = ({ block, onEdit, onDelete }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-shadow cursor-move">
      <div className="flex-1">
        <h3 className="font-semibold text-sm capitalize">{block.type}</h3>
        <p className="text-xs text-gray-500">{block.properties?.title || 'Block'}</p>
      </div>
      <div className="flex gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => onEdit(block)}
          className="gap-1"
        >
          <Edit className="w-3 h-3" />
          Edit
        </Button>
        <Button
          size="sm"
          variant="destructive"
          onClick={() => onDelete(block.id)}
          className="gap-1"
        >
          <Trash2 className="w-3 h-3" />
          Delete
        </Button>
      </div>
    </div>
  );
};
