import React, { useState } from 'react';
import { PageBlock } from '@/types/pageBuilder';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface BlockEditorProps {
  block: PageBlock | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (block: PageBlock) => void;
}

export const BlockEditor: React.FC<BlockEditorProps> = ({ block, isOpen, onClose, onSave }) => {
  const [editedBlock, setEditedBlock] = useState<PageBlock | null>(block);

  React.useEffect(() => {
    setEditedBlock(block);
  }, [block]);

  if (!editedBlock) return null;

  const handleSave = () => {
    onSave(editedBlock);
    onClose();
  };

  const handlePropertyChange = (key: string, value: any) => {
    setEditedBlock({
      ...editedBlock,
      properties: {
        ...editedBlock.properties,
        [key]: value,
      },
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Block</DialogTitle>
          <DialogDescription>
            Modify the properties of this {editedBlock.type} block
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="title" className="text-right">
              Title
            </Label>
            <Input
              id="title"
              value={editedBlock.properties?.title || ''}
              onChange={(e) => handlePropertyChange('title', e.target.value)}
              className="col-span-3"
            />
          </div>
          <div>
            <Label htmlFor="content" className="text-right">
              Content
            </Label>
            <Textarea
              id="content"
              value={editedBlock.properties?.content || ''}
              onChange={(e) => handlePropertyChange('content', e.target.value)}
              className="col-span-3"
              rows={4}
            />
          </div>
          <div>
            <Label htmlFor="backgroundColor" className="text-right">
              Background Color
            </Label>
            <Input
              id="backgroundColor"
              type="color"
              value={editedBlock.styles?.backgroundColor || '#ffffff'}
              onChange={(e) => setEditedBlock({
                ...editedBlock,
                styles: { ...editedBlock.styles, backgroundColor: e.target.value }
              })}
              className="col-span-3 h-10"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" onClick={handleSave}>
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
