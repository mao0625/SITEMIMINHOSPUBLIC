import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

export const CookieBanner = () => {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!localStorage.getItem("mc-cookies")) setShow(true);
  }, []);
  if (!show) return null;
  return (
    <div className="fixed bottom-0 inset-x-0 z-50 bg-dark text-white p-4 shadow-elegant">
      <div className="container flex flex-col md:flex-row items-center gap-4">
        <p className="text-sm flex-1">
          Utilizamos cookies para melhorar a sua experiência. Ao continuar a navegar, aceita a nossa política.
        </p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="border-white/30 text-white hover:bg-white/10" onClick={() => { localStorage.setItem("mc-cookies", "rejected"); setShow(false); }}>Recusar</Button>
          <Button size="sm" className="bg-gradient-gold" onClick={() => { localStorage.setItem("mc-cookies", "accepted"); setShow(false); }}>Aceitar</Button>
        </div>
      </div>
    </div>
  );
};
