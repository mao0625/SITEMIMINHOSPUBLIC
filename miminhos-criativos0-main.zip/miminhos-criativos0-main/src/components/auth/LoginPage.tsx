import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import heroBg from "@/assets/703861483_18091779854265014_4509197079429811173_n.jpg";

interface Props {
  title: string;
  subtitle: string;
  redirectTo?: string;
}

export const LoginPage = ({ title, subtitle, redirectTo = "/cliente" }: Props) => {
  const navigate = useNavigate();
  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const isEmail = (value: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  const isPhone = (value: string) => /^\d{9,}$/.test(value.replace(/\s|-/g, ""));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      let email = emailOrPhone;
      // Se for telefone, busca o email associado via RPC seguro
      if (isPhone(emailOrPhone)) {
        const normalized = emailOrPhone.replace(/\D/g, "");
        const { data: foundEmail } = await supabase
          .rpc("get_email_by_phone", { _phone: normalized });
        if (foundEmail) {
          email = foundEmail as string;
        } else {
          // Fallback: procura na tabela profiles
          const { data: profileRow } = await supabase
            .from("profiles")
            .select("email")
            .eq("phone", normalized)
            .maybeSingle();
          if (profileRow?.email) {
            email = profileRow.email;
          } else {
            setLoading(false);
            toast.error("Telefone não encontrado. Tenta com o email.");
            return;
          }
        }
      }
      // Login com email
      const { error, data } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      setLoading(false);
      if (error) {
        toast.error("Email ou password incorretos");
        return;
      }
      toast.success("Bem-vinda! 💛");
      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", data.user.id)
        .single();
      const role = roleData?.role;
      if (role === "admin" || role === "colaborador") {
        navigate("/admin");
      } else {
        navigate(redirectTo);
      }
    } catch (error) {
      setLoading(false);
      toast.error("Erro ao fazer login");
    }
  };

  const getInputType = () => {
    if (!emailOrPhone) return "text";
    if (isEmail(emailOrPhone)) return "email";
    return "tel";
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">

      {/* Left — image, full-bleed, quiet */}
      <div className="hidden lg:block relative overflow-hidden">
        <img
          src={heroBg}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-dark/70 via-dark/10 to-transparent" />
        <div className="absolute bottom-12 left-12 right-12">
          <p className="font-script text-3xl text-white mb-2 animate-fade-up" style={{ animationDelay: "0.1s" }}>
            A festa é sua
          </p>
          <h2 className="font-display text-4xl text-white leading-tight animate-fade-up" style={{ animationDelay: "0.2s" }}>
            O prazer em criar<br />é nosso.
          </h2>
        </div>
      </div>

      {/* Right — form, type-led, generous spacing */}
      <div className="flex items-center justify-center p-6 sm:p-10 lg:p-16 bg-gradient-champagne lg:bg-background">
        <div className="w-full max-w-sm animate-fade-up">

          <div className="mb-10 text-center lg:text-left">
            <Logo className="h-16 mx-auto lg:mx-0 mb-6" variant="dark" />
            <h1 className="font-display text-4xl md:text-5xl tracking-tight mb-2">{title}</h1>
            <p className="font-script text-xl text-primary">{subtitle}</p>
          </div>

          <form onSubmit={onSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <Label>Email ou Telefone</Label>
              <Input
                type={getInputType()}
                inputMode={/^[\d\s+-]*$/.test(emailOrPhone) && emailOrPhone.length > 0 ? "tel" : "text"}
                placeholder="exemplo@email.com ou 926992352"
                required
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                className="h-12 rounded-xl"
                autoComplete="username"
              />
              <p className="text-xs text-muted-foreground min-h-[1rem]">
                {emailOrPhone && (
                  <>
                    {isEmail(emailOrPhone) ? "✓ Email detetado" : ""}
                    {isPhone(emailOrPhone) ? "✓ Telefone detetado" : ""}
                    {!isEmail(emailOrPhone) && !isPhone(emailOrPhone) ? "Introduza um email ou telefone válido" : ""}
                  </>
                )}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label>Password</Label>
              <Input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 rounded-xl"
              />
            </div>
            <Button
              type="submit"
              disabled={loading || !emailOrPhone || !password}
              className="bg-gradient-gold w-full h-12 rounded-xl text-base shadow-gold"
            >
              {loading ? "A entrar..." : "Entrar"}
            </Button>
          </form>

          <div className="text-center mt-8 text-sm">
            <Link to="/" className="text-muted-foreground hover:text-primary transition-smooth">
              ← Voltar ao site
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
