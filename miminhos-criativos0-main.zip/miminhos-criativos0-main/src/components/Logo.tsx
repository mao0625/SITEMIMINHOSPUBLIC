import logo from "@/assets/logo.png";

interface Props {
  className?: string;
  variant?: "light" | "dark";
}

export const Logo = ({ className = "h-12", variant = "light" }: Props) => (
  <img
    src={logo}
    alt="Miminhos Criativos"
    className={`${className} object-contain ${variant === "dark" ? "" : "invert-0"}`}
    style={variant === "dark" ? { filter: "brightness(0) saturate(100%) invert(70%) sepia(40%) saturate(500%) hue-rotate(15deg)" } : undefined}
  />
);
