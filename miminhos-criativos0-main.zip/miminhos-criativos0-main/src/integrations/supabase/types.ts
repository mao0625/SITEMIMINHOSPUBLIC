export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      blog_posts: {
        Row: {
          content: string | null
          cover_url: string | null
          created_at: string
          excerpt: string | null
          id: string
          published: boolean
          published_at: string | null
          slug: string
          title: string
          updated_at: string
        }
        Insert: {
          content?: string | null
          cover_url?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          published?: boolean
          published_at?: string | null
          slug: string
          title: string
          updated_at?: string
        }
        Update: {
          content?: string | null
          cover_url?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          published?: boolean
          published_at?: string | null
          slug?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      bug_reports: {
        Row: {
          concluded_at: string | null
          created_at: string | null
          description: string
          id: string
          reporter_email: string | null
          reporter_id: string | null
          reporter_name: string | null
          status: string
          title: string
          type: string
          type_other: string | null
        }
        Insert: {
          concluded_at?: string | null
          created_at?: string | null
          description: string
          id?: string
          reporter_email?: string | null
          reporter_id?: string | null
          reporter_name?: string | null
          status?: string
          title: string
          type?: string
          type_other?: string | null
        }
        Update: {
          concluded_at?: string | null
          created_at?: string | null
          description?: string
          id?: string
          reporter_email?: string | null
          reporter_id?: string | null
          reporter_name?: string | null
          status?: string
          title?: string
          type?: string
          type_other?: string | null
        }
        Relationships: []
      }
      event_expenses: {
        Row: {
          amount: number
          category: string | null
          created_at: string
          created_by: string | null
          description: string
          event_id: string
          expense_date: string | null
          id: string
        }
        Insert: {
          amount?: number
          category?: string | null
          created_at?: string
          created_by?: string | null
          description: string
          event_id: string
          expense_date?: string | null
          id?: string
        }
        Update: {
          amount?: number
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string
          event_id?: string
          expense_date?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_expenses_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      event_notes: {
        Row: {
          author_id: string
          checked: boolean | null
          content: string
          created_at: string
          created_by: string | null
          event_id: string
          id: string
        }
        Insert: {
          author_id: string
          checked?: boolean | null
          content: string
          created_at?: string
          created_by?: string | null
          event_id: string
          id?: string
        }
        Update: {
          author_id?: string
          checked?: boolean | null
          content?: string
          created_at?: string
          created_by?: string | null
          event_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_notes_author_fk"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "event_notes_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      event_reviews: {
        Row: {
          client_id: string
          comment: string | null
          created_at: string
          event_id: string | null
          id: string
          is_public: boolean
          rating: number
          updated_at: string
        }
        Insert: {
          client_id: string
          comment?: string | null
          created_at?: string
          event_id?: string | null
          id?: string
          is_public?: boolean
          rating: number
          updated_at?: string
        }
        Update: {
          client_id?: string
          comment?: string | null
          created_at?: string
          event_id?: string | null
          id?: string
          is_public?: boolean
          rating?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_reviews_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          assigned_collaborator_id: string | null
          budget: number | null
          client_id: string | null
          created_at: string
          delivery_address: string | null
          estado_pagamento: string | null
          event_date: string | null
          event_type: string | null
          event_type_other: string | null
          guests_count: number | null
          id: string
          location: string | null
          notes: string | null
          payment_value: number | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_collaborator_id?: string | null
          budget?: number | null
          client_id?: string | null
          created_at?: string
          delivery_address?: string | null
          estado_pagamento?: string | null
          event_date?: string | null
          event_type?: string | null
          event_type_other?: string | null
          guests_count?: number | null
          id?: string
          location?: string | null
          notes?: string | null
          payment_value?: number | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_collaborator_id?: string | null
          budget?: number | null
          client_id?: string | null
          created_at?: string
          delivery_address?: string | null
          estado_pagamento?: string | null
          event_date?: string | null
          event_type?: string | null
          event_type_other?: string | null
          guests_count?: number | null
          id?: string
          location?: string | null
          notes?: string | null
          payment_value?: number | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      faqs: {
        Row: {
          answer: string
          created_at: string | null
          id: string
          order: number | null
          question: string
        }
        Insert: {
          answer: string
          created_at?: string | null
          id?: string
          order?: number | null
          question: string
        }
        Update: {
          answer?: string
          created_at?: string | null
          id?: string
          order?: number | null
          question?: string
        }
        Relationships: []
      }
      gallery_items: {
        Row: {
          category: string | null
          created_at: string
          display_order: number | null
          id: string
          image_url: string
          title: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          display_order?: number | null
          id?: string
          image_url: string
          title?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string
          display_order?: number | null
          id?: string
          image_url?: string
          title?: string | null
        }
        Relationships: []
      }
      materials: {
        Row: {
          category: string | null
          created_at: string
          id: string
          min_quantity: number
          name: string
          notes: string | null
          quantity: number
          unit: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          id?: string
          min_quantity?: number
          name: string
          notes?: string | null
          quantity?: number
          unit?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          id?: string
          min_quantity?: number
          name?: string
          notes?: string | null
          quantity?: number
          unit?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string
          created_at: string
          event_id: string | null
          id: string
          read: boolean
          recipient_id: string | null
          sender_id: string
        }
        Insert: {
          body: string
          created_at?: string
          event_id?: string | null
          id?: string
          read?: boolean
          recipient_id?: string | null
          sender_id: string
        }
        Update: {
          body?: string
          created_at?: string
          event_id?: string | null
          id?: string
          read?: boolean
          recipient_id?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_permissions: {
        Row: {
          can_send: boolean | null
          created_at: string | null
          granted_by: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          can_send?: boolean | null
          created_at?: string | null
          granted_by?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          can_send?: boolean | null
          created_at?: string | null
          granted_by?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      pos_loyalty: {
        Row: {
          client_id: string
          created_at: string | null
          discounts_used: number | null
          id: string
          last_discount_at: string | null
          total_events: number | null
        }
        Insert: {
          client_id: string
          created_at?: string | null
          discounts_used?: number | null
          id?: string
          last_discount_at?: string | null
          total_events?: number | null
        }
        Update: {
          client_id?: string
          created_at?: string | null
          discounts_used?: number | null
          id?: string
          last_discount_at?: string | null
          total_events?: number | null
        }
        Relationships: []
      }
      pos_operations: {
        Row: {
          amount_paid: number | null
          change_given: number | null
          client_id: string | null
          client_name: string | null
          created_at: string | null
          created_by: string | null
          discount_reason: string | null
          discount_value: number | null
          event_id: string | null
          event_title: string | null
          finalized_at: string | null
          id: string
          items: Json | null
          loyalty_discount: number | null
          mbway_number: string | null
          operation_number: string
          payment_method: string | null
          payment_status: string | null
          promotion_id: string | null
          questionnaire_id: string | null
          status: string | null
          subtotal: number | null
          total: number | null
        }
        Insert: {
          amount_paid?: number | null
          change_given?: number | null
          client_id?: string | null
          client_name?: string | null
          created_at?: string | null
          created_by?: string | null
          discount_reason?: string | null
          discount_value?: number | null
          event_id?: string | null
          event_title?: string | null
          finalized_at?: string | null
          id?: string
          items?: Json | null
          loyalty_discount?: number | null
          mbway_number?: string | null
          operation_number: string
          payment_method?: string | null
          payment_status?: string | null
          promotion_id?: string | null
          questionnaire_id?: string | null
          status?: string | null
          subtotal?: number | null
          total?: number | null
        }
        Update: {
          amount_paid?: number | null
          change_given?: number | null
          client_id?: string | null
          client_name?: string | null
          created_at?: string | null
          created_by?: string | null
          discount_reason?: string | null
          discount_value?: number | null
          event_id?: string | null
          event_title?: string | null
          finalized_at?: string | null
          id?: string
          items?: Json | null
          loyalty_discount?: number | null
          mbway_number?: string | null
          operation_number?: string
          payment_method?: string | null
          payment_status?: string | null
          promotion_id?: string | null
          questionnaire_id?: string | null
          status?: string | null
          subtotal?: number | null
          total?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "pos_operations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pos_operations_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "pos_promotions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pos_operations_questionnaire_id_fkey"
            columns: ["questionnaire_id"]
            isOneToOne: false
            referencedRelation: "questionnaires"
            referencedColumns: ["id"]
          },
        ]
      }
      pos_products: {
        Row: {
          active: boolean | null
          category: string | null
          created_at: string | null
          id: string
          name: string
          price: number
        }
        Insert: {
          active?: boolean | null
          category?: string | null
          created_at?: string | null
          id?: string
          name: string
          price?: number
        }
        Update: {
          active?: boolean | null
          category?: string | null
          created_at?: string | null
          id?: string
          name?: string
          price?: number
        }
        Relationships: []
      }
      pos_promotions: {
        Row: {
          active: boolean | null
          created_at: string | null
          description: string | null
          discount_type: string | null
          discount_value: number
          id: string
          name: string
        }
        Insert: {
          active?: boolean | null
          created_at?: string | null
          description?: string | null
          discount_type?: string | null
          discount_value?: number
          id?: string
          name: string
        }
        Update: {
          active?: boolean | null
          created_at?: string | null
          description?: string | null
          discount_type?: string | null
          discount_value?: number
          id?: string
          name?: string
        }
        Relationships: []
      }
      pos_settings: {
        Row: {
          id: string
          invoice_enabled: boolean | null
          loyalty_discount_value: number | null
          loyalty_enabled: boolean | null
          loyalty_events_threshold: number | null
          updated_at: string | null
        }
        Insert: {
          id?: string
          invoice_enabled?: boolean | null
          loyalty_discount_value?: number | null
          loyalty_enabled?: boolean | null
          loyalty_events_threshold?: number | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          invoice_enabled?: boolean | null
          loyalty_discount_value?: number | null
          loyalty_enabled?: boolean | null
          loyalty_events_threshold?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          assigned_collaborator_id: string | null
          client_number: number | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          must_change_password: boolean
          nif: string | null
          phone: string | null
          profile_photo_url: string | null
          status: string
          updated_at: string
        }
        Insert: {
          assigned_collaborator_id?: string | null
          client_number?: number | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          must_change_password?: boolean
          nif?: string | null
          phone?: string | null
          profile_photo_url?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          assigned_collaborator_id?: string | null
          client_number?: number | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          must_change_password?: boolean
          nif?: string | null
          phone?: string | null
          profile_photo_url?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      questionnaires: {
        Row: {
          answers: Json
          client_id: string
          created_at: string
          estado_pagamento: string | null
          event_date: string | null
          event_id: string | null
          event_title: string | null
          id: string
          orcamento: Json | null
          reference_number: string | null
          status: string
          submitted_at: string | null
          updated_at: string
        }
        Insert: {
          answers?: Json
          client_id: string
          created_at?: string
          estado_pagamento?: string | null
          event_date?: string | null
          event_id?: string | null
          event_title?: string | null
          id?: string
          orcamento?: Json | null
          reference_number?: string | null
          status?: string
          submitted_at?: string | null
          updated_at?: string
        }
        Update: {
          answers?: Json
          client_id?: string
          created_at?: string
          estado_pagamento?: string | null
          event_date?: string | null
          event_id?: string | null
          event_title?: string | null
          id?: string
          orcamento?: Json | null
          reference_number?: string | null
          status?: string
          submitted_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "questionnaires_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      quote_requests: {
        Row: {
          assigned_collaborator_id: string | null
          created_at: string
          email: string
          event_date: string | null
          event_type: string | null
          guests_count: number | null
          id: string
          message: string | null
          name: string
          phone: string
          status: string
        }
        Insert: {
          assigned_collaborator_id?: string | null
          created_at?: string
          email: string
          event_date?: string | null
          event_type?: string | null
          guests_count?: number | null
          id?: string
          message?: string | null
          name: string
          phone: string
          status?: string
        }
        Update: {
          assigned_collaborator_id?: string | null
          created_at?: string
          email?: string
          event_date?: string | null
          event_type?: string | null
          guests_count?: number | null
          id?: string
          message?: string | null
          name?: string
          phone?: string
          status?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          coming_soon_message: string | null
          coming_soon_mode: boolean
          coming_soon_title: string | null
          contact_address: string | null
          contact_email: string | null
          contact_phone: string | null
          id: number
          maintenance_message: string | null
          maintenance_mode: boolean
          updated_at: string
        }
        Insert: {
          coming_soon_message?: string | null
          coming_soon_mode?: boolean
          coming_soon_title?: string | null
          contact_address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          id?: number
          maintenance_message?: string | null
          maintenance_mode?: boolean
          updated_at?: string
        }
        Update: {
          coming_soon_message?: string | null
          coming_soon_mode?: boolean
          coming_soon_title?: string | null
          contact_address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          id?: number
          maintenance_message?: string | null
          maintenance_mode?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      staff_broadcasts: {
        Row: {
          body: string
          created_at: string | null
          id: string
          sender_id: string | null
          sender_name: string | null
          target: string | null
          title: string
        }
        Insert: {
          body: string
          created_at?: string | null
          id?: string
          sender_id?: string | null
          sender_name?: string | null
          target?: string | null
          title: string
        }
        Update: {
          body?: string
          created_at?: string | null
          id?: string
          sender_id?: string | null
          sender_name?: string | null
          target?: string | null
          title?: string
        }
        Relationships: []
      }
      user_phone_mappings: {
        Row: {
          created_at: string | null
          email: string
          id: string
          phone: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          email: string
          id?: string
          phone: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          email?: string
          id?: string
          phone?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      webmail_accounts: {
        Row: {
          active: boolean | null
          address: string
          created_at: string | null
          display_name: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          active?: boolean | null
          address: string
          created_at?: string | null
          display_name?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          active?: boolean | null
          address?: string
          created_at?: string | null
          display_name?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      webmail_messages: {
        Row: {
          body: string
          created_at: string | null
          from_account_id: string | null
          id: string
          is_to_client: boolean | null
          read: boolean | null
          subject: string
          to_account_id: string | null
          to_client_id: string | null
        }
        Insert: {
          body: string
          created_at?: string | null
          from_account_id?: string | null
          id?: string
          is_to_client?: boolean | null
          read?: boolean | null
          subject: string
          to_account_id?: string | null
          to_client_id?: string | null
        }
        Update: {
          body?: string
          created_at?: string | null
          from_account_id?: string | null
          id?: string
          is_to_client?: boolean | null
          read?: boolean | null
          subject?: string
          to_account_id?: string | null
          to_client_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "webmail_messages_from_account_id_fkey"
            columns: ["from_account_id"]
            isOneToOne: false
            referencedRelation: "webmail_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "webmail_messages_to_account_id_fkey"
            columns: ["to_account_id"]
            isOneToOne: false
            referencedRelation: "webmail_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_email_by_phone: { Args: { _phone: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
      is_staff: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "colaborador" | "cliente"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "colaborador", "cliente"],
    },
  },
} as const
