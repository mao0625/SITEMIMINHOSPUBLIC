
-- 1. Remove dangerous public read policy on user_phone_mappings
DROP POLICY IF EXISTS "Allow public read for login" ON public.user_phone_mappings;
DROP POLICY IF EXISTS "Allow users to read their own phone mapping" ON public.user_phone_mappings;
DROP POLICY IF EXISTS "Allow users to update their own phone mapping" ON public.user_phone_mappings;
DROP POLICY IF EXISTS "Allow users to delete their own phone mapping" ON public.user_phone_mappings;

CREATE POLICY "Users read own phone mapping"
  ON public.user_phone_mappings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users update own phone mapping"
  ON public.user_phone_mappings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users delete own phone mapping"
  ON public.user_phone_mappings FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Secure RPC for phone→email lookup at login (callable by anon, returns only email)
CREATE OR REPLACE FUNCTION public.get_email_by_phone(_phone text)
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT email FROM public.user_phone_mappings
  WHERE phone = regexp_replace(_phone, '\D', '', 'g')
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.get_email_by_phone(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_email_by_phone(text) TO anon, authenticated;

-- 2. Fix event_notes: scope public-role policies to authenticated
DROP POLICY IF EXISTS "Staff pode inserir notas" ON public.event_notes;
DROP POLICY IF EXISTS "Staff pode atualizar notas" ON public.event_notes;
DROP POLICY IF EXISTS "Staff pode eliminar notas" ON public.event_notes;
DROP POLICY IF EXISTS "Staff pode ver notas" ON public.event_notes;

CREATE POLICY "Staff insert notas" ON public.event_notes
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'colaborador'::app_role));

CREATE POLICY "Staff update notas" ON public.event_notes
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'colaborador'::app_role));

CREATE POLICY "Staff delete notas" ON public.event_notes
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'colaborador'::app_role));

CREATE POLICY "Staff select notas" ON public.event_notes
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'colaborador'::app_role));

-- 3. Avatars storage path scoping
DROP POLICY IF EXISTS "Users write own avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users update own avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users delete own avatar" ON storage.objects;

CREATE POLICY "Users write own avatar" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users update own avatar" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users delete own avatar" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

-- 4. Function search_path fixes
CREATE OR REPLACE FUNCTION public.generate_reference_number()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.reference_number IS NULL THEN
    NEW.reference_number := 'ORC-' || LPAD(nextval('public.reference_number_seq')::TEXT, 5, '0');
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user_phone_mapping()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_phone_mappings (user_id, phone, email)
  VALUES (
    NEW.id,
    COALESCE(NULLIF(NEW.phone, ''), 'st-' || LEFT(NEW.id::text, 8)),
    COALESCE(NULLIF(NEW.email, ''), '')
  )
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- 5. Revoke EXECUTE on has_role from anon (only authenticated needs it for RLS)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM anon, PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;
