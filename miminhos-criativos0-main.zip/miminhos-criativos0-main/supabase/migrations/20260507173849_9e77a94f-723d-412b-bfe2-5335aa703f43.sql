
-- Materials/stock
CREATE TABLE public.materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category TEXT,
  quantity NUMERIC NOT NULL DEFAULT 0,
  min_quantity NUMERIC NOT NULL DEFAULT 0,
  unit TEXT DEFAULT 'un',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.materials ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage materials" ON public.materials FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'))
  WITH CHECK (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'));
CREATE TRIGGER trg_materials_touch BEFORE UPDATE ON public.materials
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Event expenses
CREATE TABLE public.event_expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  amount NUMERIC NOT NULL DEFAULT 0,
  category TEXT,
  expense_date DATE DEFAULT CURRENT_DATE,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.event_expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff manage expenses" ON public.event_expenses FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'))
  WITH CHECK (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'));

-- Event reviews
CREATE TABLE public.event_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES public.events(id) ON DELETE SET NULL,
  client_id UUID NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  is_public BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.event_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read featured reviews" ON public.event_reviews FOR SELECT TO anon, authenticated
  USING (is_public = true);
CREATE POLICY "Client manage own review" ON public.event_reviews FOR ALL TO authenticated
  USING (client_id = auth.uid() OR has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'))
  WITH CHECK (client_id = auth.uid() OR has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'));
CREATE TRIGGER trg_reviews_touch BEFORE UPDATE ON public.event_reviews
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Delivery address on events
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS delivery_address TEXT;
