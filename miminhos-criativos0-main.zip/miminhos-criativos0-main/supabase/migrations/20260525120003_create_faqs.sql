create table if not exists faqs (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  "order" integer default 0,
  created_at timestamptz default now()
);

alter table faqs enable row level security;

-- Qualquer pessoa pode ler as FAQs (página pública)
create policy "publico pode ler faqs"
  on faqs for select
  to anon, authenticated
  using (true);

-- Só admin e colaborador podem criar/editar/eliminar
create policy "admin pode gerir faqs"
  on faqs for all
  to authenticated
  using (
    exists (
      select 1 from user_roles
      where user_id = auth.uid()
      and role in ('admin', 'colaborador')
    )
  );
