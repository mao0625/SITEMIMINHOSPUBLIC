-- Adiciona coluna NIF à tabela profiles
alter table profiles add column if not exists nif text;
