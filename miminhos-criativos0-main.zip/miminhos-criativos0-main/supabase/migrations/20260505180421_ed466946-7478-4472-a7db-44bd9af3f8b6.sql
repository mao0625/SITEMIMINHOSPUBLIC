
-- 1. Add coming_soon_mode to site_settings
ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS coming_soon_mode boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS coming_soon_title text DEFAULT 'Site brevemente disponível',
  ADD COLUMN IF NOT EXISTS coming_soon_message text DEFAULT 'Estamos a preparar algo especial para si. Em breve!';

-- 2. Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES
  ('gallery', 'gallery', true),
  ('blog', 'blog', true),
  ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- 3. Storage policies — staff can manage
DO $$ BEGIN
  CREATE POLICY "Public read gallery storage" ON storage.objects FOR SELECT USING (bucket_id = 'gallery');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY "Staff write gallery storage" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'gallery' AND (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador')));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY "Staff delete gallery storage" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'gallery' AND (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador')));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Public read blog storage" ON storage.objects FOR SELECT USING (bucket_id = 'blog');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY "Staff write blog storage" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'blog' AND (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador')));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY "Staff delete blog storage" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'blog' AND (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador')));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Public read avatars storage" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY "Auth write avatars storage" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 4. Bootstrap admin account: mao0625@outlook.pt / Mateus2011
DO $$
DECLARE
  uid uuid;
BEGIN
  SELECT id INTO uid FROM auth.users WHERE email = 'mao0625@outlook.pt';
  IF uid IS NULL THEN
    uid := gen_random_uuid();
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, confirmation_token, recovery_token, email_change_token_new, email_change
    ) VALUES (
      '00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated',
      'mao0625@outlook.pt', crypt('Mateus2011', gen_salt('bf')),
      now(), '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"Mateus Admin"}'::jsonb,
      now(), now(), '', '', '', ''
    );
    INSERT INTO auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
    VALUES (gen_random_uuid(), uid, jsonb_build_object('sub', uid::text, 'email', 'mao0625@outlook.pt'), 'email', uid::text, now(), now(), now());
  END IF;
  -- ensure profile + admin role
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (uid, 'Mateus Admin', 'mao0625@outlook.pt')
  ON CONFLICT (id) DO UPDATE SET email = EXCLUDED.email;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (uid, 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;
END $$;

-- 5. Allow recipients of profiles to be visible to staff (for listings)
DO $$ BEGIN
  CREATE POLICY "Staff view all profiles" ON public.profiles FOR SELECT TO authenticated
  USING (has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 6. Allow staff (admin OR colaborador) to insert profiles via edge function calls (was admin-only)
DROP POLICY IF EXISTS "Admins insert profiles" ON public.profiles;
CREATE POLICY "Staff insert profiles" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id OR has_role(auth.uid(),'admin') OR has_role(auth.uid(),'colaborador'));
