-- Permite múltiplos questionários por cliente (remove unique em client_id se existir)
alter table questionnaires drop constraint if exists questionnaires_client_id_key;

-- Garante que answers tem default vazio
alter table questionnaires alter column answers set default '{}'::jsonb;

-- Garante que created_at tem default
alter table questionnaires alter column created_at set default now();

-- Adiciona status "pendente" se a coluna for text (já deve funcionar)
-- Se deres erro aqui, ignora esta linha
-- alter type questionnaire_status add value if not exists 'pendente';
