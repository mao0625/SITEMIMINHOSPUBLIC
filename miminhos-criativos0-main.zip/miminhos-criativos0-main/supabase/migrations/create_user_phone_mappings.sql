-- Create table for phone to email mapping
CREATE TABLE IF NOT EXISTS public.user_phone_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  phone VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create index for faster phone lookups
CREATE INDEX IF NOT EXISTS idx_user_phone_mappings_phone 
ON public.user_phone_mappings(phone);

-- Create index for email lookups
CREATE INDEX IF NOT EXISTS idx_user_phone_mappings_email 
ON public.user_phone_mappings(email);

-- Enable RLS
ALTER TABLE public.user_phone_mappings ENABLE ROW LEVEL SECURITY;

-- Create policy - Allow public read (sem autenticação para login)
CREATE POLICY "Allow public read for login"
  ON public.user_phone_mappings
  FOR SELECT
  USING (true);

-- Create policy - Allow authenticated users to read their own
CREATE POLICY "Allow users to read their own phone mapping"
  ON public.user_phone_mappings
  FOR SELECT
  USING (auth.uid() = user_id);

-- Create policy - Allow authenticated users to update their own
CREATE POLICY "Allow users to update their own phone mapping"
  ON public.user_phone_mappings
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Create policy - Allow authenticated users to delete their own
CREATE POLICY "Allow users to delete their own phone mapping"
  ON public.user_phone_mappings
  FOR DELETE
  USING (auth.uid() = user_id);

-- Add test data (opcional - remova depois)
-- INSERT INTO public.user_phone_mappings (user_id, phone, email)
-- VALUES ('replace-with-real-user-id', '926992352', 'test@example.com');
