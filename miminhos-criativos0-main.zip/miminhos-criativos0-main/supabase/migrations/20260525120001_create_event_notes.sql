create table if not exists event_notes (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references events(id) on delete cascade not null,
  author_id uuid references auth.users(id) on delete set null,
  content text not null,
  created_at timestamptz default now()
);

create index if not exists event_notes_event_id_idx on event_notes(event_id);

alter publication supabase_realtime add table event_notes;

alter table event_notes enable row level security;

create policy "colaboradores podem ler notas"
  on event_notes for select to authenticated
  using (
    exists (
      select 1 from user_roles
      where user_id = auth.uid()
      and role in ('admin', 'colaborador')
    )
  );

create policy "colaboradores podem inserir notas"
  on event_notes for insert to authenticated
  with check (
    exists (
      select 1 from user_roles
      where user_id = auth.uid()
      and role in ('admin', 'colaborador')
    )
  );
