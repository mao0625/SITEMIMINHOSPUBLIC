-- Adicionar número de cliente auto-incrementado
CREATE SEQUENCE IF NOT EXISTS public.client_number_seq START 1000;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS client_number INTEGER UNIQUE DEFAULT nextval('public.client_number_seq');

-- Atualizar clientes existentes com número
UPDATE public.profiles
SET client_number = nextval('public.client_number_seq')
WHERE client_number IS NULL;

-- Adicionar número de referência aos questionários
CREATE SEQUENCE IF NOT EXISTS public.reference_number_seq START 1;

ALTER TABLE public.questionnaires
  ADD COLUMN IF NOT EXISTS reference_number TEXT UNIQUE;

-- Gerar referências para questionários existentes
UPDATE public.questionnaires
SET reference_number = 'ORC-' || LPAD(nextval('public.reference_number_seq')::TEXT, 5, '0')
WHERE reference_number IS NULL;

-- Função para gerar referência automaticamente em novos questionários
CREATE OR REPLACE FUNCTION public.generate_reference_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.reference_number IS NULL THEN
    NEW.reference_number := 'ORC-' || LPAD(nextval('public.reference_number_seq')::TEXT, 5, '0');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_questionnaire_reference ON public.questionnaires;
CREATE TRIGGER trg_questionnaire_reference
  BEFORE INSERT ON public.questionnaires
  FOR EACH ROW EXECUTE FUNCTION public.generate_reference_number();
