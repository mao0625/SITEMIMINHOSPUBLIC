CREATE POLICY "Staff manage phone mappings"
ON public.user_phone_mappings
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'colaborador'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'colaborador'::app_role));

CREATE POLICY "Users insert own phone mapping"
ON public.user_phone_mappings
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE UNIQUE INDEX IF NOT EXISTS user_phone_mappings_phone_key ON public.user_phone_mappings (phone);