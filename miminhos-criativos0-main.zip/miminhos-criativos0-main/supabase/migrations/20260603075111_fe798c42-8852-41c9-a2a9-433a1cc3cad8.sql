ALTER TABLE public.pos_operations
  ADD COLUMN IF NOT EXISTS payment_status text DEFAULT 'pago',
  ADD COLUMN IF NOT EXISTS mbway_number text;