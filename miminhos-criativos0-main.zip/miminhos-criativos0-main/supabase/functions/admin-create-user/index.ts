import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
 
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
 
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
 
  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supaUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
 
    const { data: { user } } = await supaUser.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
 
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
 
    // Verificar se quem chama é admin ou colaborador
    const { data: roles } = await admin.from("user_roles").select("role").eq("user_id", user.id);
    const callerRoles = (roles ?? []).map((r: any) => r.role);
    const isAdmin = callerRoles.includes("admin");
    const isStaff = isAdmin || callerRoles.includes("colaborador");
 
    if (!isStaff) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...cors, "Content-Type": "application/json" } });
 
    const { email, password, full_name, phone, role } = await req.json();
 
    if (!email || !password || !role) {
      return new Response(JSON.stringify({ error: "email, password, role required" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
    }
 
    if (!isAdmin && role !== "cliente") {
      return new Response(JSON.stringify({ error: "Apenas administradores podem criar colaboradores ou administradores" }), { status: 403, headers: { ...cors, "Content-Type": "application/json" } });
    }
 
    // Formata o telefone com +351 se não tiver prefixo
    const formattedPhone = phone
      ? phone.trim().startsWith("+")
        ? phone.trim()
        : `+351${phone.trim().replace(/\s/g, "")}`
      : undefined;
 
    // Cria o utilizador com email E telefone no auth
    const { data: created, error: cErr } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      phone: formattedPhone,        // ← associa o telefone ao auth
      phone_confirm: true,          // ← confirma sem precisar de SMS
      user_metadata: { full_name },
    });
 
    if (cErr) throw cErr;
 
    const newId = created.user!.id;
 
    await admin.from("profiles").upsert({
      id: newId,
      email,
      full_name,
      phone: formattedPhone,
      must_change_password: true,
    });
 
    await admin.from("user_roles").insert({ user_id: newId, role });

    // Cria mapeamento telefone → email para login por telefone (sem prefixo, só dígitos)
    if (phone) {
      const phoneDigits = phone.replace(/\D/g, "").replace(/^351/, "");
      if (/^\d{9,}$/.test(phoneDigits)) {
        await admin.from("user_phone_mappings").upsert(
          { user_id: newId, phone: phoneDigits, email },
          { onConflict: "phone" }
        );
      }
    }
 
    return new Response(JSON.stringify({ ok: true, user_id: newId }), {
      headers: { ...cors, "Content-Type": "application/json" },
    });
 
  } catch (e) {
    return new Response(JSON.stringify({ error: String((e as Error).message) }), {
      status: 500,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
 
