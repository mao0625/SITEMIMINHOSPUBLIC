import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const genPwd = () => {
  const buf = new Uint8Array(12);
  crypto.getRandomValues(buf);
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  return Array.from(buf, (b) => chars[b % chars.length]).join("") + "!2";
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supaUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: { user } } = await supaUser.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401, headers: { ...cors, "Content-Type": "application/json" }
    });

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Verificar role do caller
    const { data: callerRoles } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id);

    const callerRole = (callerRoles ?? []).find((r: any) =>
      r.role === "admin" || r.role === "colaborador"
    )?.role;

    if (!callerRole) return new Response(JSON.stringify({ error: "Forbidden" }), {
      status: 403, headers: { ...cors, "Content-Type": "application/json" }
    });

    const { user_id, password } = await req.json();
    if (!user_id) return new Response(JSON.stringify({ error: "user_id required" }), {
      status: 400, headers: { ...cors, "Content-Type": "application/json" }
    });

    // Impedir reset da própria conta
    if (user_id === user.id) return new Response(JSON.stringify({ error: "Não pode resetar a sua própria password por aqui" }), {
      status: 403, headers: { ...cors, "Content-Type": "application/json" }
    });

    // Verificar role do utilizador ALVO
    const { data: targetRoles } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", user_id);

    const targetRole = (targetRoles ?? []).find((r: any) =>
      r.role === "admin" || r.role === "colaborador"
    )?.role;

    // Colaborador NÃO pode resetar admin nem outro colaborador
    if (callerRole === "colaborador" && targetRole && ["admin", "colaborador"].includes(targetRole)) {
      return new Response(JSON.stringify({ error: "Colaboradores não podem resetar passwords de admins ou colaboradores" }), {
        status: 403, headers: { ...cors, "Content-Type": "application/json" }
      });
    }

    const newPwd = password || genPwd();
    const { error } = await admin.auth.admin.updateUserById(user_id, { password: newPwd });
    if (error) throw error;

    await admin.from("profiles").update({ must_change_password: true }).eq("id", user_id);

    return new Response(JSON.stringify({ ok: true, password: newPwd }), {
      headers: { ...cors, "Content-Type": "application/json" }
    });

  } catch (e) {
    return new Response(JSON.stringify({ error: String((e as Error).message) }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" }
    });
  }
});
