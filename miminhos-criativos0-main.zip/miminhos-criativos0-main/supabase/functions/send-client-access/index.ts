import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const genPassword = () => {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  const buf = new Uint8Array(12);
  crypto.getRandomValues(buf);
  return Array.from(buf, (b) => chars[b % chars.length]).join("") + "!2";
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  try {
    // Require authenticated staff caller
    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
    }
    const supaUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: { user } } = await supaUser.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: callerRoles } = await admin.from("user_roles").select("role").eq("user_id", user.id);
    const isStaff = (callerRoles ?? []).some((r: any) => r.role === "admin" || r.role === "colaborador");
    if (!isStaff) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...cors, "Content-Type": "application/json" } });

    const { name, email, phone, event_type } = await req.json();
    if (!email) return new Response(JSON.stringify({ error: "email obrigatório" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });

    // Verifica se utilizador já existe
    const { data: existing } = await admin.auth.admin.listUsers();
    let user2 = existing?.users?.find((u: any) => u.email?.toLowerCase() === email.toLowerCase());
    let tempPassword: string | null = null;

    if (!user2) {
      tempPassword = genPassword();
      const { data: created, error: cErr } = await admin.auth.admin.createUser({
        email,
        password: tempPassword,
        email_confirm: true,
        user_metadata: { full_name: name },
      });
      if (cErr) throw cErr;
      user2 = created.user!;
      await admin.from("profiles").upsert({ id: user2.id, email, full_name: name, phone, must_change_password: true });
      await admin.from("user_roles").insert({ user_id: user2.id, role: "cliente" });
    }

    // SITE_URL fixo (não confiar no Origin do cliente)
    const SITE_URL = Deno.env.get("SITE_URL") ?? "https://miminhos-criativos0.lovable.app";

    // Tenta enviar email via fila Lovable (se infra existir)
    let emailQueued = false;
    try {
      const subject = "Acesso à sua Área de Cliente — Miminhos Criativos";
      const loginUrl = `${SITE_URL}/cliente/login`;
      const html = `
        <div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#2b2b2b">
          <h2 style="color:#b8862c;font-family:Georgia,serif">Bem-vindo(a) à Miminhos Criativos 💛</h2>
          <p>Olá ${name ?? ""},</p>
          <p>Recebemos o seu pedido de orçamento para <strong>${event_type ?? "o seu evento"}</strong>. Criámos uma Área de Cliente onde poderá preencher o questionário detalhado, trocar mensagens connosco e acompanhar todo o processo.</p>
          <div style="background:#faf6ec;border:1px solid #e8d9a8;padding:16px;border-radius:8px;margin:16px 0">
            <p style="margin:0 0 8px 0"><strong>Email:</strong> ${email}</p>
            ${tempPassword ? `<p style="margin:0"><strong>Password temporária:</strong> ${tempPassword}</p>` : `<p style="margin:0">Já tem conta connosco — utilize a sua password.</p>`}
          </div>
          <p><a href="${loginUrl}" style="background:#b8862c;color:#fff;padding:12px 22px;text-decoration:none;border-radius:6px;display:inline-block">Aceder à Área de Cliente</a></p>
          <p style="font-size:12px;color:#666">Por segurança, ser-lhe-á pedido para alterar a password no primeiro acesso.</p>
          <p style="margin-top:24px;font-style:italic;color:#b8862c">A festa é sua! O prazer em criar é nosso!</p>
        </div>`;
      const { error: qErr } = await admin.rpc("enqueue_email", {
        queue_name: "transactional_emails",
        payload: { to: email, subject, html, purpose: "transactional", template_name: "client_access" },
      });
      if (!qErr) emailQueued = true;
    } catch (_) { /* sem infra de email — silencioso */ }

    return new Response(JSON.stringify({ ok: true, email_sent: emailQueued, temp_password: tempPassword }), {
      headers: { ...cors, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String((e as Error).message) }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
